"""MOTIF HyperFrames 부품 키트 (2026-11-25 제미나이 개선판 + 신규 8종 · 글자 블러는 5px 이하, 글자 확대 없음 — 마틴 기준)
릴스 한 편 = spec(dict) 하나. 부품 이름과 글자·시간만 적으면 index.html을 만들고 렌더링한다.
사용: python3 hfkit.py spec.py out.mp4 [--overlay]   (spec.py 안에 SPEC = {...})
      --overlay : 배경 투명 PNG 시퀀스(플로우 영상 위에 겹칠 때)
부품 목록과 인자는 PARTS.md 참고.
"""
import json, os, re, sys, shutil, subprocess, html as H
KIT = os.path.dirname(os.path.abspath(__file__))
W, HH = 1080, 1920
E = H.escape

# ───────── 공통 CSS (Apple/Swiss Editorial 위계 · 자간 · 다중 그림자) ─────────
CSS = r"""
@font-face{font-family:KR;font-weight:400;src:url(assets/fonts/kr-regular.woff2) format("woff2")}
@font-face{font-family:KR;font-weight:700;src:url(assets/fonts/kr-bold.woff2) format("woff2")}
@font-face{font-family:KR;font-weight:900;src:url(assets/fonts/kr-black.woff2) format("woff2")}
@font-face{font-family:ST;src:url(assets/fonts/stylish.woff2) format("woff2")}
@font-face{font-family:PP;font-weight:500;src:url(assets/fonts/pp-medium.woff2) format("woff2")}
@font-face{font-family:PP;font-weight:700;src:url(assets/fonts/pp-bold.woff2) format("woff2")}
@font-face{font-family:TWK;src:url(assets/fonts/tw-ko.woff2) format("woff2")}
@font-face{font-family:TWE;src:url(assets/fonts/tw-en.woff2) format("woff2")}
*{margin:0;padding:0;box-sizing:border-box}
html,body{width:1080px;height:1920px;overflow:hidden;background:var(--bg);-webkit-font-smoothing:antialiased}
:root{
  --bg:#f4f6fa;--ink:#14161c;--body:#2a2e39;--gry:#727785;--lgt:#c5cad6;--trk:#edf0f6;
  --b1:#245cff;--b2:#7c4dff;--b3:#e84c93;--n1:#ec5c42;--n2:#fa963c;
  --paper:#fcfaf5;--tw:#262422;--twb:#2240aa;--twr:#962834
}
#root{position:relative;width:1080px;height:1920px;font-family:KR,PP,sans-serif;color:var(--ink);letter-spacing:-.032em;word-break:keep-all}
.clip{position:absolute;z-index:2}
.hdr,.lgo{z-index:5}
.scard{z-index:1}
.card{
  position:absolute;background:#fff;border-radius:38px;
  border:1px solid rgba(20,22,28,.055);
  box-shadow:0 2px 6px rgba(20,25,40,.03),0 18px 44px rgba(25,35,65,.075),0 36px 80px rgba(25,35,65,.05)
}
.card.ghost{background:transparent!important;border-color:transparent!important;box-shadow:none!important}
.paper{background:var(--paper);border-radius:26px}
.g-b{background:linear-gradient(95deg,var(--b1),var(--b2))}
.g-p{background:linear-gradient(95deg,var(--b2),var(--b3))}
.g-n{background:linear-gradient(95deg,var(--n1),var(--n2))}
.g-bp{background:linear-gradient(95deg,var(--b1) 0%,var(--b2) 55%,var(--b3) 100%)}
.gt{-webkit-background-clip:text;background-clip:text;color:transparent}
.tnum,.n{font-family:PP,KR,sans-serif;font-variant-numeric:tabular-nums;font-feature-settings:"tnum" 1;letter-spacing:-.03em}
.tag{font-family:PP,KR,sans-serif;font-weight:700;font-size:22px;color:var(--gry);letter-spacing:.14em;text-transform:uppercase}
.tagline{display:inline-block;width:54px;height:2.5px;background:var(--b1);vertical-align:middle;margin-left:14px;transform-origin:left;border-radius:2px}
.cap{left:72px;width:936px;font-weight:900;line-height:1.30;letter-spacing:-.038em}
.cap .row{display:block;white-space:nowrap;margin-bottom:4px}
.cap .row.sub{font-weight:700;font-size:.80em;line-height:1.36;letter-spacing:-.025em;color:var(--gry)}
.cap .cw{display:inline-block;will-change:transform,opacity,filter}
.k{position:relative;display:inline-block;padding:0 2px}
.k .band{position:absolute;left:-6px;right:-6px;top:56%;bottom:2%;border-radius:8px;transform-origin:left;z-index:0}
.k em{position:relative;z-index:1;font-style:normal;font-weight:900}
.band.b{background:rgba(36,92,255,.13)}.band.p{background:rgba(124,77,255,.14)}.band.n{background:rgba(236,92,66,.14)}.band.bp{background:rgba(124,77,255,.13)}
.gry{color:var(--gry);font-weight:700}
.bgw{font-family:PP,KR,sans-serif;font-weight:700;font-size:290px;letter-spacing:-.02em;color:rgba(34,56,110,.046);white-space:nowrap;top:1345px;left:560px;z-index:0;pointer-events:none}
.tw{font-family:TWE,TWK,serif;color:var(--tw);letter-spacing:0}
.twk{font-family:TWK,TWE,serif;letter-spacing:0}
.cursor{display:inline-block;width:.5em;height:.9em;background:var(--twb);vertical-align:-.1em;margin-left:6px;opacity:.85}
.ink{filter:url(#ink)}
"""
SVG_DEFS = """<svg width="0" height="0" style="position:absolute"><filter id="ink"><feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" seed="3"/><feColorMatrix values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 -1.0 1.4"/><feComposite in="SourceGraphic" operator="in"/><feGaussianBlur stdDeviation="0.35"/></filter></svg>"""

CAPTION_PRO_CSS = r"""
#stage{position:absolute;inset:0;transform-origin:540px 720px;will-change:transform,filter}
.cap .cmask{display:inline-block;overflow:hidden;vertical-align:bottom;padding:12px 10px;margin:-12px -10px}
.cap .cw{display:inline-block;will-change:transform,opacity,filter}
.k{position:relative;display:inline-block;padding:0 6px}
.k .band{position:absolute;left:-4px;right:-4px;top:14%;bottom:6%;border-radius:10px;transform-origin:left center;z-index:0}
.k .pin{position:absolute;top:8%;bottom:2%;width:3.5px;border-radius:2px;z-index:2;pointer-events:none}
.k .pin.l{left:-5px;background:var(--b1)}
.k .pin.r{left:0%;background:var(--b2)}
.k .pin::after{content:"";position:absolute;left:-4.25px;width:12px;height:12px;border-radius:50%;background:inherit}
.k .pin.l::after{top:-7px}
.k .pin.r::after{bottom:-7px}
"""

MORPH_PARTS = {
    "titlecard", "checklist", "hbars", "xyline", "counter", "ring", "slot",
    "skeleton", "progress", "splitline", "ladder", "focusword", "crossscan", "metricpair"
}

class B:
    """html·js 조각을 모은다"""
    def __init__(s): s.h = []; s.j = []; s.n = 0
    def id(s, p="e"): s.n += 1; return f"{p}{s.n}"
    def clip(s, t, d, inner, style="", cls=""):
        i = s.id("c"); s.h.append(f'<div id="{i}" class="clip {cls}" data-start="{t:.3f}" data-duration="{d:.3f}" data-track-index="{s.n}" style="{style}">{inner}</div>'); return i
    def js(s, code): s.j.append(code)

def gtext(txt, g="b", tag="span", cls=""):
    if g in (None, "k", "ink"): return f'<{tag} class="{cls}" style="color:var(--ink)">{E(txt)}</{tag}>'
    if g == "g": return f'<{tag} class="gry {cls}">{E(txt)}</{tag}>'
    gc = "b" if g == "n" else g
    return f'<{tag} class="gt g-{gc} {cls}">{E(txt)}</{tag}>'

def popin(b, sel, t, d=0.66, y=38, float_=True, out=None, ghost=False):
    if ghost:
        b.js(f'tl.fromTo("{sel}",{{opacity:0,y:16,filter:"blur(6px)"}},{{opacity:1,y:0,filter:"blur(0px)",duration:.48,ease:"expo.out"}},{t + .06:.3f});')
        if out is not None:
            b.js(f'tl.to("{sel}",{{opacity:0,y:-12,filter:"blur(4px)",duration:.22,ease:"power2.in"}},{out - .24:.3f});')
        return
    b.js(f'tl.fromTo("{sel}",{{opacity:0,y:{y},scale:.985}},{{opacity:1,y:0,scale:1,duration:{d},ease:"expo.out"}},{t:.3f});')
    if float_:
        b.js(f'tl.to("{sel}",{{y:-5,duration:2.8,ease:"sine.inOut",yoyo:true,repeat:5}},{t + d:.3f});')
    if out is not None:
        b.js(f'tl.to("{sel}",{{opacity:0,y:-16,scale:.99,duration:.28,ease:"power2.in"}},{out - .30:.3f});')

def sharedcard(b, t, d, chain):
    x0, y0, w0, h0 = chain[0]["box"]
    i = b.clip(t, d, "", f"left:0;top:0;width:{w0}px;height:{h0}px", "card scard")
    b.js(f'tl.fromTo("#{i}",{{opacity:0,x:{x0},y:{y0 + 36},width:{w0},height:{h0},scale:.985}},{{opacity:1,x:{x0},y:{y0},width:{w0},height:{h0},scale:1,duration:.68,ease:"expo.out"}},{t:.3f});')
    for nxt in chain[1:]:
        xn, yn, wn, hn = nxt["box"]
        tm = max(t + .32, nxt["t"] - .16)
        b.js(f'tl.to("#{i}",{{x:{xn},y:{yn},width:{wn},height:{hn},duration:.62,ease:"power3.inOut"}},{tm:.3f});')
    xl, yl, _, _ = chain[-1]["box"]
    b.js(f'tl.to("#{i}",{{opacity:0,y:{yl - 18},scale:.99,duration:.30,ease:"power2.in"}},{t + d - .32:.3f});')

# ───────── 기본 부품 ─────────
def header(b, t, d, title, left="MOTIF", right="SOLAR GARD LX"):
    i = b.clip(t, d,
               f'<div class="hb" style="position:absolute;left:72px;top:92px;width:6px;height:42px;border-radius:3px;background:var(--b1);transform-origin:top"></div>'
               f'<div class="ht" style="position:absolute;left:94px;top:88px;font-weight:700;font-size:36px;letter-spacing:-.03em;color:var(--ink)">{E(title)}</div>'
               f'<div class="hl" style="position:absolute;left:74px;top:156px;font-family:PP,KR,sans-serif;font-weight:700;font-size:19px;letter-spacing:.22em;color:#3c404c">{E(left)}</div>'
               f'<div class="hr" style="position:absolute;right:72px;top:156px;font-family:PP,KR,sans-serif;font-weight:500;font-size:19px;letter-spacing:.18em;color:var(--gry)">{E(right)}</div>',
               "left:0;top:0;width:1080px;height:210px", "hdr")
    b.js(f'tl.fromTo("#{i} .hb",{{scaleY:0,opacity:0}},{{scaleY:1,opacity:1,duration:.5,ease:"expo.out"}},{t + .06:.3f});'
         f'tl.fromTo("#{i} .ht",{{opacity:0,y:14,filter:"blur(6px)"}},{{opacity:1,y:0,filter:"blur(0px)",duration:.55,ease:"expo.out"}},{t + .13:.3f});'
         f'tl.fromTo(["#{i} .hl","#{i} .hr"],{{opacity:0,y:8}},{{opacity:1,y:0,duration:.5,stagger:.06,ease:"power2.out"}},{t + .22:.3f});'
         f'tl.to("#{i}",{{opacity:0,duration:.35,ease:"power2.in"}},{t + d - .36:.3f});')

def logo(b, t, d, name="motif", w=150, y=1780):
    src = {"motif": "motif_logo_dark.png", "motif_w": "motif_logo_light.png", "lxsg": "lxsg_ink_dark.png", "lxsg_w": "lxsg_ink_light.png", "thelx": "thelx_ink_dark.png"}[name]
    i = b.clip(t, d, f'<img src="assets/{src}" style="width:{w}px;display:block">', f"left:{540 - w / 2}px;top:{y}px;transform:translateY(-50%)", "lgo")
    b.js(f'tl.fromTo("#{i}",{{opacity:0}},{{opacity:.92,duration:.6,ease:"power2.out"}},{t + .26:.3f});'
         f'tl.to("#{i}",{{opacity:0,duration:.35,ease:"power2.in"}},{t + d - .36:.3f});')

def bgword(b, t, d, word):
    i = b.clip(t, d, f'<div class="w">{E(word)}</div>', "", "bgw")
    b.js(f'tl.fromTo("#{i} .w",{{opacity:0,x:48}},{{opacity:1,x:0,duration:.85,ease:"power2.out"}},{t:.3f});'
         f'tl.to("#{i} .w",{{x:-38*{d:.2f},duration:{d:.2f},ease:"none"}},{t:.3f});'
         f'tl.to("#{i}",{{opacity:0,duration:.3}},{t + d - .32:.3f});')

def caption(b, t, d, rows, y=1020, size=58):
    out = []
    for r in rows:
        all_sub = bool(r) and all(st == "g" for _, st in r)
        tokens = []
        for tx, st in r:
            glue = tx.startswith("~"); tx = tx.lstrip("~")
            if st in ("b", "p", "n", "bp"):
                hp = (f'<span class="k"><i class="band {st}"></i>'
                      f'<i class="pin l"></i><i class="pin r"></i>'
                      f'<em class="gt g-{st}">{E(tx)}</em></span>')
                if glue and tokens: tokens[-1] += hp
                else: tokens.append(hp)
            else:
                fmt = (lambda w: E(w)) if all_sub else ((lambda w: f'<span class="gry">{E(w)}</span>') if st == "g" else (lambda w: E(w)))
                for idx, w in enumerate(tx.split(" ")):
                    if not w: continue
                    if idx == 0 and glue and tokens: tokens[-1] += fmt(w)
                    else: tokens.append(fmt(w))
        rc = "row sub" if all_sub else "row"
        out.append(f'<span class="{rc}">' + " ".join(f'<span class="cmask"><span class="cw">{tk}</span></span>' for tk in tokens) + "</span>")
    i = b.clip(t, d, "".join(out), f"top:{y}px;font-size:{size}px", "cap")
    b.js(f'tl.fromTo("#{i} .cw",{{opacity:0,yPercent:110,filter:"blur(4px)"}},{{opacity:1,yPercent:0,filter:"blur(0px)",duration:.54,ease:"expo.out",stagger:.058}},{t:.3f});'
         f'tl.fromTo("#{i} .band",{{scaleX:0}},{{scaleX:1,duration:.54,ease:"expo.out",stagger:.09}},{t + .16:.3f});'
         f'tl.fromTo("#{i} .pin.l",{{opacity:0,scaleY:0}},{{opacity:1,scaleY:1,duration:.24,ease:"expo.out"}},{t + .14:.3f});'
         f'tl.fromTo("#{i} .pin.r",{{opacity:0,left:"0%"}},{{opacity:1,left:"100%",duration:.54,ease:"expo.out"}},{t + .16:.3f});'
         f'tl.to("#{i} .pin",{{opacity:0,duration:.26,ease:"power2.in"}},{t + .82:.3f});'
         f'tl.to("#{i}",{{opacity:0,y:-12,filter:"blur(4px)",duration:.22,ease:"power2.in"}},{t + d - .24:.3f});')


def kinetic(b, t, d, words, y=700, size=120, g="bp"):
    inner = "".join(f'<span class="wd" style="display:inline-block;margin-right:.24em">{gtext(w, s) if s else E(w)}</span>' for w, s in words)
    i = b.clip(t, d, inner, f"left:72px;top:{y}px;width:936px;font-weight:900;font-size:{size}px;line-height:1.18;letter-spacing:-.04em")
    b.js(f'tl.fromTo("#{i} .wd",{{opacity:0,y:54,scale:1.18,filter:"blur(8px)"}},{{opacity:1,y:0,scale:1,filter:"blur(0px)",duration:.46,ease:"back.out(1.7)",stagger:.14}},{t:.3f});'
         f'tl.to("#{i}",{{opacity:0,duration:.25}},{t + d - .27:.3f});')

def titlecard(b, t, d, box, tag, lines, size=76, paper=False, _ghost=False):
    x, y, w, h = box
    ln = "".join(f'<div class="ln" style="font-size:{size}px;font-weight:900;line-height:1.16;letter-spacing:-.04em">{gtext(s, g) if g else E(s)}</div>' for s, g in lines)
    cls = "paper" if paper else ("ghost" if _ghost else "")
    i = b.clip(t, d, f'<div class="card {cls}" style="left:0;top:0;width:{w}px;height:{h}px;padding:44px 52px;display:flex;flex-direction:column;justify-content:center"><div class="tag">{E(tag)}<span class="tagline"></span></div><div style="margin-top:18px">{ln}</div></div>', f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, ghost=_ghost and not paper)
    b.js(f'tl.fromTo("#{i} .tagline",{{scaleX:0}},{{scaleX:1,duration:.6,ease:"expo.out"}},{t + .16:.3f});'
         f'tl.fromTo("#{i} .ln",{{opacity:0,y:22,filter:"blur(6px)"}},{{opacity:1,y:0,filter:"blur(0px)",duration:.5,ease:"expo.out",stagger:.11}},{t + .18:.3f});')

def strike(b, t, d, box, text, at, to=None, to_g="bp", size=50):
    x, y, w, h = box
    if to and y + 2 * h + 56 > 960: h = max(170, int((960 - y - 56) / 2))
    inner = (f'<div class="card c0" style="left:24px;top:0;width:{w - 48}px;height:{h}px;display:flex;align-items:center;justify-content:center">'
             f'<span style="position:relative;font-weight:700;font-size:{size - 2}px;color:var(--gry)">{E(text)}'
             f'<i class="st" style="position:absolute;left:-16px;right:-16px;top:52%;height:5px;background:linear-gradient(90deg,var(--b2),var(--b3));border-radius:3px;transform-origin:left"></i></span></div>')
    if to:
        inner += (f'<div class="card nw" style="left:0;top:{h + 34}px;width:{w}px;height:{h + 24}px;display:flex;flex-direction:column;align-items:center;justify-content:center">'
                  f'<span class="tag" style="color:var(--b1);margin-bottom:10px;font-size:20px">FOCUS</span>'
                  f'<span style="font-size:{size + 10}px;font-weight:900;letter-spacing:-.04em">{gtext(to, to_g)}</span></div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{2 * h + 70}px")
    popin(b, f"#{i} .c0", t, out=t + d, float_=False)
    b.js(f'tl.fromTo("#{i} .st",{{scaleX:0}},{{scaleX:1,duration:.48,ease:"expo.out"}},{at:.3f});'
         f'tl.to("#{i} .c0",{{scale:.96,opacity:.58,duration:.5,ease:"power2.out"}},{at + .15:.3f});')
    if to:
        popin(b, f"#{i} .nw", at + .26, out=t + d, float_=True)

def checklist(b, t, d, box, title, items, _ghost=False):
    x, y, w, h = box
    rh = min(84, max(62, int((h - 176) / max(1, len(items)))))
    rows = "".join(
        f'<div class="ci{k}" style="display:flex;align-items:center;justify-content:space-between;height:{rh}px;border-bottom:{1 if k < len(items) - 1 else 0}px solid #eef0f6">'
        f'<div style="display:flex;align-items:center;gap:22px">'
        f'<span class="cb" style="position:relative;width:42px;height:42px;border-radius:50%;border:2.5px solid #d7dce8;flex:none">'
        f'<svg viewBox="0 0 42 42" style="position:absolute;left:-2.5px;top:-2.5px;width:42px;height:42px">'
        f'<circle class="cf" cx="21" cy="21" r="21" fill="#245cff"/>'
        f'<path class="ck" d="M12 21.5 L18.5 28 L30.5 15" stroke="#fff" stroke-width="4.2" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="36" stroke-dashoffset="36"/></svg></span>'
        f'<span class="cl" style="font-weight:700;font-size:34px;color:#9aa0ae">{E(n)}</span></div>'
        f'<span class="cp" style="opacity:0;font-size:21px;font-weight:700;color:var(--b1);background:rgba(36,92,255,.09);padding:6px 16px;border-radius:99px">기본</span></div>'
        for k, (n, _) in enumerate(items))
    i = b.clip(t, d,
               f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px;padding:42px 54px">'
               f'<div class="tag" style="color:var(--b1)">INCLUDED</div>'
               f'<div style="font-weight:900;font-size:42px;margin:6px 0 18px;letter-spacing:-.04em">{E(title)}</div>{rows}</div>',
               f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, float_=False, ghost=_ghost)
    for k, (_, tk) in enumerate(items):
        sel = f"#{i} .ci{k}"
        b.js(f'tl.fromTo("{sel} .cf",{{scale:0,transformOrigin:"50% 50%"}},{{scale:1,duration:.38,ease:"expo.out"}},{tk:.3f});'
             f'tl.to("{sel} .ck",{{strokeDashoffset:0,duration:.36,ease:"power2.out"}},{tk + .10:.3f});'
             f'tl.fromTo("{sel} .cl",{{x:6,color:"#9aa0ae"}},{{x:0,color:"#14161c",duration:.38,ease:"expo.out"}},{tk:.3f});'
             f'tl.fromTo("{sel} .cp",{{opacity:0,x:8}},{{opacity:1,x:0,duration:.38,ease:"expo.out"}},{tk + .12:.3f});')

def hbars(b, t, d, box, title, rows, vmax, unit="", ticks=(), gcls=("b", "b", "bp"), _ghost=False):
    x, y, w, h = box; bw = w - 108
    rh = min(132, max(96, int((h - 158) / max(1, len(rows)))))
    rs = "".join(
        f'<div class="hr{k}" style="position:relative;height:{rh}px;display:flex;flex-direction:column;justify-content:center">'
        f'<div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:14px">'
        f'<span style="font-weight:700;font-size:30px;color:var(--ink)">{E(l)}</span>'
        f'<span class="vl" style="font-weight:900;font-size:40px"><span class="n gt g-{gcls[min(k, len(gcls) - 1)]}">0</span>'
        f'<span style="font-size:24px;font-weight:700;color:var(--gry);margin-left:4px">{E(unit)}</span></span></div>'
        f'<div style="position:relative;width:100%;height:24px;border-radius:12px;background:var(--trk);overflow:hidden">'
        f'<div class="bar g-{gcls[min(k, len(gcls) - 1)]}" style="height:100%;width:0%;border-radius:12px"></div></div></div>'
        for k, (l, v, _) in enumerate(rows))
    tk = "".join(f'<div style="position:absolute;left:{54 + bw * v / vmax:.0f}px;bottom:30px;font-family:PP,KR,sans-serif;font-size:20px;font-weight:500;color:#9aa0ae;transform:translateX(-50%)">{v}</div>' for v in ticks)
    i = b.clip(t, d,
               f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px;padding:42px 54px">'
               f'<div class="tag" style="color:var(--b1)">COMPARISON</div>'
               f'<div style="font-weight:900;font-size:38px;margin:4px 0 14px;letter-spacing:-.038em">{E(title)}</div>'
               f'<div>{rs}</div>{tk}</div>',
               f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, float_=False, ghost=_ghost)
    for k, (_, v, tk_) in enumerate(rows):
        pct = min(100.0, 100.0 * v / vmax)
        sel = f"#{i} .hr{k}"
        b.js(f'tl.fromTo("{sel}",{{opacity:.25,y:10}},{{opacity:1,y:0,duration:.45,ease:"expo.out"}},{tk_ - .08:.3f});'
             f'tl.to("{sel} .bar",{{width:"{pct:.1f}%",duration:1.25,ease:"expo.out"}},{tk_:.3f});'
             f'(function(){{const o={{v:0}};const el=document.querySelector("{sel} .n");tl.to(o,{{v:{v},duration:1.25,ease:"expo.out",onUpdate:()=>el.textContent=Math.round(o.v)}},{tk_:.3f});}})();')

def xyline(b, t, d, box, title, pts, vmax, at, dur=2.3, thr=None, thr_label="", caption_="", over_label="", _ghost=False):
    x, y, w, h = box; X0, X1, Y0, Y1 = 82, w - 58, h - 106, 128
    n = len(pts); P = [(X0 + 26 + (X1 - X0 - 52) * k / max(1, n - 1), Y0 - (Y0 - Y1) * v / vmax) for k, (_, v) in enumerate(pts)]
    line_d = "M%.1f %.1f " % P[0] + " ".join("L%.1f %.1f" % p for p in P[1:])
    area_d = line_d + f" L{P[-1][0]:.1f} {Y0} L{P[0][0]:.1f} {Y0} Z"
    L = sum(((P[k][0] - P[k - 1][0]) ** 2 + (P[k][1] - P[k - 1][1]) ** 2) ** .5 for k in range(1, n)) + 40
    gid = b.id("xa")
    grids = "".join(f'<line x1="{X0}" y1="{Y1 + (Y0 - Y1) * g / 3:.0f}" x2="{X1}" y2="{Y1 + (Y0 - Y1) * g / 3:.0f}" stroke="#eef0f6" stroke-width="2"/>' for g in range(3))
    dots = "".join(f'<circle class="dt{k}" cx="{p[0]:.1f}" cy="{p[1]:.1f}" r="9" fill="{"#7c4dff" if thr is not None and pts[k][1] > thr else "#245cff"}" stroke="#fff" stroke-width="3.5"/>' for k, p in enumerate(P))
    xl = "".join(f'<text x="{p[0]:.1f}" y="{Y0 + 38}" font-size="22" font-weight="700" fill="#727785" text-anchor="middle" font-family="KR">{E(pts[k][0])}</text>' for k, p in enumerate(P))
    th = ""
    if thr is not None:
        ty = Y0 - (Y0 - Y1) * thr / vmax
        th = f'<line class="th" x1="{X0}" y1="{ty:.1f}" x2="{X1}" y2="{ty:.1f}" stroke="#7c4dff" stroke-opacity=".55" stroke-width="2.5" stroke-dasharray="10 10"/><text class="thl" x="{X1}" y="{ty - 14:.1f}" font-size="22" font-weight="700" fill="#7c4dff" text-anchor="end" font-family="KR">{E(thr_label)}</text>'
    svg = (f'<svg width="{w}" height="{h}" style="position:absolute;left:0;top:0">'
           f'<defs><linearGradient id="{gid}" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#245cff" stop-opacity=".16"/><stop offset="100%" stop-color="#245cff" stop-opacity="0"/></linearGradient></defs>'
           f'{grids}<path d="M{X0} {Y1 - 16} L{X0} {Y0} L{X1} {Y0}" stroke="#d5d9e4" stroke-width="2.5" fill="none"/>'
           f'<path class="ar" d="{area_d}" fill="url(#{gid})" opacity="0"/>{th}'
           f'<path class="ln" d="{line_d}" stroke="#245cff" stroke-width="7" fill="none" stroke-linejoin="round" stroke-linecap="round" stroke-dasharray="{L:.0f}" stroke-dashoffset="{L:.0f}"/>'
           f'{dots}{xl}</svg>')
    ol = f'<div class="ov" style="position:absolute;right:56px;top:{max(88, P[-1][1] - 62):.0f}px;padding:6px 18px;border-radius:99px;background:rgba(124,77,255,.11);font-weight:700;font-size:23px;color:var(--b2)">{E(over_label)}</div>' if over_label else ""
    cap = f'<div style="position:absolute;right:56px;bottom:20px;font-size:20px;color:#9aa0ae">{E(caption_)}</div>' if caption_ else ""
    i = b.clip(t, d,
               f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px">'
               f'<div style="position:absolute;left:54px;top:38px;font-weight:900;font-size:34px;letter-spacing:-.035em">{E(title)}</div>'
               f'{svg}{ol}{cap}</div>',
               f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, float_=False, ghost=_ghost)
    if thr is not None: b.js(f'tl.fromTo("#{i} .th,#{i} .thl",{{opacity:0}},{{opacity:1,duration:.5}},{max(t + .1, at - .2):.3f});')
    b.js(f'tl.to("#{i} .ln",{{strokeDashoffset:0,duration:{dur},ease:"power2.inOut"}},{at:.3f});'
         f'tl.to("#{i} .ar",{{opacity:1,duration:.8,ease:"power2.out"}},{at + dur * .45:.3f});')
    for k in range(n):
        b.js(f'tl.fromTo("#{i} .dt{k}",{{scale:0,transformOrigin:"50% 50%",transformBox:"fill-box"}},{{scale:1,duration:.35,ease:"expo.out"}},{at + dur * k / max(1, n - 1):.3f});')
    if over_label: b.js(f'tl.fromTo("#{i} .ov",{{opacity:0,y:10}},{{opacity:1,y:0,duration:.45,ease:"expo.out"}},{at + dur - .25:.3f});')

def counter(b, t, d, box, label, v0, v1, unit="", g="b", at=None, bar=None, size=190, caption_="", _ghost=False):
    x, y, w, h = box; at = t + .32 if at is None else at
    br = f'<div style="position:absolute;left:64px;right:64px;bottom:68px;height:22px;border-radius:11px;background:var(--trk);overflow:hidden"><div class="br g-{g}" style="height:100%;width:0%;border-radius:11px"></div></div>' if bar else ""
    i = b.clip(t, d,
               f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px;text-align:center;padding-top:52px">'
               f'<div class="tag">{E(label)}</div>'
               f'<div style="font-weight:900;font-size:{size}px;line-height:1.12;margin-top:10px"><span class="gt g-{g} n">{v0}</span>'
               f'<span class="gt g-{g}" style="font-size:{size * .42:.0f}px;margin-left:6px">{E(unit)}</span></div>'
               f'<div style="font-size:26px;font-weight:700;color:var(--gry);margin-top:8px">{E(caption_)}</div>{br}</div>',
               f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, ghost=_ghost)
    dec = 0 if float(v1).is_integer() else 1
    b.js(f'(function(){{const o={{v:{v0}}};const el=document.querySelector("#{i} .n");tl.to(o,{{v:{v1},duration:1.35,ease:"expo.out",onUpdate:()=>el.textContent=o.v.toFixed({dec})}},{at:.3f});}})();')
    if bar: b.js(f'tl.to("#{i} .br",{{width:"{min(100.0, 100.0 * v1 / bar):.1f}%",duration:1.35,ease:"expo.out"}},{at:.3f});')

def ring(b, t, d, box, label, pct, at=None, g=("#245cff", "#7c4dff"), sub="", _ghost=False):
    x, y, w, h = box; at = t + .32 if at is None else at; R = min(w, h) * .32; C = 2 * 3.14159 * R
    gid = b.id("rg")
    svg = f'<svg width="{w}" height="{h}" style="position:absolute;left:0;top:0"><defs><linearGradient id="{gid}"><stop offset="0" stop-color="{g[0]}"/><stop offset="1" stop-color="{g[1]}"/></linearGradient></defs><circle cx="{w / 2}" cy="{h / 2 + 20}" r="{R:.0f}" stroke="#edf0f6" stroke-width="32" fill="none"/><circle class="rr" cx="{w / 2}" cy="{h / 2 + 20}" r="{R:.0f}" stroke="url(#{gid})" stroke-width="32" fill="none" stroke-linecap="round" stroke-dasharray="{C:.0f}" stroke-dashoffset="{C:.0f}" transform="rotate(-90 {w / 2} {h / 2 + 20})"/></svg>'
    i = b.clip(t, d, f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px">{svg}<div class="tag" style="position:absolute;top:40px;width:100%;text-align:center">{E(label)}</div><div style="position:absolute;top:{h / 2 - 48}px;width:100%;text-align:center;font-weight:900;font-size:98px"><span class="n gt g-b">0</span><span class="gt g-b" style="font-size:48px">%</span></div><div style="position:absolute;top:{h / 2 + 62}px;width:100%;text-align:center;font-size:25px;font-weight:700;color:var(--gry)">{E(sub)}</div></div>', f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, ghost=_ghost)
    b.js(f'tl.to("#{i} .rr",{{strokeDashoffset:{C * (1 - pct / 100):.0f},duration:1.4,ease:"expo.out"}},{at:.3f});(function(){{const o={{v:0}};const el=document.querySelector("#{i} .n");tl.to(o,{{v:{pct},duration:1.4,ease:"expo.out",onUpdate:()=>el.textContent=Math.round(o.v)}},{at:.3f});}})();')

def seesaw(b, t, d, left, right, y=360, note="", lg="p", rg="b"):
    if rg == "n": rg = "b"
    if lg == "n": lg = "p"
    i = b.clip(t, d,
               f'<div class="bm" style="position:absolute;left:200px;top:{y + 210}px;width:680px;height:10px;background:#cbd1de;border-radius:5px;transform-origin:50% 50%">'
               f'<div class="card cl" style="left:-110px;top:-152px;width:360px;height:124px;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:40px;color:var(--gry)">{E(left)}</div>'
               f'<div class="card cr" style="left:430px;top:-162px;width:360px;height:134px;display:flex;align-items:center;justify-content:center;font-weight:900;font-size:44px;border:2px solid rgba(36,92,255,.18)">{gtext(right, rg)}</div></div>'
               f'<div style="position:absolute;left:526px;top:{y + 202}px;width:28px;height:28px;border-radius:50%;background:#fff;border:6px solid var(--b1);z-index:3"></div>'
               f'<svg width="140" height="150" style="position:absolute;left:470px;top:{y + 216}px"><path d="M70 8 L124 136 L16 136 Z" fill="#e6eaf2" stroke="#cbd1de" stroke-width="3" stroke-linejoin="round"/></svg>'
               f'<div style="position:absolute;left:0;width:1080px;top:{y + 392}px;text-align:center;font-size:28px;font-weight:700;color:var(--gry)">{E(note)}</div>',
               "left:0;top:0;width:1080px;height:960px")
    b.js(f'tl.fromTo("#{i}",{{opacity:0,y:36}},{{opacity:1,y:0,duration:.65,ease:"expo.out"}},{t:.3f});'
         f'tl.fromTo("#{i} .bm",{{rotation:-7}},{{rotation:8.5,duration:1.35,ease:"power3.inOut"}},{t + .22:.3f});'
         f'tl.to("#{i} .bm",{{rotation:6.8,duration:2.0,ease:"sine.inOut",yoyo:true,repeat:{max(1, int(d / 2.0))}}},{t + 1.57:.3f});'
         f'tl.to("#{i}",{{opacity:0,y:-14,duration:.28,ease:"power2.in"}},{t + d - .30:.3f});')

def steps(b, t, d, items, y=320, gap=196):
    inner = ""
    for k, (s, g, tk) in enumerate(items):
        gc = "b" if g == "n" else g
        if k:
            inner += f'<div class="ar{k}" style="position:absolute;left:538px;top:{y + k * gap - (gap - 134)}px;width:4px;height:{gap - 134}px;background:linear-gradient(180deg,var(--b1),var(--b2));border-radius:2px;transform-origin:top"></div>'
        inner += (f'<div class="st{k} card" style="left:110px;top:{y + k * gap}px;width:860px;height:134px;padding:0 48px;display:flex;align-items:center;gap:30px">'
                  f'<span class="tnum" style="width:58px;height:58px;border-radius:18px;background:rgba(36,92,255,.09);color:var(--b1);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:26px;flex:none">0{k + 1}</span>'
                  f'<span style="font-weight:900;font-size:46px;letter-spacing:-.038em">{gtext(s, gc)}</span></div>')
    i = b.clip(t, d, inner, "left:0;top:0;width:1080px;height:1050px")
    for k, (_, _, tk) in enumerate(items):
        if k:
            b.js(f'tl.fromTo("#{i} .ar{k}",{{scaleY:0,opacity:0}},{{scaleY:1,opacity:1,duration:.36,ease:"expo.out"}},{tk - .18:.3f});'
                 f'tl.to("#{i} .ar{k}",{{opacity:0,duration:.26}},{t + d - .28:.3f});')
        popin(b, f"#{i} .st{k}", tk, d=.58, y=28, out=t + d, float_=False)

def versus(b, t, d, a, bb, y=350, at2=None):
    at2 = t + .65 if at2 is None else at2; inner = ""
    for k, (lab, val, sub, g) in enumerate([a, bb]):
        gc = "p" if g == "n" else g
        x = 76 + k * 484
        fsz = min(84, max(44, int(350 / max(1, len(val) * .88))))
        inner += (f'<div class="v{k} card" style="left:{x}px;top:{y}px;width:444px;height:440px;padding:52px 32px;display:flex;flex-direction:column;align-items:center;justify-content:space-between;text-align:center">'
                  f'<div class="tag">{E(lab)}</div>'
                  f'<div style="font-weight:900;font-size:{fsz}px;line-height:1.18;letter-spacing:-.04em">{gtext(val, gc)}</div>'
                  f'<div style="font-size:26px;font-weight:700;color:var(--gry)">{E(sub)}</div></div>')
    inner += f'<div class="vs" style="position:absolute;left:502px;top:{y + 182}px;width:76px;height:76px;border-radius:50%;background:var(--ink);border:6px solid var(--bg);color:#fff;font-family:PP,sans-serif;font-weight:700;font-size:24px;letter-spacing:.06em;display:flex;align-items:center;justify-content:center;z-index:4">VS</div>'
    i = b.clip(t, d, inner, "left:0;top:0;width:1080px;height:960px")
    popin(b, f"#{i} .v0", t, out=t + d); popin(b, f"#{i} .v1", at2, out=t + d)
    b.js(f'tl.fromTo("#{i} .vs",{{scale:.5,opacity:0}},{{scale:1,opacity:1,duration:.45,ease:"expo.out"}},{at2 + .14:.3f});'
         f'tl.to("#{i} .vs",{{opacity:0,duration:.28}},{t + d - .30:.3f});')

def photo(b, t, d, box, src, badge=None, label=None, zoom=1.07):
    x, y, w, h = box
    bd = f'<div class="bd card" style="right:24px;bottom:24px;padding:14px 28px;border-radius:26px;font-weight:900;font-size:44px">{gtext(badge, "b")}</div>' if badge else ""
    lb = f'<div style="position:absolute;left:24px;top:24px;padding:10px 22px;border-radius:99px;background:rgba(20,22,28,.72);backdrop-filter:blur(10px);color:#fff;font-weight:700;font-size:24px">{E(label)}</div>' if label else ""
    i = b.clip(t, d, f'<div class="card" style="left:0;top:0;width:{w}px;height:{h}px;overflow:hidden"><img class="ph" src="assets/{src}" style="width:100%;height:100%;object-fit:cover">{lb}{bd}</div>', f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, float_=False)
    b.js(f'tl.fromTo("#{i} .ph",{{scale:1.01}},{{scale:{zoom},duration:{d},ease:"none"}},{t:.3f});')
    if badge: b.js(f'tl.fromTo("#{i} .bd",{{opacity:0,y:16}},{{opacity:1,y:0,duration:.5,ease:"expo.out"}},{t + .55:.3f});')

def spectrum(b, t, d, y=340, pass_label="가시광선 · 선명하게 통과", block_label="적외선 열 · 선택적 차단", at=None):
    at = t + .45 if at is None else at
    lines = "".join(f'<div class="sl" style="position:absolute;left:{130 + k * 68}px;top:170px;width:6px;height:210px;background:{c};border-radius:3px;transform-origin:top"></div>' for k, c in enumerate(["#6366f1", "#245cff", "#0ea5e9", "#14b8a6"]))
    blocks = "".join(f'<div class="bl" style="position:absolute;left:{570 + k * 76}px;top:170px;width:6px;height:82px;background:#7c4dff;border-radius:3px;transform-origin:top"></div><div class="bx" style="position:absolute;left:{558 + k * 76}px;top:262px;font-weight:900;font-size:30px;color:#7c4dff">×</div>' for k in range(3))
    i = b.clip(t, d,
               f'<div class="card" style="left:84px;top:{y}px;width:912px;height:540px">'
               f'<div style="position:absolute;left:64px;top:52px;font-size:24px;font-weight:700;color:var(--b1)">가시광선 (VLT)</div>'
               f'<div style="position:absolute;right:64px;top:52px;font-size:24px;font-weight:700;color:var(--b2)">적외선 열에너지 (IR)</div>'
               f'<div class="sp" style="position:absolute;left:64px;top:102px;width:784px;height:48px;border-radius:24px;background:linear-gradient(90deg,#6366f1,#245cff,#0ea5e9,#14b8a6,#7c4dff,#c026d3)"></div>'
               f'{lines}{blocks}'
               f'<div class="pl" style="position:absolute;left:64px;bottom:48px;font-weight:900;font-size:30px;color:var(--b1)">{E(pass_label)}</div>'
               f'<div class="pl" style="position:absolute;right:64px;bottom:48px;font-weight:900;font-size:30px;color:var(--b2)">{E(block_label)}</div></div>',
               "left:0;top:0;width:1080px;height:960px")
    popin(b, f"#{i} .card", t, out=t + d, float_=False)
    b.js(f'tl.fromTo("#{i} .sp",{{scaleX:0,transformOrigin:"left"}},{{scaleX:1,duration:.7,ease:"expo.out"}},{t + .15:.3f});'
         f'tl.fromTo("#{i} .sl,#{i} .bl",{{scaleY:0}},{{scaleY:1,duration:.55,stagger:.06,ease:"expo.out"}},{at:.3f});'
         f'tl.fromTo("#{i} .bx,#{i} .pl",{{opacity:0,y:8}},{{opacity:1,y:0,duration:.45,stagger:.06,ease:"expo.out"}},{at + .45:.3f});')

def waves(b, t, d, y=320, glass="SOLAR FILM", passed=False, note_l="태양열 · 눈부심", note_r="열에너지 제어"):
    wv = ""
    for k in range(4):
        through = passed or k == 0
        L = 780 if through else 410
        col = "#245cff" if k == 0 else "#7c4dff"
        p = "M48 0 " + " ".join(f"Q{48 + j * 36 + 18} {(-12 if j % 2 == 0 else 12)} {48 + (j + 1) * 36} 0" for j in range(int((L - 48) / 36)))
        wv += f'<svg class="wv" width="840" height="36" style="position:absolute;left:36px;top:{130 + k * 74}px;overflow:visible"><path d="{p}" transform="translate(0,18)" stroke="{col}" stroke-width="4.5" stroke-linecap="round" fill="none" stroke-dasharray="1100" stroke-dashoffset="1100"/></svg>'
    i = b.clip(t, d,
               f'<div class="card" style="left:84px;top:{y}px;width:912px;height:560px">'
               f'<div style="position:absolute;left:56px;top:44px;font-weight:700;font-size:25px;color:var(--b2)">{E(note_l)}</div>'
               f'<div class="nr" style="position:absolute;right:56px;top:40px;padding:8px 22px;border-radius:99px;background:rgba(36,92,255,.10);font-weight:700;font-size:24px;color:var(--b1)">{E(note_r)}</div>'
               f'<div class="gl" style="position:absolute;left:442px;top:104px;width:28px;height:330px;border-radius:14px;background:linear-gradient(180deg,rgba(36,92,255,.22),rgba(124,77,255,.28));border:2.5px solid rgba(36,92,255,.45)"></div>'
               f'{wv}<div class="tag" style="position:absolute;left:0;width:100%;bottom:38px;text-align:center;color:var(--b1)">{E(glass)}</div></div>',
               "left:0;top:0;width:1080px;height:960px")
    popin(b, f"#{i} .card", t, out=t + d, float_=False)
    b.js(f'tl.fromTo("#{i} .gl",{{opacity:0,scaleY:.4}},{{opacity:1,scaleY:1,duration:.55,ease:"expo.out"}},{t + .12:.3f});'
         f'tl.to("#{i} .wv path",{{strokeDashoffset:0,duration:1.5,ease:"power2.out",stagger:.18}},{t + .25:.3f});'
         f'tl.fromTo("#{i} .nr",{{opacity:0,y:10}},{{opacity:1,y:0,duration:.45,ease:"expo.out"}},{t + 1.1:.3f});')

def timeline(b, t, d, items, y=340):
    inner = f'<div class="tl0" style="position:absolute;left:180px;top:{y + 30}px;width:4px;height:{max(1, len(items) - 1) * 150}px;background:linear-gradient(180deg,var(--b1),var(--lgt));border-radius:2px;transform-origin:top"></div>'
    for k, (a, s, tk) in enumerate(items):
        inner += f'<div class="ti{k}" style="position:absolute;left:150px;top:{y + k * 150}px;width:820px;height:120px"><span style="position:absolute;left:13px;top:36px;width:38px;height:38px;border-radius:50%;background:var(--b1);border:7px solid #dce5ff"></span><div class="card" style="left:88px;top:0;width:720px;height:114px;padding:20px 36px"><div class="tag" style="font-size:20px">{E(a)}</div><div style="font-weight:900;font-size:38px;margin-top:4px">{E(s)}</div></div></div>'
    i = b.clip(t, d, inner, "left:0;top:0;width:1080px;height:1100px")
    b.js(f'tl.fromTo("#{i} .tl0",{{scaleY:0}},{{scaleY:1,duration:{max(.6, items[-1][2] - t):.2f},ease:"power2.out"}},{t:.3f});')
    for k, (_, _, tk) in enumerate(items): popin(b, f"#{i} .ti{k}", tk, out=t + d, float_=False, y=28)

def typeline(b, t, d, box, lines, size=64, cps=12, paper=True, tag=None):
    x, y, w, h = box; col = {"ink": "var(--tw)", "blue": "var(--twb)", "red": "var(--twr)"}
    ls = "".join(f'<div class="tl{k} ink" style="font-size:{size}px;line-height:1.3;color:{col[c]};white-space:nowrap">' + "".join(f'<span class="ch" style="display:none">{E(ch) if ch != " " else "&nbsp;"}</span>' for ch in s) + '</div>' for k, (s, c) in enumerate(lines))
    ls = ls.replace("</div>", '<span class="cursor" style="display:none"></span></div>')
    tg = f'<div class="ink" style="font-family:TWE;font-size:26px;letter-spacing:.12em;color:var(--gry);margin-bottom:14px">{E(tag)}</div>' if tag else ""
    i = b.clip(t, d, f'<div class="card {"paper" if paper else ""} tw" style="left:0;top:0;width:{w}px;height:{h}px;padding:40px 44px">{tg}{ls}</div>', f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, float_=False)
    ts = t + .35
    for k, (s, _) in enumerate(lines):
        b.js(f'tl.set("#{i} .cursor",{{display:"none"}},{ts:.3f});tl.set("#{i} .tl{k} .cursor",{{display:"inline-block"}},{ts:.3f});tl.to("#{i} .tl{k} .ch",{{display:"inline",duration:.01,stagger:{1 / cps:.3f}}},{ts:.3f});'); ts += len(s) / cps + .2
    b.js(f'tl.fromTo("#{i} .cursor",{{opacity:0}},{{opacity:.85,duration:.01,repeat:{int(d * 2.4)},yoyo:true,repeatDelay:.4}},{t:.3f});')
    return ts

def receipt(b, t, d, box, title, rows, cps=40, red_last=True):
    x, y, w, h = box; inner = f'<div class="ink" style="font-family:TWE;font-size:28px;letter-spacing:.12em;color:var(--gry);margin-bottom:26px">{E(title)}</div>'
    for k, (n, v) in enumerate(rows):
        c = "var(--twr)" if red_last and k == len(rows) - 1 else "var(--tw)"
        inner += f'<div class="r{k} ink" style="display:flex;align-items:center;height:94px;font-size:40px;color:{c}"><span class="nm">' + "".join(f'<span class="ch" style="display:none">{E(ch) if ch != " " else "&nbsp;"}</span>' for ch in n) + f'</span><span class="dl" style="flex:1;margin:0 18px;border-bottom:3px dotted #c6cad4;transform-origin:left"></span><span class="vv">' + "".join(f'<span class="ch" style="display:none">{E(ch) if ch != " " else "&nbsp;"}</span>' for ch in v) + '</span></div>'
    i = b.clip(t, d, f'<div class="card paper tw" style="left:0;top:0;width:{w}px;height:{h}px;padding:44px 50px">{inner}</div>', f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, float_=False)
    ts = t + .3
    for k, (n, v) in enumerate(rows):
        b.js(f'tl.to("#{i} .r{k} .nm .ch",{{display:"inline",duration:.01,stagger:{1 / cps:.3f}}},{ts:.3f});tl.fromTo("#{i} .r{k} .dl",{{scaleX:0}},{{scaleX:1,duration:.22}},{ts + len(n) / cps:.3f});tl.to("#{i} .r{k} .vv .ch",{{display:"inline",duration:.01,stagger:{1 / cps:.3f}}},{ts + len(n) / cps + .22:.3f});')
        ts += (len(n) + len(v)) / cps + .34
    return ts

def slot(b, t, d, box, label, value, unit="", at=None, g="b", _ghost=False):
    x, y, w, h = box; at = t + .35 if at is None else at; digs = str(value); S = 170
    cols = "".join(f'<span class="tnum" style="display:inline-block;height:{S * 1.15:.0f}px;overflow:hidden;vertical-align:top"><span class="dg{k}" style="display:block">' + "".join(f'<span class="gt g-{g}" style="display:block;height:{S * 1.15:.0f}px;line-height:{S * 1.15:.0f}px">{(int(c) + j) % 10 if c.isdigit() else c}</span>' for j in range(10, -1, -1)) + '</span></span>' for k, c in enumerate(digs))
    i = b.clip(t, d, f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px;text-align:center;padding-top:48px"><div class="tag">{E(label)}</div><div style="font-weight:900;font-size:{S}px;margin-top:8px">{cols}<span class="gt g-{g}" style="font-size:{S * .4:.0f}px;margin-left:6px">{E(unit)}</span></div></div>', f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, float_=False, ghost=_ghost)
    for k, c in enumerate(digs):
        if c.isdigit(): b.js(f'tl.fromTo("#{i} .dg{k}",{{y:0,filter:"blur(6px)"}},{{y:-{S * 1.15 * 10:.0f},filter:"blur(0px)",duration:{1.1 + k * .22:.2f},ease:"expo.out"}},{at:.3f});')

def compare(b, t, d, box, left, right, at=None):
    x, y, w, h = box; at = t + .45 if at is None else at
    i = b.clip(t, d, f'<div class="card" style="left:0;top:0;width:{w}px;height:{h}px;overflow:hidden"><img src="assets/{right[1]}" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover"><div class="lf" style="position:absolute;inset:0;clip-path:inset(0 0% 0 0)"><img src="assets/{left[1]}" style="width:{w}px;height:{h}px;object-fit:cover"></div><div class="hd" style="position:absolute;top:0;bottom:0;left:0;width:4px;background:#fff;box-shadow:0 0 16px rgba(0,0,0,.28)"></div><div style="position:absolute;left:24px;top:24px;padding:8px 20px;border-radius:99px;background:rgba(20,22,28,.72);color:#fff;font-weight:700;font-size:24px">{E(left[0])}</div><div style="position:absolute;right:24px;top:24px;padding:8px 20px;border-radius:99px;background:var(--b1);color:#fff;font-weight:700;font-size:24px">{E(right[0])}</div></div>', f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, float_=False)
    b.js(f'tl.fromTo("#{i} .lf",{{clipPath:"inset(0 0% 0 0)"}},{{clipPath:"inset(0 50% 0 0)",duration:1.2,ease:"power3.inOut"}},{at:.3f});tl.fromTo("#{i} .hd",{{x:{w}}},{{x:{w * .5:.0f},duration:1.2,ease:"power3.inOut"}},{at:.3f});')

def endcard(b, t, d, logo_="motif", lines=("솔라가드 THE LX 전주 유일 공식 특화샵",), phone="010-4814-4506", addr="전주 덕진구 정여립로 1104", big=None):
    src = {"motif": "motif_logo_dark.png", "lxsg": "lxsg_ink_dark.png"}[logo_]
    ln = "".join(f'<div class="e" style="font-weight:700;font-size:36px;margin-top:26px;letter-spacing:-.03em">{E(s)}</div>' for s in lines)
    mid = f'<div class="e" style="font-size:28px;font-weight:700;color:var(--gry);margin-top:46px">시공 및 예약 문의</div><div class="e tnum" style="font-weight:900;font-size:94px;margin-top:6px">{gtext(phone, "bp")}</div><div class="e" style="font-size:30px;color:var(--gry);margin-top:8px">{E(addr)}</div>' if phone else ""
    bg = f'<div class="e" style="font-weight:900;font-size:72px;margin-top:38px">{gtext(big, "bp")}</div>' if big else ""
    i = b.clip(t, d, f'<div style="position:absolute;left:0;top:560px;width:1080px;text-align:center"><img class="e" src="assets/{src}" style="width:{440 if logo_ == "motif" else 360}px"><div class="e g-b" style="width:76px;height:6px;margin:34px auto 0;border-radius:3px"></div>{ln}{bg}{mid}</div>', "left:0;top:0;width:1080px;height:1920px")
    b.js(f'tl.fromTo("#{i} .e",{{opacity:0,y:26,filter:"blur(6px)"}},{{opacity:1,y:0,filter:"blur(0px)",duration:.65,stagger:.11,ease:"expo.out"}},{t:.3f});')

# ───────── 프로 모션·타이포 신규 부품 8종 (해외 유튜브 레퍼런스 기반) ─────────
def splitline(b, t, d, box=(84, 330, 912, 500), top="", bottom="", tag="CONTRAST", g="b", at=None, _ghost=False):
    """[Ben Marriott Trim-Path + Track Matte] 중앙 기준선이 그어지며 위/아래 문구가 마스크 경계에서 교차 등장"""
    x, y, w, h = box; at = t + .28 if at is None else at
    mid_y = int(h * .52)
    fsz_t = min(44, max(32, int(740 / max(1, len(top)))))
    fsz_b = min(60, max(38, int(780 / max(1, len(bottom)))))
    i = b.clip(t, d,
               f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px">'
               f'<div class="tag" style="position:absolute;left:56px;top:40px;color:var(--b1)">{E(tag)}</div>'
               f'<div style="position:absolute;left:56px;right:56px;bottom:{h - mid_y + 18}px;height:120px;overflow:hidden;display:flex;align-items:flex-end;justify-content:center">'
               f'<div class="tp" style="font-weight:700;font-size:{fsz_t}px;color:var(--gry);text-align:center">{E(top)}</div></div>'
               f'<div class="ln" style="position:absolute;left:56px;right:56px;top:{mid_y}px;height:3.5px;border-radius:2px;background:linear-gradient(90deg,var(--b1),var(--b2));transform-origin:50% 50%"></div>'
               f'<div style="position:absolute;left:56px;right:56px;top:{mid_y + 20}px;height:140px;overflow:hidden;display:flex;align-items:flex-start;justify-content:center">'
               f'<div class="bt" style="font-weight:900;font-size:{fsz_b}px;letter-spacing:-.04em;text-align:center">{gtext(bottom, g)}</div></div></div>',
               f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, float_=False, ghost=_ghost)
    b.js(f'tl.fromTo("#{i} .ln",{{scaleX:0,opacity:0}},{{scaleX:1,opacity:1,duration:.58,ease:"expo.out"}},{at:.3f});'
         f'tl.fromTo("#{i} .tp",{{y:105,opacity:0,filter:"blur(6px)"}},{{y:0,opacity:1,filter:"blur(0px)",duration:.58,ease:"expo.out"}},{at + .12:.3f});'
         f'tl.fromTo("#{i} .bt",{{y:-115,opacity:0,filter:"blur(8px)"}},{{y:0,opacity:1,filter:"blur(0px)",duration:.64,ease:"expo.out"}},{at + .26:.3f});')

def morphcard(b, t, d, stages, y=340, w_end=912, h_end=520):
    """[Apple UI Single-Shape Morphing] 알약 배지 → 중간 바 → 메인 카드로 모서리 왜곡 없이 크기·곡률 연속 변형"""
    n = len(stages)
    if n == 2:
        dims = [(480, 134, 67), (w_end, h_end, 38)]
    else:
        dims = [(460, 128, 64), (740, 250, 44), (w_end, h_end, 38)]
        while len(dims) < n: dims.append((w_end, h_end, 38))
    w0, h0, r0 = dims[0]
    x0 = int(540 - w0 / 2); y0 = int(y + (h_end - h0) * .38)
    inners = ""
    for k, (tg, txt, _) in enumerate(stages):
        wk, hk, _ = dims[k]
        fsz = 36 if k == 0 else (44 if k == 1 and n > 2 else min(58, max(40, int(760 / max(1, len(txt))))))
        is_last = (k == n - 1)
        inners += (f'<div class="st{k}" style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:0 44px;text-align:center;opacity:0">'
                   f'<div class="tag" style="color:{"var(--b1)" if is_last else "var(--gry)"};font-size:{19 if k == 0 else 22}px;margin-bottom:{6 if k == 0 else 14}px">{E(tg)}</div>'
                   f'<div style="font-weight:{900 if is_last else 700};font-size:{fsz}px;letter-spacing:-.038em;white-space:nowrap">{gtext(txt, "bp" if is_last else "k")}</div></div>')
    i = b.clip(t, d, f'<div class="card mc" style="left:0;top:0;width:{w0}px;height:{h0}px;border-radius:{r0}px;overflow:hidden">{inners}</div>', "left:0;top:0;width:1080px;height:1000px")
    t_first = stages[0][2] if isinstance(stages[0][2], (int, float)) else t + .15
    b.js(f'tl.fromTo("#{i} .mc",{{opacity:0,x:{x0},y:{y0 + 30},width:{w0},height:{h0},borderRadius:{r0}}},{{opacity:1,x:{x0},y:{y0},width:{w0},height:{h0},borderRadius:{r0},duration:.58,ease:"expo.out"}},{t:.3f});'
         f'tl.fromTo("#{i} .st0",{{opacity:0,y:14,filter:"blur(6px)"}},{{opacity:1,y:0,filter:"blur(0px)",duration:.45,ease:"expo.out"}},{max(t + .1, t_first):.3f});')
    for k in range(1, n):
        wk, hk, rk = dims[k]
        xk = int(540 - wk / 2); yk = int(y + (h_end - hk) * .38)
        tk = stages[k][2]
        b.js(f'tl.to("#{i} .st{k - 1}",{{opacity:0,y:-14,filter:"blur(5px)",duration:.24,ease:"power2.in"}},{tk - .08:.3f});'
             f'tl.to("#{i} .mc",{{x:{xk},y:{yk},width:{wk},height:{hk},borderRadius:{rk},duration:.62,ease:"power3.inOut"}},{tk:.3f});'
             f'tl.fromTo("#{i} .st{k}",{{opacity:0,y:18,filter:"blur(8px)"}},{{opacity:1,y:0,filter:"blur(0px)",duration:.52,ease:"expo.out"}},{tk + .22:.3f});')
    b.js(f'tl.to("#{i} .mc",{{opacity:0,y:{int(y - 16)},scale:.99,duration:.28,ease:"power2.in"}},{t + d - .30:.3f});')

def bento(b, t, d, box=(84, 295, 912, 620), cells=()):
    """[Apple Keynote Asymmetric Bento Grid] 제어된 비대칭 여백 그리드(2~4칸 자동 분할)"""
    x, y, w, h = box; gap = 20; n = len(cells)
    if n <= 2:
        rects = [(0, 0, w, int((h - gap) * .54)), (0, int((h - gap) * .54) + gap, w, h - int((h - gap) * .54) - gap)]
    elif n == 3:
        h1 = int((h - gap) * .48); h2 = h - gap - h1; w2 = int((w - gap) / 2)
        rects = [(0, 0, w, h1), (0, h1 + gap, w2, h2), (w2 + gap, h1 + gap, w - w2 - gap, h2)]
    else:
        h1 = int((h - gap) * .50); h2 = h - gap - h1
        w_big = int((w - gap) * .57); w_sml = w - gap - w_big
        rects = [(0, 0, w_big, h1), (w_big + gap, 0, w_sml, h1), (0, h1 + gap, w_sml, h2), (w_sml + gap, h1 + gap, w_big, h2)]
    inner = ""
    for k, (tg, tit, sub, g, _) in enumerate(cells[:4]):
        cx, cy, cw, ch = rects[k]
        fsz = min(46 if cw > w * .5 else 38, max(30, int((cw - 72) / max(1, len(tit) * .9))))
        accent = "border:1.5px solid rgba(36,92,255,.20);background:linear-gradient(180deg,#ffffff 0%,#f7f9ff 100%)" if k == 0 else ""
        inner += (f'<div class="card bc{k}" style="left:{cx}px;top:{cy}px;width:{cw}px;height:{ch}px;padding:34px 38px;display:flex;flex-direction:column;justify-content:space-between;{accent}">'
                  f'<div class="tag" style="font-size:20px;color:{"var(--b1)" if k == 0 else "var(--gry)"}">{E(tg)}</div>'
                  f'<div><div style="font-weight:900;font-size:{fsz}px;letter-spacing:-.038em;line-height:1.18">{gtext(tit, g)}</div>'
                  f'<div style="font-size:25px;font-weight:700;color:var(--gry);margin-top:8px">{E(sub)}</div></div></div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    for k, (*_, tk) in enumerate(cells[:4]):
        b.js(f'tl.fromTo("#{i} .bc{k}",{{opacity:0,y:28,scale:.97,filter:"blur(6px)"}},{{opacity:1,y:0,scale:1,filter:"blur(0px)",duration:.58,ease:"expo.out"}},{tk:.3f});'
             f'tl.to("#{i} .bc{k}",{{opacity:0,y:-14,duration:.26,ease:"power2.in"}},{t + d - .28:.3f});')

def ladder(b, t, d, box=(88, 295, 904, 620), title="LINEUP", tiers=(), pick=-1, _ghost=False):
    """[Satori Graphics Isolation & Visual Weight] 라인업 사다리 목록 + 선택 등급 돌출 강조"""
    x, y, w, h = box; n = len(tiers)
    pk = (n + pick) if (isinstance(pick, int) and pick < 0) else pick
    rh = min(132, max(92, int((h - 156) / max(1, n))))
    rows = ""
    for k, (nm, val, _) in enumerate(tiers):
        rows += (f'<div class="ld{k}" style="height:{rh - 14}px;margin-bottom:14px;padding:0 36px;border-radius:24px;background:#f7f8fc;border:2px solid transparent;display:flex;align-items:center;justify-content:space-between">'
                 f'<div style="display:flex;align-items:center;gap:20px">'
                 f'<span class="tnum" style="font-size:22px;font-weight:700;color:var(--gry)">0{k + 1}</span>'
                 f'<span class="nm" style="font-weight:700;font-size:33px;color:var(--ink)">{E(nm)}</span></div>'
                 f'<span class="vl tnum" style="font-weight:900;font-size:38px">{gtext(val, "b" if k == pk else "k")}</span></div>')
    i = b.clip(t, d,
               f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px;padding:40px 48px">'
               f'<div class="tag" style="color:var(--b1)">SELECTION TIERS</div>'
               f'<div style="font-weight:900;font-size:38px;margin:4px 0 20px;letter-spacing:-.038em">{E(title)}</div>'
               f'{rows}</div>',
               f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, float_=False, ghost=_ghost)
    last_tk = t + .4
    for k, (_, _, tk) in enumerate(tiers):
        last_tk = max(last_tk, tk)
        b.js(f'tl.fromTo("#{i} .ld{k}",{{opacity:0,x:-20,filter:"blur(5px)"}},{{opacity:1,x:0,filter:"blur(0px)",duration:.5,ease:"expo.out"}},{tk:.3f});')
    if isinstance(pk, int) and 0 <= pk < n:
        ht = min(t + d - .8, last_tk + .45)
        for k in range(n):
            if k == pk:
                b.js(f'tl.to("#{i} .ld{k}",{{scale:1.025,x:8,backgroundColor:"#ffffff",borderColor:"rgba(36,92,255,.35)",boxShadow:"0 14px 32px rgba(36,92,255,.12)",duration:.55,ease:"expo.out"}},{ht:.3f});')
            else:
                b.js(f'tl.to("#{i} .ld{k}",{{opacity:.54,scale:.985,duration:.55,ease:"power2.out"}},{ht:.3f});')

def focusword(b, t, d, box=(84, 330, 912, 520), eyebrow="DESIGN PRINCIPLE", word="", sub="", g="bp", at=None, _ghost=False):
    """[Ben Marriott 106%→100% Optical Focus + Tracking] 시네마틱 자간 확장 + 광학 블러 포커스 명제 카드"""
    x, y, w, h = box; at = t + .22 if at is None else at
    fsz = min(84, max(48, int(760 / max(1, len(word) * .88))))
    i = b.clip(t, d,
               f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px;padding:52px;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center">'
               f'<div class="ey" style="font-family:PP,KR,sans-serif;font-weight:700;font-size:22px;color:var(--b1);letter-spacing:.10em;text-transform:uppercase">{E(eyebrow)}</div>'
               f'<div class="fw" style="font-weight:900;font-size:{fsz}px;letter-spacing:-.042em;line-height:1.16;margin:24px 0">{gtext(word, g)}</div>'
               f'<div class="dv" style="width:68px;height:3px;border-radius:2px;background:var(--lgt);margin-bottom:24px;transform-origin:center"></div>'
               f'<div style="height:56px;overflow:hidden"><div class="sb" style="font-size:30px;font-weight:700;color:var(--gry)">{E(sub)}</div></div></div>',
               f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, float_=True, ghost=_ghost)
    b.js(f'tl.fromTo("#{i} .ey",{{opacity:0,letterSpacing:"0.08em"}},{{opacity:1,letterSpacing:"0.26em",duration:1.4,ease:"expo.out"}},{at:.3f});'
         f'tl.fromTo("#{i} .fw",{{opacity:0,y:18,filter:"blur(5px)"}},{{opacity:1,y:0,filter:"blur(0px)",duration:.82,ease:"expo.out"}},{at + .10:.3f});'
         f'tl.fromTo("#{i} .dv",{{scaleX:0}},{{scaleX:1,duration:.5,ease:"expo.out"}},{at + .35:.3f});'
         f'tl.fromTo("#{i} .sb",{{y:50,opacity:0}},{{y:0,opacity:1,duration:.55,ease:"expo.out"}},{at + .44:.3f});')

def crossscan(b, t, d, box=(84, 330, 912, 500), tag="OPTICAL VERIFIED", text="", sub="", g="b", at=None, _ghost=False):
    """[Mhd Labs Crosshair Scan Reveal] 뷰파인더 십자선(+)이 스캔하며 핵심 스펙/문구를 현상"""
    x, y, w, h = box; at = t + .28 if at is None else at
    fsz = min(76, max(44, int(760 / max(1, len(text) * .72))))
    sw = w - 128
    brk = (f'<i style="position:absolute;left:36px;top:36px;width:22px;height:22px;border-left:3px solid var(--lgt);border-top:3px solid var(--lgt)"></i>'
           f'<i style="position:absolute;right:36px;top:36px;width:22px;height:22px;border-right:3px solid var(--lgt);border-top:3px solid var(--lgt)"></i>'
           f'<i style="position:absolute;left:36px;bottom:36px;width:22px;height:22px;border-left:3px solid var(--lgt);border-bottom:3px solid var(--lgt)"></i>'
           f'<i style="position:absolute;right:36px;bottom:36px;width:22px;height:22px;border-right:3px solid var(--lgt);border-bottom:3px solid var(--lgt)"></i>')
    i = b.clip(t, d,
               f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px">{brk}'
               f'<div class="tag" style="position:absolute;top:52px;width:100%;text-align:center;color:var(--b1)">{E(tag)}</div>'
               f'<div style="position:absolute;left:64px;top:{int(h * .36)}px;width:{sw}px;height:120px;display:flex;align-items:center;justify-content:center">'
               f'<div class="tx tnum" style="font-weight:900;font-size:{fsz}px;letter-spacing:-.035em;white-space:nowrap;clip-path:inset(0 100% 0 0)">{gtext(text, g)}</div>'
               f'<div class="ch" style="position:absolute;left:0;top:0;width:3px;height:120px;background:var(--b1);opacity:0">'
               f'<span style="position:absolute;left:-13px;top:46px;width:29px;height:29px;font-family:PP,sans-serif;font-weight:700;font-size:28px;color:var(--b1);line-height:29px;text-align:center">+</span></div></div>'
               f'<div class="sb" style="position:absolute;bottom:56px;width:100%;text-align:center;font-size:28px;font-weight:700;color:var(--gry);opacity:0">{E(sub)}</div></div>',
               f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, float_=False, ghost=_ghost)
    b.js(f'tl.set("#{i} .ch",{{opacity:1}},{at:.3f});'
         f'tl.fromTo("#{i} .ch",{{x:0}},{{x:{sw},duration:.92,ease:"power2.inOut"}},{at:.3f});'
         f'tl.fromTo("#{i} .tx",{{clipPath:"inset(0 100% 0 0)"}},{{clipPath:"inset(0 0% 0 0)",duration:.92,ease:"power2.inOut"}},{at:.3f});'
         f'tl.to("#{i} .ch",{{opacity:0,duration:.25}},{at + .90:.3f});'
         f'tl.fromTo("#{i} .sb",{{opacity:0,y:12}},{{opacity:1,y:0,duration:.48,ease:"expo.out"}},{at + .68:.3f});')

def metricpair(b, t, d, box=(84, 310, 912, 560), title="", left=("TSER", 60, "%", "b"), right=("IRER", 66, "%", "p"), at=None, caption_="", _ghost=False):
    """[1.618 Hierarchy + Unified Odometer & Track] 두 핵심 광학 수치가 좌우 대칭으로 동시 카운트업"""
    x, y, w, h = box; at = t + .32 if at is None else at
    cols = ""
    for k, (lb, val, unit, g) in enumerate([left, right]):
        gc = "p" if g == "n" else g
        cols += (f'<div class="mp{k}" style="flex:1;padding:0 44px;border-left:{2 if k else 0}px solid #eef0f6;display:flex;flex-direction:column;justify-content:center">'
                 f'<div style="font-size:26px;font-weight:700;color:var(--gry)">{E(lb)}</div>'
                 f'<div class="tnum" style="font-weight:900;font-size:116px;line-height:1.08;margin:14px 0 22px">'
                 f'<span class="n gt g-{gc}">0</span><span class="gt g-{gc}" style="font-size:48px;margin-left:4px">{E(unit)}</span></div>'
                 f'<div style="width:100%;height:20px;border-radius:10px;background:var(--trk);overflow:hidden">'
                 f'<div class="br g-{gc}" style="width:0%;height:100%;border-radius:10px"></div></div></div>')
    cap = f'<div style="position:absolute;bottom:24px;width:100%;text-align:center;font-size:21px;color:#9aa0ae">{E(caption_)}</div>' if caption_ else ""
    i = b.clip(t, d,
               f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px">'
               f'<div class="tag" style="position:absolute;left:52px;top:40px;color:var(--b1)">{E(title)}</div>'
               f'<div style="position:absolute;left:0;right:0;top:96px;bottom:56px;display:flex">{cols}</div>{cap}</div>',
               f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, float_=False, ghost=_ghost)
    for k, (_, val, _, _) in enumerate([left, right]):
        tk = at + k * .22
        pct = min(100.0, float(val))
        dec = 0 if float(val).is_integer() else 1
        b.js(f'tl.to("#{i} .mp{k} .br",{{width:"{pct:.1f}%",duration:1.35,ease:"expo.out"}},{tk:.3f});'
             f'(function(){{const o={{v:0}};const el=document.querySelector("#{i} .mp{k} .n");tl.to(o,{{v:{val},duration:1.35,ease:"expo.out",onUpdate:()=>el.textContent=o.v.toFixed({dec})}},{tk:.3f});}})();')

def stacklist(b, t, d, box=(96, 305, 888, 590), pills=(), at=None, collapse_at=None, result="", g="bp"):
    """[Pill Stack → Unified Card Collapse] 복잡한 항목들이 쌓였다가 하나의 해결책 카드로 압축 변형"""
    x, y, w, h = box; at = t + .18 if at is None else at
    collapse_at = t + d * .56 if collapse_at is None else collapse_at
    n = max(1, len(pills))
    ph = min(96, int((h - 20 * (n - 1)) / n))
    tot_h = n * ph + (n - 1) * 18
    y_start = int((h - tot_h) / 2)
    cy = int(h / 2 - ph / 2)
    pl_html = ""
    for k, s in enumerate(pills):
        py = y_start + k * (ph + 18)
        pl_html += (f'<div class="card pl{k}" style="left:44px;top:{py}px;width:{w - 88}px;height:{ph}px;border-radius:{int(ph / 2)}px;padding:0 40px;display:flex;align-items:center;justify-content:space-between">'
                    f'<span style="font-weight:700;font-size:32px;color:var(--body)">{E(s)}</span>'
                    f'<span class="tnum" style="font-size:22px;font-weight:700;color:var(--lgt)">0{k + 1}</span></div>')
    res_fsz = min(56, max(38, int(740 / max(1, len(result)))))
    res_html = (f'<div class="card rs" style="left:0;top:{int(h / 2 - 135)}px;width:{w}px;height:270px;padding:40px;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;opacity:0;border:2px solid rgba(36,92,255,.22)">'
                f'<div class="tag" style="color:var(--b1);margin-bottom:14px">ALL-IN-ONE SOLUTION</div>'
                f'<div style="font-weight:900;font-size:{res_fsz}px;letter-spacing:-.04em">{gtext(result, g)}</div></div>')
    i = b.clip(t, d, pl_html + res_html, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    for k in range(n):
        py = y_start + k * (ph + 18)
        b.js(f'tl.fromTo("#{i} .pl{k}",{{opacity:0,y:24,filter:"blur(6px)"}},{{opacity:1,y:0,filter:"blur(0px)",duration:.46,ease:"expo.out"}},{at + k * .14:.3f});')
        if result:
            b.js(f'tl.to("#{i} .pl{k}",{{y:{cy - py},scale:.90,opacity:0,filter:"blur(8px)",duration:.52,ease:"power3.inOut"}},{collapse_at:.3f});')
    if result:
        b.js(f'tl.fromTo("#{i} .rs",{{opacity:0,scale:.92,filter:"blur(10px)"}},{{opacity:1,scale:1,filter:"blur(0px)",duration:.62,ease:"expo.out"}},{collapse_at + .28:.3f});'
             f'tl.to("#{i} .rs",{{opacity:0,y:-16,duration:.28,ease:"power2.in"}},{t + d - .30:.3f});')
    else:
        b.js(f'tl.to("#{i}",{{opacity:0,y:-16,duration:.28,ease:"power2.in"}},{t + d - .30:.3f});')

# ───────── 타자기 · 센터 텍스트 · UI 패턴 부품 ─────────
_RND = "0123456789"
def _strip(ch, k, n=7):
    import random
    r = random.Random(hash((ch, k)) & 0xffff)
    if ch.isdigit(): pool = _RND
    elif "가" <= ch <= "힣": return [ch] * n + [ch]
    elif ch.isalpha(): return [ch] * n + [ch]
    else: return None
    return [r.choice(pool) for _ in range(n)] + [ch]

def roll_html(text, cls="rl"):
    out = []
    for k, ch in enumerate(text):
        st = _strip(ch, k)
        if st is None: out.append(f'<span class="{cls} fx" style="display:inline-block">{"&nbsp;" if ch == " " else E(ch)}</span>')
        else: out.append(f'<span class="{cls} cw" style="display:inline-block;height:1.08em;overflow:hidden;vertical-align:top"><span class="sx" style="display:block">' + "".join(f'<span style="display:block;height:1.08em;line-height:1.08em">{E(c)}</span>' for c in st) + '</span></span>')
    return "".join(out)

def roll_js(b, sel, t, stagger=.07, dur=.9):
    b.js(f'document.querySelectorAll("{sel} .cw").forEach((el,k)=>{{const s=el.querySelector(".sx");const n=s.children.length;tl.fromTo(s,{{yPercent:0,filter:"blur(7px)"}},{{yPercent:-100*(n-1)/n,filter:"blur(0px)",duration:{dur},ease:"expo.out"}},{t:.3f}+k*{stagger});}});'
         f'tl.fromTo("{sel} .fx",{{opacity:0}},{{opacity:1,duration:.3,stagger:{stagger}}},{t + .3:.3f});')

def rollstat(b, t, d, x, y, w, title, cols, at=None, theme="dark", size=150, label_size=26, gap=.35):
    at = t + .4 if at is None else at; col = "#14161c" if theme == "dark" else "#fff"; sub = "rgba(20,22,28,.55)" if theme == "dark" else "rgba(255,255,255,.72)"; ln = "rgba(20,22,28,.22)" if theme == "dark" else "rgba(255,255,255,.4)"
    cw = w / len(cols)
    cs = "".join(f'<div class="cl{k}" style="position:absolute;left:{k * cw:.0f}px;top:70px;width:{cw:.0f}px;height:{size * 1.5:.0f}px;{"border-left:2px solid " + ln + ";padding-left:28px" if k else ""}"><div class="lb" style="font-family:ST,PP,KR;font-weight:500;font-size:{label_size}px;letter-spacing:.18em;color:{sub}">{E(l)}</div><div class="vv tnum" style="font-family:ST,PP,KR;font-weight:400;font-size:{size}px;line-height:1.08;color:{col};white-space:nowrap;margin-top:6px">{roll_html(v)}</div></div>' for k, (l, v) in enumerate(cols))
    i = b.clip(t, d, f'<div class="tt" style="font-family:ST,PP,KR;font-weight:500;font-size:{label_size + 2}px;letter-spacing:.22em;color:{col};white-space:nowrap">{E(title)}</div><div class="hl" style="position:absolute;left:0;top:50px;width:{w}px;height:2px;background:{ln};transform-origin:left"></div>{cs}', f"left:{x}px;top:{y}px;width:{w}px;height:{size * 1.6 + 80:.0f}px")
    b.js(f'tl.fromTo("#{i} .tt",{{opacity:0,y:14}},{{opacity:1,y:0,duration:.5,ease:"expo.out"}},{t:.3f});tl.fromTo("#{i} .hl",{{scaleX:0}},{{scaleX:1,duration:.7,ease:"power2.inOut"}},{t + .1:.3f});tl.fromTo("#{i} .lb",{{opacity:0}},{{opacity:1,duration:.4,stagger:{gap}}},{at - .2:.3f});tl.to("#{i}",{{opacity:0,duration:.35}},{t + d - .37:.3f});')
    for k in range(len(cols)): roll_js(b, f"#{i} .cl{k}", at + k * gap)

def rolltext(b, t, d, x, y, text, size=110, theme="dark", label=None, align="left", w=940, mode="type", cps=14):
    col = "#14161c" if theme == "dark" else "#fff"; sub = "rgba(20,22,28,.55)" if theme == "dark" else "rgba(255,255,255,.72)"
    lb = f'<div class="lb" style="font-family:ST,PP,KR;font-size:26px;letter-spacing:.22em;color:{sub};margin-bottom:10px">{E(label)}</div>' if label else ""
    body = roll_html(text) if mode == "roll" else "".join(f'<span class="ch" style="display:none">{"&nbsp;" if c == " " else E(c)}</span>' for c in text)
    i = b.clip(t, d, f'<div style="text-align:{align}">{lb}<div style="font-family:ST,PP,KR;font-weight:400;font-size:{size}px;line-height:1.08;color:{col};white-space:nowrap">{body}</div></div>', f"left:{x}px;top:{y}px;width:{w}px")
    b.js(f'tl.fromTo("#{i} .lb",{{opacity:0}},{{opacity:1,duration:.3}},{t:.3f});tl.to("#{i}",{{opacity:0,duration:.35}},{t + d - .37:.3f});')
    if mode == "roll": roll_js(b, f"#{i}", t + .25, .06, .8)
    else: b.js(f'tl.to("#{i} .ch",{{display:"inline",duration:.01,stagger:{1 / cps:.4f}}},{t + .25:.3f});')

def type_clicks(items, cps=14):
    out = []
    for it in items:
        if it.get("p") != "rolltext" or it.get("mode", "type") != "type": continue
        t0 = it["t"] + .25; c = it.get("cps", cps)
        for k, ch in enumerate(it["text"]):
            if ch.strip(): out.append((round(t0 + k / c, 3), .11))
        out.append((round(t0 + len(it["text"]) / c + .12, 3), .18))
    return out

def click_wav(clicks, total, path):
    import numpy as np, wave, random
    SR = 44100; au = np.zeros(int(total * SR) + SR); rng = np.random.default_rng(5); m = int(.035 * SR); n = np.arange(m)
    for tc, g in clicks:
        x = rng.standard_normal(m) * np.exp(-n / (.004 * SR)) + .4 * np.sin(2 * np.pi * 1800 * n / SR) * np.exp(-n / (.002 * SR))
        i = int(tc * SR); au[i:i + m] += x * g * (.85 + .3 * random.random())
    au = np.clip(au[:int(total * SR)], -1, 1); w = wave.open(path, "wb"); w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((au * 30000).astype(np.int16).tobytes()); w.close()

def centertext(b, t, d, y, lines, size=40, theme="dark", hold_end=True):
    col = "#14161c" if theme == "dark" else "#fff"
    ln = "".join(f'<div class="e" style="font-weight:{900 if g in ("b","p","bp","k") else 700};font-size:{size * (1.55 if g in ("b","p","bp","k") else 1):.0f}px;color:{"var(--gry)" if g == "g" else col};margin-top:16px;letter-spacing:-.035em">{gtext(s, g) if g in ("b","p","bp","n") else E(s)}</div>' for s, g in lines)
    i = b.clip(t, d, f'<div style="text-align:center"><div class="e g-b" style="width:72px;height:6px;border-radius:3px;margin:0 auto 12px"></div>{ln}</div>', f"left:0;top:{y}px;width:1080px")
    b.js(f'tl.fromTo("#{i} .e",{{opacity:0,y:24,filter:"blur(6px)"}},{{opacity:1,y:0,filter:"blur(0px)",duration:.62,stagger:.13,ease:"expo.out"}},{t:.3f});')
    if not hold_end:
        b.js(f'tl.to("#{i}",{{opacity:0,duration:.35}},{t + d - .37:.3f});')

UICSS = r"""
.ui-dark{background:rgba(20,22,28,.94);color:#fff;backdrop-filter:blur(12px)}
.ui-pill{position:absolute;border-radius:999px;display:flex;align-items:center;gap:18px;padding:0 40px;font-weight:700}
.ui-field{position:absolute;background:#fff;border-radius:22px;border:2px solid #dfe3ec}
.ui-ico{display:inline-flex;align-items:center;justify-content:center;border-radius:50%;font-weight:900;flex:none}
.ui-btn{display:flex;align-items:center;justify-content:center;border-radius:22px;font-weight:700}
.ui-sk{background:linear-gradient(90deg,#eceef3 0%,#f6f7fa 40%,#eceef3 80%);background-size:300% 100%;border-radius:14px;position:absolute}
.ui-dim{position:absolute;left:0;top:0;width:1080px;height:1920px;background:rgba(20,22,30,.36)}
.ui-row{display:flex;align-items:center;justify-content:space-between}
"""

def _in(b, sel, t, d=.68, y=32, x=0, sc=None):
    s = f",scale:{sc}" if sc else ""; e = ",scale:1" if sc else ""
    b.js(f'tl.fromTo("{sel}",{{opacity:0,y:{y},x:{x}{s}}},{{opacity:1,y:0,x:0{e},duration:{d},ease:"expo.out"}},{t:.3f});')

def _out(b, sel, tend, d=.32, y=-16):
    b.js(f'tl.to("{sel}",{{opacity:0,y:{y},duration:{d},ease:"power2.in"}},{tend - d - .02:.3f});')

def _count(b, sel, v0, v1, at, dur=1.35, dec=0):
    b.js(f'(function(){{const o={{v:{v0}}};const el=document.querySelector("{sel}");tl.to(o,{{v:{v1},duration:{dur},ease:"expo.out",onUpdate:()=>el.textContent=o.v.toFixed({dec})}},{at:.3f});}})();')

def toast(b, t, d, text, icon="✓", y=420):
    i = b.clip(t, d, f'<div class="ui-pill ui-dark" style="left:50%;transform:translateX(-50%);top:0;height:96px;font-size:35px;white-space:nowrap;box-shadow:0 18px 40px rgba(20,22,30,.22)"><span class="ui-ico" style="width:44px;height:44px;background:var(--b1);font-size:24px">{E(icon)}</span>{E(text)}</div>', f"left:0;top:{y}px;width:1080px;height:120px")
    _in(b, f"#{i} .ui-pill", t, y=-60); _out(b, f"#{i} .ui-pill", t + d, y=-30)

def snackbar(b, t, d, text, action="보기", y=1180, at=None):
    at = t + d * .6 if at is None else at
    i = b.clip(t, d, f'<div class="sb ui-dark" style="position:absolute;left:72px;top:0;width:936px;height:116px;border-radius:24px;padding:0 44px;font-size:34px;font-weight:700"><div class="ui-row" style="height:100%"><span>{E(text)}</span><span class="act" style="color:#8fb0ff;padding:12px 22px;border-radius:16px">{E(action)}</span></div></div>', f"left:0;top:{y}px;width:1080px;height:130px")
    _in(b, f"#{i} .sb", t, y=80); _out(b, f"#{i} .sb", t + d, y=50)
    b.js(f'tl.to("#{i} .act",{{backgroundColor:"rgba(143,176,255,.22)",duration:.35,ease:"power2.out"}},{at:.3f});tl.to("#{i} .act",{{backgroundColor:"rgba(143,176,255,0)",duration:.5}},{at + .4:.3f});')

def banner(b, t, d, title, text, y=360, icon="i"):
    i = b.clip(t, d, f'<div class="card bn" style="left:72px;top:0;width:936px;height:190px;border-radius:30px;overflow:hidden"><div class="bl" style="position:absolute;left:0;top:0;width:10px;height:100%;background:linear-gradient(180deg,var(--b1),var(--b2));transform-origin:top"></div><div style="position:absolute;left:52px;top:46px;display:flex;gap:28px;align-items:flex-start"><span class="ui-ico" style="width:60px;height:60px;background:#e6ecff;color:var(--b1);font-size:32px">{E(icon)}</span><div><div style="font-weight:900;font-size:38px">{E(title)}</div><div style="font-size:29px;color:var(--gry);margin-top:10px">{E(text)}</div></div></div></div>', f"left:0;top:{y}px;width:1080px;height:200px")
    _in(b, f"#{i} .bn", t, y=-44); _out(b, f"#{i} .bn", t + d)
    b.js(f'tl.fromTo("#{i} .bl",{{scaleY:0}},{{scaleY:1,duration:.8,ease:"expo.out"}},{t + .22:.3f});')

def modal(b, t, d, title, body, ok="확인", cancel="닫기", at=None):
    at = t + d - 1.0 if at is None else at
    i = b.clip(t, d, f'<div class="ui-dim"></div><div class="card md" style="left:140px;top:640px;width:800px;padding:64px 60px 50px;border-radius:42px;text-align:center"><div style="font-weight:900;font-size:48px">{E(title)}</div><div style="font-size:31px;color:var(--gry);line-height:1.5;margin-top:22px">{E(body)}</div><div style="display:flex;gap:20px;margin-top:46px"><div class="ui-btn" style="flex:1;height:100px;background:#eff1f5;color:var(--gry);font-size:33px">{E(cancel)}</div><div class="ui-btn ok" style="flex:1;height:100px;background:linear-gradient(90deg,var(--b1),var(--b2));color:#fff;font-size:33px">{E(ok)}</div></div></div>', "left:0;top:0;width:1080px;height:1920px;z-index:10")
    b.js(f'tl.fromTo("#{i} .ui-dim",{{opacity:0}},{{opacity:1,duration:.5,ease:"power2.out"}},{t:.3f});tl.to("#{i} .ui-dim",{{opacity:0,duration:.4}},{t + d - .42:.3f});')
    _in(b, f"#{i} .md", t + .12, y=28, sc=.97); _out(b, f"#{i} .md", t + d, y=10)
    b.js(f'tl.to("#{i} .ok",{{scale:.96,duration:.16,ease:"power2.out"}},{at:.3f});tl.to("#{i} .ok",{{scale:1,duration:.28,ease:"expo.out"}},{at + .18:.3f});')

def bottomsheet(b, t, d, title, rows, top=980, stagger=.15):
    rh = "".join(f'<div class="r{k} ui-row" style="height:96px;border-top:1.5px solid #eceef3;font-size:34px"><span style="color:var(--gry)">{E(a)}</span><span style="font-weight:900">{E(v)}</span></div>' for k, (a, v) in enumerate(rows))
    h = 200 + 96 * len(rows) + 120
    i = b.clip(t, d, f'<div class="ui-dim"></div><div class="sh" style="position:absolute;left:0;top:{top}px;width:1080px;height:{h + 400}px;background:#fff;border-radius:46px 46px 0 0;box-shadow:0 -20px 60px rgba(40,50,80,.14);padding:30px 80px"><div style="width:84px;height:8px;border-radius:4px;background:#d7dbe3;margin:0 auto 44px"></div><div style="font-weight:900;font-size:44px;margin-bottom:26px">{E(title)}</div>{rh}</div>', "left:0;top:0;width:1080px;height:1920px;z-index:10")
    b.js(f'tl.fromTo("#{i} .ui-dim",{{opacity:0}},{{opacity:.65,duration:.5}},{t:.3f});tl.to("#{i} .ui-dim",{{opacity:0,duration:.4}},{t + d - .42:.3f});')
    b.js(f'tl.fromTo("#{i} .sh",{{y:860}},{{y:0,duration:.8,ease:"expo.out"}},{t:.3f});tl.to("#{i} .sh",{{y:860,duration:.45,ease:"power2.in"}},{t + d - .47:.3f});')
    for k in range(len(rows)): _in(b, f"#{i} .r{k}", t + .45 + stagger * k, d=.55, y=20)

def inlineerror(b, t, d, label, value, error, fixed=None, box=(140, 520, 800, 0), at=None, fix_at=None):
    x, y, w, _ = box; at = t + .85 if at is None else at; fix_at = at + 1.5 if fix_at is None else fix_at
    fx = f'<span class="fv" style="position:absolute;left:40px;top:62px;opacity:0;font-size:38px;font-weight:700">{E(fixed)}</span>' if fixed else ""
    i = b.clip(t, d, f'<div style="font-size:26px;color:var(--gry);font-weight:700;margin:0 0 14px 8px">{E(label)}</div><div class="ui-field fd" style="position:relative;width:{w}px;height:128px"><span class="v0" style="position:absolute;left:40px;top:38px;font-size:38px;font-weight:700">{E(value)}</span>{fx}<span class="ck ui-ico" style="position:absolute;right:34px;top:34px;width:58px;height:58px;background:var(--b1);color:#fff;font-size:30px;opacity:0">✓</span></div><div class="er" style="margin:16px 0 0 8px;font-size:26px;color:#7c4dff;font-weight:700;opacity:0">{E(error)}</div>', f"left:{x}px;top:{y}px;width:{w}px;height:300px")
    _in(b, f"#{i}", t); _out(b, f"#{i}", t + d)
    b.js(f'tl.to("#{i} .fd",{{borderColor:"#7c4dff",duration:.35}},{at:.3f});tl.fromTo("#{i} .er",{{opacity:0,y:-8}},{{opacity:1,y:0,duration:.45,ease:"expo.out"}},{at:.3f});')
    if fixed:
        b.js(f'tl.to("#{i} .v0",{{opacity:0,duration:.25}},{fix_at:.3f});tl.fromTo("#{i} .fv",{{opacity:0,y:10}},{{opacity:1,y:-24,duration:.48,ease:"expo.out"}},{fix_at + .18:.3f});tl.to("#{i} .fd",{{borderColor:"#245cff",duration:.35}},{fix_at + .18:.3f});tl.to("#{i} .er",{{opacity:0,duration:.25}},{fix_at:.3f});tl.fromTo("#{i} .ck",{{opacity:0,scale:.7}},{{opacity:1,scale:1,duration:.5,ease:"expo.out"}},{fix_at + .42:.3f});')

def tooltip(b, t, d, x, y, text, side="top", at=None):
    at = t + .45 if at is None else at; up = side == "top"
    tw = 44 + 29 * len(text)
    bx, by = max(40, min(1040 - tw, x - tw / 2)), (y - 148 if up else y + 48)
    ar = f'<i style="position:absolute;left:{x - bx - 14}px;{"bottom:-14px" if up else "top:-14px"};border-left:14px solid transparent;border-right:14px solid transparent;{"border-top" if up else "border-bottom"}:16px solid rgba(20,22,28,.94)"></i>'
    i = b.clip(t, d, f'<div class="dot" style="position:absolute;left:{x - 15}px;top:{y - 15}px;width:30px;height:30px;border-radius:50%;background:var(--b1)"></div><div class="rp" style="position:absolute;left:{x - 15}px;top:{y - 15}px;width:30px;height:30px;border-radius:50%;border:2.5px solid var(--b1)"></div><div class="tt ui-dark" style="position:absolute;left:{bx}px;top:{by}px;width:{tw}px;height:96px;border-radius:22px;display:flex;align-items:center;justify-content:center;font-size:32px;font-weight:700">{E(text)}{ar}</div>', "left:0;top:0;width:1080px;height:1920px")
    _in(b, f"#{i} .dot", t, y=0, sc=.5); _out(b, f"#{i} .dot", t + d, y=0)
    b.js(f'tl.fromTo("#{i} .rp",{{scale:1,opacity:.75}},{{scale:3.0,opacity:0,duration:1.6,ease:"power2.out",repeat:{max(0, int(d / 1.6) - 1)}}},{t + .2:.3f});')
    _in(b, f"#{i} .tt", at, y=(16 if up else -16)); _out(b, f"#{i} .tt", t + d, y=0)

def coachmark(b, t, d, cx, cy, r, title, text, step="1 / 3", card_y=None):
    card_y = cy + r + 60 if card_y is None else card_y
    i = b.clip(t, d, f'<div class="sp" style="position:absolute;left:{cx - r}px;top:{cy - r}px;width:{2 * r}px;height:{2 * r}px;border-radius:50%;box-shadow:0 0 0 2400px rgba(14,16,24,.58);border:3px solid rgba(255,255,255,.9)"></div><div class="cm card" style="left:110px;top:{card_y}px;width:860px;padding:44px 50px;border-radius:36px"><div class="tag" style="color:var(--b1)">{E(step)}</div><div style="font-weight:900;font-size:42px;margin-top:10px">{E(title)}</div><div style="font-size:29px;color:var(--gry);margin-top:12px;line-height:1.5">{E(text)}</div></div>', "left:0;top:0;width:1080px;height:1920px;z-index:10")
    b.js(f'tl.fromTo("#{i} .sp",{{opacity:0,scale:2.2}},{{opacity:1,scale:1,duration:.9,ease:"expo.out"}},{t:.3f});tl.to("#{i} .sp",{{scale:1.05,duration:1.4,yoyo:true,repeat:{max(1, int(d / 1.4) - 2)},ease:"sine.inOut"}},{t + .9:.3f});tl.to("#{i} .sp",{{opacity:0,duration:.4}},{t + d - .42:.3f});')
    _in(b, f"#{i} .cm", t + .4); _out(b, f"#{i} .cm", t + d)

def badge(b, t, d, x, y, text="NEW", count=None, at=None):
    at = t if at is None else at
    inner = f'<span class="n">0</span>' if count is not None else E(text)
    i = b.clip(t, d, f'<div class="bg" style="position:absolute;left:0;top:0;height:62px;min-width:62px;padding:0 22px;border-radius:31px;background:linear-gradient(90deg,var(--b1),var(--b2));color:#fff;font-weight:900;font-size:30px;display:flex;align-items:center;justify-content:center;box-shadow:0 10px 24px rgba(36,92,255,.28)">{inner}</div>', f"left:{x}px;top:{y}px;width:300px;height:80px")
    _in(b, f"#{i} .bg", at, y=0, sc=.6); _out(b, f"#{i} .bg", t + d, y=0)
    if count is not None: _count(b, f"#{i} .n", 0, count, at + .18, 1.0)

def spinner(b, t, d, label="분석 중", y=640, done=None, done_at=None):
    done_at = t + d - 1.4 if done_at is None else done_at
    dn = f'<div class="dn" style="position:absolute;top:0;left:0;width:100%;text-align:center;opacity:0"><span class="ui-ico" style="width:144px;height:144px;background:linear-gradient(135deg,var(--b1),var(--b2));color:#fff;font-size:74px">✓</span><div style="font-weight:900;font-size:42px;margin-top:38px">{E(done)}</div></div>' if done else ""
    i = b.clip(t, d, f'<div class="sp" style="position:absolute;left:468px;top:0;width:144px;height:144px;border-radius:50%;border:11px solid #e7eaf1;border-top-color:var(--b1);border-right-color:var(--b2)"></div><div class="lb" style="position:absolute;top:186px;width:100%;text-align:center;font-weight:700;font-size:36px;color:var(--gry)">{E(label)}<span class="d1">.</span><span class="d2">.</span><span class="d3">.</span></div>{dn}', f"left:0;top:{y}px;width:1080px;height:340px")
    _in(b, f"#{i} .sp", t, y=0, sc=.75); _in(b, f"#{i} .lb", t + .18, y=14)
    b.js(f'tl.to("#{i} .sp",{{rotation:360*{max(1, int(d / .9))},duration:{d},ease:"none"}},{t:.3f});')
    for k in (1, 2, 3): b.js(f'tl.fromTo("#{i} .d{k}",{{opacity:.15}},{{opacity:1,duration:.4,yoyo:true,repeat:{max(1, int(d / .8))},ease:"sine.inOut"}},{t + .15 * k:.3f});')
    if done:
        b.js(f'tl.to(["#{i} .sp","#{i} .lb"],{{opacity:0,duration:.35}},{done_at:.3f});tl.fromTo("#{i} .dn",{{opacity:0,y:18}},{{opacity:1,y:0,duration:.65,ease:"expo.out"}},{done_at + .25:.3f});')
    _out(b, f"#{i}", t + d)

def skeleton(b, t, d, box, title, lines, at=None, img=True, _ghost=False):
    x, y, w, h = box; at = t + 1.3 if at is None else at
    sk = (f'<div class="ui-sk" style="left:40px;top:40px;width:{w - 80}px;height:{h * .42:.0f}px;border-radius:26px"></div>' if img else "") + "".join(
        f'<div class="ui-sk" style="left:40px;top:{(h * .42 + 80 if img else 50) + k * 62:.0f}px;width:{(w - 80) * (0.9 if k == 0 else 0.7 - 0.12 * (k % 2)):.0f}px;height:{38 if k == 0 else 28}px"></div>' for k in range(len(lines) + 1))
    ct = (f'<div style="position:absolute;left:40px;top:40px;width:{w - 80}px;height:{h * .42:.0f}px;border-radius:26px;background:linear-gradient(135deg,#e6ecff,#efe6ff)"></div>' if img else "") + f'<div style="position:absolute;left:40px;top:{h * .42 + 70 if img else 44:.0f}px;width:{w - 80}px"><div style="font-weight:900;font-size:42px">{E(title)}</div>' + "".join(f'<div style="font-size:29px;color:var(--gry);margin-top:14px">{E(s)}</div>' for s in lines) + "</div>"
    i = b.clip(t, d, f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px;overflow:hidden"><div class="sk">{sk}</div><div class="ct" style="opacity:0">{ct}</div></div>', f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, float_=False, ghost=_ghost)
    b.js(f'tl.fromTo("#{i} .ui-sk",{{backgroundPosition:"100% 0"}},{{backgroundPosition:"-100% 0",duration:1.1,repeat:{max(1, int((at - t) / 1.1))},ease:"none"}},{t:.3f});tl.to("#{i} .sk",{{opacity:0,duration:.45}},{at:.3f});tl.fromTo("#{i} .ct",{{opacity:0,y:12}},{{opacity:1,y:0,duration:.6,ease:"expo.out"}},{at + .12:.3f});')

def progress(b, t, d, box, label, pct=100, steps=None, at=None, dur=2.2, _ghost=False):
    x, y, w, h = box; at = t + .35 if at is None else at
    st = ""
    if steps:
        st = f'<div style="position:absolute;left:52px;top:198px;width:{w - 104}px;display:flex;justify-content:space-between">' + "".join(f'<div class="s{k}" style="text-align:center;font-size:27px;font-weight:700;color:var(--lgt)"><div class="sd" style="width:24px;height:24px;border-radius:50%;background:#e3e6ee;margin:0 auto 14px"></div>{E(s)}</div>' for k, s in enumerate(steps)) + "</div>"
    i = b.clip(t, d, f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px"><div class="ui-row" style="position:absolute;left:52px;top:44px;width:{w - 104}px"><span class="tag">{E(label)}</span><span style="font-weight:900;font-size:50px" class="gt g-b tnum"><span class="n">0</span>%</span></div><div style="position:absolute;left:52px;top:128px;width:{w - 104}px;height:18px;border-radius:9px;background:var(--trk);overflow:hidden"><div class="fl" style="width:0%;height:100%;border-radius:9px;background:linear-gradient(90deg,var(--b1),var(--b2))"></div></div>{st}</div>', f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, float_=False, ghost=_ghost)
    b.js(f'tl.to("#{i} .fl",{{width:"{pct:.1f}%",duration:{dur},ease:"expo.out"}},{at:.3f});'); _count(b, f"#{i} .n", 0, pct, at, dur)
    if steps:
        for k in range(len(steps)):
            tk = at + dur * (k + .4) / len(steps)
            b.js(f'tl.to("#{i} .s{k}",{{color:"#14161c",duration:.35}},{tk:.3f});tl.to("#{i} .s{k} .sd",{{backgroundColor:"#245cff",scale:1.15,duration:.45,ease:"expo.out"}},{tk:.3f});')

def inputfield(b, t, d, box, label, text, cps=12, at=None, ok=True):
    x, y, w, _ = box; at = t + .55 if at is None else at
    i = b.clip(t, d, f'<div class="ui-field fd" style="left:0;top:0;width:{w}px;height:148px"><span class="lb" style="position:absolute;left:40px;top:50px;font-size:36px;color:var(--gry);transform-origin:left top">{E(label)}</span><span class="tx" style="position:absolute;left:40px;top:68px;font-size:40px;font-weight:700"></span><span class="cu" style="position:absolute;top:70px;width:3.5px;height:46px;background:var(--b1);opacity:0"></span><span class="ck ui-ico" style="position:absolute;right:36px;top:44px;width:60px;height:60px;background:var(--b1);color:#fff;font-size:30px;opacity:0">✓</span></div>', f"left:{x}px;top:{y}px;width:{w}px;height:160px")
    _in(b, f"#{i} .fd", t); _out(b, f"#{i} .fd", t + d)
    b.js(f'tl.to("#{i} .fd",{{borderColor:"#245cff",boxShadow:"0 0 0 8px rgba(36,92,255,.10)",duration:.35}},{at:.3f});tl.to("#{i} .lb",{{y:-32,scale:.68,color:"#245cff",duration:.45,ease:"expo.out"}},{at:.3f});tl.to("#{i} .cu",{{opacity:1,duration:.2}},{at + .25:.3f});')
    s = json.dumps(text, ensure_ascii=False); T = len(text) / cps
    b.js(f'(function(){{const o={{n:0}};const el=document.querySelector("#{i} .tx");const cu=document.querySelector("#{i} .cu");const s={s};tl.to(o,{{n:s.length,duration:{T:.2f},ease:"none",onUpdate:()=>{{el.textContent=s.slice(0,Math.round(o.n));cu.style.left=(44+el.offsetWidth)+"px";}}}},{at + .45:.3f});}})();')
    if ok: b.js(f'tl.to("#{i} .cu",{{opacity:0,duration:.2}},{at + .55 + T:.3f});tl.fromTo("#{i} .ck",{{opacity:0,scale:.65}},{{opacity:1,scale:1,duration:.5,ease:"expo.out"}},{at + .65 + T:.3f});')

def toggles(b, t, d, box, items, title=None):
    x, y, w, _ = box; th = f'<div class="tag" style="padding:40px 50px 10px">{E(title)}</div>' if title else ""
    rows = "".join(f'<div class="ui-row" style="height:118px;padding:0 50px;border-top:{0 if k == 0 and not title else 1.5}px solid #eceef3;font-size:35px;font-weight:700"><span>{E(a)}</span><span class="tg{k}" style="position:relative;width:116px;height:66px;border-radius:33px;background:#dfe2ea"><i class="kn" style="position:absolute;left:6px;top:6px;width:54px;height:54px;border-radius:50%;background:#fff;box-shadow:0 4px 10px rgba(0,0,0,.14)"></i></span></div>' for k, (a, _) in enumerate(items))
    h = (90 if title else 0) + 118 * len(items) + 20
    i = b.clip(t, d, f'<div class="card" style="left:0;top:0;width:{w}px;height:{h}px">{th}{rows}</div>', f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    _in(b, f"#{i} .card", t); _out(b, f"#{i} .card", t + d)
    for k, (_, tk) in enumerate(items):
        b.js(f'tl.to("#{i} .tg{k}",{{backgroundColor:"#245cff",duration:.42,ease:"expo.out"}},{tk:.3f});tl.to("#{i} .tg{k} .kn",{{x:50,duration:.42,ease:"expo.out"}},{tk:.3f});')

def segmented(b, t, d, options, seq, y=520, w=900):
    n = len(options); cw = (w - 20) / n
    opts = "".join(f'<div class="o{k}" style="position:absolute;left:{10 + k * cw:.0f}px;top:10px;width:{cw:.0f}px;height:100px;display:flex;align-items:center;justify-content:center;font-size:33px;font-weight:700;color:var(--gry)">{E(o)}</div>' for k, o in enumerate(options))
    i = b.clip(t, d, f'<div class="sg" style="position:absolute;left:{(1080 - w) / 2:.0f}px;top:0;width:{w}px;height:120px;border-radius:60px;background:#e9ecf2"><div class="ind" style="position:absolute;left:10px;top:10px;width:{cw:.0f}px;height:100px;border-radius:50px;background:#fff;box-shadow:0 8px 20px rgba(40,50,80,.12)"></div>{opts}</div>', f"left:0;top:{y}px;width:1080px;height:130px")
    _in(b, f"#{i} .sg", t); _out(b, f"#{i} .sg", t + d)
    k0 = seq[0][0] if seq else 0
    b.js(f'tl.set("#{i} .ind",{{x:{k0 * cw:.0f}}},{t:.3f});tl.set("#{i} .o{k0}",{{color:"#245cff"}},{t:.3f});')
    prev = k0
    for k, tk in seq[1:]:
        b.js(f'tl.to("#{i} .ind",{{x:{k * cw:.0f},duration:.55,ease:"expo.out"}},{tk:.3f});tl.to("#{i} .o{prev}",{{color:"#727785",duration:.35}},{tk:.3f});tl.to("#{i} .o{k}",{{color:"#245cff",duration:.35}},{tk + .15:.3f});'); prev = k

def rangeslider(b, t, d, box, label, vmin, vmax, value, unit="", at=None, start=None):
    x, y, w, _ = box; at = t + .45 if at is None else at; start = vmin if start is None else start
    L = w - 120; p0 = (start - vmin) / (vmax - vmin); p1 = (value - vmin) / (vmax - vmin)
    i = b.clip(t, d, f'<div class="card" style="left:0;top:0;width:{w}px;height:280px"><div class="ui-row" style="position:absolute;left:60px;top:46px;width:{L}px"><span class="tag">{E(label)}</span><span style="font-weight:900;font-size:58px" class="gt g-b tnum"><span class="n">{start}</span>{E(unit)}</span></div><div style="position:absolute;left:60px;top:176px;width:{L}px;height:14px;border-radius:7px;background:var(--trk)"><div class="fl" style="width:{p0 * 100:.1f}%;height:100%;border-radius:7px;background:linear-gradient(90deg,var(--b1),var(--b2))"></div><div class="kb" style="position:absolute;left:-28px;top:-21px;width:56px;height:56px;border-radius:50%;background:#fff;border:4px solid var(--b1);box-shadow:0 6px 16px rgba(36,92,255,.26);transform:translateX({p0 * L:.0f}px)"></div></div><div class="ui-row tnum" style="position:absolute;left:60px;top:214px;width:{L}px;font-size:23px;color:var(--lgt);font-weight:700"><span>{vmin}{E(unit)}</span><span>{vmax}{E(unit)}</span></div></div>', f"left:{x}px;top:{y}px;width:{w}px;height:290px")
    _in(b, f"#{i} .card", t); _out(b, f"#{i} .card", t + d)
    b.js(f'tl.to("#{i} .fl",{{width:"{p1 * 100:.1f}%",duration:1.45,ease:"expo.out"}},{at:.3f});tl.to("#{i} .kb",{{x:{p1 * L:.0f},duration:1.45,ease:"expo.out"}},{at:.3f});'); _count(b, f"#{i} .n", start, value, at, 1.45)

def chat(b, t, d, msgs, top=380, cps=22):
    y = 0; html = ""; js = []
    for k, (who, txt, tk) in enumerate(msgs):
        me = who == "user"; lines = max(1, int(len(txt) / 15) + 1); hgt = 60 + 52 * lines
        st = "right:72px;background:linear-gradient(90deg,var(--b1),var(--b2));color:#fff;border-radius:38px 38px 10px 38px" if me else "left:72px;background:#fff;color:var(--ink);border-radius:38px 38px 38px 10px;box-shadow:0 14px 34px rgba(40,50,80,.10)"
        av = "" if me else f'<div class="av{k} tag" style="position:absolute;left:76px;top:{y}px;font-size:21px;color:var(--b1)">AI</div>'
        yy = y + (0 if me else 38)
        html += av + f'<div class="m{k}" style="position:absolute;top:{yy}px;{st};max-width:760px;padding:28px 38px;font-size:35px;font-weight:700;line-height:1.45"><span class="tx">{"" if not me else E(txt)}</span>' + ("" if me else '<span class="dots" style="letter-spacing:8px">● ● ●</span>') + "</div>"
        _in(b, f"#__ID__ .m{k}", tk, d=.55, y=22)
        if not me:
            _in(b, f"#__ID__ .av{k}", tk, d=.45, y=8)
            js.append((k, txt, tk))
        y = yy + hgt + 32
    i = b.clip(t, d, html, f"left:0;top:{top}px;width:1080px;height:{y + 40}px")
    b.j = [s.replace("__ID__", i) for s in b.j]
    for k, txt, tk in js:
        s = json.dumps(txt, ensure_ascii=False); T = len(txt) / cps
        b.js(f'tl.fromTo("#{i} .m{k} .dots",{{opacity:.25}},{{opacity:1,duration:.38,yoyo:true,repeat:3,ease:"sine.inOut"}},{tk + .1:.3f});tl.to("#{i} .m{k} .dots",{{opacity:0,duration:.01}},{tk + 1.2:.3f});tl.set("#{i} .m{k} .dots",{{display:"none"}},{tk + 1.22:.3f});')
        b.js(f'(function(){{const o={{n:0}};const el=document.querySelector("#{i} .m{k} .tx");const s={s};tl.to(o,{{n:s.length,duration:{T:.2f},ease:"none",onUpdate:()=>el.textContent=s.slice(0,Math.round(o.n))}},{tk + 1.25:.3f});}})();')
    _out(b, f"#{i}", t + d)

def emptystate(b, t, d, title, sub, btn=None, y=560, icon="⌕"):
    bt = f'<div class="bt ui-btn" style="margin:44px auto 0;width:400px;height:104px;background:linear-gradient(90deg,var(--b1),var(--b2));color:#fff;font-size:34px">{E(btn)}</div>' if btn else ""
    i = b.clip(t, d, f'<div class="ic ui-ico" style="display:flex;margin:0 auto;width:210px;height:210px;background:#eef1f7;color:#a9b0c0;font-size:112px">{E(icon)}</div><div class="t1" style="text-align:center;font-weight:900;font-size:48px;margin-top:46px">{E(title)}</div><div class="t2" style="text-align:center;font-size:31px;color:var(--gry);margin-top:16px;line-height:1.5">{E(sub)}</div>{bt}', f"left:0;top:{y}px;width:1080px;height:700px")
    _in(b, f"#{i} .ic", t, y=20, sc=.9); _in(b, f"#{i} .t1", t + .24); _in(b, f"#{i} .t2", t + .4)
    if btn: _in(b, f"#{i} .bt", t + .65)
    b.js(f'tl.to("#{i} .ic",{{y:-6,duration:2.2,yoyo:true,repeat:{max(1, int(d / 2.2))},ease:"sine.inOut"}},{t + .8:.3f});'); _out(b, f"#{i}", t + d)

def tap(b, t, d, x, y, at=None, n=1):
    at = t if at is None else at
    i = b.clip(t, d, f'<div class="f" style="position:absolute;left:-38px;top:-38px;width:76px;height:76px;border-radius:50%;background:rgba(36,92,255,.26);border:3px solid rgba(255,255,255,.9)"></div><div class="w" style="position:absolute;left:-38px;top:-38px;width:76px;height:76px;border-radius:50%;border:2.5px solid var(--b1)"></div>', f"left:{x}px;top:{y}px;width:1px;height:1px")
    for k in range(n):
        tk = at + k * .85
        b.js(f'tl.fromTo("#{i} .f",{{opacity:0,scale:1.25}},{{opacity:1,scale:.88,duration:.28,ease:"expo.out"}},{tk:.3f});tl.to("#{i} .f",{{opacity:0,scale:1,duration:.38}},{tk + .42:.3f});tl.fromTo("#{i} .w",{{opacity:.85,scale:.8}},{{opacity:0,scale:2.7,duration:.85,ease:"expo.out"}},{tk + .08:.3f});')

def swipecards(b, t, d, cards, y=420, h=560, dwell=1.6):
    n = len(cards)
    html = "".join(f'<div class="cd{k} card" style="left:140px;top:{k * 20}px;width:800px;height:{h}px;z-index:{n - k};padding:58px;transform:scale({1 - .045 * k})"><div class="tag">{k + 1:02d} / {n:02d}</div><div style="font-weight:900;font-size:54px;margin-top:28px">{gtext(a, "b")}</div><div style="font-size:31px;color:var(--gry);margin-top:22px;line-height:1.5">{E(s)}</div></div>' for k, (a, s) in enumerate(cards))
    i = b.clip(t, d, html, f"left:0;top:{y}px;width:1080px;height:{h + 120}px")
    _in(b, f"#{i}", t); _out(b, f"#{i}", t + d)
    for k in range(n - 1):
        tk = t + .8 + dwell * (k + 1) - .6
        b.js(f'tl.to("#{i} .cd{k}",{{x:-1100,rotation:-11,opacity:0,duration:.75,ease:"power3.in"}},{tk:.3f});')
        for j in range(k + 1, n): b.js(f'tl.to("#{i} .cd{j}",{{y:{-20 * (k + 1)},scale:{1 - .045 * (j - k - 1)},duration:.65,ease:"expo.out"}},{tk + .25:.3f});')

def tabbar(b, t, d, tabs, seq, y=1170, icons=None):
    n = len(tabs); w = 936; cw = w / n; icons = icons or ["●"] * n
    opts = "".join(f'<div class="o{k}" style="position:absolute;left:{k * cw:.0f}px;top:0;width:{cw:.0f}px;height:146px;text-align:center;color:var(--lgt);font-weight:700;font-size:25px;padding-top:28px"><div style="font-size:38px;margin-bottom:10px">{E(icons[k])}</div>{E(tb)}</div>' for k, tb in enumerate(tabs))
    i = b.clip(t, d, f'<div class="tb card" style="left:72px;top:0;width:{w}px;height:146px;border-radius:42px"><div class="ind" style="position:absolute;left:{cw / 2 - 28:.0f}px;top:0;width:56px;height:5px;border-radius:3px;background:var(--b1)"></div>{opts}</div>', f"left:0;top:{y}px;width:1080px;height:166px")
    _in(b, f"#{i} .tb", t, y=54); _out(b, f"#{i} .tb", t + d, y=36)
    k0 = seq[0][0] if seq else 0
    b.js(f'tl.set("#{i} .ind",{{x:{k0 * cw:.0f}}},{t:.3f});tl.set("#{i} .o{k0}",{{color:"#245cff"}},{t:.3f});'); prev = k0
    for k, tk in seq[1:]:
        b.js(f'tl.to("#{i} .ind",{{x:{k * cw:.0f},duration:.55,ease:"expo.out"}},{tk:.3f});tl.to("#{i} .o{prev}",{{color:"#c5cad6",duration:.35}},{tk:.3f});tl.to("#{i} .o{k}",{{color:"#245cff",duration:.35}},{tk + .15:.3f});'); prev = k

def carousel(b, t, d, box, slides, dwell=1.8):
    x, y, w, h = box; n = len(slides)
    sl = ""
    for k, (a, s, img) in enumerate(slides):
        top = f'<div style="height:{h * .55:.0f}px;border-radius:28px;overflow:hidden;background:linear-gradient(135deg,#e6ecff,#efe6ff)">' + (f'<img src="assets/{img}" style="width:100%;height:100%;object-fit:cover">' if img else "") + "</div>"
        sl += f'<div class="card" style="left:{k * (w + 40)}px;top:0;width:{w}px;height:{h}px;padding:30px">{top}<div style="font-weight:900;font-size:44px;margin-top:32px">{E(a)}</div><div style="font-size:29px;color:var(--gry);margin-top:12px">{E(s)}</div></div>'
    dots = "".join(f'<i class="dt{k}" style="display:inline-block;width:14px;height:14px;border-radius:7px;margin:0 7px;background:{"#245cff" if k == 0 else "#d5d9e2"}"></i>' for k in range(n))
    i = b.clip(t, d, f'<div class="tr" style="position:absolute;left:40px;top:40px;width:{n * (w + 40)}px;height:{h}px">{sl}</div><div style="position:absolute;left:40px;top:{h + 68}px;width:{w}px;text-align:center">{dots}</div>', f"left:{x - 40}px;top:{y - 40}px;width:{w + 80}px;height:{h + 140}px;overflow:hidden;padding:40px")
    _in(b, f"#{i}", t); _out(b, f"#{i}", t + d)
    for k in range(1, n):
        tk = t + .8 + dwell * k - .6
        b.js(f'tl.to("#{i} .tr",{{x:{-k * (w + 40)},duration:.75,ease:"power3.inOut"}},{tk:.3f});tl.to("#{i} .dt{k - 1}",{{backgroundColor:"#d5d9e2",width:14,duration:.35}},{tk:.3f});tl.to("#{i} .dt{k}",{{backgroundColor:"#245cff",width:38,duration:.45}},{tk + .18:.3f});')
    b.js(f'tl.set("#{i} .dt0",{{width:38}},{t:.3f});')

def dropdown(b, t, d, box, label, options, pick, at=None):
    x, y, w, _ = box; at = t + .45 if at is None else at; n = len(options)
    li = "".join(f'<div class="li{k} ui-row" style="height:98px;padding:0 44px;font-size:33px;font-weight:700;color:var(--ink)"><span>{E(o)}</span><span class="tk" style="color:var(--b1);opacity:0">✓</span></div>' for k, o in enumerate(options))
    i = b.clip(t, d, f'<div style="font-size:26px;color:var(--gry);font-weight:700;margin:0 0 14px 8px">{E(label)}</div><div class="ui-field fd" style="position:relative;width:{w}px;height:118px;display:flex;align-items:center;padding:0 44px;font-size:36px;font-weight:700"><span class="vl" style="color:var(--lgt)">선택</span><span class="cv" style="position:absolute;right:44px;font-size:28px;color:var(--gry)">▼</span></div><div class="ls card" style="position:relative;left:0;top:14px;width:{w}px;border-radius:26px;overflow:hidden;transform-origin:top;padding:10px 0">{li}</div>', f"left:{x}px;top:{y}px;width:{w}px;height:{200 + 98 * n}px")
    _in(b, f"#{i}", t); _out(b, f"#{i}", t + d)
    b.js(f'tl.set("#{i} .ls",{{opacity:0,scaleY:.92}},{t:.3f});tl.to("#{i} .fd",{{borderColor:"#245cff",duration:.3}},{at:.3f});tl.to("#{i} .cv",{{rotation:180,duration:.38}},{at:.3f});tl.to("#{i} .ls",{{opacity:1,scaleY:1,duration:.48,ease:"expo.out"}},{at + .08:.3f});')
    hk = at + .65
    b.js(f'tl.to("#{i} .li{pick}",{{backgroundColor:"#eef2ff",duration:.32}},{hk:.3f});tl.to("#{i} .li{pick} .tk",{{opacity:1,duration:.28}},{hk + .18:.3f});')
    s = json.dumps(options[pick], ensure_ascii=False)
    b.js(f'tl.to("#{i} .ls",{{opacity:0,scaleY:.94,duration:.36,ease:"power2.in"}},{hk + .75:.3f});tl.to("#{i} .cv",{{rotation:0,duration:.36}},{hk + .75:.3f});tl.to("#{i} .vl",{{opacity:0,duration:.14}},{hk + .84:.3f});(function(){{const el=document.querySelector("#{i} .vl");tl.set(el,{{textContent:{s},color:"#14161c"}},{hk + .98:.3f});}})();tl.to("#{i} .vl",{{opacity:1,duration:.28}},{hk + 1.0:.3f});')


# ───────── 그림 부품 (2026-11-25 · 장면마다 다른 그림이 나오도록) ─────────
# 예전에 장면마다 직접 그리던 개념도(보온병 · 온도 곡선 · 필름 단면 · 파장 곡선 · 차량 평면도 · 열 흐름 · 세로 막대 · 게이지 · 도넛)를 부품으로.
# 색: 블루(#245cff) · 보라(#7c4dff) · 무채색만. 모든 선은 서서히 그려지고 숫자는 0부터 올라간다.
def _plen(P):
    return sum(((P[k][0] - P[k - 1][0]) ** 2 + (P[k][1] - P[k - 1][1]) ** 2) ** .5 for k in range(1, len(P)))

def _path(P):
    return "M%.1f %.1f " % P[0] + " ".join("L%.1f %.1f" % p for p in P[1:])

def _icard(b, t, d, box, svg, tag="", title="", extra=""):
    x, y, w, h = box
    hd = (f'<div class="tag" style="position:absolute;left:54px;top:38px;color:var(--b1)">{E(tag)}</div>' if tag else "") + \
         (f'<div style="position:absolute;left:54px;top:{70 if tag else 40}px;font-weight:900;font-size:36px;letter-spacing:-.035em">{E(title)}</div>' if title else "")
    i = b.clip(t, d, f'<div class="card" style="left:0;top:0;width:{w}px;height:{h}px;overflow:hidden">{svg}{hd}{extra}</div>', f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, float_=False)
    return i

_ARROW = '<marker id="{id}" viewBox="0 0 10 10" refX="7" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" fill="{c}"/></marker>'

def _draw(b, sel, L, at, dur=.9, ease="power2.inOut"):
    b.js(f'tl.fromTo("{sel}",{{strokeDashoffset:{L:.0f}}},{{strokeDashoffset:0,duration:{dur},ease:"{ease}"}},{at:.3f});')

def thermos(b, t, d, box=(84, 300, 912, 640), mode="winter", tag="THERMOS PRINCIPLE", title="", inside="실내 온기", outside="바깥 냉기", note="", at=None):
    """보온병 단면: 안쪽 금속 코팅이 열을 되돌려 보낸다. mode=winter(안의 온기가 밖으로 못 나감) · summer(밖의 열기가 안으로 못 들어옴)"""
    x, y, w, h = box; at = t + .5 if at is None else at
    cx = w / 2; top = 150; bot = h - 60; bw = 230
    mk = b.id("mk"); mk2 = b.id("mk")
    body = (f'<rect x="{cx - bw / 2}" y="{top + 40}" width="{bw}" height="{bot - top - 40}" rx="46" fill="#f6f8fc" stroke="#c9cfdc" stroke-width="4"/>'
            f'<rect class="mt" x="{cx - bw / 2 + 18}" y="{top + 58}" width="{bw - 36}" height="{bot - top - 76}" rx="34" fill="none" stroke="url(#{mk}g)" stroke-width="9" stroke-dasharray="2000" stroke-dashoffset="2000"/>'
            f'<rect x="{cx - 70}" y="{top}" width="140" height="48" rx="14" fill="#dfe4ee"/>')
    arrows = []; L = 0
    for k in range(3):
        yy = top + 120 + k * (bot - top - 200) / 2
        if mode == "winter":
            for s in (-1, 1):
                P = [(cx + s * 30, yy), (cx + s * (bw / 2 - 26), yy + 18), (cx + s * 40, yy + 46)]
                arrows.append((P, "#7c4dff"))
        else:
            for s in (-1, 1):
                P = [(cx + s * (bw / 2 + 170), yy - 10), (cx + s * (bw / 2 + 4), yy + 12), (cx + s * (bw / 2 + 150), yy + 46)]
                arrows.append((P, "#7c4dff"))
    asvg = ""
    for n, (P, c) in enumerate(arrows):
        Ln = _plen(P) + 10; L = max(L, Ln)
        asvg += f'<path class="ar{n}" d="{_path(P)}" fill="none" stroke="{c}" stroke-width="5" stroke-linecap="round" stroke-linejoin="round" marker-end="url(#{mk2})" stroke-dasharray="{Ln:.0f}" stroke-dashoffset="{Ln:.0f}"/>'
    glow = f'<circle class="gw" cx="{cx}" cy="{(top + bot) / 2 + 20}" r="{bw / 2 - 40}" fill="url(#{mk}r)" opacity="0"/>' if mode == "winter" else ""
    svg = (f'<svg width="{w}" height="{h}" style="position:absolute;left:0;top:0"><defs>'
           f'<linearGradient id="{mk}g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#9fb4e8"/><stop offset=".5" stop-color="#245cff"/><stop offset="1" stop-color="#b9c6ea"/></linearGradient>'
           f'<radialGradient id="{mk}r"><stop offset="0" stop-color="#7c4dff" stop-opacity=".22"/><stop offset="1" stop-color="#7c4dff" stop-opacity="0"/></radialGradient>'
           + _ARROW.format(id=mk2, c="#7c4dff") + f'</defs>{glow}{body}{asvg}</svg>')
    lab = (f'<div class="lb" style="position:absolute;left:54px;bottom:54px;font-weight:700;font-size:28px;color:var(--gry)">{E(outside)}</div>'
           f'<div class="lb" style="position:absolute;right:54px;bottom:54px;font-weight:900;font-size:30px;color:var(--b2)">{E(inside)}</div>'
           f'<div class="lb" style="position:absolute;left:{cx + bw / 2 + 24}px;top:{top + 70}px;padding:6px 16px;border-radius:99px;background:rgba(36,92,255,.10);font-weight:700;font-size:22px;color:var(--b1)">금속 코팅</div>')
    nt = f'<div class="lb" style="position:absolute;left:0;right:0;bottom:16px;text-align:center;font-size:21px;color:#9aa0ae">{E(note)}</div>' if note else ""
    i = _icard(b, t, d, box, svg, tag, title, lab + nt)
    _draw(b, f"#{i} .mt", 2000, t + .25, 1.1)
    if mode == "winter": b.js(f'tl.to("#{i} .gw",{{opacity:1,duration:1.2,ease:"sine.inOut"}},{at - .3:.3f});tl.to("#{i} .gw",{{scale:1.06,transformOrigin:"50% 50%",duration:1.6,yoyo:true,repeat:{max(1, int(d / 1.6))},ease:"sine.inOut"}},{at + .9:.3f});')
    for n in range(len(arrows)): _draw(b, f"#{i} .ar{n}", 400, at + .12 * n, .9)
    b.js(f'tl.fromTo("#{i} .lb",{{opacity:0,y:10}},{{opacity:1,y:0,duration:.5,stagger:.1,ease:"expo.out"}},{at + .5:.3f});')

def tempcurve(b, t, d, box=(84, 300, 912, 640), title="", series=(), xlabels=(), ymin=0, ymax=30, unit="℃", at=None, dur=2.0, delta="", caption_="", tag="TEMPERATURE"):
    """시간에 따른 온도 XY 곡선 2개 비교. series=[["맨유리",[값...]],["LX",[값...]]] (첫째 회색 · 둘째 파랑)"""
    x, y, w, h = box; at = t + .5 if at is None else at
    X0, X1, Y0, Y1 = 96, w - 150, h - 96, 150
    n = max(len(s[1]) for s in series) if series else 2
    px = lambda k: X0 + (X1 - X0) * k / max(1, n - 1)
    py = lambda v: Y0 - (Y0 - Y1) * (v - ymin) / max(1e-6, ymax - ymin)
    grid = "".join(f'<line x1="{X0}" x2="{X1}" y1="{py(ymin + (ymax - ymin) * g / 4):.0f}" y2="{py(ymin + (ymax - ymin) * g / 4):.0f}" stroke="#eef0f6" stroke-width="2"/><text x="{X0 - 16}" y="{py(ymin + (ymax - ymin) * g / 4) + 7:.0f}" font-size="20" fill="#9aa0ae" text-anchor="end" font-family="PP">{ymin + (ymax - ymin) * g / 4:g}</text>' for g in range(5))
    xl = "".join(f'<text x="{px(k):.0f}" y="{Y0 + 36}" font-size="21" font-weight="700" fill="#727785" text-anchor="middle" font-family="KR">{E(s)}</text>' for k, s in enumerate(xlabels))
    lines = ""; ends = ""
    for k, (nm, vals) in enumerate(series):
        P = [(px(j), py(v)) for j, v in enumerate(vals)]; Lk = _plen(P) + 20
        col = "#b3b9c6" if k == 0 else "#245cff"
        lines += f'<path class="cv{k}" d="{_path(P)}" fill="none" stroke="{col}" stroke-width="{6 if k else 5}" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="{Lk:.0f}" stroke-dashoffset="{Lk:.0f}"/>'
        lines += f'<circle class="ce{k}" cx="{P[-1][0]:.1f}" cy="{P[-1][1]:.1f}" r="9" fill="{col}" stroke="#fff" stroke-width="3.5" opacity="0"/>'
        ends += f'<div class="el{k}" style="position:absolute;left:{X1 + 22}px;top:{P[-1][1] - 22:.0f}px;font-weight:{900 if k else 700};font-size:{26 if k else 23}px;color:{"var(--b1)" if k else "#9aa0ae"};white-space:nowrap;opacity:0">{E(nm)}<br><span class="tnum">{vals[-1]:g}{E(unit)}</span></div>'
    svg = f'<svg width="{w}" height="{h}" style="position:absolute;left:0;top:0">{grid}<path d="M{X0} {Y1 - 20} L{X0} {Y0} L{X1 + 10} {Y0}" stroke="#d5d9e4" stroke-width="2.5" fill="none"/>{xl}{lines}</svg>'
    dl = f'<div class="dl" style="position:absolute;right:54px;top:40px;padding:8px 20px;border-radius:99px;background:rgba(36,92,255,.10);font-weight:900;font-size:26px;color:var(--b1);opacity:0">{E(delta)}</div>' if delta else ""
    cp = f'<div style="position:absolute;left:54px;bottom:16px;font-size:20px;color:#9aa0ae">{E(caption_)}</div>' if caption_ else ""
    i = _icard(b, t, d, box, svg, tag, title, ends + dl + cp)
    for k in range(len(series)):
        tk = at + k * .35
        b.js(f'tl.to("#{i} .cv{k}",{{strokeDashoffset:0,duration:{dur},ease:"power2.inOut"}},{tk:.3f});')
        b.js(f'tl.to("#{i} .ce{k}",{{opacity:1,duration:.3}},{tk + dur - .1:.3f});tl.fromTo("#{i} .el{k}",{{opacity:0,x:-10}},{{opacity:1,x:0,duration:.5,ease:"expo.out"}},{tk + dur - .05:.3f});')
    if delta: b.js(f'tl.fromTo("#{i} .dl",{{opacity:0,y:-8}},{{opacity:1,y:0,duration:.6,ease:"expo.out"}},{at + dur + .5:.3f});')

def filmlayers(b, t, d, box=(84, 300, 912, 640), title="", layers=(), tag="FILM STRUCTURE", at=None, gap=.28, badge=""):
    """필름 단면: 층이 위에서부터 하나씩 쌓인다. layers=[["이름","m"|"c"|"a"|"d"|"h"], ...] m 금속 · c 투명 PET · a 접착 · d 염료 · h 하드코팅"""
    x, y, w, h = box; at = t + .45 if at is None else at
    fills = {"m": "linear-gradient(90deg,#aebde6,#245cff 50%,#c3cdea)", "c": "#e9edf6", "a": "#f2efe6", "d": "#3a3d48", "h": "#f7f9fd"}
    n = max(1, len(layers)); top = 150; lh = min(62, int((h - top - 80) / n) - 10)
    rows = ""
    for k, (nm, kd) in enumerate(layers):
        yy = top + k * (lh + 10)
        bd = "border:2px solid #dde2ec;" if kd in ("h", "c") else ""
        rows += (f'<div class="ly{k}" style="position:absolute;left:54px;top:{yy}px;width:{w * .52:.0f}px;height:{lh}px;border-radius:12px;background:{fills.get(kd, "#e9edf6")};{bd}transform-origin:left"></div>'
                 f'<div class="lt{k}" style="position:absolute;left:{w * .52 + 84:.0f}px;top:{yy + lh / 2 - 19:.0f}px;font-weight:{900 if kd == "m" else 700};font-size:30px;color:{"var(--b1)" if kd == "m" else "var(--body)"};white-space:nowrap">{E(nm)}</div>'
                 f'<div class="lk{k}" style="position:absolute;left:{w * .52 + 60:.0f}px;top:{yy + lh / 2:.0f}px;width:16px;height:2px;background:#cbd1de"></div>')
    bg = f'<div class="bgd" style="position:absolute;right:54px;top:40px;padding:8px 20px;border-radius:99px;background:rgba(36,92,255,.10);font-weight:900;font-size:24px;color:var(--b1);opacity:0">{E(badge)}</div>' if badge else ""
    i = _icard(b, t, d, box, "", tag, title, rows + bg)
    for k in range(n):
        tk = at + k * gap
        b.js(f'tl.fromTo("#{i} .ly{k}",{{scaleX:0,opacity:0}},{{scaleX:1,opacity:1,duration:.7,ease:"expo.out"}},{tk:.3f});'
             f'tl.fromTo(["#{i} .lt{k}","#{i} .lk{k}"],{{opacity:0,x:-12}},{{opacity:1,x:0,duration:.5,ease:"expo.out"}},{tk + .2:.3f});')
    if badge: b.js(f'tl.fromTo("#{i} .bgd",{{opacity:0,y:-8}},{{opacity:1,y:0,duration:.6,ease:"expo.out"}},{at + n * gap + .3:.3f});')

def spectrumcurve(b, t, d, box=(84, 300, 912, 640), title="", pts=(), at=None, dur=2.2, tag="SPECTRUM", caption_="개념도", xmax=2500):
    """파장별 투과율 XY 곡선: 가시광선 띠(380~780nm)는 옅은 무지개, 적외선 구간은 회색. pts=[[nm,투과율%], ...]"""
    x, y, w, h = box; at = t + .5 if at is None else at
    X0, X1, Y0, Y1 = 96, w - 56, h - 100, 150
    px = lambda nm: X0 + (X1 - X0) * (nm - 300) / (xmax - 300); py = lambda v: Y0 - (Y0 - Y1) * v / 100
    gid = b.id("sg")
    band = f'<rect class="vb" x="{px(380):.0f}" y="{Y1}" width="{px(780) - px(380):.0f}" height="{Y0 - Y1}" fill="url(#{gid})" opacity="0"/>'
    ir = f'<rect class="ib" x="{px(780):.0f}" y="{Y1}" width="{X1 - px(780):.0f}" height="{Y0 - Y1}" fill="#f3f4f8" opacity="0"/>'
    grid = "".join(f'<line x1="{X0}" x2="{X1}" y1="{py(v):.0f}" y2="{py(v):.0f}" stroke="#eef0f6" stroke-width="2"/><text x="{X0 - 14}" y="{py(v) + 7:.0f}" font-size="20" fill="#9aa0ae" text-anchor="end" font-family="PP">{v}</text>' for v in (0, 25, 50, 75, 100))
    xt = "".join(f'<text x="{px(nm):.0f}" y="{Y0 + 34}" font-size="20" fill="#9aa0ae" text-anchor="middle" font-family="PP">{nm}</text>' for nm in (380, 780, 1500, xmax))
    P = [(px(a), py(v)) for a, v in pts] if pts else [(X0, Y0), (X1, Y0)]; L = _plen(P) + 20
    svg = (f'<svg width="{w}" height="{h}" style="position:absolute;left:0;top:0"><defs><linearGradient id="{gid}"><stop offset="0" stop-color="#8b5cf6" stop-opacity=".16"/><stop offset=".3" stop-color="#245cff" stop-opacity=".16"/><stop offset=".55" stop-color="#14b8a6" stop-opacity=".14"/><stop offset=".8" stop-color="#eab308" stop-opacity=".12"/><stop offset="1" stop-color="#ef4444" stop-opacity=".12"/></linearGradient></defs>'
           f'{ir}{band}{grid}<path d="M{X0} {Y1 - 16} L{X0} {Y0} L{X1} {Y0}" stroke="#d5d9e4" stroke-width="2.5" fill="none"/>{xt}'
           f'<path class="sc" d="{_path(P)}" fill="none" stroke="#245cff" stroke-width="6" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="{L:.0f}" stroke-dashoffset="{L:.0f}"/></svg>')
    lab = (f'<div class="bl" style="position:absolute;left:{px(380) + 10:.0f}px;top:{Y1 + 12}px;font-weight:700;font-size:21px;color:var(--b1);opacity:0">가시광선</div>'
           f'<div class="bl" style="position:absolute;left:{px(1100):.0f}px;top:{Y1 + 12}px;font-weight:700;font-size:21px;color:#9aa0ae;opacity:0">적외선(열)</div>'
           f'<div style="position:absolute;right:56px;bottom:20px;font-size:19px;color:#9aa0ae">파장(nm) · {E(caption_)}</div>'
           f'<div style="position:absolute;left:30px;top:{Y1 - 46}px;font-size:19px;color:#9aa0ae">투과율(%)</div>')
    i = _icard(b, t, d, box, svg, tag, title, lab)
    b.js(f'tl.to(["#{i} .vb","#{i} .ib"],{{opacity:1,duration:.7,stagger:.15}},{t + .3:.3f});tl.to("#{i} .bl",{{opacity:1,duration:.5,stagger:.12}},{t + .6:.3f});'
         f'tl.to("#{i} .sc",{{strokeDashoffset:0,duration:{dur},ease:"power2.inOut"}},{at:.3f});')

_CAR = {  # 차량 평면도 유리 위치 (가로 420 · 세로 760 기준)
    "front": (60, 150, 300, 110, 30), "side1": (22, 290, 34, 150, 10), "side1r": (364, 290, 34, 150, 10),
    "side2": (22, 460, 34, 150, 10), "side2r": (364, 460, 34, 150, 10), "roof": (90, 290, 240, 270, 26), "rear": (80, 600, 260, 90, 26)}

def cartop(b, t, d, box=(84, 290, 912, 680), zones=(), tag="TINT MAP", title=""):
    """차량 평면도: 유리 위치마다 농도만큼 어두워지고 이름표가 붙는다. zones=[["front"|"side1"|"side2"|"roof"|"rear","LX 40",시각], ...]"""
    x, y, w, h = box; cw, chh = 420, 760; s = min((h - 150) / chh, 1.0); ox = 90; oy = 120
    car = (f'<rect x="10" y="40" width="400" height="690" rx="150" fill="#f4f6fb" stroke="#cfd5e2" stroke-width="5"/>'
           f'<rect x="0" y="230" width="20" height="70" rx="8" fill="#cfd5e2"/><rect x="400" y="230" width="20" height="70" rx="8" fill="#cfd5e2"/>')
    gl = ""; labels = ""
    for k, (key, lab, _) in enumerate(zones):
        ks = [key] if key not in ("side1", "side2") else [key, key + "r"]
        m = re.search(r"(\d+)", lab); pct = int(m.group(1)) if m else 50
        op = max(.18, min(.92, 1 - pct / 100))
        for kk in ks:
            gx, gy, gw, gh, gr = _CAR[kk]
            gl += f'<rect class="z{k}" x="{gx}" y="{gy}" width="{gw}" height="{gh}" rx="{gr}" fill="#1c2233" opacity="0" data-op="{op:.2f}"/>'
            gl += f'<rect x="{gx}" y="{gy}" width="{gw}" height="{gh}" rx="{gr}" fill="none" stroke="#c3cad8" stroke-width="3"/>'
        gx, gy, gw, gh, _ = _CAR[ks[-1]]
        lx = ox + (gx + gw) * s + 40; ly = oy + (gy + gh / 2) * s - 24
        labels += (f'<div class="zl{k}" style="position:absolute;left:{max(lx, ox + 440 * s):.0f}px;top:{ly:.0f}px;display:flex;align-items:center;gap:14px;opacity:0">'
                   f'<span style="width:40px;height:2px;background:#cbd1de"></span><span style="font-weight:700;font-size:24px;color:var(--gry)">{E({"front": "전면", "side1": "1열", "side2": "2열 · 후면", "roof": "루프", "rear": "후면 유리"}.get(key, key))}</span>'
                   f'<span style="font-weight:900;font-size:32px;color:var(--b1)">{E(lab)}</span></div>')
    svg = f'<svg width="{w}" height="{h}" style="position:absolute;left:0;top:0"><g transform="translate({ox},{oy:.0f}) scale({s:.3f})">{car}{gl}</g></svg>'
    i = _icard(b, t, d, box, svg, tag, title, labels)
    for k, (_, _, tk) in enumerate(zones):
        b.js(f'document.querySelectorAll("#{i} .z{k}").forEach(el=>tl.to(el,{{opacity:+el.dataset.op,duration:.8,ease:"power2.inOut"}},{tk:.3f}));'
             f'tl.fromTo("#{i} .zl{k}",{{opacity:0,x:-14}},{{opacity:1,x:0,duration:.55,ease:"expo.out"}},{tk + .25:.3f});')

def heatflow(b, t, d, box=(84, 300, 912, 640), mode="summer", tag="HEAT PATH", title="", outside="바깥", inside="실내", film="LX 금속층", at=None, passed=1):
    """유리 단면에서 열이 흐르는 길: summer = 바깥 태양열이 필름에서 반사, winter = 실내 난방열이 필름에서 다시 실내로. passed=통과하는 가는 화살표 수"""
    x, y, w, h = box; at = t + .45 if at is None else at
    gx = w * .5; top = 150; bot = h - 80; mk = b.id("hm")
    glass = (f'<rect x="{gx - 14}" y="{top}" width="28" height="{bot - top}" rx="8" fill="#e6ecfa" stroke="#c3cde6" stroke-width="2.5"/>'
             f'<rect class="fm" x="{gx + (14 if mode == "summer" else -22)}" y="{top}" width="8" height="{bot - top}" rx="4" fill="#245cff" transform-origin="{gx} {top}"/>')
    src = -1 if mode == "summer" else 1   # 열이 오는 쪽 (-1 왼쪽 바깥, +1 오른쪽 실내)
    wall = gx + (8 if mode == "summer" else -8) * 1
    arr = ""; n = 4
    for k in range(n):
        yy = top + 50 + k * (bot - top - 100) / (n - 1)
        sx = gx + src * (w * .4); P = [(sx, yy - 30), (gx + src * 22, yy), (sx + -src * -10, yy + 34)]
        P = [(sx, yy - 34), (gx + src * 26, yy), (gx + src * (w * .36), yy + 38)]
        L = _plen(P) + 10
        arr += f'<path class="h{k}" d="{_path(P)}" fill="none" stroke="#7c4dff" stroke-width="5.5" stroke-linecap="round" stroke-linejoin="round" marker-end="url(#{mk})" stroke-dasharray="{L:.0f}" stroke-dashoffset="{L:.0f}"/>'
    for k in range(passed):
        yy = (top + bot) / 2 + 10
        P = [(gx + src * (w * .4), yy + 80), (gx - src * (w * .3), yy + 80)]; L = _plen(P) + 10
        arr += f'<path class="p{k}" d="{_path(P)}" fill="none" stroke="#c4b5fd" stroke-width="3" stroke-dasharray="6 10" stroke-linecap="round" opacity="0"/>'
    svg = f'<svg width="{w}" height="{h}" style="position:absolute;left:0;top:0"><defs>{_ARROW.format(id=mk, c="#7c4dff")}</defs>{glass}{arr}</svg>'
    lab = (f'<div class="lb" style="position:absolute;left:54px;bottom:30px;font-weight:{900 if mode == "summer" else 700};font-size:28px;color:{"var(--b2)" if mode == "summer" else "var(--gry)"}">{E(outside)}</div>'
           f'<div class="lb" style="position:absolute;right:54px;bottom:30px;font-weight:{900 if mode == "winter" else 700};font-size:28px;color:{"var(--b2)" if mode == "winter" else "var(--gry)"}">{E(inside)}</div>'
           f'<div class="lb" style="position:absolute;left:{gx - 100:.0f}px;width:200px;text-align:center;bottom:30px;padding:6px 0;border-radius:99px;background:rgba(36,92,255,.10);font-weight:700;font-size:22px;color:var(--b1)">{E(film)}</div>')
    i = _icard(b, t, d, box, svg, tag, title, lab)
    b.js(f'tl.fromTo("#{i} .fm",{{scaleY:0}},{{scaleY:1,duration:.8,ease:"expo.out"}},{t + .3:.3f});')
    for k in range(n): b.js(f'tl.to("#{i} .h{k}",{{strokeDashoffset:0,duration:1.0,ease:"power2.inOut"}},{at + k * .16:.3f});')
    for k in range(passed): b.js(f'tl.to("#{i} .p{k}",{{opacity:1,duration:.6}},{at + .9:.3f});')
    b.js(f'tl.fromTo("#{i} .lb",{{opacity:0,y:8}},{{opacity:1,y:0,duration:.5,stagger:.1,ease:"expo.out"}},{at + .3:.3f});')

def colbars(b, t, d, box=(84, 300, 912, 640), title="", bars=(), vmax=100, unit="", ticks=(), hi=-1, tag="COMPARISON", caption_=""):
    """세로 막대 XY 그래프: 축 → 눈금 → 막대가 차례로 자라며 숫자 카운트. hi=강조 막대 번호(파랑), 나머지 회색. bars=[["라벨",값,시각], ...]"""
    x, y, w, h = box; X0, X1, Y0, Y1 = 96, w - 56, h - 96, 160
    n = max(1, len(bars)); hi = n + hi if hi < 0 else hi; slot = (X1 - X0) / n; bw = min(120, slot * .5)
    py = lambda v: Y0 - (Y0 - Y1) * v / vmax
    grid = "".join(f'<div style="position:absolute;left:{X0}px;right:56px;top:{py(v):.0f}px;height:2px;background:#eef0f6"></div><div class="tnum" style="position:absolute;left:{X0 - 60}px;width:46px;text-align:right;top:{py(v) - 13:.0f}px;font-size:20px;color:#9aa0ae">{v}</div>' for v in ticks)
    cols = ""
    for k, (lb, v, _) in enumerate(bars):
        cx = X0 + slot * (k + .5); bh = (Y0 - Y1) * min(v, vmax) / vmax; strong = k == hi
        cols += (f'<div class="cb{k}" style="position:absolute;left:{cx - bw / 2:.0f}px;top:{Y0 - bh:.0f}px;width:{bw:.0f}px;height:{bh:.0f}px;border-radius:14px 14px 4px 4px;background:{"linear-gradient(180deg,var(--b2),var(--b1))" if strong else "#d9dee8"};transform-origin:bottom;transform:scaleY(0)"></div>'
                 f'<div class="cv{k}" style="position:absolute;left:{cx - 90:.0f}px;width:180px;text-align:center;top:{Y0 - bh - 52:.0f}px;font-weight:900;font-size:{36 if strong else 30}px;color:{"var(--b1)" if strong else "#8a90a0"};opacity:0"><span class="n">0</span><span style="font-size:20px;margin-left:3px">{E(unit)}</span></div>'
                 f'<div style="position:absolute;left:{cx - slot / 2:.0f}px;width:{slot:.0f}px;text-align:center;top:{Y0 + 16}px;font-weight:{900 if strong else 700};font-size:24px;color:{"var(--ink)" if strong else "var(--gry)"}">{E(lb)}</div>')
    ax = f'<div class="ax" style="position:absolute;left:{X0}px;right:56px;top:{Y0}px;height:3px;background:#cfd5e2;transform-origin:left"></div>'
    cp = f'<div style="position:absolute;right:56px;bottom:14px;font-size:19px;color:#9aa0ae">{E(caption_)}</div>' if caption_ else ""
    i = _icard(b, t, d, box, "", tag, title, grid + ax + cols + cp)
    b.js(f'tl.fromTo("#{i} .ax",{{scaleX:0}},{{scaleX:1,duration:.7,ease:"expo.out"}},{t + .25:.3f});')
    for k, (_, v, tk) in enumerate(bars):
        dec = 0 if float(v).is_integer() else 1
        b.js(f'tl.to("#{i} .cb{k}",{{scaleY:1,duration:1.2,ease:"power3.out"}},{tk:.3f});tl.to("#{i} .cv{k}",{{opacity:1,duration:.3}},{tk + .1:.3f});'
             f'(function(){{const o={{v:0}};const el=document.querySelector("#{i} .cv{k} .n");tl.to(o,{{v:{v},duration:1.2,ease:"power3.out",onUpdate:()=>el.textContent=o.v.toFixed({dec})}},{tk:.3f});}})();')

def dial(b, t, d, box=(140, 300, 800, 600), label="", value=0, vmax=100, unit="%", at=None, sub="", tag="GAUGE"):
    """반원 계기판: 바늘이 돌아가며 수치가 올라간다"""
    x, y, w, h = box; at = t + .45 if at is None else at
    cx, cy, R = w / 2, h - 210, min(w * .34, h - 300)
    import math
    arc = lambda a0, a1: f"M{cx + R * math.cos(math.pi * (1 - a0)):.1f} {cy - R * math.sin(math.pi * (1 - a0)):.1f} A{R:.0f} {R:.0f} 0 0 1 {cx + R * math.cos(math.pi * (1 - a1)):.1f} {cy - R * math.sin(math.pi * (1 - a1)):.1f}"
    L = math.pi * R; f = min(1, value / vmax); gid = b.id("dg")
    ticks = "".join(f'<line x1="{cx + (R - 44) * math.cos(math.pi * (1 - k / 10)):.1f}" y1="{cy - (R - 44) * math.sin(math.pi * (1 - k / 10)):.1f}" x2="{cx + (R - 30) * math.cos(math.pi * (1 - k / 10)):.1f}" y2="{cy - (R - 30) * math.sin(math.pi * (1 - k / 10)):.1f}" stroke="#cfd5e2" stroke-width="3"/>' for k in range(11))
    svg = (f'<svg width="{w}" height="{h}" style="position:absolute;left:0;top:0"><defs><linearGradient id="{gid}"><stop offset="0" stop-color="#245cff"/><stop offset="1" stop-color="#7c4dff"/></linearGradient></defs>'
           f'<path d="{arc(0, 1)}" fill="none" stroke="#edf0f6" stroke-width="30" stroke-linecap="round"/>'
           f'<path class="da" d="{arc(0, 1)}" fill="none" stroke="url(#{gid})" stroke-width="30" stroke-linecap="round" stroke-dasharray="{L:.0f}" stroke-dashoffset="{L:.0f}"/>{ticks}'
           f'<line class="nd" x1="{cx}" y1="{cy}" x2="{cx - R + 70:.0f}" y2="{cy}" stroke="#14161c" stroke-width="7" stroke-linecap="round"/><circle cx="{cx}" cy="{cy}" r="16" fill="#14161c"/></svg>')
    txt = (f'<div style="position:absolute;left:0;right:0;top:{cy + 24:.0f}px;text-align:center;font-weight:900;font-size:80px" class="tnum"><span class="n gt g-b">0</span><span class="gt g-b" style="font-size:40px">{E(unit)}</span></div>'
           f'<div style="position:absolute;left:0;right:0;top:40px;text-align:center" class="tag">{E(label)}</div>'
           f'<div style="position:absolute;left:0;right:0;bottom:22px;text-align:center;font-size:24px;font-weight:700;color:var(--gry)">{E(sub)}</div>')
    i = _icard(b, t, d, box, svg, "", "", txt)
    dec = 0 if float(value).is_integer() else 1
    b.js(f'tl.to("#{i} .da",{{strokeDashoffset:{L * (1 - f):.0f},duration:1.6,ease:"power3.out"}},{at:.3f});'
         f'tl.fromTo("#{i} .nd",{{rotation:0,svgOrigin:"{cx} {cy}"}},{{rotation:{180 * f:.1f},svgOrigin:"{cx} {cy}",duration:1.6,ease:"power3.out"}},{at:.3f});'
         f'(function(){{const o={{v:0}};const el=document.querySelector("#{i} .n");tl.to(o,{{v:{value},duration:1.6,ease:"power3.out",onUpdate:()=>el.textContent=o.v.toFixed({dec})}},{at:.3f});}})();')

def donut(b, t, d, box=(84, 300, 912, 620), title="", parts=(), at=None, center="", tag="BREAKDOWN", caption_=""):
    """도넛 비율: 조각이 차례로 그려지고 오른쪽 범례 숫자가 올라간다. parts=[["반사",45,"b"],["흡수",25,"p"],["투과",30,"g"]]"""
    x, y, w, h = box; at = t + .45 if at is None else at
    import math
    cx, cy, R = w * .3, h / 2 + 30, min(w * .2, h * .3); C = 2 * math.pi * R
    col = {"b": "#245cff", "p": "#7c4dff", "g": "#cfd5e2", "k": "#3a3f4c"}
    tot = sum(p[1] for p in parts) or 1; acc = 0; segs = ""; leg = ""
    for k, (nm, v, g) in enumerate(parts):
        ln = C * v / tot
        segs += f'<circle class="sg{k}" cx="{cx:.0f}" cy="{cy:.0f}" r="{R:.0f}" fill="none" stroke="{col.get(g, "#cfd5e2")}" stroke-width="54" stroke-dasharray="0 {C:.0f}" transform="rotate({-90 + 360 * acc / tot:.1f} {cx:.0f} {cy:.0f})" data-l="{ln - 4:.0f}"/>'
        acc += v
        leg += (f'<div class="lg{k}" style="position:absolute;left:{w * .56:.0f}px;top:{cy - 90 + k * 80:.0f}px;display:flex;align-items:center;gap:18px;opacity:0">'
                f'<span style="width:22px;height:22px;border-radius:6px;background:{col.get(g, "#cfd5e2")}"></span><span style="font-weight:700;font-size:30px;color:var(--body);width:150px">{E(nm)}</span>'
                f'<span class="tnum" style="font-weight:900;font-size:40px;color:{col.get(g) if g in "bp" else "var(--ink)"}"><span class="n">0</span><span style="font-size:22px">%</span></span></div>')
    ctr = f'<div style="position:absolute;left:{cx - 120:.0f}px;width:240px;top:{cy - 26:.0f}px;text-align:center;font-weight:900;font-size:36px">{E(center)}</div>' if center else ""
    cp = f'<div style="position:absolute;right:56px;bottom:16px;font-size:19px;color:#9aa0ae">{E(caption_)}</div>' if caption_ else ""
    svg = f'<svg width="{w}" height="{h}" style="position:absolute;left:0;top:0"><circle cx="{cx:.0f}" cy="{cy:.0f}" r="{R:.0f}" fill="none" stroke="#f0f2f7" stroke-width="54"/>{segs}</svg>'
    i = _icard(b, t, d, box, svg, tag, title, ctr + leg + cp)
    for k, (_, v, _) in enumerate(parts):
        tk = at + k * .45
        b.js(f'(function(){{const el=document.querySelector("#{i} .sg{k}");const o={{v:0}};const L=+el.dataset.l;tl.to(o,{{v:L,duration:.9,ease:"power2.inOut",onUpdate:()=>el.setAttribute("stroke-dasharray",o.v+" {C:.0f}")}},{tk:.3f});}})();'
             f'tl.fromTo("#{i} .lg{k}",{{opacity:0,x:-10}},{{opacity:1,x:0,duration:.5,ease:"expo.out"}},{tk:.3f});')
        _count(b, f"#{i} .lg{k} .n", 0, v, tk, .9)

ILLUS_PARTS = dict(thermos=thermos, tempcurve=tempcurve, filmlayers=filmlayers, spectrumcurve=spectrumcurve, cartop=cartop,
                   heatflow=heatflow, colbars=colbars, dial=dial, donut=donut)

PRO_PARTS = dict(splitline=splitline, morphcard=morphcard, bento=bento, ladder=ladder,
                 focusword=focusword, crossscan=crossscan, metricpair=metricpair, stacklist=stacklist)

UI_PARTS = dict(toast=toast, snackbar=snackbar, banner=banner, modal=modal, bottomsheet=bottomsheet, inlineerror=inlineerror, tooltip=tooltip,
                coachmark=coachmark, badge=badge, spinner=spinner, skeleton=skeleton, progress=progress, inputfield=inputfield, toggles=toggles,
                segmented=segmented, rangeslider=rangeslider, chat=chat, emptystate=emptystate, tap=tap, swipecards=swipecards, tabbar=tabbar,
                carousel=carousel, dropdown=dropdown)

PARTS = dict(sharedcard=sharedcard, centertext=centertext, rollstat=rollstat, rolltext=rolltext, header=header, logo=logo, bgword=bgword, caption=caption, kinetic=kinetic, titlecard=titlecard, strike=strike, checklist=checklist,
             hbars=hbars, xyline=xyline, counter=counter, ring=ring, seesaw=seesaw, steps=steps, versus=versus, photo=photo, spectrum=spectrum,
             waves=waves, timeline=timeline, typeline=typeline, receipt=receipt, slot=slot, compare=compare, endcard=endcard)
PARTS.update(UI_PARTS)
PARTS.update(PRO_PARTS)
PARTS.update(ILLUS_PARTS)

def _prepare_items(raw_items, overlay=False):
    items = [dict(x) for x in raw_items]
    if overlay: return items
    cands = [it for it in items if it.get("p") in MORPH_PARTS and not it.get("paper", False)
             and isinstance(it.get("box"), (list, tuple)) and len(it["box"]) == 4 and it["box"][3] > 0]
    cands.sort(key=lambda x: x["t"])
    chains, cur = [], []
    for it in cands:
        if cur and abs(it["t"] - (cur[-1]["t"] + cur[-1]["d"])) <= 0.45:
            cur.append(it)
        else:
            if len(cur) >= 2: chains.append(cur)
            cur = [it]
    if len(cur) >= 2: chains.append(cur)
    shared = []
    for ch in chains:
        for it in ch: it["_ghost"] = True
        t0 = ch[0]["t"]; t1 = ch[-1]["t"] + ch[-1]["d"]
        shared.append(dict(p="sharedcard", t=round(t0, 3), d=round(t1 - t0, 3), chain=[dict(t=c["t"], d=c["d"], box=c["box"]) for c in ch]))
    return shared + items

# ───────── 조립 · 폰트 · 렌더 ─────────
# ───────── Swiss Editorial Full-Canvas Kinetic Engine (style:"editorial") ─────────
ED_CSS = r"""
.ed-grid{position:absolute;inset:210px 56px 210px 56px;border-top:1.5px solid rgba(20,22,28,.10);border-bottom:1.5px solid rgba(20,22,28,.10);pointer-events:none}
.ed-grid::before{content:"";position:absolute;inset:0;background-image:linear-gradient(90deg,rgba(20,22,28,.045) 1px,transparent 1px);background-size:322px 100%}
.ed-meta{font-family:PP,KR,sans-serif;font-size:20px;font-weight:700;letter-spacing:.20em;color:var(--b1);display:flex;justify-content:space-between;align-items:center}
.ed-kwrap{position:absolute;left:72px;width:936px}
.ed-sent{position:absolute;left:0;top:0;width:100%}
.ed-row{display:block;font-weight:900;font-size:66px;line-height:1.22;letter-spacing:-.042em;margin-bottom:8px;white-space:nowrap}
.ed-m{display:inline-block;overflow:hidden;vertical-align:bottom;padding:12px 8px;margin:-12px -8px}
.ed-w{display:inline-block;will-change:transform,opacity,filter}
.ed-hl{position:relative;display:inline-block;padding:0 8px}
.ed-hl .eb{position:absolute;left:-2px;right:-2px;top:14%;bottom:6%;border-radius:12px;background:rgba(36,92,255,.13);transform-origin:left}
.ed-hl .ep{position:absolute;top:6%;bottom:0;width:3.5px;border-radius:2px;background:var(--b1)}
.ed-hl .ep.r{background:var(--b2);left:0%}
.ed-hl .ep.l{left:-4px}
.ed-hl em{position:relative;z-index:1;font-style:normal}
.ed-dark .ed-row{color:#fff}
.ed-dark .ed-hl .eb{background:rgba(124,77,255,.28)}
"""

def _ed_type_html(caps):
    sents = []
    for si, rows in enumerate(caps):
        rhtml = []
        for r in rows:
            toks = []
            for tx, st in r:
                glue = tx.startswith("~"); tx = tx.lstrip("~")
                if st in ("b", "p", "n", "bp"):
                    hp = f'<span class="ed-hl"><i class="eb"></i><i class="ep l"></i><i class="ep r"></i><em class="gt g-{st if st != "n" else "b"}">{E(tx)}</em></span>'
                    if glue and toks: toks[-1] += hp
                    else: toks.append(hp)
                else:
                    for idx, w in enumerate(tx.split(" ")):
                        if not w: continue
                        s = f'<span class="gry">{E(w)}</span>' if st == "g" else E(w)
                        if idx == 0 and glue and toks: toks[-1] += s
                        else: toks.append(s)
            rhtml.append('<span class="ed-row">' + " ".join(f'<span class="ed-m"><span class="ed-w">{tk}</span></span>' for tk in toks) + "</span>")
        sents.append(f'<div class="ed-sent es{si}" style="opacity:{1 if si == 0 else 0}">{"".join(rhtml)}</div>')
    return "".join(sents)

def _ed_type_js(b, cid, t, d, caps, stimes):
    for si in range(len(caps)):
        ts = stimes[si] if si < len(stimes) else t + si * 2.8
        te = (stimes[si + 1] - 0.08) if si + 1 < len(caps) else (t + d - 0.24)
        if si > 0:
            b.js(f'tl.set("#{cid} .es{si}",{{opacity:1}},{ts:.3f});')
        b.js(f'tl.fromTo("#{cid} .es{si} .ed-w",{{yPercent:115,opacity:0,filter:"blur(4px)"}},{{yPercent:0,opacity:1,filter:"blur(0px)",duration:.56,ease:"expo.out",stagger:.055}},{ts:.3f});'
             f'tl.fromTo("#{cid} .es{si} .eb",{{scaleX:0}},{{scaleX:1,duration:.54,ease:"expo.out"}},{ts + .16:.3f});'
             f'tl.fromTo("#{cid} .es{si} .ep.l",{{scaleY:0,opacity:0}},{{scaleY:1,opacity:1,duration:.24,ease:"expo.out"}},{ts + .14:.3f});'
             f'tl.fromTo("#{cid} .es{si} .ep.r",{{left:"0%",opacity:0}},{{left:"100%",opacity:1,duration:.54,ease:"expo.out"}},{ts + .16:.3f});'
             f'tl.to("#{cid} .es{si} .ep",{{opacity:0,duration:.25}},{ts + .82:.3f});'
             f'tl.to("#{cid} .es{si}",{{y:-18,opacity:0,filter:"blur(6px)",duration:.24,ease:"power2.in"}},{max(ts + .6, te):.3f});')

def _ed_cam(b, cid, t, d, x0=0, y0=28, s0=1.05, r0=0):
    b.js(f'tl.fromTo("#{cid}",{{opacity:0,x:{x0},y:{y0},scale:{s0},rotation:{r0},filter:"blur(4px)"}},{{opacity:1,x:0,y:0,scale:1,rotation:0,filter:"blur(0px)",duration:.64,ease:"expo.out"}},{t:.3f});'
         f'tl.to("#{cid}",{{scale:1.018,y:-6,duration:{max(.8, d - .9):.2f},ease:"sine.inOut"}},{t + .64:.3f});'
         f'tl.to("#{cid}",{{opacity:0,scale:.96,y:-34,filter:"blur(4px)",duration:.26,ease:"power2.in"}},{t + d - .28:.3f});')

def ed_split(b, t, d, no="01", q_tag="", q_txt="", a_tag="", t_high="23°C", t_low="-5°C", rule="", caps=(), stimes=()):
    s2 = stimes[1] if len(stimes) > 1 else t + d * .48
    html = (f'<div class="ed-grid"></div>'
            f'<div class="ed-meta" style="position:absolute;left:72px;right:72px;top:234px"><span>{E(no)}</span><span>THERMAL VECTOR</span></div>'
            f'<div class="ed-kwrap" style="top:296px">{_ed_type_html(caps)}</div>'
            f'<div class="bx1" style="position:absolute;left:72px;top:560px;width:936px;height:280px;border-radius:34px;background:#eef1f8;padding:42px 50px;overflow:hidden">'
            f'<div class="tag">{E(q_tag)}</div><div style="font-weight:900;font-size:48px;color:var(--gry);margin-top:16px">{E(q_txt)}</div>'
            f'<div class="sl" style="position:absolute;left:44px;right:44px;top:154px;height:6px;background:var(--b2);border-radius:3px;transform-origin:left"></div></div>'
            f'<div class="bx2 card" style="left:72px;top:876px;width:936px;height:680px;padding:52px;overflow:hidden;border:2px solid rgba(36,92,255,.18)">'
            f'<div class="tag" style="color:var(--b1)">{E(a_tag)}</div>'
            f'<div style="display:flex;align-items:center;justify-content:space-between;margin-top:64px">'
            f'<div><div style="font-size:24px;font-weight:700;color:var(--gry)">HIGH TEMP</div><div class="tnum gt g-p" style="font-size:104px;font-weight:900">{E(t_high)}</div></div>'
            f'<div style="flex:1;margin:0 36px;height:10px;border-radius:5px;background:#e6ebf5;position:relative;overflow:hidden"><div class="vec g-b" style="width:100%;height:100%;transform-origin:left"></div></div>'
            f'<div style="text-align:right"><div style="font-size:24px;font-weight:700;color:var(--gry)">LOW TEMP</div><div class="tnum gt g-b" style="font-size:104px;font-weight:900">{E(t_low)}</div></div></div>'
            f'<div class="rl" style="margin-top:78px;padding:28px 36px;border-radius:22px;background:#f4f7ff;font-size:36px;font-weight:900;text-align:center;color:var(--b1)">{E(rule)}</div></div>')
    i = b.clip(t, d, html, "left:0;top:0;width:1080px;height:1920px")
    _ed_cam(b, i, t, d, y0=40, s0=1.06); _ed_type_js(b, i, t, d, caps, stimes)
    b.js(f'tl.fromTo("#{i} .bx1",{{opacity:0,y:30}},{{opacity:1,y:0,duration:.55,ease:"expo.out"}},{t + .18:.3f});'
         f'tl.fromTo("#{i} .sl",{{scaleX:0}},{{scaleX:1,duration:.5,ease:"expo.out"}},{s2 - .15:.3f});'
         f'tl.to("#{i} .bx1",{{opacity:.48,scale:.97,duration:.5}},{s2:.3f});'
         f'tl.fromTo("#{i} .bx2",{{opacity:0,y:70,scale:.95}},{{opacity:1,y:0,scale:1,duration:.68,ease:"expo.out"}},{s2:.3f});'
         f'tl.fromTo("#{i} .vec",{{scaleX:0}},{{scaleX:1,duration:.9,ease:"expo.out"}},{s2 + .25:.3f});'
         f'tl.fromTo("#{i} .rl",{{opacity:0,y:18}},{{opacity:1,y:0,duration:.5,ease:"expo.out"}},{s2 + .5:.3f});')

def ed_temp(b, t, d, no="02", bare=(), lx=(), xlabels=(), badge="", caps=(), stimes=()):
    W0, H0 = 936, 760; X0, X1, Y0, Y1 = 76, 876, 640, 110; vmax = 26.0
    pts_b = [(X0 + (X1 - X0) * k / max(1, len(bare) - 1), Y0 - (Y0 - Y1) * v / vmax) for k, v in enumerate(bare)]
    pts_l = [(X0 + (X1 - X0) * k / max(1, len(lx) - 1), Y0 - (Y0 - Y1) * v / vmax) for k, v in enumerate(lx)]
    pb = "M%.1f %.1f " % pts_b[0] + " ".join("L%.1f %.1f" % p for p in pts_b[1:])
    pl = "M%.1f %.1f " % pts_l[0] + " ".join("L%.1f %.1f" % p for p in pts_l[1:])
    poly = " ".join(f"{x:.1f},{y:.1f}" for x, y in pts_l + list(reversed(pts_b)))
    grid = "".join(f'<line x1="{X0}" y1="{Y1 + (Y0 - Y1) * g / 4:.0f}" x2="{X1}" y2="{Y1 + (Y0 - Y1) * g / 4:.0f}" stroke="rgba(20,22,28,.07)" stroke-width="2"/>' for g in range(5))
    xlab = "".join(f'<text x="{pts_b[k][0]:.1f}" y="{Y0 + 48}" font-size="24" font-weight="700" fill="#727785" text-anchor="middle" font-family="KR">{E(xl)}</text>' for k, xl in enumerate(xlabels))
    html = (f'<div class="ed-grid"></div>'
            f'<div class="ed-meta" style="position:absolute;left:72px;right:72px;top:234px"><span>{E(no)}</span><span>CABIN HEAT RETENTION</span></div>'
            f'<div class="ed-kwrap" style="top:296px">{_ed_type_html(caps)}</div>'
            f'<div style="position:absolute;left:72px;top:580px;width:{W0}px;height:980px">'
            f'<svg width="{W0}" height="{H0}" style="overflow:visible">{grid}'
            f'<polygon class="shd" points="{poly}" fill="rgba(36,92,255,.12)" opacity="0"/>'
            f'<path class="cb" d="{pb}" stroke="#9aa2b4" stroke-width="7" stroke-dasharray="14 12" fill="none"/>'
            f'<path class="cl" d="{pl}" stroke="#245cff" stroke-width="11" stroke-linecap="round" fill="none" stroke-dasharray="1400" stroke-dashoffset="1400"/>'
            f'<circle class="dl" cx="{pts_l[-1][0]:.1f}" cy="{pts_l[-1][1]:.1f}" r="14" fill="#245cff" stroke="#fff" stroke-width="5"/>'
            f'<circle class="db" cx="{pts_b[-1][0]:.1f}" cy="{pts_b[-1][1]:.1f}" r="12" fill="#9aa2b4" stroke="#fff" stroke-width="4"/>'
            f'{xlab}</svg>'
            f'<div class="lb1 card" style="right:10px;top:{pts_l[-1][1] - 92:.0f}px;padding:16px 28px;border-radius:22px;font-weight:900;font-size:34px;color:var(--b1)">SOLAR GARD LX · {lx[-1]}°C</div>'
            f'<div class="lb2" style="position:absolute;right:16px;top:{pts_b[-1][1] + 22:.0f}px;font-weight:700;font-size:30px;color:var(--gry)">맨유리 · {bare[-1]}°C 급락</div>'
            f'<div style="position:absolute;left:0;bottom:80px;padding:14px 28px;border-radius:99px;background:rgba(36,92,255,.09);font-weight:700;font-size:25px;color:var(--b1)">{E(badge)}</div></div>')
    i = b.clip(t, d, html, "left:0;top:0;width:1080px;height:1920px")
    _ed_cam(b, i, t, d, x0=50, y0=0, s0=1.04); _ed_type_js(b, i, t, d, caps, stimes)
    b.js(f'tl.fromTo("#{i} .cb",{{opacity:0}},{{opacity:1,duration:.8}},{t + .3:.3f});'
         f'tl.to("#{i} .cl",{{strokeDashoffset:0,duration:2.1,ease:"power2.out"}},{t + .4:.3f});'
         f'tl.to("#{i} .shd",{{opacity:1,duration:.9}},{t + 1.3:.3f});'
         f'tl.fromTo(["#{i} .dl","#{i} .db","#{i} .lb1","#{i} .lb2"],{{opacity:0,y:16}},{{opacity:1,y:0,duration:.55,stagger:.1,ease:"expo.out"}},{t + 1.9:.3f});')

def ed_thermos(b, t, d, no="03", in_label="", out_label="", wall="", caps=(), stimes=()):
    rays_in = "".join(f'<path class="ri" d="M210 {180 + k * 140} L445 {235 + k * 140} L210 {290 + k * 140}" stroke="#7c4dff" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" fill="none" stroke-dasharray="600" stroke-dashoffset="600"/>' for k in range(3))
    rays_out = "".join(f'<path class="ro" d="M730 {180 + k * 140} L495 {235 + k * 140} L730 {290 + k * 140}" stroke="#245cff" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" fill="none" stroke-dasharray="600" stroke-dashoffset="600"/>' for k in range(3))
    html = (f'<div class="ed-grid"></div>'
            f'<div class="ed-meta" style="position:absolute;left:72px;right:72px;top:234px"><span>{E(no)}</span><span>VACUUM METAL BARRIER</span></div>'
            f'<div class="ed-kwrap" style="top:296px">{_ed_type_html(caps)}</div>'
            f'<div style="position:absolute;left:72px;top:580px;width:936px;height:980px">'
            f'<svg width="936" height="760" style="overflow:visible">'
            f'<rect x="90" y="90" width="355" height="560" rx="40" fill="rgba(124,77,255,.06)"/>'
            f'<rect x="495" y="90" width="355" height="560" rx="40" fill="rgba(36,92,255,.06)"/>'
            f'<rect class="mw" x="452" y="60" width="36" height="620" rx="18" fill="url(#g_wall)"/>'
            f'<defs><linearGradient id="g_wall" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#245cff"/><stop offset="100%" stop-color="#7c4dff"/></linearGradient></defs>'
            f'{rays_in}{rays_out}</svg>'
            f'<div style="position:absolute;left:110px;top:118px;font-weight:900;font-size:32px;color:var(--b2)">{E(in_label)}</div>'
            f'<div style="position:absolute;right:110px;top:118px;font-weight:900;font-size:32px;color:var(--b1)">{E(out_label)}</div>'
            f'<div class="card" style="left:218px;bottom:140px;width:500px;height:94px;border-radius:47px;display:flex;align-items:center;justify-content:center;font-family:PP,sans-serif;font-weight:700;font-size:24px;letter-spacing:.16em;color:var(--b1)">{E(wall)}</div></div>')
    i = b.clip(t, d, html, "left:0;top:0;width:1080px;height:1920px")
    _ed_cam(b, i, t, d, x0=-45, y0=15, s0=1.05); _ed_type_js(b, i, t, d, caps, stimes)
    b.js(f'tl.fromTo("#{i} .mw",{{scaleY:0,transformOrigin:"50% 50%"}},{{scaleY:1,duration:.65,ease:"expo.out"}},{t + .2:.3f});'
         f'tl.to("#{i} .ri",{{strokeDashoffset:0,duration:1.3,stagger:.18,ease:"power2.out"}},{t + .5:.3f});'
         f'tl.to("#{i} .ro",{{strokeDashoffset:0,duration:1.3,stagger:.18,ease:"power2.out"}},{t + .9:.3f});')

def ed_odometer(b, t, d, no="04", label="", val=20, unit="%", layers=(), caps=(), stimes=()):
    lays = "".join(
        f'<div class="ly{k}" style="height:68px;margin-bottom:12px;border-radius:20px;padding:0 36px;display:flex;align-items:center;justify-content:space-between;'
        f'background:{"linear-gradient(90deg,#245cff,#7c4dff);color:#fff" if "METAL" in s else "#fff;color:var(--ink);border:1.5px solid rgba(20,22,28,.08)"}">'
        f'<span style="font-family:PP,sans-serif;font-weight:700;font-size:24px;letter-spacing:.14em">{E(s)}</span>'
        f'<span style="font-size:22px;font-weight:700;opacity:.8">{"열반사 핵심층" if "METAL" in s else "광학 보호층"}</span></div>'
        for k, s in enumerate(layers))
    html = (f'<div class="ed-grid"></div>'
            f'<div class="ed-meta" style="position:absolute;left:72px;right:72px;top:234px"><span>{E(no)}</span><span>{E(label)}</span></div>'
            f'<div class="ed-kwrap" style="top:296px">{_ed_type_html(caps)}</div>'
            f'<div class="numbox" style="position:absolute;left:72px;top:545px;width:936px;text-align:center">'
            f'<div class="tnum" style="font-weight:900;font-size:260px;line-height:1;letter-spacing:-.05em">'
            f'<span class="gt g-bp">+</span><span class="n gt g-bp">0</span><span class="gt g-b" style="font-size:120px">{E(unit)}</span></div></div>'
            f'<div style="position:absolute;left:72px;top:885px;width:936px">{lays}</div>')
    i = b.clip(t, d, html, "left:0;top:0;width:1080px;height:1920px")
    _ed_cam(b, i, t, d, y0=50, s0=1.08); _ed_type_js(b, i, t, d, caps, stimes)
    b.js(f'tl.fromTo("#{i} .numbox",{{scale:.96,opacity:0,filter:"blur(5px)"}},{{scale:1,opacity:1,filter:"blur(0px)",duration:.75,ease:"expo.out"}},{t + .35:.3f});'
         f'(function(){{const o={{v:0}};const el=document.querySelector("#{i} .n");tl.to(o,{{v:{val},duration:1.5,ease:"expo.out",onUpdate:()=>el.textContent=Math.round(o.v)}},{t + .45:.3f});}})();')
    for k in range(len(layers)):
        b.js(f'tl.fromTo("#{i} .ly{k}",{{opacity:0,y:26}},{{opacity:1,y:0,duration:.48,ease:"expo.out"}},{t + .85 + k * .11:.3f});')

def ed_bento(b, t, d, no="05", main_tit="", main_sub="", summer=("", "", ""), winter=("", "", ""), caps=(), stimes=()):
    s2 = stimes[1] if len(stimes) > 1 else t + d * .5
    bars = "".join(f'<div class="bb{k}" style="flex:1;height:78px;border-radius:14px;background:#e6ebf5;overflow:hidden"><div class="bf g-b" style="width:100%;height:100%;transform-origin:bottom"></div></div>' for k in range(8))
    html = (f'<div class="ed-grid"></div>'
            f'<div class="ed-meta" style="position:absolute;left:72px;right:72px;top:234px"><span>{E(no)}</span><span>ALL-SEASON EV THERMAL</span></div>'
            f'<div class="ed-kwrap" style="top:296px">{_ed_type_html(caps)}</div>'
            f'<div class="b0 card" style="left:72px;top:575px;width:936px;height:430px;padding:48px 54px;display:flex;flex-direction:column;justify-content:space-between">'
            f'<div><div class="tag" style="color:var(--b1)">BATTERY &amp; HVAC DEFENSE</div>'
            f'<div style="font-weight:900;font-size:54px;margin-top:10px">{gtext(main_tit, "b")}</div>'
            f'<div style="font-size:30px;font-weight:700;color:var(--gry);margin-top:8px">{E(main_sub)}</div></div>'
            f'<div style="display:flex;gap:14px">{bars}</div></div>'
            f'<div class="b1 card" style="left:72px;top:1035px;width:454px;height:470px;padding:44px;display:flex;flex-direction:column;justify-content:space-between">'
            f'<div class="tag">{E(summer[0])}</div><div><div style="font-weight:900;font-size:40px">{E(summer[1])}</div>'
            f'<div style="font-size:28px;font-weight:700;color:var(--gry);margin-top:12px">{E(summer[2])}</div></div></div>'
            f'<div class="b2 card" style="left:554px;top:1035px;width:454px;height:470px;padding:44px;display:flex;flex-direction:column;justify-content:space-between;border:2px solid rgba(124,77,255,.26)">'
            f'<div class="tag" style="color:var(--b2)">{E(winter[0])}</div><div><div style="font-weight:900;font-size:40px">{gtext(winter[1], "p")}</div>'
            f'<div style="font-size:28px;font-weight:700;color:var(--gry);margin-top:12px">{E(winter[2])}</div></div></div>')
    i = b.clip(t, d, html, "left:0;top:0;width:1080px;height:1920px")
    _ed_cam(b, i, t, d, x0=40, y0=20, s0=1.04); _ed_type_js(b, i, t, d, caps, stimes)
    b.js(f'tl.fromTo("#{i} .b0",{{opacity:0,y:40}},{{opacity:1,y:0,duration:.6,ease:"expo.out"}},{t + .22:.3f});'
         f'tl.fromTo("#{i} .bf",{{scaleY:0}},{{scaleY:1,duration:.55,stagger:.06,ease:"expo.out"}},{t + .45:.3f});'
         f'tl.fromTo(["#{i} .b1","#{i} .b2"],{{opacity:0,y:44}},{{opacity:1,y:0,duration:.6,stagger:.14,ease:"expo.out"}},{s2 - .1:.3f});')

def ed_night(b, t, d, no="06", model="", val=6, sub="", caps=(), stimes=()):
    """원형 아이리스 다크모드 반전(#0D1017) + 십자선 레이저 스캔 야간 시야 뷰파인더"""
    html = (f'<div class="dk ed-dark" style="position:absolute;left:36px;top:214px;width:1008px;height:1460px;border-radius:46px;background:#0d1017;overflow:hidden;clip-path:circle(0% at 50% 50%)">'
            f'<div class="ed-meta" style="position:absolute;left:48px;right:48px;top:40px;color:#8fb0ff"><span>{E(no)}</span><span>{E(model)}</span></div>'
            f'<div class="ed-kwrap" style="left:48px;width:912px;top:106px">{_ed_type_html(caps)}</div>'
            f'<div style="position:absolute;left:48px;top:420px;width:912px;height:760px;border-radius:36px;border:1.5px solid rgba(255,255,255,.12);background:radial-gradient(circle at 50% 35%,rgba(36,92,255,.20),rgba(13,16,23,.95));overflow:hidden">'
            f'<div class="gh" style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;filter:blur(16px);opacity:.65">'
            f'<div style="width:420px;height:120px;border-radius:60px;background:linear-gradient(90deg,#ec4e94,#7c4dff)"></div></div>'
            f'<div class="scn" style="position:absolute;top:0;bottom:0;left:0;width:4px;background:#5983ff;box-shadow:0 0 28px #245cff"></div>'
            f'<div style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center">'
            f'<div style="font-family:PP,sans-serif;font-size:22px;font-weight:700;letter-spacing:.24em;color:#8fb0ff">INTERNAL REFLECTANCE</div>'
            f'<div class="tnum" style="font-weight:900;font-size:230px;color:#fff;line-height:1.05;margin-top:10px"><span class="n">20</span><span style="font-size:100px;color:#5983ff">%</span></div>'
            f'<div style="font-size:30px;font-weight:700;color:rgba(255,255,255,.72);margin-top:18px">{E(sub)}</div></div></div></div>')
    i = b.clip(t, d, html, "left:0;top:0;width:1080px;height:1920px")
    _ed_type_js(b, i, t, d, caps, stimes)
    b.js(f'tl.to("#{i} .dk",{{clipPath:"circle(100% at 50% 50%)",duration:.85,ease:"expo.inOut"}},{t:.3f});'
         f'tl.fromTo("#{i} .scn",{{x:0}},{{x:912,duration:1.5,ease:"power2.inOut"}},{t + .45:.3f});'
         f'tl.to("#{i} .gh",{{opacity:.06,duration:1.3,ease:"power2.out"}},{t + .55:.3f});'
         f'(function(){{const o={{v:18}};const el=document.querySelector("#{i} .n");tl.to(o,{{v:{val},duration:1.4,ease:"expo.out",onUpdate:()=>el.textContent=Math.round(o.v)}},{t + .45:.3f});}})();'
         f'tl.to("#{i} .dk",{{clipPath:"circle(0% at 50% 50%)",duration:.45,ease:"power2.in"}},{t + d - .46:.3f});')

def ed_verdict(b, t, d, no="07", left="", right="", sub="", caps=(), stimes=()):
    html = (f'<div class="ed-grid"></div>'
            f'<div class="ed-meta" style="position:absolute;left:72px;right:72px;top:234px"><span>{E(no)}</span><span>CONCLUSION</span></div>'
            f'<div class="ed-kwrap" style="top:296px">{_ed_type_html(caps)}</div>'
            f'<div style="position:absolute;left:72px;top:620px;width:936px;height:860px">'
            f'<div class="bm" style="position:absolute;left:88px;top:360px;width:760px;height:10px;border-radius:5px;background:#cbd1de;transform-origin:50% 50%">'
            f'<div class="card" style="left:-40px;top:-165px;width:360px;height:134px;display:flex;align-items:center;justify-content:center;font-size:34px;font-weight:700;color:var(--gry)">{E(left)}</div>'
            f'<div class="card" style="right:-40px;top:-175px;width:390px;height:148px;display:flex;align-items:center;justify-content:center;font-size:38px;font-weight:900;border:2.5px solid rgba(36,92,255,.28)">{gtext(right, "b")}</div></div>'
            f'<svg width="160" height="170" style="position:absolute;left:388px;top:368px"><path d="M80 8 L144 152 L16 152 Z" fill="#e6ebf5"/></svg>'
            f'<div style="position:absolute;bottom:140px;width:100%;text-align:center;font-size:32px;font-weight:700;color:var(--gry)">{E(sub)}</div></div>')
    i = b.clip(t, d, html, "left:0;top:0;width:1080px;height:1920px")
    _ed_cam(b, i, t, d, y0=30, s0=1.05); _ed_type_js(b, i, t, d, caps, stimes)
    b.js(f'tl.fromTo("#{i} .bm",{{rotation:-8}},{{rotation:9,duration:1.3,ease:"power3.inOut"}},{t + .25:.3f});')

CSS += ED_CSS
ED_PARTS = dict(ed_split=ed_split, ed_temp=ed_temp, ed_thermos=ed_thermos, ed_odometer=ed_odometer, ed_bento=ed_bento, ed_night=ed_night, ed_verdict=ed_verdict)
PARTS.update(ED_PARTS)

# ───────── 2026 리서치 신규 모션 부품 10종 (sankey ~ ripplefield) ─────────
CSS += r"""
.tnum{font-family:PP,KR,sans-serif;font-variant-numeric:tabular-nums;font-feature-settings:"tnum" 1;letter-spacing:-.03em}
.dw-mask{-webkit-mask-image:linear-gradient(180deg,transparent 0%,#000 26%,#000 74%,transparent 100%);mask-image:linear-gradient(180deg,transparent 0%,#000 26%,#000 74%,transparent 100%)}
"""

def _t26_gt(txt, g="b"):
    if g in (None, "k", "ink"): return f'<span style="color:var(--ink)">{E(txt)}</span>'
    if g == "g": return f'<span class="gry">{E(txt)}</span>'
    gc = "b" if g == "n" else g
    return f'<span class="gt g-{gc}">{E(txt)}</span>'

def _t26_card(b, sel, t, d, float_=False, ghost=False):
    if "ghost" in popin.__code__.co_varnames:
        popin(b, sel, t, out=t + d, float_=float_, ghost=ghost)
    else:
        b.js(f'tl.fromTo("{sel}",{{opacity:0,y:36,scale:.985}},{{opacity:1,y:0,scale:1,duration:.66,ease:"expo.out"}},{t:.3f});')
        if float_: b.js(f'tl.to("{sel}",{{y:-5,duration:2.6,ease:"sine.inOut",yoyo:true,repeat:5}},{t + .66:.3f});')
        b.js(f'tl.to("{sel}",{{opacity:0,y:-16,duration:.28,ease:"power2.in"}},{t + d - .30:.3f});')

# 1) Diverging Sankey Stream (생키 에너지 분기 흐름도)
def sankey(b, t, d, box=(84, 300, 912, 600), title="태양에너지 분기 경로", source="태양에너지 100%",
           branches=(("외부 반사", 55, "b"), ("원단 흡수", 16, "p"), ("실내 투과", 29, "g")), unit="%", caption_="", at=None, _ghost=False):
    x, y, w, h = box; at = t + .26 if at is None else at
    n = max(1, len(branches)); cmap = {"b": "#245cff", "p": "#7c4dff", "g": "#c6cad4", "n": "#245cff"}
    y_src = 326; ys = [int(196 + k * (260 / max(1, n - 1))) for k in range(n)] if n > 1 else [326]
    paths_svg, flows_svg, rows_html = "", "", ""
    for k, (lb, val, gc) in enumerate(branches):
        col = cmap.get(gc, "#245cff"); sw = max(12, min(52, int(float(val) * .72))); yk = ys[k]
        pth = f"M 244 {y_src} C 390 {y_src}, 420 {yk}, 576 {yk}"
        paths_svg += f'<path class="skp{k}" d="{pth}" stroke="{col}" stroke-opacity="{.88 if gc != "g" else .55}" stroke-width="{sw}" fill="none" pathLength="100" stroke-dasharray="100" stroke-dashoffset="100"/>'
        if gc != "g":
            flows_svg += f'<path class="skf{k}" d="{pth}" stroke="#fff" stroke-opacity=".55" stroke-width="3" stroke-linecap="round" fill="none" stroke-dasharray="6 28" stroke-dashoffset="0" opacity="0"/>'
        rows_html += (f'<div class="skr{k}" style="position:absolute;left:600px;top:{yk - 38}px;width:264px;display:flex;align-items:baseline;justify-content:space-between">'
                      f'<span style="font-weight:700;font-size:27px;color:{"var(--ink)" if gc != "g" else "var(--gry)"}">{E(lb)}</span>'
                      f'<span class="tnum" style="font-weight:900;font-size:44px;color:{col if gc != "g" else "var(--gry)"}"><span class="n">0</span><span style="font-size:24px;margin-left:2px">{E(unit)}</span></span></div>')
    cap = f'<div style="position:absolute;right:52px;bottom:22px;font-size:20px;color:#9aa0ae">{E(caption_)}</div>' if caption_ else ""
    inner = (f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px">'
             f'<div class="tag" style="position:absolute;left:52px;top:38px;color:var(--b1)">ENERGY SANKEY</div>'
             f'<div style="position:absolute;left:52px;top:70px;font-weight:900;font-size:36px">{E(title)}</div>'
             f'<svg width="{w}" height="{h}" style="position:absolute;left:0;top:0">'
             f'<line class="skt" x1="184" y1="{y_src}" x2="250" y2="{y_src}" stroke="#245cff" stroke-width="46" pathLength="100" stroke-dasharray="100" stroke-dashoffset="100"/>'
             f'{paths_svg}{flows_svg}</svg>'
             f'<div class="sks" style="position:absolute;left:48px;top:{y_src - 62}px;width:146px;height:124px;border-radius:24px;background:#f4f6fb;border:1.5px solid #dfe4f0;padding:18px;display:flex;align-items:center;justify-content:center;text-align:center;font-weight:900;font-size:25px;line-height:1.3">{E(source)}</div>'
             f'{rows_html}{cap}</div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    _t26_card(b, f"#{i} .card", t, d, ghost=_ghost)
    b.js(f'tl.fromTo("#{i} .sks",{{opacity:0,x:-16,filter:"blur(4px)"}},{{opacity:1,x:0,filter:"blur(0px)",duration:.5,ease:"expo.out"}},{at:.3f});'
         f'tl.to("#{i} .skt",{{strokeDashoffset:0,duration:.52,ease:"power2.out"}},{at + .12:.3f});')
    for k, (_, val, gc) in enumerate(branches):
        tk = at + .36 + k * .12; ct = tk + .42; dec = 0 if float(val).is_integer() else 1
        b.js(f'tl.to("#{i} .skp{k}",{{strokeDashoffset:0,duration:1.12,ease:"power3.inOut"}},{tk:.3f});'
             f'tl.fromTo("#{i} .skr{k}",{{opacity:0,x:14,filter:"blur(4px)"}},{{opacity:1,x:0,filter:"blur(0px)",duration:.5,ease:"expo.out"}},{ct:.3f});'
             f'(function(){{const o={{v:0}},el=document.querySelector("#{i} .skr{k} .n");tl.fromTo(o,{{v:0}},{{v:{val},duration:1.25,ease:"expo.out",onUpdate:()=>el.textContent=o.v.toFixed({dec})}},{ct:.3f});}})();')
        if gc != "g":
            b.js(f'tl.to("#{i} .skf{k}",{{opacity:1,duration:.4}},{tk + .7:.3f});'
                 f'tl.to("#{i} .skf{k}",{{strokeDashoffset:-136,duration:{max(1.2, d - 1.0):.2f},ease:"none"}},{tk + .7:.3f});')

# 2) Optical Magnifier Loupe (광학 확대 루페 검수창)
def loupe(b, t, d, box=(84, 300, 912, 600), title="초정밀 마감 검수", mode="shaving", zoom=2.4,
          metric_label="끝단 여백", value=0.2, unit="mm", caption_="", at=None, _ghost=False):
    x, y, w, h = box; at = t + .28 if at is None else at; cid = b.id("lpc")
    if mode == "ppf_edge":
        base_g = '<path d="M90 380 L520 250 M90 402 L520 272" stroke="#c6cad4" stroke-width="3" fill="none"/><path d="M90 385 L520 255" stroke="#9aa0ae" stroke-width="2" stroke-dasharray="8 6" fill="none"/>'
        zoom_g = '<path d="M90 380 L520 250" stroke="#16171c" stroke-width="2.2" fill="none"/><path d="M90 384 L520 254" stroke="#245cff" stroke-width="3.2" fill="none"/><path d="M90 402 L520 272" stroke="#7c4dff" stroke-width="1.8" stroke-opacity=".55" fill="none"/>'
    elif mode == "paint":
        base_g = '<line x1="80" y1="320" x2="540" y2="320" stroke="#c6cad4" stroke-width="3"/><circle cx="356" cy="320" r="3" fill="#9aa0ae"/>'
        zoom_g = '<line x1="80" y1="320" x2="540" y2="320" stroke="#16171c" stroke-width="2"/><circle cx="356" cy="320" r="5" fill="none" stroke="#245cff" stroke-width="2"/><line x1="342" y1="320" x2="370" y2="320" stroke="#7c4dff" stroke-width="1.2"/>'
    else:
        base_g = '<path d="M84 366 Q310 268 536 306" stroke="#c6cad4" stroke-width="5" fill="none"/><path d="M84 373 Q310 275 536 313" stroke="#9aa0ae" stroke-width="2" fill="none"/>'
        zoom_g = '<path d="M84 366 Q310 268 536 306" stroke="#16171c" stroke-width="2.6" fill="none"/><path d="M84 368.5 Q310 270.5 536 308.5" stroke="#245cff" stroke-width="2.8" fill="none"/>'
    ticks = "".join(f'<line x1="{120 + k * 24}" y1="150" x2="{120 + k * 24}" y2="490" stroke="#eef1f7" stroke-width="1.5"/>' for k in range(18))
    cap = f'<div style="position:absolute;right:52px;bottom:22px;font-size:20px;color:#9aa0ae">{E(caption_)}</div>' if caption_ else ""
    dec = 0 if float(value).is_integer() else (2 if round(float(value) * 10) != float(value) * 10 else 1)
    inner = (f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px">'
             f'<div class="tag" style="position:absolute;left:52px;top:38px;color:var(--b1)">OPTICAL LOUPE · {zoom:.1f}X</div>'
             f'<div style="position:absolute;left:52px;top:70px;font-weight:900;font-size:36px">{E(title)}</div>'
             f'<svg width="{w}" height="{h}" style="position:absolute;left:0;top:0">'
             f'<defs><clipPath id="{cid}"><circle class="lpc" cx="205" cy="365" r="112"/></clipPath></defs>'
             f'<rect x="52" y="138" width="516" height="404" rx="28" fill="#f7f9fc" stroke="#e5e9f2" stroke-width="2"/>'
             f'{ticks}{base_g}'
             f'<g clip-path="url(#{cid})"><rect x="0" y="0" width="{w}" height="{h}" fill="#ffffff"/>{ticks}<g class="lpz">{zoom_g}</g></g>'
             f'<g class="lpr" transform="translate(205,365)"><circle cx="0" cy="0" r="112" fill="rgba(36,92,255,.03)" stroke="#245cff" stroke-width="4"/>'
             f'<circle cx="0" cy="0" r="102" fill="none" stroke="rgba(124,77,255,.25)" stroke-width="1.5" stroke-dasharray="6 8"/>'
             f'<line x1="-14" y1="0" x2="14" y2="0" stroke="#245cff" stroke-width="1.8"/><line x1="0" y1="-14" x2="0" y2="14" stroke="#245cff" stroke-width="1.8"/></g></svg>'
             f'<div class="lpb" style="position:absolute;left:604px;top:178px;width:260px">'
             f'<div style="font-size:25px;font-weight:700;color:var(--gry)">{E(metric_label)}</div>'
             f'<div class="tnum" style="font-weight:900;font-size:96px;line-height:1.1;margin:12px 0 22px"><span class="n gt g-b">0</span><span class="gt g-b" style="font-size:40px;margin-left:4px">{E(unit)}</span></div>'
             f'<div style="width:100%;height:16px;border-radius:8px;background:#edf0f6;overflow:hidden"><div class="br g-b" style="width:0%;height:100%;border-radius:8px"></div></div></div>{cap}</div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    _t26_card(b, f"#{i} .card", t, d, ghost=_ghost)
    ct = at + .68
    b.js(f'(function(){{const Z={zoom},o={{x:205,y:365}},c=document.querySelector("#{i} .lpc"),r=document.querySelector("#{i} .lpr"),z=document.querySelector("#{i} .lpz");'
         f'const u=()=>{{c.setAttribute("cx",o.x.toFixed(1));c.setAttribute("cy",o.y.toFixed(1));r.setAttribute("transform","translate("+o.x.toFixed(1)+","+o.y.toFixed(1)+")");'
         f'z.setAttribute("transform","translate("+(o.x*(1-Z)).toFixed(1)+","+(o.y*(1-Z)).toFixed(1)+") scale("+Z+")");}};u();'
         f'tl.fromTo("#{i} .lpr",{{opacity:0}},{{opacity:1,duration:.4,ease:"expo.out"}},{at:.3f});'
         f'tl.fromTo(o,{{x:205,y:365}},{{x:356,y:304,duration:1.15,ease:"power3.inOut",onUpdate:u}},{at:.3f});'
         f'tl.to(o,{{x:368,y:298,duration:2.1,ease:"sine.inOut",yoyo:true,repeat:2,onUpdate:u}},{at + 1.45:.3f});}})();'
         f'tl.fromTo("#{i} .lpb",{{opacity:0,y:18,filter:"blur(4px)"}},{{opacity:1,y:0,filter:"blur(0px)",duration:.55,ease:"expo.out"}},{ct:.3f});'
         f'tl.to("#{i} .br",{{width:"88%",duration:1.2,ease:"expo.out"}},{ct:.3f});'
         f'(function(){{const o={{v:0}},el=document.querySelector("#{i} .n");tl.fromTo(o,{{v:0}},{{v:{value},duration:1.2,ease:"expo.out",onUpdate:()=>el.textContent=o.v.toFixed({dec})}},{ct:.3f});}})();')

# 3) 100-Cell Dot Matrix Grid (100칸 도트 매트릭스 밀도판)
def dotmatrix(b, t, d, box=(84, 300, 912, 600), title="에너지 차단 밀도", count=71, second_count=0,
              unit="%", label="총태양에너지 차단", sub="", g="b", caption_="", at=None, _ghost=False):
    x, y, w, h = box; at = t + .24 if at is None else at
    c1 = "#7c4dff" if g == "p" else "#245cff"; c2 = "#7c4dff"
    cells = sorted([(r, c) for r in range(10) for c in range(10)], key=lambda rc: (9 - rc[0]) + rc[1])
    dots = "".join(f'<circle class="dm{idx}" cx="{78 + c * 39}" cy="{162 + r * 39}" r="12.5" fill="#e6eaf2"/>' for idx, (r, c) in enumerate(cells))
    cap = f'<div style="position:absolute;right:52px;bottom:22px;font-size:20px;color:#9aa0ae">{E(caption_)}</div>' if caption_ else ""
    inner = (f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px">'
             f'<div class="tag" style="position:absolute;left:56px;top:38px;color:var(--b1)">100-CELL MATRIX</div>'
             f'<div style="position:absolute;left:56px;top:70px;font-weight:900;font-size:36px">{E(title)}</div>'
             f'<svg width="{w}" height="{h}" style="position:absolute;left:0;top:0">{dots}<line x1="484" y1="148" x2="484" y2="524" stroke="#eef0f6" stroke-width="2"/></svg>'
             f'<div class="dmp" style="position:absolute;left:524px;top:176px;width:336px">'
             f'<div style="font-size:26px;font-weight:700;color:var(--gry)">{E(label)}</div>'
             f'<div class="tnum" style="font-weight:900;font-size:122px;line-height:1.05;margin:12px 0 20px"><span class="n gt g-{"p" if g == "p" else "b"}">0</span><span class="gt g-{"p" if g == "p" else "b"}" style="font-size:48px;margin-left:4px">{E(unit)}</span></div>'
             f'<div style="width:100%;height:18px;border-radius:9px;background:#edf0f6;overflow:hidden"><div class="br g-{"p" if g == "p" else "b"}" style="width:0%;height:100%;border-radius:9px"></div></div>'
             f'<div style="font-size:24px;font-weight:700;color:var(--gry);margin-top:20px;line-height:1.4">{E(sub)}</div></div>{cap}</div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    _t26_card(b, f"#{i} .card", t, d, ghost=_ghost)
    n1 = max(0, min(100, int(round(count)))); n2 = max(0, min(100 - n1, int(round(second_count))))
    for idx in range(n1 + n2):
        col = c1 if idx < n1 else c2; tk = at + .22 + idx * .011
        b.js(f'tl.to("#{i} .dm{idx}",{{fill:"{col}",duration:.32,ease:"sine.out"}},{tk:.3f});')
    b.js(f'tl.to("#{i} .br",{{width:"{min(100.0, float(count)):.1f}%",duration:1.35,ease:"expo.out"}},{at + .28:.3f});'
         f'(function(){{const o={{v:0}},el=document.querySelector("#{i} .n");tl.fromTo(o,{{v:0}},{{v:{count},duration:1.35,ease:"expo.out",onUpdate:()=>el.textContent=Math.round(o.v)}},{at + .28:.3f});}})();')

# 4) Blueprint Vernier Caliper (블루프린트 정밀 치수 캘리퍼스)
def caliper(b, t, d, box=(84, 310, 912, 560), title="원단 두께 정밀 계측", target_label="다층 스퍼터링 원단",
            v1=8.5, compare_v=0.0, unit="mil", caption_="", at=None, _ghost=False):
    x, y, w, h = box; at = t + .26 if at is None else at
    cy = 316; sh = 132; y_top = int(cy - sh / 2); y_bot = int(cy + sh / 2)
    ticks = "".join(f'<line class="ctk" x1="68" y1="{146 + k * 17}" x2="{94 if k % 5 == 0 else 84}" y2="{146 + k * 17}" stroke="#c6cad4" stroke-width="2"/>' for k in range(21))
    cmp_box = ""
    if compare_v and compare_v > 0:
        ch = max(24, int(sh * float(compare_v) / max(.1, float(v1))))
        cmp_box = f'<rect x="164" y="{int(cy - ch / 2)}" width="332" height="{ch}" rx="8" fill="none" stroke="#9aa0ae" stroke-width="2" stroke-dasharray="8 8"/>'
    dec = 0 if float(v1).is_integer() else 1
    cap = f'<div style="position:absolute;right:52px;bottom:20px;font-size:20px;color:#9aa0ae">{E(caption_)}</div>' if caption_ else ""
    inner = (f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px">'
             f'<div class="tag" style="position:absolute;left:56px;top:36px;color:var(--b1)">BLUEPRINT CALIPER</div>'
             f'<div style="position:absolute;left:56px;top:68px;font-weight:900;font-size:36px">{E(title)}</div>'
             f'<svg width="{w}" height="{h}" style="position:absolute;left:0;top:0">'
             f'<line x1="68" y1="140" x2="68" y2="492" stroke="#c6cad4" stroke-width="2.5"/>{ticks}'
             f'<g class="csl"><rect x="152" y="{y_top}" width="356" height="{sh}" rx="14" fill="rgba(36,92,255,.10)" stroke="rgba(36,92,255,.35)" stroke-width="2.5"/>'
             f'<line x1="152" y1="{cy - 22}" x2="508" y2="{cy - 22}" stroke="rgba(124,77,255,.30)" stroke-width="2"/>'
             f'<line x1="152" y1="{cy + 22}" x2="508" y2="{cy + 22}" stroke="rgba(36,92,255,.30)" stroke-width="2"/></g>{cmp_box}'
             f'<g class="cjt"><rect x="68" y="-12" width="466" height="12" rx="4" fill="#245cff"/><path d="M68 -28 L108 -28 L124 0 L68 0 Z" fill="#245cff"/></g>'
             f'<g class="cjb"><rect x="68" y="0" width="466" height="12" rx="4" fill="#245cff"/><path d="M68 28 L108 28 L124 0 L68 0 Z" fill="#245cff"/></g></svg>'
             f'<div class="crd" style="position:absolute;left:566px;top:172px;width:296px">'
             f'<div style="font-size:25px;font-weight:700;color:var(--gry)">{E(target_label)}</div>'
             f'<div class="tnum" style="font-weight:900;font-size:108px;line-height:1.08;margin:12px 0 20px"><span class="n gt g-b">0</span><span class="gt g-b" style="font-size:42px;margin-left:6px">{E(unit)}</span></div>'
             f'<div style="width:100%;height:16px;border-radius:8px;background:#edf0f6;overflow:hidden"><div class="br g-b" style="width:0%;height:100%;border-radius:8px"></div></div></div>{cap}</div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    _t26_card(b, f"#{i} .card", t, d, ghost=_ghost)
    b.js(f'tl.fromTo("#{i} .ctk",{{opacity:0,scaleX:0,transformOrigin:"left"}},{{opacity:1,scaleX:1,duration:.45,stagger:.018,ease:"expo.out"}},{at:.3f});'
         f'tl.fromTo("#{i} .csl",{{opacity:0,scaleX:.85,transformOrigin:"152px {cy}px"}},{{opacity:1,scaleX:1,duration:.6,ease:"expo.out"}},{at + .14:.3f});'
         f'tl.fromTo("#{i} .cjt",{{y:{cy - 168}}},{{y:{y_top},duration:.95,ease:"power3.inOut"}},{at + .36:.3f});'
         f'tl.fromTo("#{i} .cjb",{{y:{cy + 168}}},{{y:{y_bot},duration:.95,ease:"power3.inOut"}},{at + .36:.3f});'
         f'tl.to("#{i} .br",{{width:"86%",duration:1.25,ease:"expo.out"}},{at + .55:.3f});'
         f'(function(){{const o={{v:0}},el=document.querySelector("#{i} .n");tl.fromTo(o,{{v:0}},{{v:{v1},duration:1.25,ease:"expo.out",onUpdate:()=>el.textContent=o.v.toFixed({dec})}},{at + .55:.3f});}})();')

# 5) Node Routing Circuit (노드 분기 의사결정 회로도)
def nodeflow(b, t, d, box=(84, 295, 912, 620), title="주행 환경 맞춤 설계", root="운행 환경",
             paths=(("야간 · 전파 민감", "제니스 IR", False), ("사계절 단열 · 전기차", "솔라가드 LX", True)), caption_="", at=None, _ghost=False):
    x, y, w, h = box; at = t + .24 if at is None else at
    n = max(1, len(paths)); ry = 338
    ys = [int(210 + k * (256 / max(1, n - 1))) for k in range(n)] if n > 1 else [338]
    wires, pulses, nodes_html = "", "", ""
    for k, (cond, dest, active) in enumerate(paths):
        yk = ys[k]; col = "#245cff" if active else "#c6cad4"; col2 = "#7c4dff" if active else "#c6cad4"
        p1 = f"M 218 {ry} C 266 {ry}, 270 {yk}, 318 {yk}"
        p2 = f"M 578 {yk} C 618 {yk}, 622 {yk}, 662 {yk}"
        wires += (f'<path class="nw1_{k}" d="{p1}" stroke="{col}" stroke-width="{4 if active else 2.5}" fill="none" pathLength="100" stroke-dasharray="100" stroke-dashoffset="100"/>'
                  f'<path class="nw2_{k}" d="{p2}" stroke="{col2}" stroke-width="{4 if active else 2.5}" fill="none" pathLength="100" stroke-dasharray="100" stroke-dashoffset="100"/>')
        if active:
            pulses += f'<path class="nwp{k}" d="M 218 {ry} C 266 {ry}, 270 {yk}, 318 {yk} L 578 {yk} L 662 {yk}" stroke="#245cff" stroke-width="6" stroke-opacity=".28" stroke-linecap="round" fill="none" stroke-dasharray="14 64" opacity="0"/>'
        nodes_html += (f'<div class="nm{k}" style="position:absolute;left:318px;top:{yk - 44}px;width:260px;height:88px;border-radius:22px;background:{"#f4f7ff" if active else "#f6f7fa"};border:2px solid {"rgba(36,92,255,.32)" if active else "#e5e8f0"};display:flex;align-items:center;justify-content:center;font-weight:700;font-size:26px;color:{"var(--ink)" if active else "var(--gry)"}">{E(cond)}</div>'
                       f'<div class="nd{k}" style="position:absolute;left:662px;top:{yk - 48}px;width:206px;height:96px;border-radius:24px;background:#fff;border:2.5px solid {"#245cff" if active else "#e5e8f0"};box-shadow:{"0 12px 28px rgba(36,92,255,.12)" if active else "none"};display:flex;align-items:center;justify-content:center;font-weight:900;font-size:30px">{_t26_gt(dest, "b" if active else "g")}</div>')
    cap = f'<div style="position:absolute;right:52px;bottom:20px;font-size:20px;color:#9aa0ae">{E(caption_)}</div>' if caption_ else ""
    inner = (f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px">'
             f'<div class="tag" style="position:absolute;left:52px;top:38px;color:var(--b1)">ROUTING LOGIC</div>'
             f'<div style="position:absolute;left:52px;top:70px;font-weight:900;font-size:36px">{E(title)}</div>'
             f'<svg width="{w}" height="{h}" style="position:absolute;left:0;top:0">{wires}{pulses}</svg>'
             f'<div class="nrt" style="position:absolute;left:44px;top:{ry - 52}px;width:174px;height:104px;border-radius:26px;background:linear-gradient(135deg,#245cff,#7c4dff);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:900;font-size:28px">{E(root)}</div>'
             f'{nodes_html}{cap}</div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    _t26_card(b, f"#{i} .card", t, d, ghost=_ghost)
    b.js(f'tl.fromTo("#{i} .nrt",{{opacity:0,x:-16,filter:"blur(4px)"}},{{opacity:1,x:0,filter:"blur(0px)",duration:.5,ease:"expo.out"}},{at:.3f});')
    for k, (_, _, active) in enumerate(paths):
        tk = at + .30 + k * .14
        b.js(f'tl.to("#{i} .nw1_{k}",{{strokeDashoffset:0,duration:.65,ease:"power3.inOut"}},{tk:.3f});'
             f'tl.fromTo("#{i} .nm{k}",{{opacity:0,y:12,filter:"blur(4px)"}},{{opacity:1,y:0,filter:"blur(0px)",duration:.48,ease:"expo.out"}},{tk + .38:.3f});'
             f'tl.to("#{i} .nw2_{k}",{{strokeDashoffset:0,duration:.55,ease:"power3.inOut"}},{tk + .62:.3f});'
             f'tl.fromTo("#{i} .nd{k}",{{opacity:0,x:14,filter:"blur(4px)"}},{{opacity:1,x:0,filter:"blur(0px)",duration:.52,ease:"expo.out"}},{tk + .88:.3f});')
        if active:
            b.js(f'tl.to("#{i} .nwp{k}",{{opacity:1,duration:.4}},{tk + 1.1:.3f});'
                 f'tl.to("#{i} .nwp{k}",{{strokeDashoffset:-156,duration:{max(1.2, d - 1.2):.2f},ease:"none"}},{tk + 1.1:.3f});')

# 6) Pinned Elastic Surface Mesh (양단 고정 탄성 복원 그리드)
def elasticmesh(b, t, d, box=(84, 300, 912, 600), title="우레탄 탄성 충격 분산 · 복원",
                impact_label="스톤칩 충격 흡수", base_label="도장면 무손상 보호", pct=100, caption_="", at=None, _ghost=False):
    x, y, w, h = box; at = t + .25 if at is None else at
    ys = [248 + k * 36 for k in range(5)]
    mesh = "".join(
        f'<path class="em{k}" d="M76 {yk} Q456 {yk} 836 {yk}" stroke="{"#245cff" if k < 2 else "#7c4dff"}" stroke-opacity="{1.0 - k * .13:.2f}" stroke-width="{4.5 if k == 0 else 3}" fill="none" pathLength="100" stroke-dasharray="100" stroke-dashoffset="100"/>'
        f'<circle cx="76" cy="{yk}" r="4.5" fill="#245cff"/><circle cx="836" cy="{yk}" r="4.5" fill="#245cff"/>'
        for k, yk in enumerate(ys))
    cap = f'<div style="position:absolute;right:52px;bottom:20px;font-size:20px;color:#9aa0ae">{E(caption_)}</div>' if caption_ else ""
    inner = (f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px">'
             f'<div class="tag" style="position:absolute;left:52px;top:38px;color:var(--b1)">ELASTIC RECOVERY</div>'
             f'<div style="position:absolute;left:52px;top:70px;font-weight:900;font-size:36px">{E(title)}</div>'
             f'<div style="position:absolute;right:52px;top:38px;text-align:right"><div class="tnum gt g-b" style="font-weight:900;font-size:52px;line-height:1"><span class="n">0</span><span style="font-size:28px">%</span></div>'
             f'<div style="width:160px;height:10px;border-radius:5px;background:#edf0f6;margin-top:8px;overflow:hidden"><div class="br g-b" style="width:0%;height:100%"></div></div></div>'
             f'<svg width="{w}" height="{h}" style="position:absolute;left:0;top:0">'
             f'<rect x="76" y="486" width="760" height="26" rx="8" fill="#e8ecf4"/>'
             f'{mesh}'
             f'<circle class="emr" cx="456" cy="248" r="12" fill="none" stroke="#245cff" stroke-width="2.5" opacity="0"/>'
             f'<polygon class="ems" points="456,244 440,218 452,202 472,214" fill="#7c4dff" opacity="0"/></svg>'
             f'<div class="emb" style="position:absolute;left:76px;top:154px;padding:8px 20px;border-radius:99px;background:rgba(36,92,255,.09);font-weight:700;font-size:23px;color:var(--b1)">{E(impact_label)}</div>'
             f'<div style="position:absolute;left:0;width:100%;bottom:42px;text-align:center;font-size:23px;font-weight:700;color:var(--gry)">{E(base_label)}</div>{cap}</div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    _t26_card(b, f"#{i} .card", t, d, ghost=_ghost)
    for k in range(5):
        b.js(f'tl.to("#{i} .em{k}",{{strokeDashoffset:0,duration:.58,ease:"expo.out"}},{at + k * .06:.3f});')
    imp_t = at + .42; heal_t = imp_t + .48
    b.js(f'tl.fromTo("#{i} .ems",{{y:-86,opacity:0}},{{y:4,opacity:1,duration:.40,ease:"power2.in"}},{imp_t - .38:.3f});'
         f'tl.to("#{i} .ems",{{x:58,y:-68,opacity:0,duration:.55,ease:"power2.out"}},{imp_t + .06:.3f});'
         f'tl.fromTo("#{i} .emr",{{attr:{{r:10}},opacity:.85}},{{attr:{{r:78}},opacity:0,duration:.75,ease:"power2.out"}},{imp_t:.3f});'
         f'(function(){{const o={{a:0}},ys=[248,284,320,356,392],dp=[96,78,60,42,24],els=ys.map((_,k)=>document.querySelector("#{i} .em"+k));'
         f'const u=()=>els.forEach((el,k)=>{{if(el)el.setAttribute("d","M76 "+ys[k]+" Q456 "+(ys[k]+o.a*dp[k]).toFixed(1)+" 836 "+ys[k]);}});'
         f'tl.fromTo(o,{{a:0}},{{a:1,duration:.46,ease:"power2.out",onUpdate:u}},{imp_t:.3f});'
         f'tl.to(o,{{a:0,duration:1.15,ease:"expo.out",onUpdate:u}},{heal_t:.3f});'
         f'tl.to(o,{{a:.05,duration:1.8,ease:"sine.inOut",yoyo:true,repeat:2,onUpdate:u}},{heal_t + 1.15:.3f});}})();'
         f'tl.to("#{i} .br",{{width:"{min(100.0, float(pct)):.1f}%",duration:1.3,ease:"expo.out"}},{heal_t:.3f});'
         f'(function(){{const o={{v:0}},el=document.querySelector("#{i} .n");tl.fromTo(o,{{v:0}},{{v:{pct},duration:1.3,ease:"expo.out",onUpdate:()=>el.textContent=Math.round(o.v)}},{heal_t:.3f});}})();')

# 7) Frosted Clarity Lens Window (프로스티드 선명도·헤이즈 투시창)
def frostlens(b, t, d, box=(84, 300, 912, 600), title="광학 선명도 · 잔상 억제", haze_label="빛 번짐 · 실내 잔상",
              clear_label="선명한 광학 시야", metric_name="내부 반사율", metric_val=6, unit="%", caption_="", at=None, _ghost=False):
    x, y, w, h = box; at = t + .26 if at is None else at
    scene_haze = ('<svg width="808" height="396" style="position:absolute;inset:0">'
                  '<line x1="60" y1="168" x2="748" y2="168" stroke="#9aa0ae" stroke-width="2.5"/>'
                  '<path d="M130 356 L354 168 M678 356 L454 168 M404 356 L404 184" stroke="#767a84" stroke-width="5" stroke-dasharray="18 14" fill="none"/>'
                  '<circle cx="290" cy="146" r="24" fill="rgba(124,77,255,.38)"/><circle cx="518" cy="146" r="24" fill="rgba(124,77,255,.38)"/>'
                  '<ellipse cx="404" cy="272" rx="190" ry="34" fill="none" stroke="rgba(124,77,255,.42)" stroke-width="8"/></svg>')
    scene_clear = ('<svg width="808" height="396" style="position:absolute;inset:0;background:#ffffff">'
                   '<line x1="60" y1="168" x2="748" y2="168" stroke="#c6cad4" stroke-width="2"/>'
                   '<path d="M130 356 L354 168 M678 356 L454 168" stroke="#16171c" stroke-width="4.5" fill="none"/>'
                   '<line x1="404" y1="356" x2="404" y2="184" stroke="#245cff" stroke-width="4.5" stroke-dasharray="20 14"/>'
                   '<circle cx="290" cy="146" r="10" fill="#245cff"/><circle cx="518" cy="146" r="10" fill="#245cff"/></svg>')
    cap = f'<div style="position:absolute;right:52px;bottom:20px;font-size:20px;color:#9aa0ae">{E(caption_)}</div>' if caption_ else ""
    dec = 0 if float(metric_val).is_integer() else 1
    inner = (f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px">'
             f'<div class="tag" style="position:absolute;left:52px;top:38px;color:var(--b1)">OPTICAL CLARITY</div>'
             f'<div style="position:absolute;left:52px;top:70px;font-weight:900;font-size:36px">{E(title)}</div>'
             f'<div style="position:absolute;right:52px;top:34px;text-align:right"><span style="font-size:22px;font-weight:700;color:var(--gry);margin-right:10px">{E(metric_name)}</span>'
             f'<span class="tnum gt g-b" style="font-weight:900;font-size:52px"><span class="n">0</span><span style="font-size:28px">{E(unit)}</span></span></div>'
             f'<div style="position:absolute;left:52px;top:140px;width:808px;height:396px;border-radius:28px;background:#f2f4f9;border:1.5px solid #e3e7f0;overflow:hidden">'
             f'<div style="position:absolute;inset:0;filter:blur(4.2px);opacity:.66">{scene_haze}</div>'
             f'<div style="position:absolute;left:26px;top:24px;font-size:23px;font-weight:700;color:var(--gry)">{E(haze_label)}</div>'
             f'<div class="flc" style="position:absolute;inset:0;clip-path:inset(24px 418px 24px 30px round 22px)">{scene_clear}</div>'
             f'<div class="flw" style="position:absolute;left:0;top:24px;width:360px;height:348px;border-radius:22px;border:2.5px solid #245cff;box-shadow:0 14px 34px rgba(36,92,255,.14)">'
             f'<div style="position:absolute;left:18px;top:16px;padding:6px 16px;border-radius:99px;background:rgba(36,92,255,.10);font-size:21px;font-weight:700;color:var(--b1)">{E(clear_label)}</div></div></div>{cap}</div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    _t26_card(b, f"#{i} .card", t, d, ghost=_ghost)
    b.js(f'(function(){{const o={{x:32}},cl=document.querySelector("#{i} .flc"),wn=document.querySelector("#{i} .flw");'
         f'const u=()=>{{cl.style.clipPath="inset(24px "+(808-o.x-360).toFixed(1)+"px 24px "+o.x.toFixed(1)+"px round 22px)";wn.style.transform="translateX("+o.x.toFixed(1)+"px)";}};u();'
         f'tl.fromTo(o,{{x:32}},{{x:412,duration:1.35,ease:"power3.inOut",onUpdate:u}},{at:.3f});'
         f'tl.to(o,{{x:396,duration:2.1,ease:"sine.inOut",yoyo:true,repeat:2,onUpdate:u}},{at + 1.35:.3f});}})();'
         f'(function(){{const o={{v:0}},el=document.querySelector("#{i} .n");tl.fromTo(o,{{v:0}},{{v:{metric_val},duration:1.25,ease:"expo.out",onUpdate:()=>el.textContent=o.v.toFixed({dec})}},{at + .45:.3f});}})();')

# 8) Guide-Locked Vertical Drum Wheel (가이드 고정 수직 드럼 피커)
def drumwheel(b, t, d, box=(84, 300, 912, 600), title="시공 농도 · 등급 선택",
              options=("15% · 05%", "30% · 15%", "40% · 25%", "70% · 40%"), pick=2,
              spec_label="전면 실 농도 VLT", spec_val=42, unit="%", caption_="", at=None, _ghost=False):
    x, y, w, h = box; at = t + .24 if at is None else at
    opts = list(options); pk = max(0, min(len(opts) - 1, int(pick)))
    seq = opts + opts[:pk + 2]; target_row = len(opts) + pk; rh = 86
    y_end = 152 - target_row * rh
    rows = "".join(f'<div class="dwr{k}" style="height:{rh}px;line-height:{rh}px;font-weight:900;font-size:38px;color:#9aa0ae;text-align:center;white-space:nowrap">{E(s)}</div>' for k, s in enumerate(seq))
    cap = f'<div style="position:absolute;right:52px;bottom:20px;font-size:20px;color:#9aa0ae">{E(caption_)}</div>' if caption_ else ""
    dec = 0 if float(spec_val).is_integer() else 1
    inner = (f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px">'
             f'<div class="tag" style="position:absolute;left:52px;top:38px;color:var(--b1)">PRECISION PICKER</div>'
             f'<div style="position:absolute;left:52px;top:70px;font-weight:900;font-size:36px">{E(title)}</div>'
             f'<div class="dw-mask" style="position:absolute;left:52px;top:144px;width:456px;height:390px;overflow:hidden">'
             f'<div class="dws" style="position:absolute;left:0;top:0;width:100%">{rows}</div></div>'
             f'<div class="dwg" style="position:absolute;left:68px;top:296px;width:424px;height:{rh}px;border-top:2.5px solid #245cff;border-bottom:2.5px solid #245cff;background:rgba(36,92,255,.04);pointer-events:none;transform-origin:center"></div>'
             f'<div class="dwp" style="position:absolute;left:548px;top:156px;width:312px;height:366px;border-radius:28px;background:#f5f7fc;padding:38px 34px;display:flex;flex-direction:column;justify-content:center">'
             f'<div style="font-size:24px;font-weight:700;color:var(--gry)">{E(spec_label)}</div>'
             f'<div class="tnum" style="font-weight:900;font-size:104px;line-height:1.08;margin:14px 0 22px"><span class="n gt g-b">0</span><span class="gt g-b" style="font-size:42px;margin-left:4px">{E(unit)}</span></div>'
             f'<div style="width:100%;height:16px;border-radius:8px;background:#e3e7f1;overflow:hidden"><div class="br g-b" style="width:0%;height:100%;border-radius:8px"></div></div></div>{cap}</div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    _t26_card(b, f"#{i} .card", t, d, ghost=_ghost)
    b.js(f'tl.fromTo("#{i} .dwg",{{scaleX:0,opacity:0}},{{scaleX:1,opacity:1,duration:.45,ease:"expo.out"}},{at:.3f});'
         f'tl.fromTo("#{i} .dws",{{y:152}},{{y:{y_end},duration:1.35,ease:"expo.out"}},{at + .22:.3f});'
         f'tl.to("#{i} .dwr{target_row}",{{color:"#245cff",duration:.4,ease:"power2.out"}},{at + 1.05:.3f});'
         f'tl.to("#{i} .br",{{width:"{min(100.0, float(spec_val)):.1f}%",duration:1.2,ease:"expo.out"}},{at + .65:.3f});'
         f'(function(){{const o={{v:0}},el=document.querySelector("#{i} .n");tl.fromTo(o,{{v:0}},{{v:{spec_val},duration:1.2,ease:"expo.out",onUpdate:()=>el.textContent=o.v.toFixed({dec})}},{at + .65:.3f});}})();')

# 9) Stepped Optical Vernier Scale (광학 눈금 스텝 레일)
def vernier(b, t, d, box=(84, 300, 912, 600), title="농도별 투과율 · 열차단 연동",
            steps=(("LX 15", 12, 71), ("LX 25", 23, 65), ("LX 40", 42, 61), ("LX 70", 72, 55)), target_idx=2, caption_="", at=None, _ghost=False):
    x, y, w, h = box; at = t + .25 if at is None else at
    st = list(steps); ti = max(0, min(len(st) - 1, int(target_idx)))
    nm_t, vlt_t, tser_t = st[ti]; cx = int(w / 2); sp = 210
    ruler_svg = ""
    for k, (nm, _, _) in enumerate(st):
        xk = k * sp
        ruler_svg += f'<line x1="{xk}" y1="0" x2="{xk}" y2="38" stroke="{"#245cff" if k == ti else "#767a84"}" stroke-width="3"/><text x="{xk}" y="68" font-size="25" font-weight="900" fill="{"#245cff" if k == ti else "#767a84"}" text-anchor="middle" font-family="PP,KR,sans-serif">{E(nm)}</text>'
        if k < len(st) - 1:
            for m in range(1, 10):
                xm = xk + m * (sp / 10)
                ruler_svg += f'<line x1="{xm:.1f}" y1="0" x2="{xm:.1f}" y2="{24 if m == 5 else 14}" stroke="#c6cad4" stroke-width="1.8"/>'
    cap = f'<div style="position:absolute;right:52px;bottom:18px;font-size:20px;color:#9aa0ae">{E(caption_)}</div>' if caption_ else ""
    inner = (f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px;overflow:hidden">'
             f'<div class="tag" style="position:absolute;left:52px;top:36px;color:var(--b1)">OPTICAL VERNIER</div>'
             f'<div style="position:absolute;left:52px;top:68px;font-weight:900;font-size:35px">{E(title)}</div>'
             f'<div style="position:absolute;left:52px;top:138px;width:270px;height:212px;border-radius:26px;background:repeating-linear-gradient(45deg,#eef1f8 0 14px,#ffffff 14px 28px);border:2px solid #dfe4f0;overflow:hidden">'
             f'<div class="vsw" style="position:absolute;inset:0;background:#161b28;opacity:.75"></div>'
             f'<div style="position:absolute;left:20px;bottom:18px;padding:6px 16px;border-radius:99px;background:rgba(255,255,255,.9);font-weight:900;font-size:23px;color:var(--b1)">{E(nm_t)}</div></div>'
             f'<div style="position:absolute;left:358px;top:142px;width:502px">'
             f'<div style="display:flex;justify-content:space-between;align-items:baseline"><span style="font-size:24px;font-weight:700;color:var(--gry)">실 농도 VLT</span><span class="tnum gt g-b" style="font-weight:900;font-size:52px"><span class="nv">0</span><span style="font-size:26px">%</span></span></div>'
             f'<div style="width:100%;height:16px;border-radius:8px;background:#edf0f6;margin:8px 0 24px;overflow:hidden"><div class="bv g-b" style="width:0%;height:100%"></div></div>'
             f'<div style="display:flex;justify-content:space-between;align-items:baseline"><span style="font-size:24px;font-weight:700;color:var(--gry)">총태양에너지 차단 TSER</span><span class="tnum gt g-b" style="font-weight:900;font-size:52px"><span class="nt">0</span><span style="font-size:26px">%</span></span></div>'
             f'<div style="width:100%;height:16px;border-radius:8px;background:#edf0f6;margin-top:8px;overflow:hidden"><div class="bt g-b" style="width:0%;height:100%"></div></div></div>'
             f'<svg width="{w}" height="170" style="position:absolute;left:0;bottom:28px">'
             f'<line x1="52" y1="36" x2="{w - 52}" y2="36" stroke="#e5e9f2" stroke-width="2"/>'
             f'<g class="vrul" transform="translate({cx},36)">{ruler_svg}</g>'
             f'<polygon points="{cx},32 {cx - 11},12 {cx + 11},12" fill="#245cff"/><line x1="{cx}" y1="32" x2="{cx}" y2="82" stroke="#245cff" stroke-width="2.5"/></svg>{cap}</div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    _t26_card(b, f"#{i} .card", t, d, ghost=_ghost)
    end_op = max(.12, min(.82, (100 - float(vlt_t)) / 100 * .82))
    b.js(f'tl.fromTo("#{i} .vrul",{{x:{cx},y:36}},{{x:{cx - ti * sp},y:36,duration:1.45,ease:"power3.inOut"}},{at:.3f});'
         f'tl.to("#{i} .vsw",{{opacity:{end_op:.2f},duration:1.45,ease:"power2.inOut"}},{at:.3f});'
         f'tl.to("#{i} .bv",{{width:"{min(100.0, float(vlt_t)):.1f}%",duration:1.45,ease:"expo.out"}},{at + .15:.3f});'
         f'tl.to("#{i} .bt",{{width:"{min(100.0, float(tser_t)):.1f}%",duration:1.45,ease:"expo.out"}},{at + .25:.3f});'
         f'(function(){{const o={{v:0,t:0}},ev=document.querySelector("#{i} .nv"),et=document.querySelector("#{i} .nt");'
         f'tl.fromTo(o,{{v:0,t:0}},{{v:{vlt_t},t:{tser_t},duration:1.45,ease:"expo.out",onUpdate:()=>{{ev.textContent=Math.round(o.v);et.textContent=Math.round(o.t);}}}},{at + .15:.3f});}})();')

# 10) Concentric Wavefront Field (동심원 전파·열분산 필드)
def ripplefield(b, t, d, box=(84, 300, 912, 600), title="비금속 세라믹 무간섭 전파 투과", mode="rf_pass",
                src_label="GPS · 하이패스 신호", dst_label="실내 단말기 수신", barrier="XENITH IR", pct=100, unit="%", caption_="", at=None, _ghost=False):
    x, y, w, h = box; at = t + .24 if at is None else at
    arcs_svg = ""
    if mode == "heat_dispersion":
        for k in range(4):
            r = 85 + k * 66
            arcs_svg += f'<path class="rfa{k}" d="M {170 + r * .7:.1f} {340 - r * .65:.1f} A {r} {r} 0 0 1 {170 + r * .7:.1f} {340 + r * .65:.1f}" stroke="#7c4dff" stroke-width="4" stroke-linecap="round" fill="none" opacity="0"/>'
            rr = 70 + k * 58
            arcs_svg += f'<path class="rfr{k}" d="M {448 - rr * .65:.1f} {340 - rr * .75:.1f} A {rr} {rr} 0 0 0 {448 - rr * .65:.1f} {340 + rr * .75:.1f}" stroke="#245cff" stroke-width="3.5" stroke-dasharray="10 8" stroke-linecap="round" fill="none" opacity="0"/>'
    else:
        for k in range(6):
            r = 90 + k * 86
            arcs_svg += f'<path class="rfa{k}" d="M {168 + r * .74:.1f} {340 - r * .55:.1f} A {r} {r} 0 0 1 {168 + r * .74:.1f} {340 + r * .55:.1f}" stroke="#245cff" stroke-width="4" stroke-linecap="round" fill="none" opacity="0"/>'
    cap = f'<div style="position:absolute;right:52px;bottom:20px;font-size:20px;color:#9aa0ae">{E(caption_)}</div>' if caption_ else ""
    inner = (f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px">'
             f'<div class="tag" style="position:absolute;left:52px;top:38px;color:var(--b1)">WAVEFRONT FIELD</div>'
             f'<div style="position:absolute;left:52px;top:70px;font-weight:900;font-size:35px">{E(title)}</div>'
             f'<div style="position:absolute;right:52px;top:38px;text-align:right"><div class="tnum gt g-b" style="font-weight:900;font-size:54px;line-height:1"><span class="n">0</span><span style="font-size:28px">{E(unit)}</span></div></div>'
             f'<svg width="{w}" height="{h}" style="position:absolute;left:0;top:0">'
             f'{arcs_svg}'
             f'<rect x="444" y="156" width="24" height="368" rx="12" fill="rgba(36,92,255,.16)" stroke="#245cff" stroke-width="2.5"/>'
             f'<circle cx="168" cy="340" r="22" fill="#245cff"/><circle class="rfd" cx="744" cy="340" r="22" fill="#c6cad4"/></svg>'
             f'<div style="position:absolute;left:64px;top:382px;width:210px;text-align:center;font-size:23px;font-weight:700;color:var(--ink)">{E(src_label)}</div>'
             f'<div style="position:absolute;left:376px;bottom:34px;width:160px;text-align:center;font-family:PP,KR,sans-serif;font-size:20px;font-weight:700;letter-spacing:.12em;color:var(--b1)">{E(barrier)}</div>'
             f'<div style="position:absolute;right:64px;top:382px;width:210px;text-align:center;font-size:23px;font-weight:700;color:var(--ink)">{E(dst_label)}</div>{cap}</div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    _t26_card(b, f"#{i} .card", t, d, ghost=_ghost)
    if mode == "heat_dispersion":
        for k in range(4):
            b.js(f'tl.fromTo("#{i} .rfa{k}",{{opacity:0,x:-14}},{{opacity:.75,x:0,duration:.55,ease:"power2.out"}},{at + k * .14:.3f});'
                 f'tl.fromTo("#{i} .rfr{k}",{{opacity:0,x:10}},{{opacity:.9,x:0,duration:.65,ease:"expo.out"}},{at + .48 + k * .14:.3f});')
        b.js(f'tl.to("#{i} .rfd",{{fill:"#245cff",duration:.5}},{at + .85:.3f});')
    else:
        for k in range(6):
            b.js(f'tl.fromTo("#{i} .rfa{k}",{{opacity:0,x:-16}},{{opacity:{.92 - k * .10:.2f},x:0,duration:.65,ease:"power2.out"}},{at + k * .14:.3f});'
                 f'tl.to("#{i} .rfa{k}",{{opacity:{.45 - k * .05:.2f},duration:1.4,ease:"sine.inOut",yoyo:true,repeat:2}},{at + .8 + k * .14:.3f});')
        b.js(f'tl.to("#{i} .rfd",{{fill:"#245cff",duration:.45,ease:"expo.out"}},{at + .72:.3f});')
    b.js(f'(function(){{const o={{v:0}},el=document.querySelector("#{i} .n");tl.fromTo(o,{{v:0}},{{v:{pct},duration:1.3,ease:"expo.out",onUpdate:()=>el.textContent=Math.round(o.v)}},{at + .45:.3f});}})();')

TREND26_PARTS = dict(
    sankey=sankey, loupe=loupe, dotmatrix=dotmatrix, caliper=caliper, nodeflow=nodeflow,
    elasticmesh=elasticmesh, frostlens=frostlens, drumwheel=drumwheel, vernier=vernier, ripplefield=ripplefield
)
PARTS.update(TREND26_PARTS)
if "MORPH_PARTS" in globals():
    MORPH_PARTS.update(TREND26_PARTS.keys())

# ═══════════════════════════════════════════════════════════════════════════
# VORTEX 30 — 2026 해외 프로 모션 스튜디오 리서치 기반 신규 도구 30종
# (3D Isometric · Optical Liquid Glass · Physics · Cavalry Procedural · FX)
# ═══════════════════════════════════════════════════════════════════════════
import math as _vx_math

CSS += r"""
.vx-3d{perspective:1150px;transform-style:preserve-3d}
.vx-tnum{font-family:PP,KR,sans-serif;font-variant-numeric:tabular-nums;font-feature-settings:"tnum" 1;letter-spacing:-.03em}
.vx-glass{background:linear-gradient(135deg,rgba(255,255,255,.78),rgba(255,255,255,.46));backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);border:1.5px solid rgba(255,255,255,.92);box-shadow:0 22px 50px rgba(22,26,42,.09),inset 0 2px 10px rgba(255,255,255,.95),inset 0 -2px 8px rgba(36,92,255,.10)}
.vx-cad-h{position:absolute;width:12px;height:12px;border-radius:3px;background:#fff;border:2.5px solid var(--b1);box-shadow:0 2px 8px rgba(36,92,255,.22)}
.vx-flap{background:linear-gradient(180deg,#ffffff 0%,#f3f6fc 49%,#e9eef8 51%,#f6f8fd 100%);color:var(--b1);border:1.5px solid #dfe4f0;border-radius:16px;box-shadow:0 10px 26px rgba(16,18,26,.16);position:relative;overflow:hidden}
.vx-flap::after{content:"";position:absolute;left:0;right:0;top:50%;height:2px;background:rgba(36,92,255,.18)}
"""

def _vx_gt(txt, g="b"):
    if g in (None, "k", "ink"): return f'<span style="color:var(--ink)">{E(txt)}</span>'
    if g == "g": return f'<span class="gry">{E(txt)}</span>'
    gc = "b" if g == "n" else g
    return f'<span class="gt g-{gc}">{E(txt)}</span>'

def _vx_card(b, sel, t, d, ghost=False):
    if "popin" in globals() and "ghost" in popin.__code__.co_varnames:
        popin(b, sel, t, out=t + d, float_=False, ghost=ghost)
    else:
        b.js(f'tl.fromTo("{sel}",{{opacity:0,y:34,scale:.985}},{{opacity:1,y:0,scale:1,duration:.64,ease:"expo.out"}},{t:.3f});'
             f'tl.to("{sel}",{{opacity:0,y:-16,duration:.28,ease:"power2.in"}},{t + d - .30:.3f});')

def _vx_count(b, sel, val, t_start, dur=1.28, dec=None):
    if dec is None:
        dec = 0 if float(val).is_integer() else (2 if round(float(val) * 10) != float(val) * 10 else 1)
    b.js(f'(function(){{const o={{v:0}},el=document.querySelector("{sel}");if(!el)return;'
         f'tl.fromTo(o,{{v:0}},{{v:{float(val)},duration:{dur:.2f},ease:"expo.out",onUpdate:()=>el.textContent=o.v.toFixed({dec})}},{t_start:.3f});}})();')

# ── A1. isoexplode: SSR 30° 등각투영 3D 슬래브 분해도 ──
def isoexplode(b, t, d, box=(84, 295, 912, 610), title="다층 스퍼터링 3D 등각 분해도",
               slabs=(("보호 하드코팅", "g"), ("1차 금속 반사층", "b"), ("광학 클리어 PET", "w"), ("2차 금속 반사층", "p"), ("마운팅 점착층", "g")),
               metric_label="설계 보증", val=10, unit="년", caption_="", at=None, _ghost=False):
    x, y, w, h = box; at = t + .24 if at is None else at; n = len(slabs)
    fills = {"b": ("rgba(36,92,255,.18)", "#245cff"), "p": ("rgba(124,77,255,.16)", "#7c4dff"),
             "w": ("rgba(255,255,255,.92)", "#aeb5c5"), "g": ("rgba(232,236,245,.88)", "#9aa1b2")}
    layers_svg, labels_html = "", ""
    cx, cy = 290, 355
    for k, (nm, st) in enumerate(reversed(list(slabs))):
        idx = n - 1 - k; fl, stk = fills.get(st, fills["g"])
        pts = f"{cx},{cy - 76} {cx + 178},{cy + 14} {cx},{cy + 104} {cx - 178},{cy + 14}"
        side = f"{cx - 178},{cy + 14} {cx},{cy + 104} {cx},{cy + 118} {cx - 178},{cy + 28}"
        side2 = f"{cx + 178},{cy + 14} {cx},{cy + 104} {cx},{cy + 118} {cx + 178},{cy + 28}"
        glow = f'<ellipse class="ieg{idx}" cx="{cx}" cy="{cy + 14}" rx="92" ry="44" fill="rgba(36,92,255,.22)" opacity="0"/>' if st in ("b", "p") else ""
        layers_svg += f'<g class="iel{idx}">{glow}<polygon points="{side}" fill="{stk}" fill-opacity=".28"/><polygon points="{side2}" fill="{stk}" fill-opacity=".18"/><polygon points="{pts}" fill="{fl}" stroke="{stk}" stroke-width="2.5"/></g>'
        yk = 178 + idx * int(330 / max(1, n - 1))
        labels_html += (f'<div class="iet{idx}" style="position:absolute;left:526px;top:{yk - 18}px;display:flex;align-items:center;gap:12px">'
                        f'<span style="width:28px;height:2.5px;background:{stk};display:inline-block"></span>'
                        f'<span style="font-size:24px;font-weight:{900 if st in ("b","p") else 700};color:{"var(--b1)" if st=="b" else ("var(--b2)" if st=="p" else "var(--ink)")}">{E(nm)}</span></div>')
    cap = f'<div style="position:absolute;right:48px;bottom:18px;font-size:20px;color:#9aa0ae">{E(caption_)}</div>' if caption_ else ""
    inner = (f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px">'
             f'<div class="tag" style="position:absolute;left:52px;top:36px;color:var(--b1)">ISOMETRIC AXONOMETRIC</div>'
             f'<div style="position:absolute;left:52px;top:68px;font-weight:900;font-size:35px">{E(title)}</div>'
             f'<div style="position:absolute;right:52px;top:34px;text-align:right"><div style="font-size:21px;font-weight:700;color:var(--gry)">{E(metric_label)}</div>'
             f'<div class="vx-tnum gt g-b" style="font-weight:900;font-size:52px;line-height:1.05"><span class="n">0</span><span style="font-size:26px">{E(unit)}</span></div></div>'
             f'<svg width="{w}" height="{h}" style="position:absolute;left:0;top:0"><ellipse class="iesh" cx="{cx}" cy="492" rx="148" ry="54" fill="rgba(20,24,38,.07)"/>{layers_svg}</svg>'
             f'{labels_html}{cap}</div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    _vx_card(b, f"#{i} .card", t, d, ghost=_ghost)
    mid = (n - 1) / 2.0
    for idx in range(n):
        dy = (idx - mid) * 62
        b.js(f'tl.fromTo("#{i} .iel{idx}",{{y:{(idx - mid) * 10:.1f},opacity:0}},{{y:{(idx - mid) * 10:.1f},opacity:1,duration:.4,ease:"expo.out"}},{at + idx * .05:.3f});'
             f'tl.to("#{i} .iel{idx}",{{y:{dy:.1f},duration:1.15,ease:"power3.inOut"}},{at + .32:.3f});'
             f'tl.to("#{i} .iel{idx}",{{y:{dy - 5:.1f},duration:2.0,ease:"sine.inOut",yoyo:true,repeat:2}},{at + 1.48 + idx * .08:.3f});'
             f'tl.fromTo("#{i} .iet{idx}",{{opacity:0,x:14}},{{opacity:1,x:0,duration:.5,ease:"expo.out"}},{at + .68 + idx * .09:.3f});')
    b.js(f'tl.to("#{i} .ieg0, #{i} .ieg1, #{i} .ieg2, #{i} .ieg3, #{i} .ieg4",{{opacity:1,duration:.8}},{at + .6:.3f});'
         f'tl.fromTo("#{i} .iesh",{{scale:1,transformOrigin:"center"}},{{scale:.82,opacity:.45,duration:1.15,ease:"power3.inOut"}},{at + .32:.3f});')
    _vx_count(b, f"#{i} .n", val, at + .55)

# ── A2. zparallax: 3중 Z-뎁스 패럴랙스 카메라 돌리 리그 (카드 틀 탈피) ──
def zparallax(b, t, d, box=(72, 285, 936, 630), eyebrow="SPATIAL DEPTH TELEMETRY", big_val=65, unit="%",
              headline="열반사 밸런스의 정점", chips=("전면 LX 40", "측후면 LX 25", "10년 보증"), at=None):
    x, y, w, h = box; at = t + .18 if at is None else at
    ch_html = "".join(
        f'<div class="zpc{k}" style="position:absolute;left:{44 + k * 296}px;bottom:48px;width:268px;height:86px;border-radius:24px;'
        f'background:#fff;border:1.5px solid rgba(36,92,255,.20);box-shadow:0 18px 40px rgba(18,22,36,.10);display:flex;align-items:center;justify-content:center;'
        f'font-weight:900;font-size:27px;color:{"var(--b1)" if k==0 else "var(--ink)"};transform:translateZ(95px)">{E(c)}</div>'
        for k, c in enumerate(chips[:3]))
    grid = "".join(f'<line x1="{k*78}" y1="0" x2="{k*78}" y2="{h}" stroke="rgba(36,92,255,.07)" stroke-width="1.5"/>' for k in range(13))
    inner = (f'<div class="vx-3d" style="position:absolute;inset:0;overflow:visible">'
             f'<div class="zrig" style="position:absolute;inset:0;transform-style:preserve-3d">'
             f'<div style="position:absolute;inset:24px;border-radius:40px;background:rgba(255,255,255,.55);border:1.5px solid rgba(20,22,28,.08);transform:translateZ(-110px);overflow:hidden">'
             f'<svg width="{w}" height="{h}">{grid}<circle cx="{w//2}" cy="{h//2}" r="240" fill="none" stroke="rgba(36,92,255,.10)" stroke-width="2" stroke-dasharray="10 10"/></svg></div>'
             f'<div class="card" style="left:118px;top:76px;width:700px;height:410px;display:flex;flex-direction:column;align-items:center;justify-content:center;transform:translateZ(10px)">'
             f'<div class="tag" style="color:var(--b1)">{E(eyebrow)}</div>'
             f'<div class="vx-tnum" style="font-weight:900;font-size:168px;line-height:1.02;margin:10px 0"><span class="n gt g-bp">0</span><span class="gt g-b" style="font-size:74px">{E(unit)}</span></div>'
             f'<div style="font-weight:900;font-size:34px;color:var(--ink)">{E(headline)}</div></div>'
             f'{ch_html}</div></div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    b.js(f'tl.fromTo("#{i} .zrig",{{opacity:0,scale:1.16,rotationX:9,rotationY:-8,y:28}},{{opacity:1,scale:1,rotationX:0,rotationY:0,y:0,duration:1.25,ease:"expo.out"}},{at:.3f});'
         f'tl.to("#{i} .zrig",{{rotationY:3.5,rotationX:-2,y:-6,duration:{max(1.2, d - 1.5):.2f},ease:"sine.inOut"}},{at + 1.25:.3f});'
         f'tl.fromTo("#{i} [class^=zpc]",{{opacity:0,y:36}},{{opacity:1,y:0,duration:.65,stagger:.11,ease:"expo.out"}},{at + .42:.3f});'
         f'tl.to("#{i}",{{opacity:0,scale:.96,duration:.28,ease:"power2.in"}},{t + d - .30:.3f});')
    _vx_count(b, f"#{i} .n", big_val, at + .28, dur=1.35)

# ── A3. rackfocus: 전경(통념) ↔ 원경(진실 수치) 시네마틱 포커스 풀 ──
def rackfocus(b, t, d, box=(84, 295, 912, 610), front_tag="COMMON MYTH", front_text="어두운 농도 = 높은 열차단?",
              back_tag="OPTICAL FACT", back_val=61, back_unit="%", back_sub="밝은 LX 40에서도 지켜내는 TSER", at=None):
    x, y, w, h = box; shift_t = (t + d * .46) if at is None else at
    inner = (f'<div style="position:absolute;inset:0">'
             f'<div class="rfb card" style="left:44px;top:24px;width:824px;height:430px;padding:44px 52px;border:2px solid rgba(36,92,255,.22);filter:blur(4.8px);opacity:.46;transform:scale(.94)">'
             f'<div class="tag" style="color:var(--b1)">{E(back_tag)}</div>'
             f'<div style="display:flex;align-items:baseline;gap:24px;margin-top:18px">'
             f'<div class="vx-tnum" style="font-weight:900;font-size:148px;line-height:1"><span class="n gt g-b">0</span><span class="gt g-b" style="font-size:64px">{E(back_unit)}</span></div>'
             f'<div style="font-weight:900;font-size:34px;line-height:1.35;color:var(--ink)">{E(back_sub)}</div></div></div>'
             f'<div class="rff card" style="left:86px;top:332px;width:740px;height:236px;padding:38px 46px;background:#f7f8fc;border:1.5px solid #dde2ee">'
             f'<div class="tag">{E(front_tag)}</div>'
             f'<div style="font-weight:900;font-size:40px;color:var(--ink);margin-top:14px">{E(front_text)}</div></div></div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    b.js(f'tl.fromTo("#{i} .rff",{{opacity:0,y:28}},{{opacity:1,y:0,duration:.55,ease:"expo.out"}},{t + .12:.3f});'
         f'tl.fromTo("#{i} .rfb",{{opacity:0}},{{opacity:.46,duration:.55}},{t + .18:.3f});'
         f'tl.to("#{i} .rff",{{filter:"blur(4.6px)",opacity:.38,scale:.95,y:26,duration:.82,ease:"power3.inOut"}},{shift_t:.3f});'
         f'tl.to("#{i} .rfb",{{filter:"blur(0px)",opacity:1,scale:1,y:16,duration:.85,ease:"power3.inOut"}},{shift_t:.3f});'
         f'tl.to("#{i}",{{opacity:0,y:-16,duration:.28,ease:"power2.in"}},{t + d - .30:.3f});')
    _vx_count(b, f"#{i} .n", back_val, shift_t + .12, dur=1.2)

# ── A4. hudtilt: 3D 퍼스펙티브 텔레메트리 데크 ──
def hudtilt(b, t, d, box=(84, 295, 912, 610), title="광학 스펙 텔레메트리", code="TELEMETRY HUD",
            main_val=71, unit="%", specs=(("TSER", "71%"), ("실 농도", "12%"), ("보증", "10년")), at=None):
    x, y, w, h = box; at = t + .22 if at is None else at
    sp_html = "".join(
        f'<div class="hsp{k}" style="flex:1;padding:20px 22px;border-radius:20px;background:#f4f7fd;border:1.5px solid rgba(36,92,255,.14)">'
        f'<div style="font-size:20px;font-weight:700;color:var(--gry)">{E(k_lb)}</div>'
        f'<div class="vx-tnum" style="font-size:34px;font-weight:900;color:var(--b1);margin-top:6px">{E(k_v)}</div></div>'
        for k, (k_lb, k_v) in enumerate(specs[:3]))
    inner = (f'<div class="vx-3d" style="position:absolute;inset:0">'
             f'<div class="hdk card" style="left:18px;top:16px;width:{w - 36}px;height:{h - 32}px;padding:42px 48px;transform-style:preserve-3d;border:1.5px solid rgba(36,92,255,.20)">'
             f'<div style="display:flex;justify-content:space-between;align-items:center"><span class="tag" style="color:var(--b1)">{E(code)}</span><span style="font-family:PP,sans-serif;font-size:20px;color:#9aa0ae">3D AXIS ACTIVE</span></div>'
             f'<div style="font-weight:900;font-size:36px;margin-top:8px">{E(title)}</div>'
             f'<div style="display:flex;align-items:center;justify-content:space-between;margin:26px 0 28px">'
             f'<svg width="230" height="230" style="overflow:visible">'
             f'<circle cx="115" cy="115" r="96" fill="none" stroke="#e5e9f2" stroke-width="10"/>'
             f'<circle class="hr1" cx="115" cy="115" r="96" fill="none" stroke="#245cff" stroke-width="10" stroke-linecap="round" pathLength="100" stroke-dasharray="100" stroke-dashoffset="100" transform="rotate(-90 115 115)"/>'
             f'<circle class="hr2" cx="115" cy="115" r="72" fill="none" stroke="#7c4dff" stroke-width="2.5" stroke-dasharray="12 10"/></svg>'
             f'<div style="flex:1;padding-left:42px"><div class="vx-tnum" style="font-weight:900;font-size:132px;line-height:1"><span class="n gt g-bp">0</span><span class="gt g-b" style="font-size:54px">{E(unit)}</span></div></div></div>'
             f'<div style="display:flex;gap:16px">{sp_html}</div></div></div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    b.js(f'tl.fromTo("#{i} .hdk",{{opacity:0,rotationX:22,rotationY:-16,y:36,scale:.95}},{{opacity:1,rotationX:7,rotationY:-6,y:0,scale:1,duration:1.05,ease:"expo.out"}},{t:.3f});'
         f'tl.to("#{i} .hdk",{{rotationX:3,rotationY:4,duration:{max(1.2, d - 1.4):.2f},ease:"sine.inOut"}},{t + 1.05:.3f});'
         f'tl.to("#{i} .hr1",{{strokeDashoffset:{100 - min(100, float(main_val)):.1f},duration:1.3,ease:"expo.out"}},{at + .2:.3f});'
         f'tl.to("#{i} .hr2",{{rotation:160,transformOrigin:"115px 115px",duration:{max(1.5, d - .5):.2f},ease:"none"}},{t:.3f});'
         f'tl.fromTo("#{i} [class^=hsp]",{{opacity:0,y:18}},{{opacity:1,y:0,duration:.5,stagger:.1,ease:"expo.out"}},{at + .55:.3f});'
         f'tl.to("#{i}",{{opacity:0,y:-16,duration:.28,ease:"power2.in"}},{t + d - .30:.3f});')
    _vx_count(b, f"#{i} .n", main_val, at + .2)

# ── A5. irisshutter: 4분할 트리고노메트리 조리개 셔터 리빌 ──
def irisshutter(b, t, d, box=(84, 300, 912, 600), tag="GEOMETRIC APERTURE", val=10, unit="년",
                label="생고뱅 공식 워런티", sub="색 빠짐 · 금속 산화 제로 설계", at=None, _ghost=False):
    x, y, w, h = box; open_t = (t + .38) if at is None else at
    blades = (
        f'<rect class="ib0" x="0" y="0" width="{w//2 + 2}" height="{h//2 + 2}" fill="#eef1f8" stroke="#dfe4f0"/>'
        f'<rect class="ib1" x="{w//2 - 2}" y="0" width="{w//2 + 2}" height="{h//2 + 2}" fill="#e9edf7" stroke="#dfe4f0"/>'
        f'<rect class="ib2" x="0" y="{h//2 - 2}" width="{w//2 + 2}" height="{h//2 + 2}" fill="#e9edf7" stroke="#dfe4f0"/>'
        f'<rect class="ib3" x="{w//2 - 2}" y="{h//2 - 2}" width="{w//2 + 2}" height="{h//2 + 2}" fill="#eef1f8" stroke="#dfe4f0"/>')
    inner = (f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px;overflow:hidden">'
             f'<div class="icore" style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center">'
             f'<div class="tag" style="color:var(--b1)">{E(tag)}</div>'
             f'<div class="vx-tnum" style="font-weight:900;font-size:164px;line-height:1.05;margin:12px 0"><span class="n gt g-bp">0</span><span class="gt g-b" style="font-size:68px;margin-left:6px">{E(unit)}</span></div>'
             f'<div style="font-weight:900;font-size:38px;color:var(--ink)">{E(label)}</div>'
             f'<div style="font-size:25px;font-weight:700;color:var(--gry);margin-top:10px">{E(sub)}</div></div>'
             f'<svg width="{w}" height="{h}" style="position:absolute;inset:0;pointer-events:none">{blades}</svg></div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    _vx_card(b, f"#{i} .card", t, d, ghost=_ghost)
    dirs = [(-w * .56, -h * .56, -24), (w * .56, -h * .56, 24), (-w * .56, h * .56, 24), (w * .56, h * .56, -24)]
    for k, (dx, dy, rot) in enumerate(dirs):
        b.js(f'tl.to("#{i} .ib{k}",{{x:{dx:.0f},y:{dy:.0f},rotation:{rot},duration:1.05,ease:"power3.inOut"}},{open_t:.3f});')
    b.js(f'tl.fromTo("#{i} .icore",{{scale:.9,opacity:0}},{{scale:1,opacity:1,duration:.85,ease:"expo.out"}},{open_t + .22:.3f});')
    _vx_count(b, f"#{i} .n", val, open_t + .30)

# ── A6. hingeportal: 3D 경첩 도어 스윙 포털 전환 ──
def hingeportal(b, t, d, box=(84, 300, 912, 600), door_tag="BEFORE · 재시공 악순환", door_title="염료 변색 후 중복 지출",
                inside_tag="SOLUTION · 한 번의 설계", inside_title="풀메탈 스퍼터링 직행", inside_val=10, inside_unit="년 보증", at=None):
    x, y, w, h = box; open_t = (t + d * .42) if at is None else at
    inner = (f'<div class="vx-3d" style="position:absolute;inset:0">'
             f'<div class="hpi card" style="left:0;top:0;width:{w}px;height:{h}px;padding:52px;display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;border:2px solid rgba(36,92,255,.24)">'
             f'<div class="tag" style="color:var(--b1)">{E(inside_tag)}</div>'
             f'<div class="vx-tnum" style="font-weight:900;font-size:132px;line-height:1.08;margin:14px 0"><span class="n gt g-b">0</span><span class="gt g-b" style="font-size:48px;margin-left:8px">{E(inside_unit)}</span></div>'
             f'<div style="font-weight:900;font-size:40px;color:var(--ink)">{E(inside_title)}</div></div>'
             f'<div class="hpd card" style="left:0;top:0;width:{w}px;height:{h}px;padding:56px;display:flex;flex-direction:column;justify-content:center;background:#eff2f9;transform-origin:left center;backface-visibility:hidden">'
             f'<div class="tag">{E(door_tag)}</div>'
             f'<div style="font-weight:900;font-size:46px;color:var(--gry);margin-top:18px">{E(door_title)}</div>'
             f'<div style="width:120px;height:6px;border-radius:3px;background:var(--b2);margin-top:28px"></div></div></div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    b.js(f'tl.fromTo("#{i}",{{opacity:0,y:30}},{{opacity:1,y:0,duration:.55,ease:"expo.out"}},{t:.3f});'
         f'tl.to("#{i} .hpd",{{rotationY:-106,opacity:0,duration:1.05,ease:"power3.inOut"}},{open_t:.3f});'
         f'tl.fromTo("#{i} .hpi",{{scale:.92,opacity:.4}},{{scale:1,opacity:1,duration:.95,ease:"expo.out"}},{open_t + .12:.3f});'
         f'tl.to("#{i}",{{opacity:0,y:-16,duration:.28,ease:"power2.in"}},{t + d - .30:.3f});')
    _vx_count(b, f"#{i} .n", inside_val, open_t + .25)

# ── B7. liquidglass: 애플 리퀴드 글래스 굴절 + 듀얼 라이트 스윕 ──
def liquidglass(b, t, d, box=(84, 300, 912, 600), title="광학 클리어 리퀴드 글래스", bg_word="OPTICAL",
                val=42, unit="% VLT", sub="선명한 야간 시인성과 열반사의 공존", at=None, _ghost=False):
    x, y, w, h = box; at = t + .22 if at is None else at; cid = b.id("lgc")
    stripes = "".join(f'<line x1="{60 + k * 48}" y1="140" x2="{180 + k * 48}" y2="540" stroke="rgba(36,92,255,.13)" stroke-width="10" stroke-linecap="round"/>' for k in range(16))
    bg_svg = (f'<text x="456" y="378" font-family="PP,sans-serif" font-weight="900" font-size="128" fill="#dfe5f2" text-anchor="middle" letter-spacing="6">{E(bg_word)}</text>{stripes}')
    mag_svg = (f'<text x="456" y="378" font-family="PP,sans-serif" font-weight="900" font-size="128" fill="rgba(36,92,255,.22)" text-anchor="middle" letter-spacing="6">{E(bg_word)}</text>{stripes}')
    inner = (f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px;overflow:hidden">'
             f'<div class="tag" style="position:absolute;left:52px;top:36px;color:var(--b1)">LIQUID GLASS REFRACTION</div>'
             f'<div style="position:absolute;left:52px;top:68px;font-weight:900;font-size:35px">{E(title)}</div>'
             f'<svg width="{w}" height="{h}" style="position:absolute;inset:0">'
             f'<defs><clipPath id="{cid}"><rect class="lgm" x="120" y="168" width="540" height="310" rx="68"/></clipPath></defs>'
             f'{bg_svg}<g clip-path="url(#{cid})"><rect x="0" y="0" width="{w}" height="{h}" fill="rgba(255,255,255,.82)"/><g class="lgz">{mag_svg}</g></g></svg>'
             f'<div class="lgp vx-glass" style="position:absolute;left:120px;top:168px;width:540px;height:310px;border-radius:68px;padding:38px 48px;display:flex;flex-direction:column;justify-content:center;overflow:hidden">'
             f'<div class="lgs" style="position:absolute;top:-40px;bottom:-40px;left:-140px;width:110px;background:linear-gradient(90deg,transparent,rgba(255,255,255,.92),transparent);transform:skewX(-24deg)"></div>'
             f'<div class="vx-tnum" style="font-weight:900;font-size:108px;line-height:1"><span class="n gt g-bp">0</span><span class="gt g-b" style="font-size:40px;margin-left:8px">{E(unit)}</span></div>'
             f'<div style="font-size:25px;font-weight:700;color:var(--ink);margin-top:14px">{E(sub)}</div></div></div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    _vx_card(b, f"#{i} .card", t, d, ghost=_ghost)
    b.js(f'(function(){{const o={{x:96}},m=document.querySelector("#{i} .lgm"),p=document.querySelector("#{i} .lgp"),z=document.querySelector("#{i} .lgz");'
         f'const u=()=>{{m.setAttribute("x",o.x.toFixed(1));p.style.left=o.x.toFixed(1)+"px";const cx=o.x+270;z.setAttribute("transform","translate("+(-cx*.12).toFixed(1)+",-38) scale(1.12)");}};u();'
         f'tl.fromTo(o,{{x:96}},{{x:268,duration:1.45,ease:"power3.inOut",onUpdate:u}},{at:.3f});'
         f'tl.to(o,{{x:196,duration:2.2,ease:"sine.inOut",yoyo:true,repeat:2,onUpdate:u}},{at + 1.45:.3f});}})();'
         f'tl.fromTo("#{i} .lgs",{{x:0}},{{x:760,duration:1.25,ease:"power2.inOut"}},{at + .35:.3f});')
    _vx_count(b, f"#{i} .n", val, at + .28)

# ── B8. prismray: 광학 프리즘 파장 분광기 ──
def prismray(b, t, d, box=(84, 300, 912, 600), title="선택적 파장 분광 · 열반사", pass_txt="가시광선 시야 투과",
             block_txt="적외선 · 자외선 반사", pct=65, unit="%", caption_="", at=None, _ghost=False):
    x, y, w, h = box; at = t + .24 if at is None else at
    cap = f'<div style="position:absolute;right:52px;bottom:18px;font-size:20px;color:#9aa0ae">{E(caption_)}</div>' if caption_ else ""
    inner = (f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px">'
             f'<div class="tag" style="position:absolute;left:52px;top:36px;color:var(--b1)">OPTICAL PRISM DISPERSION</div>'
             f'<div style="position:absolute;left:52px;top:68px;font-weight:900;font-size:35px">{E(title)}</div>'
             f'<div style="position:absolute;right:52px;top:36px;text-align:right"><span class="vx-tnum gt g-b" style="font-weight:900;font-size:56px"><span class="n">0</span><span style="font-size:28px">{E(unit)}</span></span></div>'
             f'<svg width="{w}" height="{h}" style="position:absolute;inset:0">'
             f'<line class="pri" x1="66" y1="360" x2="358" y2="334" stroke="#9aa0ae" stroke-width="8" stroke-linecap="round" pathLength="100" stroke-dasharray="100" stroke-dashoffset="100"/>'
             f'<polygon class="prp" points="426,178 556,456 296,456" fill="rgba(36,92,255,.10)" stroke="#245cff" stroke-width="3.5"/>'
             f'<path class="prb1" d="M 358 334 L 166 206" stroke="#245cff" stroke-width="6.5" stroke-linecap="round" fill="none" pathLength="100" stroke-dasharray="100" stroke-dashoffset="100"/>'
             f'<path class="prb2" d="M 358 334 L 188 258" stroke="#7c4dff" stroke-width="5" stroke-linecap="round" fill="none" pathLength="100" stroke-dasharray="100" stroke-dashoffset="100"/>'
             f'<path class="prpass" d="M 358 334 L 494 326 L 832 368" stroke="#767a84" stroke-width="5.5" stroke-dasharray="12 10" stroke-linecap="round" fill="none" pathLength="100" stroke-dasharray="100" stroke-dashoffset="100"/></svg>'
             f'<div class="prl1" style="position:absolute;left:66px;top:152px;padding:8px 20px;border-radius:99px;background:rgba(36,92,255,.10);font-weight:900;font-size:23px;color:var(--b1)">{E(block_txt)}</div>'
             f'<div class="prl2" style="position:absolute;right:62px;top:392px;font-weight:700;font-size:24px;color:var(--gry)">{E(pass_txt)}</div>{cap}</div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    _vx_card(b, f"#{i} .card", t, d, ghost=_ghost)
    b.js(f'tl.fromTo("#{i} .prp",{{scale:.86,opacity:0,transformOrigin:"426px 340px"}},{{scale:1,opacity:1,duration:.55,ease:"expo.out"}},{at:.3f});'
         f'tl.to("#{i} .pri",{{strokeDashoffset:0,duration:.5,ease:"power2.in"}},{at + .18:.3f});'
         f'tl.to(["#{i} .prb1","#{i} .prb2"],{{strokeDashoffset:0,duration:.75,stagger:.1,ease:"expo.out"}},{at + .62:.3f});'
         f'tl.fromTo("#{i} .prpass",{{opacity:0}},{{opacity:1,duration:.65,ease:"power2.out"}},{at + .68:.3f});'
         f'tl.fromTo(["#{i} .prl1","#{i} .prl2"],{{opacity:0,y:12}},{{opacity:1,y:0,duration:.5,stagger:.14,ease:"expo.out"}},{at + .85:.3f});')
    _vx_count(b, f"#{i} .n", pct, at + .55)

# ── B9. raindrop: 발수 접촉각 & 스피드램프 레인 시뮬레이터 ──
def raindrop(b, t, d, box=(84, 300, 912, 600), title="초발수 코팅 접촉각 계측", angle=112,
             surface="발수 코팅 표면", sub="물방울 응집 · 우천 시야 확보", caption_="", at=None, _ghost=False):
    x, y, w, h = box; at = t + .22 if at is None else at
    streaks = "".join(f'<line class="rds{k}" x1="{130 + k * 95}" y1="145" x2="{130 + k * 95}" y2="210" stroke="#c6cad4" stroke-width="2.5" stroke-linecap="round" opacity="0"/>' for k in range(4))
    cap = f'<div style="position:absolute;right:52px;bottom:18px;font-size:20px;color:#9aa0ae">{E(caption_)}</div>' if caption_ else ""
    inner = (f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px">'
             f'<div class="tag" style="position:absolute;left:52px;top:36px;color:var(--b1)">HYDROPHOBIC CONTACT ANGLE</div>'
             f'<div style="position:absolute;left:52px;top:68px;font-weight:900;font-size:35px">{E(title)}</div>'
             f'<svg width="{w}" height="{h}" style="position:absolute;inset:0">{streaks}'
             f'<line x1="68" y1="448" x2="536" y2="448" stroke="#16171c" stroke-width="5" stroke-linecap="round"/>'
             f'<ellipse class="rdr" cx="302" cy="448" rx="18" ry="6" fill="none" stroke="#245cff" stroke-width="2.5" opacity="0"/>'
             f'<g class="rdd" transform="translate(302,180)"><path d="M -56 0 A 62 62 0 1 1 56 0 Z" fill="rgba(36,92,255,.18)" stroke="#245cff" stroke-width="4"/></g>'
             f'<path class="rda" d="M 358 448 L 408 356" stroke="#7c4dff" stroke-width="3" stroke-dasharray="8 6" opacity="0"/>'
             f'<path class="rda" d="M 392 448 A 36 36 0 0 0 374 416" fill="none" stroke="#7c4dff" stroke-width="3" opacity="0"/></svg>'
             f'<div style="position:absolute;left:68px;top:466px;font-size:22px;font-weight:700;color:var(--gry)">{E(surface)}</div>'
             f'<div style="position:absolute;left:578px;top:186px;width:288px">'
             f'<div style="font-size:24px;font-weight:700;color:var(--gry)">접촉각 (Contact Angle)</div>'
             f'<div class="vx-tnum" style="font-weight:900;font-size:108px;line-height:1.05;margin:10px 0 16px"><span class="n gt g-b">0</span><span class="gt g-b" style="font-size:52px">°</span></div>'
             f'<div style="font-size:24px;font-weight:700;color:var(--ink);line-height:1.4">{E(sub)}</div></div>{cap}</div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    _vx_card(b, f"#{i} .card", t, d, ghost=_ghost)
    b.js(f'tl.fromTo("#{i} [class^=rds]",{{y:0,opacity:.7}},{{y:210,opacity:0,duration:.45,stagger:.08,ease:"power2.in"}},{at:.3f});'
         f'tl.fromTo("#{i} .rdd",{{y:170,scaleX:.55,scaleY:1.45,opacity:0}},{{y:448,scaleX:1,scaleY:1,opacity:1,duration:.78,ease:"expo.out"}},{at + .18:.3f});'
         f'tl.fromTo("#{i} .rdr",{{attr:{{rx:18,ry:5}},opacity:.9}},{{attr:{{rx:135,ry:24}},opacity:0,duration:.85,ease:"power2.out"}},{at + .52:.3f});'
         f'tl.to("#{i} .rda",{{opacity:1,duration:.5,ease:"expo.out"}},{at + .72:.3f});')
    _vx_count(b, f"#{i} .n", angle, at + .58)

# ── B10. debrisshield: 탄도 파편 방어 포커스 배리어 & 리코일 ──
def debrisshield(b, t, d, box=(84, 300, 912, 600), title="주행 스톤칩 · 열원 탄성 방어",
                 shield_label="PROTECTIVE BARRIER", hits=3, pct=100, unit="%", at=None, _ghost=False):
    x, y, w, h = box; at = t + .20 if at is None else at
    projs = "".join(f'<circle class="dsp{k}" cx="90" cy="{210 + k * 105}" r="11" fill="#7c4dff" opacity="0"/>'
                    f'<circle class="dsr{k}" cx="366" cy="{255 + k * 70}" r="10" fill="none" stroke="#245cff" stroke-width="3" opacity="0"/>' for k in range(3))
    inner = (f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px">'
             f'<div class="tag" style="position:absolute;left:52px;top:36px;color:var(--b1)">IMPACT DEFLECTION</div>'
             f'<div style="position:absolute;left:52px;top:68px;font-weight:900;font-size:35px">{E(title)}</div>'
             f'<svg width="{w}" height="{h}" style="position:absolute;inset:0">{projs}</svg>'
             f'<div class="dsb" style="position:absolute;left:366px;top:168px;width:476px;height:352px;border-radius:42px;border:3.5px solid #245cff;background:rgba(36,92,255,.05);display:flex;flex-direction:column;align-items:center;justify-content:center">'
             f'<div class="tag" style="color:var(--b1)">{E(shield_label)}</div>'
             f'<div class="vx-tnum" style="font-weight:900;font-size:116px;line-height:1.05;margin-top:8px"><span class="n gt g-b">0</span><span class="gt g-b" style="font-size:48px">{E(unit)}</span></div></div></div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    _vx_card(b, f"#{i} .card", t, d, ghost=_ghost)
    b.js(f'tl.fromTo("#{i} .dsb",{{scale:.5,borderRadius:"180px",opacity:0}},{{scale:1,borderRadius:"42px",opacity:1,duration:.65,ease:"expo.out"}},{at:.3f});')
    for k in range(min(3, max(1, int(hits)))):
        ht = at + .52 + k * .32
        b.js(f'tl.fromTo("#{i} .dsp{k}",{{x:0,y:0,opacity:1}},{{x:268,y:{45 - k * 35},duration:.28,ease:"power2.in"}},{ht - .28:.3f});'
             f'tl.to("#{i} .dsp{k}",{{x:80,y:{-70 + k * 65},opacity:0,duration:.45,ease:"power2.out"}},{ht:.3f});'
             f'tl.fromTo("#{i} .dsr{k}",{{attr:{{r:10}},opacity:.9}},{{attr:{{r:68}},opacity:0,duration:.55,ease:"power2.out"}},{ht:.3f});'
             f'tl.to("#{i} .dsb",{{x:10,duration:.08,ease:"power2.out"}},{ht:.3f});'
             f'tl.to("#{i} .dsb",{{x:0,duration:.22,ease:"expo.out"}},{ht + .08:.3f});')
    _vx_count(b, f"#{i} .n", pct, at + .52)

# ── B11. polarizer: 회전 편광 글레어 소거 필터 ──
def polarizer(b, t, d, box=(84, 300, 912, 600), title="야간 난반사 · 잔상 편광 제어",
              before_txt="산란 눈부심", after_txt="정렬된 클리어 시야", val=6, unit="%", at=None, _ghost=False):
    x, y, w, h = box; at = t + .25 if at is None else at
    glare = "".join(f'<line class="pzg" x1="270" y1="350" x2="{270 + 135 * _vx_math.cos(k * .52):.1f}" y2="{350 + 135 * _vx_math.sin(k * .52):.1f}" stroke="#7c4dff" stroke-width="3.5" stroke-linecap="round"/>' for k in range(12))
    slits = "".join(f'<line x1="158" y1="{254 + k * 24}" x2="382" y2="{254 + k * 24}" stroke="rgba(36,92,255,.32)" stroke-width="2"/>' for k in range(9))
    inner = (f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px">'
             f'<div class="tag" style="position:absolute;left:52px;top:36px;color:var(--b1)">POLARIZING OPTICS</div>'
             f'<div style="position:absolute;left:52px;top:68px;font-weight:900;font-size:35px">{E(title)}</div>'
             f'<svg width="{w}" height="{h}" style="position:absolute;inset:0">{glare}'
             f'<g class="pzr"><circle cx="270" cy="350" r="132" fill="rgba(255,255,255,.65)" stroke="#245cff" stroke-width="5"/>{slits}'
             f'<circle cx="270" cy="218" r="8" fill="#245cff"/></g><circle cx="270" cy="350" r="18" fill="#245cff"/></svg>'
             f'<div style="position:absolute;left:476px;top:186px;width:376px">'
             f'<div class="pzb" style="font-size:25px;font-weight:700;color:var(--gry)">{E(before_txt)} → <span style="color:var(--b1)">{E(after_txt)}</span></div>'
             f'<div class="vx-tnum" style="font-weight:900;font-size:112px;line-height:1.08;margin:14px 0"><span class="n gt g-b">0</span><span class="gt g-b" style="font-size:46px">{E(unit)}</span></div>'
             f'<div style="width:100%;height:14px;border-radius:7px;background:#edf0f6;overflow:hidden"><div class="br g-b" style="width:0%;height:100%"></div></div></div></div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    _vx_card(b, f"#{i} .card", t, d, ghost=_ghost)
    b.js(f'tl.fromTo("#{i} .pzr",{{rotation:-90,transformOrigin:"270px 350px"}},{{rotation:0,duration:1.3,ease:"power3.inOut"}},{at:.3f});'
         f'tl.to("#{i} .pzg",{{scale:.22,opacity:.12,transformOrigin:"270px 350px",duration:1.2,ease:"power3.inOut"}},{at + .15:.3f});'
         f'tl.to("#{i} .br",{{width:"82%",duration:1.2,ease:"expo.out"}},{at + .35:.3f});')
    _vx_count(b, f"#{i} .n", val, at + .35)

# ── B12. heatcamera: 등온선 컨투어 열화상 스캐너 ──
def heatcamera(b, t, d, box=(84, 300, 912, 600), title="유리창 등온선 열유출 스캔", mode="winter",
               delta=20, unit="%", label="단열 효율 상승", caption_="개념도", at=None, _ghost=False):
    x, y, w, h = box; at = t + .24 if at is None else at
    rings = "".join(f'<ellipse class="hcr{k}" cx="290" cy="348" rx="{56 + k * 42}" ry="{38 + k * 28}" fill="none" stroke="{"#245cff" if k < 3 else "#7c4dff"}" stroke-width="{3.5 if k==0 else 2.2}" stroke-opacity="{.9 - k * .15:.2f}" opacity="0"/>' for k in range(5))
    cap = f'<div style="position:absolute;right:52px;bottom:18px;font-size:20px;color:#9aa0ae">{E(caption_)}</div>' if caption_ else ""
    inner = (f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px">'
             f'<div class="tag" style="position:absolute;left:52px;top:36px;color:var(--b1)">ISOTHERMAL CONTOUR SCAN</div>'
             f'<div style="position:absolute;left:52px;top:68px;font-weight:900;font-size:35px">{E(title)}</div>'
             f'<svg width="{w}" height="{h}" style="position:absolute;inset:0">'
             f'<rect x="56" y="152" width="468" height="392" rx="28" fill="#f5f7fc" stroke="#dfe4f0" stroke-width="2"/>'
             f'{rings}<line class="hcs" x1="56" y1="162" x2="524" y2="162" stroke="#245cff" stroke-width="3"/></svg>'
             f'<div style="position:absolute;left:566px;top:186px;width:296px">'
             f'<div style="font-size:25px;font-weight:700;color:var(--gry)">{E(label)}</div>'
             f'<div class="vx-tnum" style="font-weight:900;font-size:112px;line-height:1.05;margin:12px 0"><span class="gt g-b">+</span><span class="n gt g-b">0</span><span class="gt g-b" style="font-size:46px">{E(unit)}</span></div></div>{cap}</div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    _vx_card(b, f"#{i} .card", t, d, ghost=_ghost)
    b.js(f'tl.fromTo("#{i} .hcs",{{y:0}},{{y:370,duration:1.35,ease:"power2.inOut"}},{at:.3f});'
         f'tl.fromTo("#{i} [class^=hcr]",{{opacity:0,scale:.88,transformOrigin:"290px 348px"}},{{opacity:1,scale:1,duration:.65,stagger:.12,ease:"expo.out"}},{at + .2:.3f});')
    _vx_count(b, f"#{i} .n", delta, at + .35)

# ── B13. selfheal: 온열 파동 마이크로 스크래치 자가복원 ──
def selfheal(b, t, d, box=(84, 300, 912, 600), title="마이크로 스월 열복원 시뮬레이션",
             temp_label="SELF-HEALING", pct=100, sub="우레탄 엘라스토머 표면 무결점 복원", at=None, _ghost=False):
    x, y, w, h = box; at = t + .24 if at is None else at
    scratches = (
        '<path class="shs" d="M 110 250 Q 280 310 460 220" stroke="#7c4dff" stroke-width="3.5" fill="none" pathLength="100" stroke-dasharray="100" stroke-dashoffset="0"/>'
        '<path class="shs" d="M 130 350 Q 310 280 480 380" stroke="#767a84" stroke-width="3" fill="none" pathLength="100" stroke-dasharray="100" stroke-dashoffset="0"/>'
        '<path class="shs" d="M 160 430 Q 290 390 440 450" stroke="#7c4dff" stroke-width="2.8" fill="none" pathLength="100" stroke-dasharray="100" stroke-dashoffset="0"/>')
    inner = (f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px">'
             f'<div class="tag" style="position:absolute;left:52px;top:36px;color:var(--b1)">{E(temp_label)}</div>'
             f'<div style="position:absolute;left:52px;top:68px;font-weight:900;font-size:35px">{E(title)}</div>'
             f'<svg width="{w}" height="{h}" style="position:absolute;inset:0">'
             f'<rect x="56" y="152" width="468" height="392" rx="28" fill="#f7f9fd" stroke="#e2e7f2" stroke-width="2"/>'
             f'{scratches}<circle class="shw" cx="290" cy="348" r="24" fill="rgba(36,92,255,.08)" stroke="#245cff" stroke-width="3.5" opacity="0"/></svg>'
             f'<div style="position:absolute;left:566px;top:186px;width:296px">'
             f'<div class="vx-tnum" style="font-weight:900;font-size:112px;line-height:1.05"><span class="n gt g-b">0</span><span class="gt g-b" style="font-size:46px">%</span></div>'
             f'<div style="font-size:25px;font-weight:700;color:var(--ink);margin-top:16px;line-height:1.4">{E(sub)}</div></div></div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    _vx_card(b, f"#{i} .card", t, d, ghost=_ghost)
    b.js(f'tl.fromTo("#{i} .shw",{{attr:{{r:20}},opacity:.95}},{{attr:{{r:240}},opacity:0,duration:1.35,ease:"power2.out"}},{at + .28:.3f});'
         f'tl.to("#{i} .shs",{{strokeDashoffset:100,opacity:0,duration:1.15,stagger:.12,ease:"power2.inOut"}},{at + .35:.3f});')
    _vx_count(b, f"#{i} .n", pct, at + .38)

# ── C14. repelfield: Cavalry 스타일 반응형 벡터장 리펠러 매트릭스 ──
def repelfield(b, t, d, box=(84, 300, 912, 600), title="금속 반사장 복사열 밀어냄",
               probe_label="SOLAR GARD LX FIELD", metric_val=71, unit="%", caption_="", at=None, _ghost=False):
    x, y, w, h = box; at = t + .20 if at is None else at
    cols, rows = 8, 5; vecs = ""
    for r in range(rows):
        for c in range(cols):
            cx, cy = 88 + c * 62, 186 + r * 76
            vecs += f'<line class="rfv" data-x="{cx}" data-y="{cy}" x1="{cx - 14}" y1="{cy}" x2="{cx + 14}" y2="{cy}" stroke="#9aa2b4" stroke-width="4" stroke-linecap="round"/>'
    cap = f'<div style="position:absolute;right:52px;bottom:18px;font-size:20px;color:#9aa0ae">{E(caption_)}</div>' if caption_ else ""
    inner = (f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px">'
             f'<div class="tag" style="position:absolute;left:52px;top:36px;color:var(--b1)">VECTOR REPELLER FIELD</div>'
             f'<div style="position:absolute;left:52px;top:68px;font-weight:900;font-size:35px">{E(title)}</div>'
             f'<svg width="{w}" height="{h}" style="position:absolute;inset:0">{vecs}'
             f'<circle class="rfp" cx="90" cy="338" r="32" fill="rgba(36,92,255,.16)" stroke="#245cff" stroke-width="3.5"/></svg>'
             f'<div style="position:absolute;left:610px;top:186px;width:254px">'
             f'<div style="font-size:22px;font-weight:700;color:var(--b1)">{E(probe_label)}</div>'
             f'<div class="vx-tnum" style="font-weight:900;font-size:112px;line-height:1.05;margin-top:12px"><span class="n gt g-b">0</span><span class="gt g-b" style="font-size:44px">{E(unit)}</span></div></div>{cap}</div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    _vx_card(b, f"#{i} .card", t, d, ghost=_ghost)
    b.js(f'(function(){{const o={{x:90,y:338}},pr=document.querySelector("#{i} .rfp"),vs=[...document.querySelectorAll("#{i} .rfv")];'
         f'const u=()=>{{pr.setAttribute("cx",o.x.toFixed(1));pr.setAttribute("cy",o.y.toFixed(1));'
         f'vs.forEach(el=>{{const vx=+el.dataset.x,vy=+el.dataset.y,dx=vx-o.x,dy=vy-o.y,dist=Math.hypot(dx,dy),f=Math.max(0,1-dist/195);'
         f'const ang=Math.atan2(dy,dx),px=vx+Math.cos(ang)*f*22,py=vy+Math.sin(ang)*f*22;'
         f'el.setAttribute("x1",(px-Math.cos(ang)*14).toFixed(1));el.setAttribute("y1",(py-Math.sin(ang)*14).toFixed(1));'
         f'el.setAttribute("x2",(px+Math.cos(ang)*14).toFixed(1));el.setAttribute("y2",(py+Math.sin(ang)*14).toFixed(1));'
         f'el.setAttribute("stroke",f>.25?"#245cff":"#b5bccb");}});}};u();'
         f'tl.fromTo(o,{{x:90,y:260}},{{x:515,y:395,duration:1.65,ease:"power2.inOut",onUpdate:u}},{at:.3f});'
         f'tl.to(o,{{x:320,y:330,duration:1.9,ease:"sine.inOut",onUpdate:u}},{at + 1.65:.3f});}})();')
    _vx_count(b, f"#{i} .n", metric_val, at + .35)

# ── C15. oscwave: 하모닉 위상차 사인파 오실레이터 ──
def oscwave(b, t, d, box=(84, 300, 912, 600), title="적외선 파장 대역 정밀 차단", peak_label="IR BLOCKING",
            val=94, unit="%", caption_="개념도", at=None, _ghost=False):
    x, y, w, h = box; at = t + .20 if at is None else at
    bars = "".join(f'<rect class="owb" x="{64 + k * 21}" y="260" width="12" height="120" rx="6" fill="{"#245cff" if 7 <= k <= 16 else "#c6cad4"}"/>' for k in range(24))
    cap = f'<div style="position:absolute;right:52px;bottom:18px;font-size:20px;color:#9aa0ae">{E(caption_)}</div>' if caption_ else ""
    inner = (f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px">'
             f'<div class="tag" style="position:absolute;left:52px;top:36px;color:var(--b1)">HARMONIC OSCILLATOR</div>'
             f'<div style="position:absolute;left:52px;top:68px;font-weight:900;font-size:35px">{E(title)}</div>'
             f'<svg width="{w}" height="{h}" style="position:absolute;inset:0">{bars}</svg>'
             f'<div style="position:absolute;left:600px;top:190px;width:264px">'
             f'<div class="tag" style="color:var(--b2)">{E(peak_label)}</div>'
             f'<div class="vx-tnum" style="font-weight:900;font-size:112px;line-height:1.05;margin-top:10px"><span class="n gt g-bp">0</span><span class="gt g-b" style="font-size:44px">{E(unit)}</span></div></div>{cap}</div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    _vx_card(b, f"#{i} .card", t, d, ghost=_ghost)
    b.js(f'(function(){{const o={{ph:0,lk:0}},bs=[...document.querySelectorAll("#{i} .owb")];'
         f'const u=()=>bs.forEach((el,k)=>{{const wv=55+48*Math.sin(o.ph+k*.42), bell=38+245*Math.exp(-Math.pow((k-11.5)/4.8,2));'
         f'const hh=wv*(1-o.lk)+bell*o.lk; el.setAttribute("height",hh.toFixed(1)); el.setAttribute("y",(360-hh/2).toFixed(1));}});u();'
         f'tl.to(o,{{ph:9.5,duration:{max(1.8, d - .4):.2f},ease:"none",onUpdate:u}},{t:.3f});'
         f'tl.to(o,{{lk:1,duration:1.15,ease:"expo.out",onUpdate:u}},{at + .55:.3f});}})();')
    _vx_count(b, f"#{i} .n", val, at + .55)

# ── C16. falloffstack: 벨커브 레인지 폴오프 카드 팬 캐스케이드 ──
def falloffstack(b, t, d, box=(84, 300, 912, 600), title="100% 예약제 원스톱 공정",
                 cards=("신차 정밀 검수", "전처리 · 클리닝", "무터치 열성형", "끝단 쉐이빙", "QR 정품 보증"), pick=2, at=None, _ghost=False):
    x, y, w, h = box; at = t + .22 if at is None else at; cs = list(cards); n = len(cs); pk = max(0, min(n - 1, int(pick)))
    deck = "".join(
        f'<div class="fsc{k}" style="position:absolute;left:316px;top:178px;width:280px;height:336px;border-radius:30px;'
        f'background:{"linear-gradient(160deg,#245cff,#7c4dff);color:#fff" if k==pk else "#fff;color:var(--ink);border:1.5px solid #dfe4f0"};'
        f'box-shadow:0 18px 38px rgba(20,24,38,.10);padding:34px 28px;display:flex;flex-direction:column;justify-content:space-between;transform-origin:center 380px">'
        f'<span style="font-family:PP,sans-serif;font-weight:700;font-size:22px;opacity:.75">STEP 0{k + 1}</span>'
        f'<span style="font-weight:900;font-size:31px;line-height:1.3">{E(nm)}</span></div>'
        for k, nm in enumerate(cs))
    inner = (f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px;overflow:hidden">'
             f'<div class="tag" style="position:absolute;left:52px;top:36px;color:var(--b1)">FALLOFF PROCESS DECK</div>'
             f'<div style="position:absolute;left:52px;top:68px;font-weight:900;font-size:35px">{E(title)}</div>{deck}</div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    _vx_card(b, f"#{i} .card", t, d, ghost=_ghost)
    mid = (n - 1) / 2.0
    for k in range(n):
        off = k - mid; bell = _vx_math.exp(-((k - pk) ** 2) / 2.2)
        b.js(f'tl.fromTo("#{i} .fsc{k}",{{x:0,y:40,rotation:0,opacity:0}},{{x:{off * 138:.1f},y:{-bell * 26:.1f},rotation:{off * 7.5:.1f},opacity:1,duration:1.05,ease:"expo.out"}},{at + k * .06:.3f});')
    b.js(f'tl.to("#{i} .fsc{pk}",{{y:-38,scale:1.06,duration:.65,ease:"expo.out"}},{at + .95:.3f});')

# ── C17. radialsweep: 다축 폴라 레이더 스파이더 폴리곤 ──
def radialsweep(b, t, d, box=(84, 295, 912, 610), title="올라운드 필름 밸런스 비교",
                axes=("열반사", "야간시야", "내구성", "전비방어", "보증"), base=(46, 52, 40, 44, 38), hero=(92, 86, 96, 90, 96),
                hero_name="SOLAR GARD LX", caption_="개념도", at=None, _ghost=False):
    x, y, w, h = box; at = t + .24 if at is None else at
    n = max(3, len(axes)); cx, cy, R = 290, 356, 168
    angs = [-_vx_math.pi / 2 + 2 * _vx_math.pi * k / n for k in range(n)]
    web = "".join(
        f'<polygon points="' + " ".join(f"{cx + R * r * _vx_math.cos(a):.1f},{cy + R * r * _vx_math.sin(a):.1f}" for a in angs) + '" fill="none" stroke="#e5e9f2" stroke-width="1.8"/>'
        for r in (.33, .66, 1.0))
    spokes = "".join(f'<line x1="{cx}" y1="{cy}" x2="{cx + R * _vx_math.cos(a):.1f}" y2="{cy + R * _vx_math.sin(a):.1f}" stroke="#e5e9f2" stroke-width="1.8"/>'
                     f'<text x="{cx + (R + 34) * _vx_math.cos(a):.1f}" y="{cy + (R + 34) * _vx_math.sin(a) + 8:.1f}" font-size="22" font-weight="700" fill="#505565" text-anchor="middle" font-family="KR">{E(axes[k])}</text>'
                     for k, a in enumerate(angs))
    cap = f'<div style="position:absolute;right:52px;bottom:18px;font-size:20px;color:#9aa0ae">{E(caption_)}</div>' if caption_ else ""
    inner = (f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px">'
             f'<div class="tag" style="position:absolute;left:52px;top:36px;color:var(--b1)">MULTI-AXIS RADAR</div>'
             f'<div style="position:absolute;left:52px;top:68px;font-weight:900;font-size:35px">{E(title)}</div>'
             f'<svg width="{w}" height="{h}" style="position:absolute;inset:0">{web}{spokes}'
             f'<polygon class="rspb" points="" fill="rgba(154,160,174,.18)" stroke="#9aa0ae" stroke-width="3"/>'
             f'<polygon class="rsph" points="" fill="rgba(36,92,255,.20)" stroke="#245cff" stroke-width="4.5"/></svg>'
             f'<div style="position:absolute;left:566px;top:210px;width:296px">'
             f'<div style="padding:20px 24px;border-radius:22px;background:#f4f7ff;border:2px solid rgba(36,92,255,.22);margin-bottom:16px">'
             f'<div class="tag" style="color:var(--b1)">HERO SPEC</div><div style="font-weight:900;font-size:30px;margin-top:6px">{E(hero_name)}</div></div>'
             f'<div style="padding:18px 24px;border-radius:20px;background:#f6f7fa;font-weight:700;font-size:24px;color:var(--gry)">일반 흡수형 필름</div></div>{cap}</div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    _vx_card(b, f"#{i} .card", t, d, ghost=_ghost)
    b_arr = [float(v) / 100.0 for v in base[:n]]; h_arr = [float(v) / 100.0 for v in hero[:n]]
    b.js(f'(function(){{const o={{p:0}},angs={list(angs)},ba={b_arr},ha={h_arr},pb=document.querySelector("#{i} .rspb"),ph=document.querySelector("#{i} .rsph");'
         f'const u=()=>{{pb.setAttribute("points",angs.map((a,k)=>({cx}+{R}*ba[k]*o.p*Math.cos(a)).toFixed(1)+","+({cy}+{R}*ba[k]*o.p*Math.sin(a)).toFixed(1)).join(" "));'
         f'ph.setAttribute("points",angs.map((a,k)=>({cx}+{R}*ha[k]*o.p*Math.cos(a)).toFixed(1)+","+({cy}+{R}*ha[k]*o.p*Math.sin(a)).toFixed(1)).join(" "));}};u();'
         f'tl.fromTo(o,{{p:0}},{{p:1,duration:1.3,ease:"expo.out",onUpdate:u}},{at:.3f});}})();')

# ── C18. echostack: 인덱스 딜레이 윤곽선 에코 타이포 ──
def echostack(b, t, d, box=(84, 310, 912, 560), eyebrow="PROCEDURAL ECHO", word="10 YEARS",
              sub="재시공 중복 지출을 끊어내는 기준", g="b", at=None, _ghost=False):
    x, y, w, h = box; at = t + .20 if at is None else at
    col = "#7c4dff" if g == "p" else "#245cff"
    echoes = "".join(
        f'<div class="ecs{k}" style="position:absolute;left:0;right:0;top:206px;text-align:center;font-family:PP,KR,sans-serif;font-weight:900;font-size:128px;line-height:1;'
        f'color:transparent;-webkit-text-stroke:2px {col};opacity:{.45 - k * .09:.2f}">{E(word)}</div>'
        for k in range(4))
    inner = (f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px;overflow:hidden">'
             f'<div class="tag" style="position:absolute;left:0;right:0;top:64px;text-align:center;color:var(--b1)">{E(eyebrow)}</div>'
             f'{echoes}'
             f'<div class="ecm" style="position:absolute;left:0;right:0;top:206px;text-align:center;font-family:PP,KR,sans-serif;font-weight:900;font-size:128px;line-height:1">{_vx_gt(word, g)}</div>'
             f'<div class="ecs_sub" style="position:absolute;left:60px;right:60px;bottom:74px;text-align:center;font-weight:700;font-size:29px;color:var(--ink)">{E(sub)}</div></div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    _vx_card(b, f"#{i} .card", t, d, ghost=_ghost)
    b.js(f'tl.fromTo("#{i} .ecm",{{y:72,opacity:0}},{{y:0,opacity:1,duration:.72,ease:"expo.out"}},{at:.3f});')
    for k in range(4):
        b.js(f'tl.fromTo("#{i} .ecs{k}",{{y:{90 + k * 28},opacity:0}},{{y:{-(k + 1) * 14},opacity:{.36 - k * .07:.2f},duration:.85,ease:"expo.out"}},{at + .06 * (k + 1):.3f});'
             f'tl.to("#{i} .ecs{k}",{{y:0,opacity:0,duration:.75,ease:"power3.inOut"}},{at + 1.05:.3f});')
    b.js(f'tl.fromTo("#{i} .ecs_sub",{{opacity:0,y:16}},{{opacity:1,y:0,duration:.55,ease:"expo.out"}},{at + .55:.3f});')

# ── C19. orbitduplicator: 반경·회전 수식 연동 원형 듀플리케이터 ──
def orbitduplicator(b, t, d, box=(84, 300, 912, 600), label="SAINT-GOBAIN HERITAGE", val=1665, unit="년",
                    sub="360년 이상 축적된 유리가공 · 스퍼터링 기술", at=None, _ghost=False):
    x, y, w, h = box; at = t + .22 if at is None else at; N = 18; cx, cy = 268, 336
    pills = "".join(f'<rect class="odp" x="-6" y="-22" width="12" height="44" rx="6" fill="{"#245cff" if k % 2 == 0 else "#7c4dff"}" fill-opacity="{.85 if k % 3 == 0 else .38}"/>' for k in range(N))
    inner = (f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px">'
             f'<div class="tag" style="position:absolute;left:52px;top:36px;color:var(--b1)">{E(label)}</div>'
             f'<svg width="{w}" height="{h}" style="position:absolute;inset:0"><g class="odg">{pills}</g></svg>'
             f'<div style="position:absolute;left:506px;top:174px;width:356px">'
             f'<div class="vx-tnum" style="font-weight:900;font-size:112px;line-height:1.05"><span class="n gt g-bp">0</span><span class="gt g-b" style="font-size:40px;margin-left:6px">{E(unit)}</span></div>'
             f'<div style="font-size:26px;font-weight:700;color:var(--ink);margin-top:18px;line-height:1.45">{E(sub)}</div></div></div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    _vx_card(b, f"#{i} .card", t, d, ghost=_ghost)
    b.js(f'(function(){{const o={{r:36,rot:0}},ps=[...document.querySelectorAll("#{i} .odp")],N=ps.length;'
         f'const u=()=>ps.forEach((el,k)=>{{const a=2*Math.PI*k/N+o.rot*Math.PI/180,px={cx}+o.r*Math.cos(a),py={cy}+o.r*Math.sin(a),deg=a*180/Math.PI+90+o.rot*.5;'
         f'el.setAttribute("transform","translate("+px.toFixed(1)+","+py.toFixed(1)+") rotate("+deg.toFixed(1)+")");}});u();'
         f'tl.fromTo(o,{{r:34,rot:-40}},{{r:152,rot:0,duration:1.3,ease:"expo.out",onUpdate:u}},{at:.3f});'
         f'tl.to(o,{{rot:48,duration:{max(1.4, d - 1.5):.2f},ease:"none",onUpdate:u}},{at + 1.3:.3f});}})();')
    _vx_count(b, f"#{i} .n", val, at + .25)

# ── D20. doczoom: 성적서·보증서 매치컷 줌 & 멀티플라이 형광펜 ──
def doczoom(b, t, d, box=(84, 300, 912, 600), doc_title="OFFICIAL OPTICAL SPECIFICATION",
            lines=("가시광선 투과율 (VLT) : 42%", "총태양에너지 차단율 (TSER) : 61%", "제조사 공식 보증 기간 : 10년"), pick=1, at=None, _ghost=False):
    x, y, w, h = box; zt = (t + .45) if at is None else at; ls = list(lines); pk = max(0, min(len(ls) - 1, int(pick)))
    rows = "".join(
        f'<div class="dzr{k}" style="position:relative;padding:22px 26px;margin-bottom:14px;border-radius:16px;background:#fff;border:1px solid #e6eaf3;font-size:29px;font-weight:{900 if k==pk else 700};color:{"var(--ink)" if k==pk else "var(--gry)"}">'
        f'{"<div class=dzhl style=\"position:absolute;left:16px;right:16px;top:18%;bottom:14%;border-radius:10px;background:rgba(36,92,255,.16);transform-origin:left\"></div>" if k==pk else ""}'
        f'<span style="position:relative;z-index:1">{E(s)}</span></div>'
        for k, s in enumerate(ls))
    inner = (f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px;overflow:hidden;background:#eef1f8">'
             f'<div class="dzd" style="position:absolute;left:96px;top:64px;width:720px;padding:42px 46px;border-radius:28px;background:#fafbfe;border:1.5px solid #dfe4f0;box-shadow:0 20px 44px rgba(18,22,36,.08)">'
             f'<div style="display:flex;justify-content:space-between;border-bottom:2px solid #16171c;padding-bottom:16px;margin-bottom:24px">'
             f'<span style="font-family:PP,sans-serif;font-weight:900;font-size:22px;letter-spacing:.14em">{E(doc_title)}</span><span style="font-family:PP,sans-serif;font-size:20px;color:var(--b1)">VERIFIED</span></div>'
             f'{rows}</div></div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    _vx_card(b, f"#{i} .card", t, d, ghost=_ghost)
    ty = -(pk - 1) * 78
    b.js(f'tl.fromTo("#{i} .dzd",{{scale:.84,y:10,rotation:-1.5}},{{scale:1.12,y:{ty:.0f},rotation:0,duration:1.15,ease:"power3.inOut"}},{zt:.3f});'
         f'tl.fromTo("#{i} .dzhl",{{scaleX:0}},{{scaleX:1,duration:.65,ease:"expo.out"}},{zt + .72:.3f});')
    for k in range(len(ls)):
        if k != pk:
            b.js(f'tl.to("#{i} .dzr{k}",{{filter:"blur(2.8px)",opacity:.45,duration:.7}},{zt + .35:.3f});')

# ── D21. pannabletrack: 광폭 패닝 건축 눈금 타임라인 ──
def pannabletrack(b, t, d, box=(84, 300, 912, 600), title="시간이 증명하는 내구성 경로",
                  milestones=(("출고 당일", "새 필름 동일 외관"), ("3년 경과", "염료 변색 시작"), ("5년 경과", "열차단 저하 · 재시공"), ("10년 보증", "LX 초기 스펙 유지")),
                  pick=3, at=None, _ghost=False):
    x, y, w, h = box; at = t + .22 if at is None else at; ms = list(milestones); pk = max(0, min(len(ms) - 1, int(pick))); sp = 420
    nodes = ""
    for k, (tm, desc) in enumerate(ms):
        xk = 240 + k * sp; hi = (k == pk); top_side = (k % 2 == 0)
        nodes += (f'<div style="position:absolute;left:{xk - 150}px;top:{176 if top_side else 372}px;width:300px;text-align:center">'
                  f'<div style="font-size:22px;font-weight:900;color:{"var(--b1)" if hi else "var(--gry)"}">{E(tm)}</div>'
                  f'<div style="font-size:27px;font-weight:900;color:{"var(--ink)" if hi else "#686e7e"};margin-top:6px">{E(desc)}</div></div>'
                  f'<div style="position:absolute;left:{xk - 2}px;top:{262 if top_side else 326}px;width:4px;height:52px;background:{"#245cff" if hi else "#c6cad4"}"></div>'
                  f'<div class="ptm{k}" style="position:absolute;left:{xk - 14}px;top:312px;width:28px;height:28px;border-radius:50%;background:{"#245cff" if hi else "#fff"};border:5px solid {"#7c4dff" if hi else "#9aa0ae"}"></div>')
    ticks = "".join(f'<div style="position:absolute;left:{80 + k * 42}px;top:325px;width:2px;height:{22 if k % 5 == 0 else 10}px;background:#d8dde8"></div>' for k in range(52))
    inner = (f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px;overflow:hidden">'
             f'<div class="tag" style="position:absolute;left:52px;top:36px;color:var(--b1)">CHRONO RULER TRACK</div>'
             f'<div style="position:absolute;left:52px;top:68px;font-weight:900;font-size:35px">{E(title)}</div>'
             f'<div class="ptt" style="position:absolute;left:0;top:0;width:2400px;height:{h}px">'
             f'<div style="position:absolute;left:80px;top:324px;width:2100px;height:4px;background:#dfe4f0"></div>{ticks}{nodes}</div></div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    _vx_card(b, f"#{i} .card", t, d, ghost=_ghost)
    end_x = (w / 2) - (240 + pk * sp)
    b.js(f'tl.fromTo("#{i} .ptt",{{x:180}},{{x:{end_x:.0f},duration:1.65,ease:"power3.inOut"}},{at:.3f});'
         f'tl.fromTo("#{i} .ptm{pk}",{{scale:1}},{{scale:1.35,duration:.5,yoyo:true,repeat:2,ease:"sine.inOut"}},{at + 1.4:.3f});')

# ── D22. cadbox: 8핸들 CAD 바운딩 박스 & 가변 폰트 웨이트 보간 ──
def cadbox(b, t, d, box=(84, 310, 912, 560), tag="PRECISION FINAL-FIT", word="재단선 없는 마감",
           sub="도장 안쪽까지 감싸는 정밀 설계", val=0.1, unit="mm", at=None, _ghost=False):
    x, y, w, h = box; at = t + .24 if at is None else at
    handles = "".join(f'<i class="vx-cad-h" style="{pos}"></i>' for pos in (
        "left:-7px;top:-7px", "right:-7px;top:-7px", "left:-7px;bottom:-7px", "right:-7px;bottom:-7px",
        "left:calc(50% - 6px);top:-7px", "left:calc(50% - 6px);bottom:-7px", "left:-7px;top:calc(50% - 6px)", "right:-7px;top:calc(50% - 6px)"))
    inner = (f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px">'
             f'<div class="tag" style="position:absolute;left:52px;top:36px;color:var(--b1)">{E(tag)}</div>'
             f'<div style="position:absolute;right:52px;top:34px"><span class="vx-tnum gt g-b" style="font-weight:900;font-size:48px"><span class="n">0</span><span style="font-size:24px;margin-left:4px">{E(unit)}</span></span></div>'
             f'<div class="cbx" style="position:absolute;left:226px;top:176px;width:460px;height:186px;border:2px solid #245cff;background:rgba(36,92,255,.03);display:flex;align-items:center;justify-content:center">'
             f'{handles}<span class="cbt" style="font-size:52px;font-weight:400;letter-spacing:-.02em;color:var(--ink);white-space:nowrap">{E(word)}</span></div>'
             f'<div style="position:absolute;left:0;right:0;bottom:68px;text-align:center;font-size:26px;font-weight:700;color:var(--gry)">{E(sub)}</div></div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    _vx_card(b, f"#{i} .card", t, d, ghost=_ghost)
    b.js(f'tl.fromTo("#{i} .cbx",{{left:236,width:440,height:150}},{{left:106,width:700,height:206,duration:1.1,ease:"expo.out"}},{at + .2:.3f});'
         f'(function(){{const o={{w:350}},el=document.querySelector("#{i} .cbt");'
         f'tl.fromTo(o,{{w:350}},{{w:900,duration:1.1,ease:"expo.out",onUpdate:()=>{{el.style.fontWeight=Math.round(o.w/100)*100;el.style.letterSpacing=(-0.01-(o.w-350)/22000).toFixed(3)+"em";}}}},{at + .2:.3f});}})();')
    _vx_count(b, f"#{i} .n", val, at + .3)

# ── D23. flipboard: 기계식 스플릿 플랩 스펙 보드 ──
def flipboard(b, t, d, box=(84, 300, 912, 600), title="출고 스펙 구성표",
              rows=(("전면 시공", "LX 40 · VLT 42%"), ("측후면 시공", "LX 25 · VLT 23%"), ("열반사 보증", "10 YEARS")), at=None, _ghost=False):
    x, y, w, h = box; at = t + .20 if at is None else at; rs = list(rows)
    html_rows = ""
    for k, (lb, val) in enumerate(rs):
        yk = 152 + k * 134
        html_rows += (f'<div style="position:absolute;left:56px;top:{yk}px;width:800px;height:110px;display:flex;align-items:center;justify-content:space-between">'
                      f'<span style="font-size:28px;font-weight:700;color:var(--gry)">{E(lb)}</span>'
                      f'<div class="vx-flap fbr{k}" style="width:456px;height:102px;display:flex;align-items:center;justify-content:center">'
                      f'<span class="fbt{k} vx-tnum" style="font-family:PP,KR,sans-serif;font-weight:900;font-size:38px;letter-spacing:.06em;color:var(--b1)">---</span></div></div>')
    inner = (f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px">'
             f'<div class="tag" style="position:absolute;left:56px;top:36px;color:var(--b1)">CHRONOGRAPH SPLIT-FLAP</div>'
             f'<div style="position:absolute;left:56px;top:68px;font-weight:900;font-size:35px">{E(title)}</div>{html_rows}</div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    _vx_card(b, f"#{i} .card", t, d, ghost=_ghost)
    presets = ["S-LINE 30", "G-LINE 15", "QUANTUM", "VOGUE 30", "XENITH IR"]
    for k, (_, val) in enumerate(rs):
        tk = at + k * .24
        b.js(f'(function(){{const o={{s:0}},el=document.querySelector("#{i} .fbt{k}"),box=document.querySelector("#{i} .fbr{k}"),arr={json.dumps(presets + [val], ensure_ascii=False)};'
             f'tl.fromTo(o,{{s:0}},{{s:arr.length-1,duration:.95,ease:"power2.out",onUpdate:()=>{{el.textContent=arr[Math.min(arr.length-1,Math.floor(o.s))];}}}},{tk:.3f});'
             f'tl.fromTo(box,{{rotationX:-35}},{{rotationX:0,duration:.95,ease:"expo.out"}},{tk:.3f});}})();')

# ── D24. shuttertext: 베네시안 슬랫 블라인드 교차 리빌 ──
def shuttertext(b, t, d, box=(84, 310, 912, 560), tag="PARADIGM SHIFT",
                before="어두워야 시원하다는 오랜 통념", after="밝은 농도에서 완성한 열반사 시야", g="b", at=None, _ghost=False):
    x, y, w, h = box; flip_t = (t + d * .44) if at is None else at; N = 6; sh = int(348 / N)
    slats = ""
    for k in range(N):
        yk = k * sh
        slats += (f'<div style="position:absolute;left:48px;top:{148 + yk}px;width:{w - 96}px;height:{sh}px;overflow:hidden">'
                  f'<div class="stb" style="position:absolute;left:0;top:{-yk}px;width:100%;height:348px;background:#f4f6fb;border-radius:26px;display:flex;align-items:center;justify-content:center;font-weight:900;font-size:40px;color:var(--gry)">{E(before)}</div>'
                  f'<div class="sta" style="position:absolute;left:0;top:{-yk}px;width:100%;height:348px;background:#eef3ff;border-radius:26px;display:flex;align-items:center;justify-content:center;font-weight:900;font-size:42px;transform:translateY({sh}px)">{_vx_gt(after, g)}</div></div>')
    inner = (f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px">'
             f'<div class="tag" style="position:absolute;left:52px;top:38px;color:var(--b1)">{E(tag)}</div>{slats}</div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    _vx_card(b, f"#{i} .card", t, d, ghost=_ghost)
    b.js(f'tl.to("#{i} .stb",{{y:{-sh},duration:.68,stagger:.05,ease:"power3.inOut"}},{flip_t:.3f});'
         f'tl.to("#{i} .sta",{{y:0,duration:.68,stagger:.05,ease:"power3.inOut"}},{flip_t:.3f});')

# ── D25. certseal: 회전 오비탈 공식 인증 인장 ──
def certseal(b, t, d, box=(84, 300, 912, 600), ring_text="SOLAR GARD THE LX · OFFICIAL SPECIALIZED SHOP · ",
             center_top="WARRANTY", center_val="10YR", sub="출고 당일 QR 전자보증서 공식 등록", at=None, _ghost=False):
    x, y, w, h = box; at = t + .20 if at is None else at; pid = b.id("csp")
    inner = (f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px">'
             f'<svg width="{w}" height="{h}" style="position:absolute;inset:0">'
             f'<defs><path id="{pid}" d="M 272,300 m -172,0 a 172,172 0 1,1 344,0 a 172,172 0 1,1 -344,0"/></defs>'
             f'<g class="csr"><circle cx="272" cy="300" r="196" fill="none" stroke="#e4e8f2" stroke-width="2"/>'
             f'<text font-family="PP,sans-serif" font-size="20" font-weight="700" fill="#245cff" letter-spacing="5.2"><textPath href="#{pid}">{E((ring_text * 2)[:76])}</textPath></text></g>'
             f'<circle cx="272" cy="300" r="118" fill="#f4f7ff" stroke="#245cff" stroke-width="3"/>'
             f'<path class="csc" d="M 232 302 L 260 330 L 316 272" fill="none" stroke="#245cff" stroke-width="8" stroke-linecap="round" stroke-linejoin="round" pathLength="100" stroke-dasharray="100" stroke-dashoffset="100"/></svg>'
             f'<div style="position:absolute;left:516px;top:178px;width:344px">'
             f'<div class="tag" style="color:var(--b1)">{E(center_top)}</div>'
             f'<div class="vx-tnum gt g-bp" style="font-weight:900;font-size:104px;line-height:1.05;margin:10px 0">{E(center_val)}</div>'
             f'<div style="font-size:26px;font-weight:700;color:var(--ink);line-height:1.4">{E(sub)}</div></div></div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    _vx_card(b, f"#{i} .card", t, d, ghost=_ghost)
    b.js(f'tl.fromTo("#{i} .csr",{{rotation:0,transformOrigin:"272px 300px"}},{{rotation:90,duration:{max(1.5, d):.2f},ease:"none"}},{t:.3f});'
         f'tl.to("#{i} .csc",{{strokeDashoffset:0,duration:.75,ease:"expo.out"}},{at + .35:.3f});')

# ── E26. eyetrace: 그래픽 → 자막 시선 유도 코멧 아크 (오버레이 fx 겸용) ──
def eyetrace(b, t, d, x0=540, y0=865, x1=540, y1=1045, at=None):
    at = t + .35 if at is None else at; mx = int((x0 + x1) / 2 + 88); my = int((y0 + y1) / 2)
    pth = f"M {x0} {y0} Q {mx} {my} {x1} {y1}"
    html = (f'<svg width="1080" height="1920" style="position:absolute;inset:0;pointer-events:none">'
            f'<path class="etp" d="{pth}" fill="none" stroke="#245cff" stroke-width="5" stroke-linecap="round" pathLength="100" stroke-dasharray="32 100" stroke-dashoffset="32" opacity="0"/>'
            f'<circle class="etr" cx="{x1}" cy="{y1}" r="8" fill="none" stroke="#245cff" stroke-width="3" opacity="0"/></svg>')
    i = b.clip(t, d, html, "left:0;top:0;width:1080px;height:1920px;pointer-events:none")
    b.js(f'tl.set("#{i} .etp",{{opacity:.9}},{at:.3f});'
         f'tl.fromTo("#{i} .etp",{{strokeDashoffset:32}},{{strokeDashoffset:-100,duration:.78,ease:"power2.inOut"}},{at:.3f});'
         f'tl.fromTo("#{i} .etr",{{attr:{{r:6}},opacity:.85}},{{attr:{{r:46}},opacity:0,duration:.6,ease:"expo.out"}},{at + .52:.3f});')

# ── E27. causticsweep: 스튜디오 천창 유리 채광 고보 스윕 (오버레이 fx 겸용) ──
def causticsweep(b, t, d, angle=-24, intensity=0.55):
    op = max(.15, min(.85, float(intensity)))
    html = (f'<div class="csw" style="position:absolute;left:-420px;top:-200px;width:620px;height:2320px;pointer-events:none;opacity:{op:.2f};transform:rotate({angle}deg)">'
            f'<div style="width:240px;height:100%;background:linear-gradient(90deg,transparent,rgba(255,255,255,.88),rgba(36,92,255,.06),transparent);display:inline-block"></div>'
            f'<div style="width:130px;height:100%;margin-left:70px;background:linear-gradient(90deg,transparent,rgba(255,255,255,.72),transparent);display:inline-block"></div></div>')
    i = b.clip(t, d, html, "left:0;top:0;width:1080px;height:1920px;pointer-events:none;overflow:hidden")
    b.js(f'tl.fromTo("#{i} .csw",{{x:0}},{{x:1720,duration:{max(1.8, d * .85):.2f},ease:"sine.inOut"}},{t + .05:.3f});')

# ── E28. depthdust: Z-뎁스 광학 마이크로 보케 공기감 필드 (오버레이 fx 겸용) ──
def depthdust(b, t, d, count=14, g="b"):
    n = max(6, min(24, int(count))); col = "36,92,255" if g != "p" else "124,77,255"
    dots = ""
    for k in range(n):
        px = 96 + (k * 173) % 888; py = 250 + (k * 227) % 1080; sz = 6 + (k % 4) * 5; bl = 0 if k % 3 == 0 else 2.5
        dots += f'<div class="ddp{k}" style="position:absolute;left:{px}px;top:{py}px;width:{sz}px;height:{sz}px;border-radius:50%;background:rgba({col},{.10 + (k % 3) * .05:.2f});filter:blur({bl}px)"></div>'
    i = b.clip(t, d, dots, "left:0;top:0;width:1080px;height:1920px;pointer-events:none")
    for k in range(n):
        dy = -36 - (k % 4) * 22; dx = (-18 if k % 2 == 0 else 18)
        b.js(f'tl.fromTo("#{i} .ddp{k}",{{x:0,y:0,opacity:0}},{{x:{dx},y:{dy},opacity:1,duration:{max(1.5, d * .75):.2f},ease:"sine.out"}},{t:.3f});')
    b.js(f'tl.to("#{i}",{{opacity:0,duration:.3}},{t + d - .32:.3f});')

# ── E29. xrayblade: 엑스레이 투시 스캔 블레이드 ──
def xrayblade(b, t, d, box=(84, 300, 912, 600), title="겉모습 너머의 원단 내부 투시",
              outer_txt="출고 첫날 비슷해 보이는 외관", inner_txt="풀메탈 다층 스퍼터링 코어", val=10, unit="년", at=None, _ghost=False):
    x, y, w, h = box; at = t + .28 if at is None else at
    inner = (f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px;overflow:hidden">'
             f'<div style="position:absolute;inset:0;padding:48px 52px;background:#f6f7fb">'
             f'<div class="tag">SURFACE VIEW</div><div style="font-weight:900;font-size:35px;margin-top:8px">{E(title)}</div>'
             f'<div style="margin-top:148px;text-align:center;font-weight:900;font-size:40px;color:var(--gry)">{E(outer_txt)}</div></div>'
             f'<div class="xri" style="position:absolute;inset:0;padding:48px 52px;background:#0f1320;color:#fff;clip-path:inset(0 100% 0 0)">'
             f'<div class="tag" style="color:#7ea4ff">X-RAY INTERNAL STRUCTURE</div><div style="font-weight:900;font-size:35px;margin-top:8px">{E(title)}</div>'
             f'<div style="display:flex;align-items:center;justify-content:space-between;margin-top:96px">'
             f'<div style="font-weight:900;font-size:38px;color:#fff;max-width:470px;line-height:1.35">{E(inner_txt)}</div>'
             f'<div class="vx-tnum" style="font-weight:900;font-size:112px;color:#5985ff"><span class="n">0</span><span style="font-size:44px;margin-left:4px">{E(unit)}</span></div></div></div>'
             f'<div class="xrb" style="position:absolute;top:0;bottom:0;left:0;width:5px;background:#245cff;box-shadow:0 0 24px #245cff"></div></div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    _vx_card(b, f"#{i} .card", t, d, ghost=_ghost)
    b.js(f'(function(){{const o={{p:0}},xi=document.querySelector("#{i} .xri"),xb=document.querySelector("#{i} .xrb");'
         f'const u=()=>{{xi.style.clipPath="inset(0 "+(100-o.p).toFixed(1)+"% 0 0)";xb.style.left=(o.p*{w}/100).toFixed(1)+"px";}};u();'
         f'tl.fromTo(o,{{p:0}},{{p:100,duration:1.35,ease:"power3.inOut",onUpdate:u}},{at:.3f});}})();')
    _vx_count(b, f"#{i} .n", val, at + .45)

# ── E30. blueprintgrid: 라이브 CAD 제도선 드래프팅 프레임 (오버레이 fx 겸용) ──
def blueprintgrid(b, t, d, code="MOTIF ARCHITECTURAL SPEC", margin=48):
    m = int(margin); W, H = 1080, 1920
    html = (f'<svg width="{W}" height="{H}" style="position:absolute;inset:0;pointer-events:none">'
            f'<line class="bgl" x1="{m}" y1="214" x2="{W - m}" y2="214" stroke="rgba(36,92,255,.16)" stroke-width="1.5" pathLength="100" stroke-dasharray="100" stroke-dashoffset="100"/>'
            f'<line class="bgl" x1="{m}" y1="1680" x2="{W - m}" y2="1680" stroke="rgba(36,92,255,.16)" stroke-width="1.5" pathLength="100" stroke-dasharray="100" stroke-dashoffset="100"/>'
            f'<path class="bgc" d="M {m} 238 L {m} 214 L {m + 24} 214 M {W - m - 24} 214 L {W - m} 214 L {W - m} 238 M {m} 1656 L {m} 1680 L {m + 24} 1680 M {W - m - 24} 1680 L {W - m} 1680 L {W - m} 1656" fill="none" stroke="#245cff" stroke-width="2.5"/>'
            f'<text x="{W - m}" y="202" font-family="PP,sans-serif" font-size="16" font-weight="700" fill="rgba(36,92,255,.45)" text-anchor="end" letter-spacing="3">{E(code)}</text></svg>')
    i = b.clip(t, d, html, "left:0;top:0;width:1080px;height:1920px;pointer-events:none")
    b.js(f'tl.to("#{i} .bgl",{{strokeDashoffset:0,duration:.75,stagger:.12,ease:"expo.out"}},{t:.3f});'
         f'tl.fromTo("#{i} .bgc",{{opacity:0}},{{opacity:1,duration:.4}},{t + .25:.3f});'
         f'tl.to("#{i}",{{opacity:0,duration:.28}},{t + d - .30:.3f});')

VORTEX30_PARTS = dict(
    isoexplode=isoexplode, zparallax=zparallax, rackfocus=rackfocus, hudtilt=hudtilt, irisshutter=irisshutter, hingeportal=hingeportal,
    liquidglass=liquidglass, prismray=prismray, raindrop=raindrop, debrisshield=debrisshield, polarizer=polarizer, heatcamera=heatcamera, selfheal=selfheal,
    repelfield=repelfield, oscwave=oscwave, falloffstack=falloffstack, radialsweep=radialsweep, echostack=echostack, orbitduplicator=orbitduplicator,
    doczoom=doczoom, pannabletrack=pannabletrack, cadbox=cadbox, flipboard=flipboard, shuttertext=shuttertext, certseal=certseal,
    eyetrace=eyetrace, causticsweep=causticsweep, depthdust=depthdust, xrayblade=xrayblade, blueprintgrid=blueprintgrid,
)
PARTS.update(VORTEX30_PARTS)
if "MORPH_PARTS" in globals():
    MORPH_PARTS.update(set(VORTEX30_PARTS.keys()) - {"zparallax", "rackfocus", "hudtilt", "hingeportal", "eyetrace", "causticsweep", "depthdust", "blueprintgrid"})

# ═══════════════════════════════════════════════════════════════════════════
# KINETIC 10 (v2 Audited) — 무한 도면 원테이크 엔진 + 고급 텍스트 모션 9종
# ═══════════════════════════════════════════════════════════════════════════
CSS += r"""
.k10-tnum{font-family:PP,KR,sans-serif;font-variant-numeric:tabular-nums;font-feature-settings:"tnum" 1;letter-spacing:-.03em}
.k10-3d{perspective:1150px;transform-style:preserve-3d}
#ot-vp{position:absolute;inset:0;overflow:hidden;background:#f3f1ec}
#ot-par{position:absolute;left:540px;top:960px;width:0;height:0;will-change:transform;pointer-events:none}
.ot-grid{position:absolute;left:-8000px;top:-8000px;width:16000px;height:16000px;
 background-image:radial-gradient(rgba(22,23,28,.13) 2px,transparent 2px);background-size:72px 72px}
.ot-bgw{position:absolute;font-family:PP,sans-serif;font-weight:900;font-size:560px;color:rgba(22,23,28,.045);letter-spacing:-.04em;white-space:nowrap;user-select:none}
#ot-drift{position:absolute;left:540px;top:960px;width:0;height:0;will-change:transform}
#ot-zoom,#ot-px,#ot-py{position:absolute;left:0;top:0;width:0;height:0;will-change:transform}
.ot-st{position:absolute;width:1080px;height:1920px;transform-origin:540px 960px}
.ot-shell{position:absolute;background:#fff;border-radius:38px;box-shadow:0 24px 60px rgba(20,22,30,.07),0 3px 12px rgba(20,22,30,.04);border:1px solid rgba(22,23,28,.05)}
.ot-has-shell .ot-gw>div>.card{background:transparent!important;box-shadow:none!important;border-color:transparent!important}
.ot-sno{position:absolute;left:88px;top:232px;font-family:PP,sans-serif;font-weight:900;font-size:23px;letter-spacing:.18em;color:var(--b1)}
"""

def _k10_gt(txt, g="b"):
    if g in (None, "k", "ink"): return f'<span style="color:var(--ink)">{E(txt)}</span>'
    if g == "g": return f'<span class="gry">{E(txt)}</span>'
    gc = "b" if g == "n" else g
    return f'<span class="gt g-{gc}">{E(txt)}</span>'

def _k10_card(b, sel, t, d):
    b.js(f'tl.fromTo("{sel}",{{opacity:0,y:32,scale:.985}},{{opacity:1,y:0,scale:1,duration:.62,ease:"expo.out"}},{t:.3f});'
         f'tl.to("{sel}",{{opacity:0,y:-14,duration:.26,ease:"power2.in"}},{t + d - .28:.3f});')

def _k10_count(b, sel, val, t_start, dur=1.25):
    dec = 0 if float(val).is_integer() else (2 if round(float(val) * 10) != float(val) * 10 else 1)
    b.js(f'(function(){{const o={{v:0}},el=document.querySelector("{sel}");if(!el)return;'
         f'tl.fromTo(o,{{v:0}},{{v:{float(val)},duration:{dur:.2f},ease:"expo.out",onUpdate:()=>el.textContent=o.v.toFixed({dec})}},{t_start:.3f});}})();')

# 모든 스테이션 간 중심 거리를 2,550px 이상 확보해 1080x1920 화면 간 침범 원천 차단
OT_COORDS = [
    (0, 0, 0.0),
    (2150, -850, -5.2),
    (4250, 650, 5.8),
    (2550, 2850, -4.6),
    (150, 4150, 5.4),
    (-2250, 2950, -6.0),
    (-2450, 350, 4.8),
    (-350, -2550, 0.0),
    (2250, -3450, -4.5),
    (-2650, -2350, 5.0),
]

OT_MULTI_CARD = {
    "seesaw", "steps", "versus", "bento", "morphcard", "waves", "spectrum",
    "zparallax", "rackfocus", "hudtilt", "hingeportal", "zcorridor",
    "eyetrace", "causticsweep", "depthdust", "blueprintgrid",
}

def build_onetake(spec, D):
    dur = spec["dur"]; stations = spec.get("stations", [])
    pts = [OT_COORDS[k % len(OT_COORDS)] for k in range(len(stations))]
    st_html, js_all = [], []
    next_id = 0

    route_d = " ".join(f"{'M' if k == 0 else 'L'} {pts[k][0] + 8000} {pts[k][1] + 8000}" for k in range(len(pts))) if pts else ""
    crosses = "".join(f'<path d="M {cx + 7984} {cy + 8000} h 32 M {cx + 8000} {cy + 7984} v 32" stroke="rgba(36,92,255,.22)" stroke-width="2"/>' for cx, cy, _ in pts)
    route_svg = f'<svg width="16000" height="16000" style="position:absolute;left:-8000px;top:-8000px;pointer-events:none"><path d="{route_d}" fill="none" stroke="rgba(36,92,255,.15)" stroke-width="4" stroke-dasharray="16 18"/>{crosses}</svg>'

    for idx, st in enumerate(stations):
        wx, wy, ang = pts[idx]
        bs_g = B(); bs_g.n = next_id
        has_shell = False; shell_html = ""

        for it in st.get("g_items", []):
            it = dict(it); p = it.pop("p")
            if idx > 0 and not st.get("is_end") and p not in OT_MULTI_CARD and st.get("shell_box"):
                has_shell = True
            PARTS[p](bs_g, **it)
        next_id = bs_g.n + 10

        bs_c = B(); bs_c.n = next_id
        for it in st.get("c_items", []):
            it = dict(it); p = it.pop("p")
            PARTS[p](bs_c, **it)
        next_id = bs_c.n + 10

        if has_shell:
            sx, sy, sw, sh = st["shell_box"]
            shell_html = f'<div class="ot-shell" style="left:{sx}px;top:{sy}px;width:{sw}px;height:{sh}px"></div>'
        sno = f'<div class="ot-sno">0{idx + 1} / STATION</div>' if not st.get("is_end") else ""
        cls = "ot-st ot-has-shell" if has_shell else "ot-st"
        st_html.append(
            f'<div class="{cls}" id="ots_{idx}" style="left:{wx - 540}px;top:{wy - 960}px;transform:rotate({ang}deg)">'
            f'{sno}{shell_html}<div class="ot-gw">{"".join(bs_g.h)}</div>{"".join(bs_c.h)}</div>'
        )
        js_all.extend(bs_g.j); js_all.extend(bs_c.j)

        ct = st["cam_t"]
        if idx == 0:
            js_all.append(f'tl.set("#ot-px",{{x:{-wx}}},0);tl.set("#ot-py",{{y:{-wy}}},0);tl.set("#ot-zoom",{{scale:1,rotation:{-ang}}},0);tl.set("#ot-par",{{x:0,y:0}},0);')
        elif st.get("is_end") and st.get("overview") and len(pts) > 2:
            # 모티프 버전: 마지막 질문이 끝난 뒤 1.4초 여백 동안 전체 도면 조감 → 엔드카드 착지
            mx = sum(p[0] for p in pts[:-1]) / max(1, len(pts) - 1)
            my = sum(p[1] for p in pts[:-1]) / max(1, len(pts) - 1)
            js_all.append(
                f'tl.to("#ot-px",{{x:{-mx:.1f},duration:.62,ease:"power2.inOut"}},{ct:.3f});'
                f'tl.to("#ot-py",{{y:{-my:.1f},duration:.62,ease:"power2.inOut"}},{ct:.3f});'
                f'tl.to("#ot-zoom",{{scale:.19,rotation:0,duration:.62,ease:"power2.inOut"}},{ct:.3f});'
                f'tl.to("#ot-par",{{x:{-mx * .3:.1f},y:{-my * .3:.1f},duration:.62,ease:"power2.inOut"}},{ct:.3f});'
                f'tl.to("#ot-px",{{x:{-wx},duration:.68,ease:"expo.inOut"}},{ct + .62:.3f});'
                f'tl.to("#ot-py",{{y:{-wy},duration:.72,ease:"expo.out"}},{ct + .62:.3f});'
                f'tl.to("#ot-zoom",{{scale:1,rotation:{-ang},duration:.72,ease:"expo.inOut"}},{ct + .62:.3f});'
            )
        else:
            fd = 1.22; dip = 0.73 if idx % 2 == 1 else 0.77
            js_all.append(
                f'tl.to("#ot-px",{{x:{-wx},duration:{fd:.2f},ease:"power3.inOut"}},{ct:.3f});'
                f'tl.to("#ot-py",{{y:{-wy},duration:{fd + .10:.2f},ease:"power4.out"}},{ct:.3f});'
                f'tl.to("#ot-zoom",{{rotation:{-ang},duration:{fd + .06:.2f},ease:"power3.inOut"}},{ct:.3f});'
                f'tl.to("#ot-zoom",{{scale:{dip},duration:{fd * .44:.2f},ease:"power2.in"}},{ct:.3f});'
                f'tl.to("#ot-zoom",{{scale:1,duration:{fd * .62:.2f},ease:"expo.out"}},{ct + fd * .44:.3f});'
                f'tl.to("#ot-par",{{x:{-wx * .3:.1f},y:{-wy * .3:.1f},duration:{fd + .08:.2f},ease:"power3.out"}},{ct:.3f});'
            )

    b_top = B(); b_top.n = next_id
    for it in spec.get("hud_items", []):
        it = dict(it); p = it.pop("p"); PARTS[p](b_top, **it)
    js_all.extend(b_top.j)
    js_all.append(f'tl.to("#ot-drift",{{x:5,y:-4,duration:2.8,ease:"sine.inOut",yoyo:true,repeat:{max(2, int(dur / 2.8))}}},0);')

    bg_words = (
        '<div class="ot-bgw" style="left:-1100px;top:-620px">THE LX</div>'
        '<div class="ot-bgw" style="left:980px;top:-1120px">TSER</div>'
        '<div class="ot-bgw" style="left:1750px;top:720px">VLT</div>'
        '<div class="ot-bgw" style="left:-1650px;top:1280px">MOTIF</div>'
        '<div class="ot-bgw" style="left:-240px;top:2480px">OPTICS</div>'
    )
    ui_css = globals().get("UICSS", "") + globals().get("CAPTION_PRO_CSS", "")
    html = f'''<!doctype html><html lang="ko"><head><meta charset="UTF-8"><meta name="viewport" content="width=1080, height=1920">
<script src="assets/gsap.min.js"></script><style>{CSS}{ui_css}:root{{--bg:#f3f1ec}}</style></head><body>{SVG_DEFS}
<div id="root" data-composition-id="main" data-start="0" data-duration="{dur:.3f}" data-width="1080" data-height="1920">
<div id="ot-vp">
 <div id="ot-par"><div class="ot-grid"></div>{bg_words}</div>
 <div id="ot-drift"><div id="ot-zoom"><div id="ot-px"><div id="ot-py">{route_svg}{"".join(st_html)}</div></div></div></div>
</div>
{"".join(b_top.h)}</div>
<script>const tl=gsap.timeline({{paused:true}});{"".join(js_all)}
(window.__timelines=window.__timelines||{{}})["main"]=tl;tl.seek(0);</script></body></html>'''
    os.makedirs(os.path.join(D, "assets", "fonts"), exist_ok=True)
    for f in os.listdir(os.path.join(KIT, "assets")):
        if f != "fonts": shutil.copy(os.path.join(KIT, "assets", f), os.path.join(D, "assets", f))
    for f in spec.get("files", []): shutil.copy(f, os.path.join(D, "assets", os.path.basename(f)))
    for f in ("package.json", "hyperframes.json"): shutil.copy(os.path.join(KIT, f), os.path.join(D, f))
    open(os.path.join(D, "index.html"), "w", encoding="utf-8").write(html)
    fonts(html, D)
    return html

# 2) portaltype: 거대 숫자 스트로크 드로잉 후 숫자 내부 관통 포털 리빌
def portaltype(b, t, d, box=(84, 300, 912, 600), num="10", unit="YEARS", tag="PORTAL TYPOGRAPHY",
               headline="변색 없는 풀메탈 보증", sub="열을 머금지 않고 반사하는 구조", at=None):
    x, y, w, h = box; sd = min(d, 7.0); fly_t = (t + sd * .46) if at is None else at
    inner = (f'<div class="card" style="left:0;top:0;width:{w}px;height:{h}px;overflow:hidden">'
             f'<div class="tag" style="position:absolute;left:52px;top:36px;color:var(--b1)">{E(tag)}</div>'
             f'<div class="ptb" style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:48px;text-align:center;opacity:0">'
             f'<div style="font-family:PP,sans-serif;font-weight:900;font-size:26px;letter-spacing:.2em;color:var(--b1)">{E(num)} {E(unit)}</div>'
             f'<div style="font-weight:900;font-size:46px;color:var(--ink);margin-top:16px;line-height:1.3">{E(headline)}</div>'
             f'<div style="font-size:27px;font-weight:700;color:var(--gry);margin-top:16px">{E(sub)}</div></div>'
             f'<div class="ptf" style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;transform-origin:50% 48%">'
             f'<svg width="560" height="300" style="overflow:visible">'
             f'<text class="ptn" x="280" y="226" text-anchor="middle" font-family="PP,sans-serif" font-weight="900" font-size="230" fill="rgba(36,92,255,.08)" stroke="#245cff" stroke-width="7" stroke-dasharray="1800" stroke-dashoffset="1800">{E(num)}</text></svg>'
             f'<div style="font-family:PP,sans-serif;font-weight:900;font-size:26px;letter-spacing:.26em;color:var(--gry)">{E(unit)}</div></div></div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    _k10_card(b, f"#{i} .card", t, d)
    b.js(f'tl.to("#{i} .ptn",{{strokeDashoffset:0,duration:.82,ease:"power3.inOut"}},{t + .14:.3f});'
         f'tl.to("#{i} .ptf",{{scale:4.6,opacity:0,filter:"blur(4.5px)",duration:.86,ease:"power3.in"}},{fly_t:.3f});'
         f'tl.fromTo("#{i} .ptb",{{scale:.88,opacity:0,filter:"blur(4.5px)"}},{{scale:1,opacity:1,filter:"blur(0px)",duration:.80,ease:"expo.out",immediateRender:false}},{fly_t + .28:.3f});')

# 3) justifyslide: 퍼센트 기준 우→좌 무오차 정렬 글라이드 + 우측 스펙 카운트
def justifyslide(b, t, d, box=(84, 300, 912, 600), tag="EDITORIAL ALIGNMENT",
                 lines=("개방감은 농도가 정하고", "열차단은 등급이 정합니다"), val=61, unit="% TSER", at=None):
    x, y, w, h = box; shift_t = (t + .65) if at is None else at
    l_html = ""
    for k, ln in enumerate(lines[:3]):
        words = " ".join(f'<span class="jsw{k}" style="display:inline-block">{E(wd)}</span>' for wd in ln.split())
        l_html += (f'<div style="position:absolute;left:74px;right:56px;top:{174 + k * 96}px;height:68px">'
                   f'<div class="jsr{k}" style="position:absolute;left:100%;top:0;white-space:nowrap;font-weight:900;font-size:44px;color:{"var(--b1)" if k == len(lines[:3]) - 1 else "var(--ink)"}">{words}</div></div>')
    inner = (f'<div class="card" style="left:0;top:0;width:{w}px;height:{h}px">'
             f'<div class="tag" style="position:absolute;left:56px;top:38px;color:var(--b1)">{E(tag)}</div>'
             f'<div class="jsgl" style="position:absolute;left:56px;top:156px;bottom:84px;width:4px;border-radius:2px;background:#245cff;transform-origin:top;transform:scaleY(0)"></div>'
             f'<div style="position:absolute;right:56px;top:156px;bottom:84px;width:2px;background:#e4e8f2"></div>'
             f'{l_html}'
             f'<div class="jsm" style="position:absolute;right:74px;bottom:78px;text-align:right;opacity:0">'
             f'<div class="k10-tnum" style="font-weight:900;font-size:92px;line-height:1"><span class="n gt g-bp">0</span><span class="gt g-b" style="font-size:34px;margin-left:6px">{E(unit)}</span></div></div></div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    _k10_card(b, f"#{i} .card", t, d)
    for k in range(len(lines[:3])):
        b.js(f'tl.set("#{i} .jsr{k}",{{xPercent:-100}},{t:.3f});'
             f'tl.fromTo("#{i} .jsw{k}",{{opacity:0,y:22}},{{opacity:1,y:0,duration:.46,stagger:.06,ease:"expo.out"}},{t + .14 + k * .12:.3f});'
             f'tl.to("#{i} .jsr{k}",{{left:"0%",xPercent:0,duration:.92,ease:"power3.inOut"}},{shift_t + k * .11:.3f});')
    b.js(f'tl.to("#{i} .jsgl",{{scaleY:1,duration:.55,ease:"expo.out"}},{shift_t:.3f});'
         f'tl.to("#{i} .jsm",{{opacity:1,y:-6,duration:.6,ease:"expo.out"}},{shift_t + .45:.3f});')
    _k10_count(b, f"#{i} .n", val, shift_t + .45)

# 4) inertiatype: 속도 반응 관성 기울기(Skew) + 포물선 마침표 도트
def inertiatype(b, t, d, box=(84, 310, 912, 560), tag="VELOCITY SKEW",
                phrase="열을 반사하는 금속층", sub="원단이 지치지 않는 스퍼터링 구조", at=None):
    x, y, w, h = box; at = t + .20 if at is None else at
    fs = 54 if len(phrase) >= 11 else 64
    inner = (f'<div class="card" style="left:0;top:0;width:{w}px;height:{h}px;overflow:hidden">'
             f'<div class="tag" style="position:absolute;left:56px;top:38px;color:var(--b1)">{E(tag)}</div>'
             f'<div style="position:absolute;left:56px;right:56px;top:192px;display:flex;align-items:baseline;justify-content:center">'
             f'<div class="itw" style="font-weight:900;font-size:{fs}px;letter-spacing:-.035em;color:var(--ink);white-space:nowrap;transform-origin:bottom center">{E(phrase)}</div>'
             f'<div class="itd" style="width:20px;height:20px;border-radius:50%;background:#245cff;margin-left:10px;flex-shrink:0"></div></div>'
             f'<div class="its" style="position:absolute;left:56px;right:56px;bottom:98px;text-align:center;font-size:28px;font-weight:700;color:var(--gry)">{E(sub)}</div></div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    _k10_card(b, f"#{i} .card", t, d)
    b.js(f'tl.fromTo("#{i} .itw",{{x:220,skewX:-15,opacity:0,filter:"blur(4px)"}},{{x:0,skewX:4,opacity:1,filter:"blur(0px)",duration:.58,ease:"power3.out"}},{at:.3f});'
         f'tl.to("#{i} .itw",{{skewX:0,duration:.40,ease:"expo.out"}},{at + .58:.3f});'
         f'tl.fromTo("#{i} .itd",{{x:-380,y:-90,opacity:0}},{{x:-150,y:-110,opacity:1,duration:.36,ease:"power1.out"}},{at + .28:.3f});'
         f'tl.to("#{i} .itd",{{x:0,y:0,duration:.42,ease:"power2.in"}},{at + .64:.3f});'
         f'tl.fromTo("#{i} .its",{{opacity:0,y:16}},{{opacity:1,y:0,duration:.55,ease:"expo.out"}},{at + .66:.3f});')

# 5) orbitringtype: 3D 타원 궤도 회전 타이포
def orbitringtype(b, t, d, box=(84, 300, 912, 600), title="사계절 복사열 경로 제어",
                  words=("SUMMER BLOCK", "WINTER KEEP", "ZERO DYE", "FULL METAL"), val=20, unit="%", at=None):
    x, y, w, h = box; sd = min(d, 7.2); at = t + .20 if at is None else at; ws = list(words)[:4]
    tags = "".join(f'<div class="ort{k}" style="position:absolute;left:456px;top:368px;padding:12px 26px;border-radius:99px;background:#fff;border:2px solid #dfe4f0;font-family:PP,KR,sans-serif;font-weight:900;font-size:23px;white-space:nowrap;transform:translate(-50%,-50%)">{E(wd)}</div>' for k, wd in enumerate(ws))
    inner = (f'<div class="card" style="left:0;top:0;width:{w}px;height:{h}px;overflow:hidden">'
             f'<div class="tag" style="position:absolute;left:52px;top:36px;color:var(--b1)">3D ORBITAL TYPOGRAPHY</div>'
             f'<div style="position:absolute;left:52px;top:68px;font-weight:900;font-size:35px">{E(title)}</div>'
             f'<svg width="{w}" height="{h}" style="position:absolute;inset:0"><ellipse cx="456" cy="368" rx="324" ry="118" fill="none" stroke="#e3e7f2" stroke-width="2.5" stroke-dasharray="10 10"/></svg>'
             f'<div style="position:absolute;left:0;top:298px;width:100%;text-align:center">'
             f'<div class="k10-tnum" style="font-weight:900;font-size:104px;line-height:1"><span class="n gt g-bp">0</span><span class="gt g-b" style="font-size:42px">{E(unit)}</span></div></div>'
             f'{tags}</div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    _k10_card(b, f"#{i} .card", t, d)
    b.js(f'(function(){{const o={{a:-1.2}},els=[...document.querySelectorAll("#{i} [class^=ort]")],N=els.length;if(!N)return;'
         f'const u=()=>els.forEach((el,k)=>{{const th=o.a+2*Math.PI*k/N,px=456+324*Math.cos(th),py=368+118*Math.sin(th),front=(Math.sin(th)+1)/2;'
         f'el.style.left=px.toFixed(1)+"px";el.style.top=py.toFixed(1)+"px";el.style.transform="translate(-50%,-50%) scale("+(.78+front*.28).toFixed(2)+")";'
         f'el.style.opacity=(.40+front*.60).toFixed(2);el.style.zIndex=front>.6?5:1;'
         f'el.style.borderColor=front>.75?"#245cff":"#dfe4f0";el.style.color=front>.75?"#245cff":"#686e7e";}});u();'
         f'tl.fromTo(o,{{a:-1.2}},{{a:Math.PI/2,duration:1.5,ease:"expo.out",onUpdate:u}},{at:.3f});'
         f'tl.to(o,{{a:Math.PI/2+.48,duration:{max(1.2, sd - 1.7):.2f},ease:"sine.inOut",onUpdate:u}},{at + 1.5:.3f});}})();')
    _k10_count(b, f"#{i} .n", val, at + .25)

# 6) layoutbuild: 4방향 직교 조판 어셈블리
def layoutbuild(b, t, d, box=(84, 300, 912, 600), top_k="SAINT-GOBAIN FULL METAL",
                left_k="실 농도 42%", right_k="TSER 61%", bottom_k="밝은 시야와 열반사의 균형", hero="LX 40", at=None):
    x, y, w, h = box; at = t + .18 if at is None else at
    inner = (f'<div class="card" style="left:0;top:0;width:{w}px;height:{h}px;overflow:hidden">'
             f'<div class="lbg" style="position:absolute;inset:44px;transform-origin:center">'
             f'<div style="overflow:hidden;height:68px"><div class="lbt" style="height:68px;border-radius:18px;background:#f4f6fb;display:flex;align-items:center;justify-content:center;font-family:PP,KR,sans-serif;font-weight:900;font-size:23px;letter-spacing:.16em;color:var(--gry)">{E(top_k)}</div></div>'
             f'<div style="display:flex;gap:18px;margin:18px 0;height:268px">'
             f'<div style="flex:1;overflow:hidden"><div class="lbl" style="height:100%;border-radius:26px;background:#f4f7ff;border:1.5px solid rgba(36,92,255,.18);display:flex;align-items:center;justify-content:center;font-weight:900;font-size:33px;color:var(--b1)">{E(left_k)}</div></div>'
             f'<div class="lbh" style="width:284px;height:100%;border-radius:28px;border:2.5px solid #245cff;background:#fff;display:flex;align-items:center;justify-content:center;font-family:PP,KR,sans-serif;font-weight:900;font-size:70px">{_k10_gt(hero, "bp")}</div>'
             f'<div style="flex:1;overflow:hidden"><div class="lbr" style="height:100%;border-radius:26px;background:#f6f4ff;border:1.5px solid rgba(124,77,255,.18);display:flex;align-items:center;justify-content:center;font-weight:900;font-size:33px;color:var(--b2)">{E(right_k)}</div></div></div>'
             f'<div style="overflow:hidden;height:112px"><div class="lbb" style="height:112px;border-radius:22px;background:#f7f8fc;border:1.5px solid #e4e8f2;display:flex;align-items:center;justify-content:center;font-weight:900;font-size:33px;color:var(--ink)">{E(bottom_k)}</div></div></div></div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    _k10_card(b, f"#{i} .card", t, d)
    b.js(f'tl.fromTo("#{i} .lbg",{{scale:1.09}},{{scale:1,duration:1.3,ease:"expo.out"}},{at:.3f});'
         f'tl.fromTo("#{i} .lbh",{{opacity:0,scale:.92}},{{opacity:1,scale:1,duration:.55,ease:"expo.out"}},{at:.3f});'
         f'tl.fromTo("#{i} .lbt",{{yPercent:-105}},{{yPercent:0,duration:.62,ease:"expo.out"}},{at + .12:.3f});'
         f'tl.fromTo("#{i} .lbl",{{xPercent:105}},{{xPercent:0,duration:.66,ease:"expo.out"}},{at + .22:.3f});'
         f'tl.fromTo("#{i} .lbr",{{xPercent:-105}},{{xPercent:0,duration:.66,ease:"expo.out"}},{at + .30:.3f});'
         f'tl.fromTo("#{i} .lbb",{{yPercent:105}},{{yPercent:0,duration:.68,ease:"expo.out"}},{at + .40:.3f});')

# 7) applecut: 3-키프레임 연속 드리프트 매치컷 (지침 6-3 밑줄 배제 -> 클린 캡슐 배지)
def applecut(b, t, d, box=(84, 310, 912, 560), tag="CONTINUOUS MATCH CUT",
             first="어두운 필름 = 높은 열차단?", second="시야와 열반사는 별개의 영역", note="SOLAR GARD THE LX · OPTICAL DESIGN", at=None):
    x, y, w, h = box; sd = min(d, 7.0); cut_t = (t + sd * .44) if at is None else at
    inner = (f'<div class="card" style="left:0;top:0;width:{w}px;height:{h}px;overflow:hidden">'
             f'<div class="tag" style="position:absolute;left:56px;top:38px;color:var(--b1)">{E(tag)}</div>'
             f'<div style="position:absolute;left:48px;right:48px;top:178px;height:132px;overflow:hidden">'
             f'<div class="ac1" style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-weight:900;font-size:46px;color:var(--gry);white-space:nowrap">{E(first)}</div>'
             f'<div class="ac2" style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-weight:900;font-size:50px;white-space:nowrap;opacity:0">{_k10_gt(second, "b")}</div></div>'
             f'<div class="acn" style="position:absolute;left:50%;bottom:84px;transform:translateX(-50%);padding:12px 30px;border-radius:99px;background:#f4f7ff;border:1.5px solid rgba(36,92,255,.18);font-family:PP,KR,sans-serif;font-weight:700;font-size:22px;letter-spacing:.10em;color:var(--b1);white-space:nowrap;opacity:0">{E(note)}</div></div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    _k10_card(b, f"#{i} .card", t, d)
    b.js(f'tl.fromTo("#{i} .ac1",{{y:72,opacity:0}},{{y:6,opacity:1,duration:.50,ease:"expo.out"}},{t + .14:.3f});'
         f'tl.to("#{i} .ac1",{{y:-6,duration:{max(.25, cut_t - t - .64):.2f},ease:"none"}},{t + .64:.3f});'
         f'tl.to("#{i} .ac1",{{y:-86,opacity:0,duration:.36,ease:"power3.in"}},{cut_t:.3f});'
         f'tl.fromTo("#{i} .ac2",{{y:86,opacity:0}},{{y:4,opacity:1,duration:.52,ease:"expo.out",immediateRender:false}},{cut_t + .12:.3f});'
         f'tl.to("#{i} .ac2",{{y:-4,duration:2.2,ease:"sine.out"}},{cut_t + .64:.3f});'
         f'tl.to("#{i} .acn",{{opacity:1,duration:.55,ease:"expo.out"}},{cut_t + .42:.3f});')

# 8) zcorridor: 3D Z축 회랑 플라이스루
def zcorridor(b, t, d, box=(84, 295, 912, 610),
              stages=(("01", "염료 제로 무변색"), ("02", "다층 금속 스퍼터링"), ("03", "2차 복사열 억제"), ("04", "10년 공식 보증")), at=None):
    x, y, w, h = box; sd = min(d, 7.2); at = t + .18 if at is None else at; st = list(stages)[:4]
    frames = "".join(
        f'<div class="zcf{k} card" style="left:{156 + (-42 if k % 2 == 0 else 42)}px;top:{134 + (k % 2) * 26}px;width:600px;height:326px;padding:38px 46px;'
        f'display:flex;flex-direction:column;justify-content:center;border:2px solid rgba(36,92,255,.22);opacity:0">'
        f'<div class="tag" style="color:var(--b1)">STAGE {E(no)}</div>'
        f'<div style="font-weight:900;font-size:42px;color:var(--ink);margin-top:14px">{E(tx)}</div></div>'
        for k, (no, tx) in enumerate(st))
    inner = f'<div class="k10-3d" style="position:absolute;inset:0;overflow:hidden;border-radius:38px">{frames}</div>'
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    step_d = max(.60, (sd - .7) / max(1, len(st)))
    for k in range(len(st)):
        tk = at + k * step_d * .78
        if k < len(st) - 1:
            b.js(f'tl.fromTo("#{i} .zcf{k}",{{z:-480,scale:.74,opacity:0,filter:"blur(4px)"}},{{z:0,scale:1,opacity:1,filter:"blur(0px)",duration:{step_d * .65:.2f},ease:"power2.out",immediateRender:false}},{tk:.3f});'
                 f'tl.to("#{i} .zcf{k}",{{z:240,scale:1.16,opacity:0,filter:"blur(4px)",duration:{step_d * .52:.2f},ease:"power2.in"}},{tk + step_d * .65:.3f});')
        else:
            b.js(f'tl.fromTo("#{i} .zcf{k}",{{z:-480,scale:.74,opacity:0,filter:"blur(4px)"}},{{z:0,scale:1,opacity:1,filter:"blur(0px)",duration:.82,ease:"expo.out",immediateRender:false}},{tk:.3f});')
    b.js(f'tl.to("#{i}",{{opacity:0,y:-14,duration:.26}},{t + d - .28:.3f});')

# 9) anchormatch: 중앙 앵커 고정 다큐멘터리식 고속 검증 매치컷 (immediateRender 스택 버그 수정)
def anchormatch(b, t, d, box=(84, 300, 912, 600), anchor="IRER 66%",
                contexts=("좁은 파장 꼼수 배제", "780~2500nm 전 구간 평균", "실내 2차 복사열 페널티 반영", "국제윈도우필름협회 공식 인정"), at=None):
    x, y, w, h = box; sd = min(d, 7.0); at = t + .28 if at is None else at; cs = list(contexts)
    ctx_html = "".join(
        f'<div class="amc{k}" style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:space-between;padding:74px 56px;opacity:{1 if k == 0 else 0}">'
        f'<div style="font-family:PP,sans-serif;font-weight:700;font-size:21px;letter-spacing:.18em;color:#9aa0ae">EVIDENCE 0{k + 1} / 0{len(cs)}</div>'
        f'<div style="font-weight:900;font-size:35px;color:var(--ink);text-align:center">{E(c)}</div></div>'
        for k, c in enumerate(cs))
    inner = (f'<div class="card" style="left:0;top:0;width:{w}px;height:{h}px;overflow:hidden">'
             f'{ctx_html}'
             f'<div style="position:absolute;left:50%;top:46%;transform:translate(-50%,-50%);padding:18px 44px;border-radius:22px;background:rgba(36,92,255,.10);border:2.5px solid #245cff">'
             f'<span class="k10-tnum gt g-bp" style="font-weight:900;font-size:72px;white-space:nowrap">{E(anchor)}</span></div></div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    _k10_card(b, f"#{i} .card", t, d)
    step = min(.58, max(.36, (sd - 1.5) / max(1, len(cs))))
    for k in range(1, len(cs)):
        tk = at + k * step
        b.js(f'tl.to("#{i} .amc{k - 1}",{{opacity:0,y:-10,duration:.18,ease:"power2.in"}},{tk - .06:.3f});'
             f'tl.fromTo("#{i} .amc{k}",{{opacity:0,y:14}},{{opacity:1,y:0,duration:.26,ease:"expo.out",immediateRender:false}},{tk:.3f});')

# 10) stemsplit: 중앙 수직 기둥 마스킹 양방향 날개 전개 (6자 이상 자동 크기 조절로 줄바꿈 방지)
def stemsplit(b, t, d, box=(84, 310, 912, 560), tag="ARCHITECTURAL SPLIT",
              left_top="FRONT", left_main="LX 40%", right_top="SIDE · REAR", right_main="LX 25%",
              center_badge="VLT 42% · 23%", at=None):
    x, y, w, h = box; at = t + .22 if at is None else at; hw = w // 2
    mlen = max(len(left_main), len(right_main))
    fs = 54 if mlen >= 6 else (64 if mlen == 5 else 72)
    inner = (f'<div class="card" style="left:0;top:0;width:{w}px;height:{h}px;overflow:hidden">'
             f'<div class="tag" style="position:absolute;left:52px;top:36px;color:var(--b1)">{E(tag)}</div>'
             f'<div style="position:absolute;left:36px;top:146px;width:{hw - 44}px;height:280px;overflow:hidden">'
             f'<div class="ssl" style="width:100%;height:100%;padding-right:26px;display:flex;flex-direction:column;align-items:flex-end;justify-content:center">'
             f'<span class="tag">{E(left_top)}</span><span class="k10-tnum" style="font-weight:900;font-size:{fs}px;color:var(--ink);margin-top:10px;white-space:nowrap">{E(left_main)}</span></div></div>'
             f'<div style="position:absolute;left:{hw + 8}px;top:146px;width:{hw - 44}px;height:280px;overflow:hidden">'
             f'<div class="ssr" style="width:100%;height:100%;padding-left:26px;display:flex;flex-direction:column;align-items:flex-start;justify-content:center">'
             f'<span class="tag" style="color:var(--b1)">{E(right_top)}</span><span class="k10-tnum gt g-b" style="font-weight:900;font-size:{fs}px;margin-top:10px;white-space:nowrap">{E(right_main)}</span></div></div>'
             f'<div class="ssbar" style="position:absolute;left:{hw - 3}px;top:132px;width:6px;height:308px;border-radius:3px;background:linear-gradient(180deg,#245cff,#7c4dff);transform-origin:center"></div>'
             f'<div class="ssb" style="position:absolute;left:50%;bottom:48px;transform:translateX(-50%);padding:10px 28px;border-radius:99px;background:#f4f7ff;font-weight:900;font-size:23px;color:var(--b1);white-space:nowrap;opacity:0">{E(center_badge)}</div></div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    _k10_card(b, f"#{i} .card", t, d)
    b.js(f'tl.fromTo("#{i} .ssbar",{{scaleY:0}},{{scaleY:1,duration:.52,ease:"expo.out"}},{at:.3f});'
         f'tl.fromTo("#{i} .ssl",{{xPercent:105}},{{xPercent:0,duration:.76,ease:"expo.out"}},{at + .26:.3f});'
         f'tl.fromTo("#{i} .ssr",{{xPercent:-105}},{{xPercent:0,duration:.76,ease:"expo.out"}},{at + .32:.3f});'
         f'tl.to("#{i} .ssb",{{opacity:1,duration:.5,ease:"expo.out"}},{at + .66:.3f});')

KINETIC10_PARTS = dict(
    portaltype=portaltype, justifyslide=justifyslide, inertiatype=inertiatype,
    orbitringtype=orbitringtype, layoutbuild=layoutbuild, applecut=applecut,
    zcorridor=zcorridor, anchormatch=anchormatch, stemsplit=stemsplit,
)
PARTS.update(KINETIC10_PARTS)
if "MORPH_PARTS" in globals():
    MORPH_PARTS.update(set(KINETIC10_PARTS.keys()) - {"zcorridor"})


def build(spec, D, overlay=False):
    b_stg = B(); top_h = []   # 한 카운터로 id·트랙 번호를 매겨 클립끼리 트랙이 겹치지 않게(겹치면 헤더·로고가 중간에 사라짐)
    for it in _prepare_items(spec["items"], overlay):
        it = dict(it); p = it.pop("p"); n0 = len(b_stg.h)
        PARTS[p](b_stg, **it)
        if p in ("header", "logo"): top_h += b_stg.h[n0:]; del b_stg.h[n0:]
    b_top = B(); b_top.h = top_h
    js_all = b_stg.j
    if spec.get("zoomcut"):   # 장면 전환 순간 확대 + 블러(기본 끔 — 마틴: 화려한 펀치 줌 전환은 어색하다)
        cut_times = sorted({round(it["t"], 3) for it in spec["items"] if it.get("p") not in ("header", "logo", "bgword", "caption") and it.get("t", 0) > 0.6})
        for tc in cut_times:
            js_all.append(f'tl.to("#stage",{{scale:1.036,filter:"blur(2.5px)",duration:.16,ease:"power2.in"}},{tc - .16:.3f});'
                          f'tl.to("#stage",{{scale:1,filter:"blur(0px)",duration:.42,ease:"expo.out"}},{tc:.3f});')
    dur = spec["dur"]; bg = "transparent" if overlay else spec.get("bg", "#f4f6fa")
    html = f'''<!doctype html><html lang="ko"><head><meta charset="UTF-8"><meta name="viewport" content="width=1080, height=1920">
<script src="assets/gsap.min.js"></script><style>{CSS}{UICSS}{CAPTION_PRO_CSS}:root{{--bg:{bg}}}</style></head><body>{SVG_DEFS}
<div id="root" data-composition-id="main" data-start="0" data-duration="{dur:.3f}" data-width="1080" data-height="1920">
<div id="stage">{"".join(b_stg.h)}</div>{"".join(b_top.h)}</div>
<script>const tl=gsap.timeline({{paused:true}});{"".join(js_all)}
window.__timelines["main"]=tl;tl.seek(0);</script></body></html>'''
    os.makedirs(os.path.join(D, "assets", "fonts"), exist_ok=True)
    for f in os.listdir(os.path.join(KIT, "assets")):
        if f != "fonts": shutil.copy(os.path.join(KIT, "assets", f), os.path.join(D, "assets", f))
    for f in spec.get("files", []): shutil.copy(f, os.path.join(D, "assets", os.path.basename(f)))
    for f in ("package.json", "hyperframes.json"): shutil.copy(os.path.join(KIT, f), os.path.join(D, f))
    open(os.path.join(D, "index.html"), "w", encoding="utf-8").write(html)
    fonts(html, D)
    return html

def kr_font(w):
    from fontTools.ttLib import TTCollection, TTFont
    p = f"/usr/share/fonts/opentype/noto/NotoSansCJK-{w}.ttc"
    if os.path.exists(p): return [f for f in TTCollection(p).fonts if "KR" in f["name"].getDebugName(1)][0]
    for dd in (os.environ.get("MOTIF_FONT_DIR", ""), os.path.expanduser("~/mk/fonts"), os.path.expanduser("~/Library/Fonts"), "/Library/Fonts"):
        for nm in (f"NotoSansCJKkr-{w}.otf", f"NotoSansKR-{w}.otf", f"NotoSansKR-{w}.ttf"):
            q = os.path.join(dd, nm)
            if dd and os.path.exists(q): return TTFont(q)
    raise SystemExit(f"한글 폰트(NotoSansCJKkr-{w}.otf)를 찾지 못했습니다. setup_mac.sh를 다시 실행하세요.")

def fonts(html, D):
    from fontTools.ttLib import TTFont
    from fontTools import subset
    txt = H.unescape(re.sub(r"<[^>]+>", "", html.split("<body>")[1]))
    text = "".join(sorted(set(txt) | set("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz%/.,+-×=·~✓●⌕▼—→ ")))
    def sub(font_obj, dst):
        o = subset.Options(); o.flavor = "woff2"; tmp = f"/tmp/_hf_{os.path.basename(dst)}.otf"; font_obj.save(tmp)
        f = subset.load_font(tmp, o); s = subset.Subsetter(o); s.populate(text=text); s.subset(f); subset.save_font(f, dst, o)
    for src, dst in [("Regular", "kr-regular"), ("Bold", "kr-bold"), ("Black", "kr-black")]:
        sub(kr_font(src), os.path.join(D, "assets", "fonts", dst + ".woff2"))
    sub(TTFont(os.path.join(KIT, "assets", "NanumMyeongjo-ExtraBold.ttf")), os.path.join(D, "assets", "fonts", "tw-ko.woff2"))
    sub(TTFont(os.path.join(KIT, "assets", "SpecialElite-Regular.ttf")), os.path.join(D, "assets", "fonts", "tw-en.woff2"))
    for src, dst in [("Poppins-Medium.ttf", "pp-medium"), ("Poppins-Bold.ttf", "pp-bold"), ("Stylish-Regular.ttf", "stylish")]:
        sub(TTFont(os.path.join(KIT, "assets", src)), os.path.join(D, "assets", "fonts", dst + ".woff2"))

def render(D, out, overlay=False, quality="high"):
    env = dict(os.environ, DO_NOT_TRACK="1")
    if overlay:
        fr = os.path.join(D, "frames"); shutil.rmtree(fr, ignore_errors=True)
        subprocess.run(["npx", "--yes", "hyperframes@0.9.65", "render", "--format", "png-sequence", "--fps", "30", "--output", fr], cwd=D, env=env, check=True)
        return fr
    subprocess.run(["npx", "--yes", "hyperframes@0.9.65", "render", "--quality", quality, "--fps", "30", "--output", os.path.abspath(out)], cwd=D, env=env, check=True)
    return out

if __name__ == "__main__":
    ns = {}; exec(open(sys.argv[1], encoding="utf-8").read(), ns); spec = ns["SPEC"]
    overlay = "--overlay" in sys.argv; D = os.path.abspath(spec.get("dir", "/tmp/hf/job"))
    (build_onetake(spec, D) if spec.get("style") == "onetake" else build(spec, D, overlay))
    if "--build" in sys.argv: print("built", D); sys.exit()
    print(render(D, sys.argv[2], overlay, "draft" if "--draft" in sys.argv else "high"))
