"""MOTIF HyperFrames 부품 키트 (2026-11-25 제미나이 개선판 + 신규 8종 · 글자 블러는 5px 이하, 글자 확대 없음 — 마틴 기준)
릴스 한 편 = spec(dict) 하나. 부품 이름과 글자·시간만 적으면 index.html을 만들고 렌더링한다.
사용: python3 hfkit.py spec.py out.mp4 [--overlay]   (spec.py 안에 SPEC = {...})
      --overlay : 배경 투명 PNG 시퀀스(플로우 영상 위에 겹칠 때)
부품 목록과 인자는 PARTS.md 참고.
"""
import json, os, re, sys, shutil, subprocess, html as H
KIT = os.path.dirname(os.path.abspath(__file__))
W, HH = 1080, 1920
E = H.escape

# ───────── 공통 CSS (Apple/Swiss Editorial 위계 · 자간 · 다중 그림자) ─────────
CSS = r"""
@font-face{font-family:KR;font-weight:400;src:url(assets/fonts/kr-regular.woff2) format("woff2")}
@font-face{font-family:KR;font-weight:700;src:url(assets/fonts/kr-bold.woff2) format("woff2")}
@font-face{font-family:KR;font-weight:900;src:url(assets/fonts/kr-black.woff2) format("woff2")}
@font-face{font-family:ST;src:url(assets/fonts/stylish.woff2) format("woff2")}
@font-face{font-family:PP;font-weight:500;src:url(assets/fonts/pp-medium.woff2) format("woff2")}
@font-face{font-family:PP;font-weight:700;src:url(assets/fonts/pp-bold.woff2) format("woff2")}
@font-face{font-family:TWK;src:url(assets/fonts/tw-ko.woff2) format("woff2")}
@font-face{font-family:TWE;src:url(assets/fonts/tw-en.woff2) format("woff2")}
*{margin:0;padding:0;box-sizing:border-box}
html,body{width:1080px;height:1920px;overflow:hidden;background:var(--bg);-webkit-font-smoothing:antialiased}
:root{
  --bg:#f4f6fa;--ink:#14161c;--body:#2a2e39;--gry:#727785;--lgt:#c5cad6;--trk:#edf0f6;
  --b1:#245cff;--b2:#7c4dff;--b3:#e84c93;--n1:#ec5c42;--n2:#fa963c;
  --paper:#fcfaf5;--tw:#262422;--twb:#2240aa;--twr:#962834
}
#root{position:relative;width:1080px;height:1920px;font-family:KR,PP,sans-serif;color:var(--ink);letter-spacing:-.032em;word-break:keep-all}
.clip{position:absolute;z-index:2}
.hdr,.lgo{z-index:5}
.scard{z-index:1}
.card{
  position:absolute;background:#fff;border-radius:38px;
  border:1px solid rgba(20,22,28,.055);
  box-shadow:0 2px 6px rgba(20,25,40,.03),0 18px 44px rgba(25,35,65,.075),0 36px 80px rgba(25,35,65,.05)
}
.card.ghost{background:transparent!important;border-color:transparent!important;box-shadow:none!important}
.paper{background:var(--paper);border-radius:26px}
.g-b{background:linear-gradient(95deg,var(--b1),var(--b2))}
.g-p{background:linear-gradient(95deg,var(--b2),var(--b3))}
.g-n{background:linear-gradient(95deg,var(--n1),var(--n2))}
.g-bp{background:linear-gradient(95deg,var(--b1) 0%,var(--b2) 55%,var(--b3) 100%)}
.gt{-webkit-background-clip:text;background-clip:text;color:transparent}
.tnum,.n{font-family:PP,KR,sans-serif;font-variant-numeric:tabular-nums;font-feature-settings:"tnum" 1;letter-spacing:-.03em}
.tag{font-family:PP,KR,sans-serif;font-weight:700;font-size:22px;color:var(--gry);letter-spacing:.14em;text-transform:uppercase}
.tagline{display:inline-block;width:54px;height:2.5px;background:var(--b1);vertical-align:middle;margin-left:14px;transform-origin:left;border-radius:2px}
.cap{left:72px;width:936px;font-weight:900;line-height:1.30;letter-spacing:-.038em}
.cap .row{display:block;white-space:nowrap;margin-bottom:4px}
.cap .row.sub{font-weight:700;font-size:.80em;line-height:1.36;letter-spacing:-.025em;color:var(--gry)}
.cap .cw{display:inline-block;will-change:transform,opacity,filter}
.k{position:relative;display:inline-block;padding:0 2px}
.k .band{position:absolute;left:-6px;right:-6px;top:56%;bottom:2%;border-radius:8px;transform-origin:left;z-index:0}
.k em{position:relative;z-index:1;font-style:normal;font-weight:900}
.band.b{background:rgba(36,92,255,.13)}.band.p{background:rgba(124,77,255,.14)}.band.n{background:rgba(236,92,66,.14)}.band.bp{background:rgba(124,77,255,.13)}
.gry{color:var(--gry);font-weight:700}
.bgw{font-family:PP,KR,sans-serif;font-weight:700;font-size:290px;letter-spacing:-.02em;color:rgba(34,56,110,.046);white-space:nowrap;top:1345px;left:560px;z-index:0;pointer-events:none}
.tw{font-family:TWE,TWK,serif;color:var(--tw);letter-spacing:0}
.twk{font-family:TWK,TWE,serif;letter-spacing:0}
.cursor{display:inline-block;width:.5em;height:.9em;background:var(--twb);vertical-align:-.1em;margin-left:6px;opacity:.85}
.ink{filter:url(#ink)}
"""
SVG_DEFS = """<svg width="0" height="0" style="position:absolute"><filter id="ink"><feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" seed="3"/><feColorMatrix values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 -1.0 1.4"/><feComposite in="SourceGraphic" operator="in"/><feGaussianBlur stdDeviation="0.35"/></filter></svg>"""

CAPTION_PRO_CSS = r"""
#stage{position:absolute;inset:0;transform-origin:540px 720px;will-change:transform,filter}
.cap .cmask{display:inline-block;overflow:hidden;vertical-align:bottom;padding:12px 10px;margin:-12px -10px}
.cap .cw{display:inline-block;will-change:transform,opacity,filter}
.k{position:relative;display:inline-block;padding:0 6px}
.k .band{position:absolute;left:-4px;right:-4px;top:14%;bottom:6%;border-radius:10px;transform-origin:left center;z-index:0}
.k .pin{position:absolute;top:8%;bottom:2%;width:3.5px;border-radius:2px;z-index:2;pointer-events:none}
.k .pin.l{left:-5px;background:var(--b1)}
.k .pin.r{left:0%;background:var(--b2)}
.k .pin::after{content:"";position:absolute;left:-4.25px;width:12px;height:12px;border-radius:50%;background:inherit}
.k .pin.l::after{top:-7px}
.k .pin.r::after{bottom:-7px}
"""

MORPH_PARTS = {
    "titlecard", "checklist", "hbars", "xyline", "counter", "ring", "slot",
    "skeleton", "progress", "splitline", "ladder", "focusword", "crossscan", "metricpair"
}

class B:
    """html·js 조각을 모은다"""
    def __init__(s): s.h = []; s.j = []; s.n = 0
    def id(s, p="e"): s.n += 1; return f"{p}{s.n}"
    def clip(s, t, d, inner, style="", cls=""):
        i = s.id("c"); s.h.append(f'<div id="{i}" class="clip {cls}" data-start="{t:.3f}" data-duration="{d:.3f}" data-track-index="{s.n}" style="{style}">{inner}</div>'); return i
    def js(s, code): s.j.append(code)

def gtext(txt, g="b", tag="span", cls=""):
    if g in (None, "k", "ink"): return f'<{tag} class="{cls}" style="color:var(--ink)">{E(txt)}</{tag}>'
    if g == "g": return f'<{tag} class="gry {cls}">{E(txt)}</{tag}>'
    gc = "b" if g == "n" else g
    return f'<{tag} class="gt g-{gc} {cls}">{E(txt)}</{tag}>'

def popin(b, sel, t, d=0.66, y=38, float_=True, out=None, ghost=False):
    if ghost:
        b.js(f'tl.fromTo("{sel}",{{opacity:0,y:16,filter:"blur(6px)"}},{{opacity:1,y:0,filter:"blur(0px)",duration:.48,ease:"expo.out"}},{t + .06:.3f});')
        if out is not None:
            b.js(f'tl.to("{sel}",{{opacity:0,y:-12,filter:"blur(4px)",duration:.22,ease:"power2.in"}},{out - .24:.3f});')
        return
    b.js(f'tl.fromTo("{sel}",{{opacity:0,y:{y},scale:.985}},{{opacity:1,y:0,scale:1,duration:{d},ease:"expo.out"}},{t:.3f});')
    if float_:
        b.js(f'tl.to("{sel}",{{y:-5,duration:2.8,ease:"sine.inOut",yoyo:true,repeat:5}},{t + d:.3f});')
    if out is not None:
        b.js(f'tl.to("{sel}",{{opacity:0,y:-16,scale:.99,duration:.28,ease:"power2.in"}},{out - .30:.3f});')

def sharedcard(b, t, d, chain):
    x0, y0, w0, h0 = chain[0]["box"]
    i = b.clip(t, d, "", f"left:0;top:0;width:{w0}px;height:{h0}px", "card scard")
    b.js(f'tl.fromTo("#{i}",{{opacity:0,x:{x0},y:{y0 + 36},width:{w0},height:{h0},scale:.985}},{{opacity:1,x:{x0},y:{y0},width:{w0},height:{h0},scale:1,duration:.68,ease:"expo.out"}},{t:.3f});')
    for nxt in chain[1:]:
        xn, yn, wn, hn = nxt["box"]
        tm = max(t + .32, nxt["t"] - .16)
        b.js(f'tl.to("#{i}",{{x:{xn},y:{yn},width:{wn},height:{hn},duration:.62,ease:"power3.inOut"}},{tm:.3f});')
    xl, yl, _, _ = chain[-1]["box"]
    b.js(f'tl.to("#{i}",{{opacity:0,y:{yl - 18},scale:.99,duration:.30,ease:"power2.in"}},{t + d - .32:.3f});')

# ───────── 기본 부품 ─────────
def header(b, t, d, title, left="MOTIF", right="SOLAR GARD LX"):
    i = b.clip(t, d,
               f'<div class="hb" style="position:absolute;left:72px;top:92px;width:6px;height:42px;border-radius:3px;background:var(--b1);transform-origin:top"></div>'
               f'<div class="ht" style="position:absolute;left:94px;top:88px;font-weight:700;font-size:36px;letter-spacing:-.03em;color:var(--ink)">{E(title)}</div>'
               f'<div class="hl" style="position:absolute;left:74px;top:156px;font-family:PP,KR,sans-serif;font-weight:700;font-size:19px;letter-spacing:.22em;color:#3c404c">{E(left)}</div>'
               f'<div class="hr" style="position:absolute;right:72px;top:156px;font-family:PP,KR,sans-serif;font-weight:500;font-size:19px;letter-spacing:.18em;color:var(--gry)">{E(right)}</div>',
               "left:0;top:0;width:1080px;height:210px", "hdr")
    b.js(f'tl.fromTo("#{i} .hb",{{scaleY:0,opacity:0}},{{scaleY:1,opacity:1,duration:.5,ease:"expo.out"}},{t + .06:.3f});'
         f'tl.fromTo("#{i} .ht",{{opacity:0,y:14,filter:"blur(6px)"}},{{opacity:1,y:0,filter:"blur(0px)",duration:.55,ease:"expo.out"}},{t + .13:.3f});'
         f'tl.fromTo(["#{i} .hl","#{i} .hr"],{{opacity:0,y:8}},{{opacity:1,y:0,duration:.5,stagger:.06,ease:"power2.out"}},{t + .22:.3f});'
         f'tl.to("#{i}",{{opacity:0,duration:.35,ease:"power2.in"}},{t + d - .36:.3f});')

def logo(b, t, d, name="motif", w=150, y=1780):
    src = {"motif": "motif_logo_dark.png", "motif_w": "motif_logo_light.png", "lxsg": "lxsg_ink_dark.png", "lxsg_w": "lxsg_ink_light.png", "thelx": "thelx_ink_dark.png"}[name]
    i = b.clip(t, d, f'<img src="assets/{src}" style="width:{w}px;display:block">', f"left:{540 - w / 2}px;top:{y}px;transform:translateY(-50%)", "lgo")
    b.js(f'tl.fromTo("#{i}",{{opacity:0}},{{opacity:.92,duration:.6,ease:"power2.out"}},{t + .26:.3f});'
         f'tl.to("#{i}",{{opacity:0,duration:.35,ease:"power2.in"}},{t + d - .36:.3f});')

def bgword(b, t, d, word):
    i = b.clip(t, d, f'<div class="w">{E(word)}</div>', "", "bgw")
    b.js(f'tl.fromTo("#{i} .w",{{opacity:0,x:48}},{{opacity:1,x:0,duration:.85,ease:"power2.out"}},{t:.3f});'
         f'tl.to("#{i} .w",{{x:-38*{d:.2f},duration:{d:.2f},ease:"none"}},{t:.3f});'
         f'tl.to("#{i}",{{opacity:0,duration:.3}},{t + d - .32:.3f});')

def caption(b, t, d, rows, y=1020, size=58):
    out = []
    for r in rows:
        all_sub = bool(r) and all(st == "g" for _, st in r)
        tokens = []
        for tx, st in r:
            glue = tx.startswith("~"); tx = tx.lstrip("~")
            if st in ("b", "p", "n", "bp"):
                hp = (f'<span class="k"><i class="band {st}"></i>'
                      f'<i class="pin l"></i><i class="pin r"></i>'
                      f'<em class="gt g-{st}">{E(tx)}</em></span>')
                if glue and tokens: tokens[-1] += hp
                else: tokens.append(hp)
            else:
                fmt = (lambda w: E(w)) if all_sub else ((lambda w: f'<span class="gry">{E(w)}</span>') if st == "g" else (lambda w: E(w)))
                for idx, w in enumerate(tx.split(" ")):
                    if not w: continue
                    if idx == 0 and glue and tokens: tokens[-1] += fmt(w)
                    else: tokens.append(fmt(w))
        rc = "row sub" if all_sub else "row"
        out.append(f'<span class="{rc}">' + " ".join(f'<span class="cmask"><span class="cw">{tk}</span></span>' for tk in tokens) + "</span>")
    i = b.clip(t, d, "".join(out), f"top:{y}px;font-size:{size}px", "cap")
    b.js(f'tl.fromTo("#{i} .cw",{{opacity:0,yPercent:110,filter:"blur(4px)"}},{{opacity:1,yPercent:0,filter:"blur(0px)",duration:.54,ease:"expo.out",stagger:.058}},{t:.3f});'
         f'tl.fromTo("#{i} .band",{{scaleX:0}},{{scaleX:1,duration:.54,ease:"expo.out",stagger:.09}},{t + .16:.3f});'
         f'tl.fromTo("#{i} .pin.l",{{opacity:0,scaleY:0}},{{opacity:1,scaleY:1,duration:.24,ease:"expo.out"}},{t + .14:.3f});'
         f'tl.fromTo("#{i} .pin.r",{{opacity:0,left:"0%"}},{{opacity:1,left:"100%",duration:.54,ease:"expo.out"}},{t + .16:.3f});'
         f'tl.to("#{i} .pin",{{opacity:0,duration:.26,ease:"power2.in"}},{t + .82:.3f});'
         f'tl.to("#{i}",{{opacity:0,y:-12,filter:"blur(4px)",duration:.22,ease:"power2.in"}},{t + d - .24:.3f});')


def kinetic(b, t, d, words, y=700, size=120, g="bp"):
    inner = "".join(f'<span class="wd" style="display:inline-block;margin-right:.24em">{gtext(w, s) if s else E(w)}</span>' for w, s in words)
    i = b.clip(t, d, inner, f"left:72px;top:{y}px;width:936px;font-weight:900;font-size:{size}px;line-height:1.18;letter-spacing:-.04em")
    b.js(f'tl.fromTo("#{i} .wd",{{opacity:0,y:54,scale:1.18,filter:"blur(8px)"}},{{opacity:1,y:0,scale:1,filter:"blur(0px)",duration:.46,ease:"back.out(1.7)",stagger:.14}},{t:.3f});'
         f'tl.to("#{i}",{{opacity:0,duration:.25}},{t + d - .27:.3f});')

def titlecard(b, t, d, box, tag, lines, size=76, paper=False, _ghost=False):
    x, y, w, h = box
    ln = "".join(f'<div class="ln" style="font-size:{size}px;font-weight:900;line-height:1.16;letter-spacing:-.04em">{gtext(s, g) if g else E(s)}</div>' for s, g in lines)
    cls = "paper" if paper else ("ghost" if _ghost else "")
    i = b.clip(t, d, f'<div class="card {cls}" style="left:0;top:0;width:{w}px;height:{h}px;padding:44px 52px;display:flex;flex-direction:column;justify-content:center"><div class="tag">{E(tag)}<span class="tagline"></span></div><div style="margin-top:18px">{ln}</div></div>', f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, ghost=_ghost and not paper)
    b.js(f'tl.fromTo("#{i} .tagline",{{scaleX:0}},{{scaleX:1,duration:.6,ease:"expo.out"}},{t + .16:.3f});'
         f'tl.fromTo("#{i} .ln",{{opacity:0,y:22,filter:"blur(6px)"}},{{opacity:1,y:0,filter:"blur(0px)",duration:.5,ease:"expo.out",stagger:.11}},{t + .18:.3f});')

def strike(b, t, d, box, text, at, to=None, to_g="bp", size=50):
    x, y, w, h = box
    if to and y + 2 * h + 56 > 960: h = max(170, int((960 - y - 56) / 2))
    inner = (f'<div class="card c0" style="left:24px;top:0;width:{w - 48}px;height:{h}px;display:flex;align-items:center;justify-content:center">'
             f'<span style="position:relative;font-weight:700;font-size:{size - 2}px;color:var(--gry)">{E(text)}'
             f'<i class="st" style="position:absolute;left:-16px;right:-16px;top:52%;height:5px;background:linear-gradient(90deg,var(--b2),var(--b3));border-radius:3px;transform-origin:left"></i></span></div>')
    if to:
        inner += (f'<div class="card nw" style="left:0;top:{h + 34}px;width:{w}px;height:{h + 24}px;display:flex;flex-direction:column;align-items:center;justify-content:center">'
                  f'<span class="tag" style="color:var(--b1);margin-bottom:10px;font-size:20px">FOCUS</span>'
                  f'<span style="font-size:{size + 10}px;font-weight:900;letter-spacing:-.04em">{gtext(to, to_g)}</span></div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{2 * h + 70}px")
    popin(b, f"#{i} .c0", t, out=t + d, float_=False)
    b.js(f'tl.fromTo("#{i} .st",{{scaleX:0}},{{scaleX:1,duration:.48,ease:"expo.out"}},{at:.3f});'
         f'tl.to("#{i} .c0",{{scale:.96,opacity:.58,duration:.5,ease:"power2.out"}},{at + .15:.3f});')
    if to:
        popin(b, f"#{i} .nw", at + .26, out=t + d, float_=True)

def checklist(b, t, d, box, title, items, _ghost=False):
    x, y, w, h = box
    rh = min(84, max(62, int((h - 176) / max(1, len(items)))))
    rows = "".join(
        f'<div class="ci{k}" style="display:flex;align-items:center;justify-content:space-between;height:{rh}px;border-bottom:{1 if k < len(items) - 1 else 0}px solid #eef0f6">'
        f'<div style="display:flex;align-items:center;gap:22px">'
        f'<span class="cb" style="position:relative;width:42px;height:42px;border-radius:50%;border:2.5px solid #d7dce8;flex:none">'
        f'<svg viewBox="0 0 42 42" style="position:absolute;left:-2.5px;top:-2.5px;width:42px;height:42px">'
        f'<circle class="cf" cx="21" cy="21" r="21" fill="#245cff"/>'
        f'<path class="ck" d="M12 21.5 L18.5 28 L30.5 15" stroke="#fff" stroke-width="4.2" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="36" stroke-dashoffset="36"/></svg></span>'
        f'<span class="cl" style="font-weight:700;font-size:34px;color:#9aa0ae">{E(n)}</span></div>'
        f'<span class="cp" style="opacity:0;font-size:21px;font-weight:700;color:var(--b1);background:rgba(36,92,255,.09);padding:6px 16px;border-radius:99px">기본</span></div>'
        for k, (n, _) in enumerate(items))
    i = b.clip(t, d,
               f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px;padding:42px 54px">'
               f'<div class="tag" style="color:var(--b1)">INCLUDED</div>'
               f'<div style="font-weight:900;font-size:42px;margin:6px 0 18px;letter-spacing:-.04em">{E(title)}</div>{rows}</div>',
               f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, float_=False, ghost=_ghost)
    for k, (_, tk) in enumerate(items):
        sel = f"#{i} .ci{k}"
        b.js(f'tl.fromTo("{sel} .cf",{{scale:0,transformOrigin:"50% 50%"}},{{scale:1,duration:.38,ease:"expo.out"}},{tk:.3f});'
             f'tl.to("{sel} .ck",{{strokeDashoffset:0,duration:.36,ease:"power2.out"}},{tk + .10:.3f});'
             f'tl.fromTo("{sel} .cl",{{x:6,color:"#9aa0ae"}},{{x:0,color:"#14161c",duration:.38,ease:"expo.out"}},{tk:.3f});'
             f'tl.fromTo("{sel} .cp",{{opacity:0,x:8}},{{opacity:1,x:0,duration:.38,ease:"expo.out"}},{tk + .12:.3f});')

def hbars(b, t, d, box, title, rows, vmax, unit="", ticks=(), gcls=("b", "b", "bp"), _ghost=False):
    x, y, w, h = box; bw = w - 108
    rh = min(132, max(96, int((h - 158) / max(1, len(rows)))))
    rs = "".join(
        f'<div class="hr{k}" style="position:relative;height:{rh}px;display:flex;flex-direction:column;justify-content:center">'
        f'<div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:14px">'
        f'<span style="font-weight:700;font-size:30px;color:var(--ink)">{E(l)}</span>'
        f'<span class="vl" style="font-weight:900;font-size:40px"><span class="n gt g-{gcls[min(k, len(gcls) - 1)]}">0</span>'
        f'<span style="font-size:24px;font-weight:700;color:var(--gry);margin-left:4px">{E(unit)}</span></span></div>'
        f'<div style="position:relative;width:100%;height:24px;border-radius:12px;background:var(--trk);overflow:hidden">'
        f'<div class="bar g-{gcls[min(k, len(gcls) - 1)]}" style="height:100%;width:0%;border-radius:12px"></div></div></div>'
        for k, (l, v, _) in enumerate(rows))
    tk = "".join(f'<div style="position:absolute;left:{54 + bw * v / vmax:.0f}px;bottom:30px;font-family:PP,KR,sans-serif;font-size:20px;font-weight:500;color:#9aa0ae;transform:translateX(-50%)">{v}</div>' for v in ticks)
    i = b.clip(t, d,
               f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px;padding:42px 54px">'
               f'<div class="tag" style="color:var(--b1)">COMPARISON</div>'
               f'<div style="font-weight:900;font-size:38px;margin:4px 0 14px;letter-spacing:-.038em">{E(title)}</div>'
               f'<div>{rs}</div>{tk}</div>',
               f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, float_=False, ghost=_ghost)
    for k, (_, v, tk_) in enumerate(rows):
        pct = min(100.0, 100.0 * v / vmax)
        sel = f"#{i} .hr{k}"
        b.js(f'tl.fromTo("{sel}",{{opacity:.25,y:10}},{{opacity:1,y:0,duration:.45,ease:"expo.out"}},{tk_ - .08:.3f});'
             f'tl.to("{sel} .bar",{{width:"{pct:.1f}%",duration:1.25,ease:"expo.out"}},{tk_:.3f});'
             f'(function(){{const o={{v:0}};const el=document.querySelector("{sel} .n");tl.to(o,{{v:{v},duration:1.25,ease:"expo.out",onUpdate:()=>el.textContent=Math.round(o.v)}},{tk_:.3f});}})();')

def xyline(b, t, d, box, title, pts, vmax, at, dur=2.3, thr=None, thr_label="", caption_="", over_label="", _ghost=False):
    x, y, w, h = box; X0, X1, Y0, Y1 = 82, w - 58, h - 106, 128
    n = len(pts); P = [(X0 + 26 + (X1 - X0 - 52) * k / max(1, n - 1), Y0 - (Y0 - Y1) * v / vmax) for k, (_, v) in enumerate(pts)]
    line_d = "M%.1f %.1f " % P[0] + " ".join("L%.1f %.1f" % p for p in P[1:])
    area_d = line_d + f" L{P[-1][0]:.1f} {Y0} L{P[0][0]:.1f} {Y0} Z"
    L = sum(((P[k][0] - P[k - 1][0]) ** 2 + (P[k][1] - P[k - 1][1]) ** 2) ** .5 for k in range(1, n)) + 40
    gid = b.id("xa")
    grids = "".join(f'<line x1="{X0}" y1="{Y1 + (Y0 - Y1) * g / 3:.0f}" x2="{X1}" y2="{Y1 + (Y0 - Y1) * g / 3:.0f}" stroke="#eef0f6" stroke-width="2"/>' for g in range(3))
    dots = "".join(f'<circle class="dt{k}" cx="{p[0]:.1f}" cy="{p[1]:.1f}" r="9" fill="{"#7c4dff" if thr is not None and pts[k][1] > thr else "#245cff"}" stroke="#fff" stroke-width="3.5"/>' for k, p in enumerate(P))
    xl = "".join(f'<text x="{p[0]:.1f}" y="{Y0 + 38}" font-size="22" font-weight="700" fill="#727785" text-anchor="middle" font-family="KR">{E(pts[k][0])}</text>' for k, p in enumerate(P))
    th = ""
    if thr is not None:
        ty = Y0 - (Y0 - Y1) * thr / vmax
        th = f'<line class="th" x1="{X0}" y1="{ty:.1f}" x2="{X1}" y2="{ty:.1f}" stroke="#7c4dff" stroke-opacity=".55" stroke-width="2.5" stroke-dasharray="10 10"/><text class="thl" x="{X1}" y="{ty - 14:.1f}" font-size="22" font-weight="700" fill="#7c4dff" text-anchor="end" font-family="KR">{E(thr_label)}</text>'
    svg = (f'<svg width="{w}" height="{h}" style="position:absolute;left:0;top:0">'
           f'<defs><linearGradient id="{gid}" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#245cff" stop-opacity=".16"/><stop offset="100%" stop-color="#245cff" stop-opacity="0"/></linearGradient></defs>'
           f'{grids}<path d="M{X0} {Y1 - 16} L{X0} {Y0} L{X1} {Y0}" stroke="#d5d9e4" stroke-width="2.5" fill="none"/>'
           f'<path class="ar" d="{area_d}" fill="url(#{gid})" opacity="0"/>{th}'
           f'<path class="ln" d="{line_d}" stroke="#245cff" stroke-width="7" fill="none" stroke-linejoin="round" stroke-linecap="round" stroke-dasharray="{L:.0f}" stroke-dashoffset="{L:.0f}"/>'
           f'{dots}{xl}</svg>')
    ol = f'<div class="ov" style="position:absolute;right:56px;top:{max(88, P[-1][1] - 62):.0f}px;padding:6px 18px;border-radius:99px;background:rgba(124,77,255,.11);font-weight:700;font-size:23px;color:var(--b2)">{E(over_label)}</div>' if over_label else ""
    cap = f'<div style="position:absolute;right:56px;bottom:20px;font-size:20px;color:#9aa0ae">{E(caption_)}</div>' if caption_ else ""
    i = b.clip(t, d,
               f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px">'
               f'<div style="position:absolute;left:54px;top:38px;font-weight:900;font-size:34px;letter-spacing:-.035em">{E(title)}</div>'
               f'{svg}{ol}{cap}</div>',
               f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, float_=False, ghost=_ghost)
    if thr is not None: b.js(f'tl.fromTo("#{i} .th,#{i} .thl",{{opacity:0}},{{opacity:1,duration:.5}},{max(t + .1, at - .2):.3f});')
    b.js(f'tl.to("#{i} .ln",{{strokeDashoffset:0,duration:{dur},ease:"power2.inOut"}},{at:.3f});'
         f'tl.to("#{i} .ar",{{opacity:1,duration:.8,ease:"power2.out"}},{at + dur * .45:.3f});')
    for k in range(n):
        b.js(f'tl.fromTo("#{i} .dt{k}",{{scale:0,transformOrigin:"50% 50%",transformBox:"fill-box"}},{{scale:1,duration:.35,ease:"expo.out"}},{at + dur * k / max(1, n - 1):.3f});')
    if over_label: b.js(f'tl.fromTo("#{i} .ov",{{opacity:0,y:10}},{{opacity:1,y:0,duration:.45,ease:"expo.out"}},{at + dur - .25:.3f});')

def counter(b, t, d, box, label, v0, v1, unit="", g="b", at=None, bar=None, size=190, caption_="", _ghost=False):
    x, y, w, h = box; at = t + .32 if at is None else at
    br = f'<div style="position:absolute;left:64px;right:64px;bottom:68px;height:22px;border-radius:11px;background:var(--trk);overflow:hidden"><div class="br g-{g}" style="height:100%;width:0%;border-radius:11px"></div></div>' if bar else ""
    i = b.clip(t, d,
               f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px;text-align:center;padding-top:52px">'
               f'<div class="tag">{E(label)}</div>'
               f'<div style="font-weight:900;font-size:{size}px;line-height:1.12;margin-top:10px"><span class="gt g-{g} n">{v0}</span>'
               f'<span class="gt g-{g}" style="font-size:{size * .42:.0f}px;margin-left:6px">{E(unit)}</span></div>'
               f'<div style="font-size:26px;font-weight:700;color:var(--gry);margin-top:8px">{E(caption_)}</div>{br}</div>',
               f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, ghost=_ghost)
    dec = 0 if float(v1).is_integer() else 1
    b.js(f'(function(){{const o={{v:{v0}}};const el=document.querySelector("#{i} .n");tl.to(o,{{v:{v1},duration:1.35,ease:"expo.out",onUpdate:()=>el.textContent=o.v.toFixed({dec})}},{at:.3f});}})();')
    if bar: b.js(f'tl.to("#{i} .br",{{width:"{min(100.0, 100.0 * v1 / bar):.1f}%",duration:1.35,ease:"expo.out"}},{at:.3f});')

def ring(b, t, d, box, label, pct, at=None, g=("#245cff", "#7c4dff"), sub="", _ghost=False):
    x, y, w, h = box; at = t + .32 if at is None else at; R = min(w, h) * .32; C = 2 * 3.14159 * R
    gid = b.id("rg")
    svg = f'<svg width="{w}" height="{h}" style="position:absolute;left:0;top:0"><defs><linearGradient id="{gid}"><stop offset="0" stop-color="{g[0]}"/><stop offset="1" stop-color="{g[1]}"/></linearGradient></defs><circle cx="{w / 2}" cy="{h / 2 + 20}" r="{R:.0f}" stroke="#edf0f6" stroke-width="32" fill="none"/><circle class="rr" cx="{w / 2}" cy="{h / 2 + 20}" r="{R:.0f}" stroke="url(#{gid})" stroke-width="32" fill="none" stroke-linecap="round" stroke-dasharray="{C:.0f}" stroke-dashoffset="{C:.0f}" transform="rotate(-90 {w / 2} {h / 2 + 20})"/></svg>'
    i = b.clip(t, d, f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px">{svg}<div class="tag" style="position:absolute;top:40px;width:100%;text-align:center">{E(label)}</div><div style="position:absolute;top:{h / 2 - 48}px;width:100%;text-align:center;font-weight:900;font-size:98px"><span class="n gt g-b">0</span><span class="gt g-b" style="font-size:48px">%</span></div><div style="position:absolute;top:{h / 2 + 62}px;width:100%;text-align:center;font-size:25px;font-weight:700;color:var(--gry)">{E(sub)}</div></div>', f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, ghost=_ghost)
    b.js(f'tl.to("#{i} .rr",{{strokeDashoffset:{C * (1 - pct / 100):.0f},duration:1.4,ease:"expo.out"}},{at:.3f});(function(){{const o={{v:0}};const el=document.querySelector("#{i} .n");tl.to(o,{{v:{pct},duration:1.4,ease:"expo.out",onUpdate:()=>el.textContent=Math.round(o.v)}},{at:.3f});}})();')

def seesaw(b, t, d, left, right, y=360, note="", lg="p", rg="b"):
    if rg == "n": rg = "b"
    if lg == "n": lg = "p"
    i = b.clip(t, d,
               f'<div class="bm" style="position:absolute;left:200px;top:{y + 210}px;width:680px;height:10px;background:#cbd1de;border-radius:5px;transform-origin:50% 50%">'
               f'<div class="card cl" style="left:-110px;top:-152px;width:360px;height:124px;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:40px;color:var(--gry)">{E(left)}</div>'
               f'<div class="card cr" style="left:430px;top:-162px;width:360px;height:134px;display:flex;align-items:center;justify-content:center;font-weight:900;font-size:44px;border:2px solid rgba(36,92,255,.18)">{gtext(right, rg)}</div></div>'
               f'<div style="position:absolute;left:526px;top:{y + 202}px;width:28px;height:28px;border-radius:50%;background:#fff;border:6px solid var(--b1);z-index:3"></div>'
               f'<svg width="140" height="150" style="position:absolute;left:470px;top:{y + 216}px"><path d="M70 8 L124 136 L16 136 Z" fill="#e6eaf2" stroke="#cbd1de" stroke-width="3" stroke-linejoin="round"/></svg>'
               f'<div style="position:absolute;left:0;width:1080px;top:{y + 392}px;text-align:center;font-size:28px;font-weight:700;color:var(--gry)">{E(note)}</div>',
               "left:0;top:0;width:1080px;height:960px")
    b.js(f'tl.fromTo("#{i}",{{opacity:0,y:36}},{{opacity:1,y:0,duration:.65,ease:"expo.out"}},{t:.3f});'
         f'tl.fromTo("#{i} .bm",{{rotation:-7}},{{rotation:8.5,duration:1.35,ease:"power3.inOut"}},{t + .22:.3f});'
         f'tl.to("#{i} .bm",{{rotation:6.8,duration:2.0,ease:"sine.inOut",yoyo:true,repeat:{max(1, int(d / 2.0))}}},{t + 1.57:.3f});'
         f'tl.to("#{i}",{{opacity:0,y:-14,duration:.28,ease:"power2.in"}},{t + d - .30:.3f});')

def steps(b, t, d, items, y=320, gap=196):
    inner = ""
    for k, (s, g, tk) in enumerate(items):
        gc = "b" if g == "n" else g
        if k:
            inner += f'<div class="ar{k}" style="position:absolute;left:538px;top:{y + k * gap - (gap - 134)}px;width:4px;height:{gap - 134}px;background:linear-gradient(180deg,var(--b1),var(--b2));border-radius:2px;transform-origin:top"></div>'
        inner += (f'<div class="st{k} card" style="left:110px;top:{y + k * gap}px;width:860px;height:134px;padding:0 48px;display:flex;align-items:center;gap:30px">'
                  f'<span class="tnum" style="width:58px;height:58px;border-radius:18px;background:rgba(36,92,255,.09);color:var(--b1);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:26px;flex:none">0{k + 1}</span>'
                  f'<span style="font-weight:900;font-size:46px;letter-spacing:-.038em">{gtext(s, gc)}</span></div>')
    i = b.clip(t, d, inner, "left:0;top:0;width:1080px;height:1050px")
    for k, (_, _, tk) in enumerate(items):
        if k:
            b.js(f'tl.fromTo("#{i} .ar{k}",{{scaleY:0,opacity:0}},{{scaleY:1,opacity:1,duration:.36,ease:"expo.out"}},{tk - .18:.3f});'
                 f'tl.to("#{i} .ar{k}",{{opacity:0,duration:.26}},{t + d - .28:.3f});')
        popin(b, f"#{i} .st{k}", tk, d=.58, y=28, out=t + d, float_=False)

def versus(b, t, d, a, bb, y=350, at2=None):
    at2 = t + .65 if at2 is None else at2; inner = ""
    for k, (lab, val, sub, g) in enumerate([a, bb]):
        gc = "p" if g == "n" else g
        x = 76 + k * 484
        fsz = min(84, max(44, int(350 / max(1, len(val) * .88))))
        inner += (f'<div class="v{k} card" style="left:{x}px;top:{y}px;width:444px;height:440px;padding:52px 32px;display:flex;flex-direction:column;align-items:center;justify-content:space-between;text-align:center">'
                  f'<div class="tag">{E(lab)}</div>'
                  f'<div style="font-weight:900;font-size:{fsz}px;line-height:1.18;letter-spacing:-.04em">{gtext(val, gc)}</div>'
                  f'<div style="font-size:26px;font-weight:700;color:var(--gry)">{E(sub)}</div></div>')
    inner += f'<div class="vs" style="position:absolute;left:502px;top:{y + 182}px;width:76px;height:76px;border-radius:50%;background:var(--ink);border:6px solid var(--bg);color:#fff;font-family:PP,sans-serif;font-weight:700;font-size:24px;letter-spacing:.06em;display:flex;align-items:center;justify-content:center;z-index:4">VS</div>'
    i = b.clip(t, d, inner, "left:0;top:0;width:1080px;height:960px")
    popin(b, f"#{i} .v0", t, out=t + d); popin(b, f"#{i} .v1", at2, out=t + d)
    b.js(f'tl.fromTo("#{i} .vs",{{scale:.5,opacity:0}},{{scale:1,opacity:1,duration:.45,ease:"expo.out"}},{at2 + .14:.3f});'
         f'tl.to("#{i} .vs",{{opacity:0,duration:.28}},{t + d - .30:.3f});')

def photo(b, t, d, box, src, badge=None, label=None, zoom=1.07):
    x, y, w, h = box
    bd = f'<div class="bd card" style="right:24px;bottom:24px;padding:14px 28px;border-radius:26px;font-weight:900;font-size:44px">{gtext(badge, "b")}</div>' if badge else ""
    lb = f'<div style="position:absolute;left:24px;top:24px;padding:10px 22px;border-radius:99px;background:rgba(20,22,28,.72);backdrop-filter:blur(10px);color:#fff;font-weight:700;font-size:24px">{E(label)}</div>' if label else ""
    i = b.clip(t, d, f'<div class="card" style="left:0;top:0;width:{w}px;height:{h}px;overflow:hidden"><img class="ph" src="assets/{src}" style="width:100%;height:100%;object-fit:cover">{lb}{bd}</div>', f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, float_=False)
    b.js(f'tl.fromTo("#{i} .ph",{{scale:1.01}},{{scale:{zoom},duration:{d},ease:"none"}},{t:.3f});')
    if badge: b.js(f'tl.fromTo("#{i} .bd",{{opacity:0,y:16}},{{opacity:1,y:0,duration:.5,ease:"expo.out"}},{t + .55:.3f});')

def spectrum(b, t, d, y=340, pass_label="가시광선 · 선명하게 통과", block_label="적외선 열 · 선택적 차단", at=None):
    at = t + .45 if at is None else at
    lines = "".join(f'<div class="sl" style="position:absolute;left:{130 + k * 68}px;top:170px;width:6px;height:210px;background:{c};border-radius:3px;transform-origin:top"></div>' for k, c in enumerate(["#6366f1", "#245cff", "#0ea5e9", "#14b8a6"]))
    blocks = "".join(f'<div class="bl" style="position:absolute;left:{570 + k * 76}px;top:170px;width:6px;height:82px;background:#7c4dff;border-radius:3px;transform-origin:top"></div><div class="bx" style="position:absolute;left:{558 + k * 76}px;top:262px;font-weight:900;font-size:30px;color:#7c4dff">×</div>' for k in range(3))
    i = b.clip(t, d,
               f'<div class="card" style="left:84px;top:{y}px;width:912px;height:540px">'
               f'<div style="position:absolute;left:64px;top:52px;font-size:24px;font-weight:700;color:var(--b1)">가시광선 (VLT)</div>'
               f'<div style="position:absolute;right:64px;top:52px;font-size:24px;font-weight:700;color:var(--b2)">적외선 열에너지 (IR)</div>'
               f'<div class="sp" style="position:absolute;left:64px;top:102px;width:784px;height:48px;border-radius:24px;background:linear-gradient(90deg,#6366f1,#245cff,#0ea5e9,#14b8a6,#7c4dff,#c026d3)"></div>'
               f'{lines}{blocks}'
               f'<div class="pl" style="position:absolute;left:64px;bottom:48px;font-weight:900;font-size:30px;color:var(--b1)">{E(pass_label)}</div>'
               f'<div class="pl" style="position:absolute;right:64px;bottom:48px;font-weight:900;font-size:30px;color:var(--b2)">{E(block_label)}</div></div>',
               "left:0;top:0;width:1080px;height:960px")
    popin(b, f"#{i} .card", t, out=t + d, float_=False)
    b.js(f'tl.fromTo("#{i} .sp",{{scaleX:0,transformOrigin:"left"}},{{scaleX:1,duration:.7,ease:"expo.out"}},{t + .15:.3f});'
         f'tl.fromTo("#{i} .sl,#{i} .bl",{{scaleY:0}},{{scaleY:1,duration:.55,stagger:.06,ease:"expo.out"}},{at:.3f});'
         f'tl.fromTo("#{i} .bx,#{i} .pl",{{opacity:0,y:8}},{{opacity:1,y:0,duration:.45,stagger:.06,ease:"expo.out"}},{at + .45:.3f});')

def waves(b, t, d, y=320, glass="SOLAR FILM", passed=False, note_l="태양열 · 눈부심", note_r="열에너지 제어"):
    wv = ""
    for k in range(4):
        through = passed or k == 0
        L = 780 if through else 410
        col = "#245cff" if k == 0 else "#7c4dff"
        p = "M48 0 " + " ".join(f"Q{48 + j * 36 + 18} {(-12 if j % 2 == 0 else 12)} {48 + (j + 1) * 36} 0" for j in range(int((L - 48) / 36)))
        wv += f'<svg class="wv" width="840" height="36" style="position:absolute;left:36px;top:{130 + k * 74}px;overflow:visible"><path d="{p}" transform="translate(0,18)" stroke="{col}" stroke-width="4.5" stroke-linecap="round" fill="none" stroke-dasharray="1100" stroke-dashoffset="1100"/></svg>'
    i = b.clip(t, d,
               f'<div class="card" style="left:84px;top:{y}px;width:912px;height:560px">'
               f'<div style="position:absolute;left:56px;top:44px;font-weight:700;font-size:25px;color:var(--b2)">{E(note_l)}</div>'
               f'<div class="nr" style="position:absolute;right:56px;top:40px;padding:8px 22px;border-radius:99px;background:rgba(36,92,255,.10);font-weight:700;font-size:24px;color:var(--b1)">{E(note_r)}</div>'
               f'<div class="gl" style="position:absolute;left:442px;top:104px;width:28px;height:330px;border-radius:14px;background:linear-gradient(180deg,rgba(36,92,255,.22),rgba(124,77,255,.28));border:2.5px solid rgba(36,92,255,.45)"></div>'
               f'{wv}<div class="tag" style="position:absolute;left:0;width:100%;bottom:38px;text-align:center;color:var(--b1)">{E(glass)}</div></div>',
               "left:0;top:0;width:1080px;height:960px")
    popin(b, f"#{i} .card", t, out=t + d, float_=False)
    b.js(f'tl.fromTo("#{i} .gl",{{opacity:0,scaleY:.4}},{{opacity:1,scaleY:1,duration:.55,ease:"expo.out"}},{t + .12:.3f});'
         f'tl.to("#{i} .wv path",{{strokeDashoffset:0,duration:1.5,ease:"power2.out",stagger:.18}},{t + .25:.3f});'
         f'tl.fromTo("#{i} .nr",{{opacity:0,y:10}},{{opacity:1,y:0,duration:.45,ease:"expo.out"}},{t + 1.1:.3f});')

def timeline(b, t, d, items, y=340):
    inner = f'<div class="tl0" style="position:absolute;left:180px;top:{y + 30}px;width:4px;height:{max(1, len(items) - 1) * 150}px;background:linear-gradient(180deg,var(--b1),var(--lgt));border-radius:2px;transform-origin:top"></div>'
    for k, (a, s, tk) in enumerate(items):
        inner += f'<div class="ti{k}" style="position:absolute;left:150px;top:{y + k * 150}px;width:820px;height:120px"><span style="position:absolute;left:13px;top:36px;width:38px;height:38px;border-radius:50%;background:var(--b1);border:7px solid #dce5ff"></span><div class="card" style="left:88px;top:0;width:720px;height:114px;padding:20px 36px"><div class="tag" style="font-size:20px">{E(a)}</div><div style="font-weight:900;font-size:38px;margin-top:4px">{E(s)}</div></div></div>'
    i = b.clip(t, d, inner, "left:0;top:0;width:1080px;height:1100px")
    b.js(f'tl.fromTo("#{i} .tl0",{{scaleY:0}},{{scaleY:1,duration:{max(.6, items[-1][2] - t):.2f},ease:"power2.out"}},{t:.3f});')
    for k, (_, _, tk) in enumerate(items): popin(b, f"#{i} .ti{k}", tk, out=t + d, float_=False, y=28)

def typeline(b, t, d, box, lines, size=64, cps=12, paper=True, tag=None):
    x, y, w, h = box; col = {"ink": "var(--tw)", "blue": "var(--twb)", "red": "var(--twr)"}
    ls = "".join(f'<div class="tl{k} ink" style="font-size:{size}px;line-height:1.3;color:{col[c]};white-space:nowrap">' + "".join(f'<span class="ch" style="display:none">{E(ch) if ch != " " else "&nbsp;"}</span>' for ch in s) + '</div>' for k, (s, c) in enumerate(lines))
    ls = ls.replace("</div>", '<span class="cursor" style="display:none"></span></div>')
    tg = f'<div class="ink" style="font-family:TWE;font-size:26px;letter-spacing:.12em;color:var(--gry);margin-bottom:14px">{E(tag)}</div>' if tag else ""
    i = b.clip(t, d, f'<div class="card {"paper" if paper else ""} tw" style="left:0;top:0;width:{w}px;height:{h}px;padding:40px 44px">{tg}{ls}</div>', f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, float_=False)
    ts = t + .35
    for k, (s, _) in enumerate(lines):
        b.js(f'tl.set("#{i} .cursor",{{display:"none"}},{ts:.3f});tl.set("#{i} .tl{k} .cursor",{{display:"inline-block"}},{ts:.3f});tl.to("#{i} .tl{k} .ch",{{display:"inline",duration:.01,stagger:{1 / cps:.3f}}},{ts:.3f});'); ts += len(s) / cps + .2
    b.js(f'tl.fromTo("#{i} .cursor",{{opacity:0}},{{opacity:.85,duration:.01,repeat:{int(d * 2.4)},yoyo:true,repeatDelay:.4}},{t:.3f});')
    return ts

def receipt(b, t, d, box, title, rows, cps=40, red_last=True):
    x, y, w, h = box; inner = f'<div class="ink" style="font-family:TWE;font-size:28px;letter-spacing:.12em;color:var(--gry);margin-bottom:26px">{E(title)}</div>'
    for k, (n, v) in enumerate(rows):
        c = "var(--twr)" if red_last and k == len(rows) - 1 else "var(--tw)"
        inner += f'<div class="r{k} ink" style="display:flex;align-items:center;height:94px;font-size:40px;color:{c}"><span class="nm">' + "".join(f'<span class="ch" style="display:none">{E(ch) if ch != " " else "&nbsp;"}</span>' for ch in n) + f'</span><span class="dl" style="flex:1;margin:0 18px;border-bottom:3px dotted #c6cad4;transform-origin:left"></span><span class="vv">' + "".join(f'<span class="ch" style="display:none">{E(ch) if ch != " " else "&nbsp;"}</span>' for ch in v) + '</span></div>'
    i = b.clip(t, d, f'<div class="card paper tw" style="left:0;top:0;width:{w}px;height:{h}px;padding:44px 50px">{inner}</div>', f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, float_=False)
    ts = t + .3
    for k, (n, v) in enumerate(rows):
        b.js(f'tl.to("#{i} .r{k} .nm .ch",{{display:"inline",duration:.01,stagger:{1 / cps:.3f}}},{ts:.3f});tl.fromTo("#{i} .r{k} .dl",{{scaleX:0}},{{scaleX:1,duration:.22}},{ts + len(n) / cps:.3f});tl.to("#{i} .r{k} .vv .ch",{{display:"inline",duration:.01,stagger:{1 / cps:.3f}}},{ts + len(n) / cps + .22:.3f});')
        ts += (len(n) + len(v)) / cps + .34
    return ts

def slot(b, t, d, box, label, value, unit="", at=None, g="b", _ghost=False):
    x, y, w, h = box; at = t + .35 if at is None else at; digs = str(value); S = 170
    cols = "".join(f'<span class="tnum" style="display:inline-block;height:{S * 1.15:.0f}px;overflow:hidden;vertical-align:top"><span class="dg{k}" style="display:block">' + "".join(f'<span class="gt g-{g}" style="display:block;height:{S * 1.15:.0f}px;line-height:{S * 1.15:.0f}px">{(int(c) + j) % 10 if c.isdigit() else c}</span>' for j in range(10, -1, -1)) + '</span></span>' for k, c in enumerate(digs))
    i = b.clip(t, d, f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px;text-align:center;padding-top:48px"><div class="tag">{E(label)}</div><div style="font-weight:900;font-size:{S}px;margin-top:8px">{cols}<span class="gt g-{g}" style="font-size:{S * .4:.0f}px;margin-left:6px">{E(unit)}</span></div></div>', f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, float_=False, ghost=_ghost)
    for k, c in enumerate(digs):
        if c.isdigit(): b.js(f'tl.fromTo("#{i} .dg{k}",{{y:0,filter:"blur(6px)"}},{{y:-{S * 1.15 * 10:.0f},filter:"blur(0px)",duration:{1.1 + k * .22:.2f},ease:"expo.out"}},{at:.3f});')

def compare(b, t, d, box, left, right, at=None):
    x, y, w, h = box; at = t + .45 if at is None else at
    i = b.clip(t, d, f'<div class="card" style="left:0;top:0;width:{w}px;height:{h}px;overflow:hidden"><img src="assets/{right[1]}" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover"><div class="lf" style="position:absolute;inset:0;clip-path:inset(0 0% 0 0)"><img src="assets/{left[1]}" style="width:{w}px;height:{h}px;object-fit:cover"></div><div class="hd" style="position:absolute;top:0;bottom:0;left:0;width:4px;background:#fff;box-shadow:0 0 16px rgba(0,0,0,.28)"></div><div style="position:absolute;left:24px;top:24px;padding:8px 20px;border-radius:99px;background:rgba(20,22,28,.72);color:#fff;font-weight:700;font-size:24px">{E(left[0])}</div><div style="position:absolute;right:24px;top:24px;padding:8px 20px;border-radius:99px;background:var(--b1);color:#fff;font-weight:700;font-size:24px">{E(right[0])}</div></div>', f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, float_=False)
    b.js(f'tl.fromTo("#{i} .lf",{{clipPath:"inset(0 0% 0 0)"}},{{clipPath:"inset(0 50% 0 0)",duration:1.2,ease:"power3.inOut"}},{at:.3f});tl.fromTo("#{i} .hd",{{x:{w}}},{{x:{w * .5:.0f},duration:1.2,ease:"power3.inOut"}},{at:.3f});')

def endcard(b, t, d, logo_="motif", lines=("솔라가드 THE LX 전주 유일 공식 특화샵",), phone="010-4814-4506", addr="전주 덕진구 정여립로 1104", big=None):
    src = {"motif": "motif_logo_dark.png", "lxsg": "lxsg_ink_dark.png"}[logo_]
    ln = "".join(f'<div class="e" style="font-weight:700;font-size:36px;margin-top:26px;letter-spacing:-.03em">{E(s)}</div>' for s in lines)
    mid = f'<div class="e" style="font-size:28px;font-weight:700;color:var(--gry);margin-top:46px">시공 및 예약 문의</div><div class="e tnum" style="font-weight:900;font-size:94px;margin-top:6px">{gtext(phone, "bp")}</div><div class="e" style="font-size:30px;color:var(--gry);margin-top:8px">{E(addr)}</div>' if phone else ""
    bg = f'<div class="e" style="font-weight:900;font-size:72px;margin-top:38px">{gtext(big, "bp")}</div>' if big else ""
    i = b.clip(t, d, f'<div style="position:absolute;left:0;top:560px;width:1080px;text-align:center"><img class="e" src="assets/{src}" style="width:{440 if logo_ == "motif" else 360}px"><div class="e g-b" style="width:76px;height:6px;margin:34px auto 0;border-radius:3px"></div>{ln}{bg}{mid}</div>', "left:0;top:0;width:1080px;height:1920px")
    b.js(f'tl.fromTo("#{i} .e",{{opacity:0,y:26,filter:"blur(6px)"}},{{opacity:1,y:0,filter:"blur(0px)",duration:.65,stagger:.11,ease:"expo.out"}},{t:.3f});')

# ───────── 프로 모션·타이포 신규 부품 8종 (해외 유튜브 레퍼런스 기반) ─────────
def splitline(b, t, d, box=(84, 330, 912, 500), top="", bottom="", tag="CONTRAST", g="b", at=None, _ghost=False):
    """[Ben Marriott Trim-Path + Track Matte] 중앙 기준선이 그어지며 위/아래 문구가 마스크 경계에서 교차 등장"""
    x, y, w, h = box; at = t + .28 if at is None else at
    mid_y = int(h * .52)
    fsz_t = min(44, max(32, int(740 / max(1, len(top)))))
    fsz_b = min(60, max(38, int(780 / max(1, len(bottom)))))
    i = b.clip(t, d,
               f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px">'
               f'<div class="tag" style="position:absolute;left:56px;top:40px;color:var(--b1)">{E(tag)}</div>'
               f'<div style="position:absolute;left:56px;right:56px;bottom:{h - mid_y + 18}px;height:120px;overflow:hidden;display:flex;align-items:flex-end;justify-content:center">'
               f'<div class="tp" style="font-weight:700;font-size:{fsz_t}px;color:var(--gry);text-align:center">{E(top)}</div></div>'
               f'<div class="ln" style="position:absolute;left:56px;right:56px;top:{mid_y}px;height:3.5px;border-radius:2px;background:linear-gradient(90deg,var(--b1),var(--b2));transform-origin:50% 50%"></div>'
               f'<div style="position:absolute;left:56px;right:56px;top:{mid_y + 20}px;height:140px;overflow:hidden;display:flex;align-items:flex-start;justify-content:center">'
               f'<div class="bt" style="font-weight:900;font-size:{fsz_b}px;letter-spacing:-.04em;text-align:center">{gtext(bottom, g)}</div></div></div>',
               f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, float_=False, ghost=_ghost)
    b.js(f'tl.fromTo("#{i} .ln",{{scaleX:0,opacity:0}},{{scaleX:1,opacity:1,duration:.58,ease:"expo.out"}},{at:.3f});'
         f'tl.fromTo("#{i} .tp",{{y:105,opacity:0,filter:"blur(6px)"}},{{y:0,opacity:1,filter:"blur(0px)",duration:.58,ease:"expo.out"}},{at + .12:.3f});'
         f'tl.fromTo("#{i} .bt",{{y:-115,opacity:0,filter:"blur(8px)"}},{{y:0,opacity:1,filter:"blur(0px)",duration:.64,ease:"expo.out"}},{at + .26:.3f});')

def morphcard(b, t, d, stages, y=340, w_end=912, h_end=520):
    """[Apple UI Single-Shape Morphing] 알약 배지 → 중간 바 → 메인 카드로 모서리 왜곡 없이 크기·곡률 연속 변형"""
    n = len(stages)
    if n == 2:
        dims = [(480, 134, 67), (w_end, h_end, 38)]
    else:
        dims = [(460, 128, 64), (740, 250, 44), (w_end, h_end, 38)]
        while len(dims) < n: dims.append((w_end, h_end, 38))
    w0, h0, r0 = dims[0]
    x0 = int(540 - w0 / 2); y0 = int(y + (h_end - h0) * .38)
    inners = ""
    for k, (tg, txt, _) in enumerate(stages):
        wk, hk, _ = dims[k]
        fsz = 36 if k == 0 else (44 if k == 1 and n > 2 else min(58, max(40, int(760 / max(1, len(txt))))))
        is_last = (k == n - 1)
        inners += (f'<div class="st{k}" style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:0 44px;text-align:center;opacity:0">'
                   f'<div class="tag" style="color:{"var(--b1)" if is_last else "var(--gry)"};font-size:{19 if k == 0 else 22}px;margin-bottom:{6 if k == 0 else 14}px">{E(tg)}</div>'
                   f'<div style="font-weight:{900 if is_last else 700};font-size:{fsz}px;letter-spacing:-.038em;white-space:nowrap">{gtext(txt, "bp" if is_last else "k")}</div></div>')
    i = b.clip(t, d, f'<div class="card mc" style="left:0;top:0;width:{w0}px;height:{h0}px;border-radius:{r0}px;overflow:hidden">{inners}</div>', "left:0;top:0;width:1080px;height:1000px")
    t_first = stages[0][2] if isinstance(stages[0][2], (int, float)) else t + .15
    b.js(f'tl.fromTo("#{i} .mc",{{opacity:0,x:{x0},y:{y0 + 30},width:{w0},height:{h0},borderRadius:{r0}}},{{opacity:1,x:{x0},y:{y0},width:{w0},height:{h0},borderRadius:{r0},duration:.58,ease:"expo.out"}},{t:.3f});'
         f'tl.fromTo("#{i} .st0",{{opacity:0,y:14,filter:"blur(6px)"}},{{opacity:1,y:0,filter:"blur(0px)",duration:.45,ease:"expo.out"}},{max(t + .1, t_first):.3f});')
    for k in range(1, n):
        wk, hk, rk = dims[k]
        xk = int(540 - wk / 2); yk = int(y + (h_end - hk) * .38)
        tk = stages[k][2]
        b.js(f'tl.to("#{i} .st{k - 1}",{{opacity:0,y:-14,filter:"blur(5px)",duration:.24,ease:"power2.in"}},{tk - .08:.3f});'
             f'tl.to("#{i} .mc",{{x:{xk},y:{yk},width:{wk},height:{hk},borderRadius:{rk},duration:.62,ease:"power3.inOut"}},{tk:.3f});'
             f'tl.fromTo("#{i} .st{k}",{{opacity:0,y:18,filter:"blur(8px)"}},{{opacity:1,y:0,filter:"blur(0px)",duration:.52,ease:"expo.out"}},{tk + .22:.3f});')
    b.js(f'tl.to("#{i} .mc",{{opacity:0,y:{int(y - 16)},scale:.99,duration:.28,ease:"power2.in"}},{t + d - .30:.3f});')

def bento(b, t, d, box=(84, 295, 912, 620), cells=()):
    """[Apple Keynote Asymmetric Bento Grid] 제어된 비대칭 여백 그리드(2~4칸 자동 분할)"""
    x, y, w, h = box; gap = 20; n = len(cells)
    if n <= 2:
        rects = [(0, 0, w, int((h - gap) * .54)), (0, int((h - gap) * .54) + gap, w, h - int((h - gap) * .54) - gap)]
    elif n == 3:
        h1 = int((h - gap) * .48); h2 = h - gap - h1; w2 = int((w - gap) / 2)
        rects = [(0, 0, w, h1), (0, h1 + gap, w2, h2), (w2 + gap, h1 + gap, w - w2 - gap, h2)]
    else:
        h1 = int((h - gap) * .50); h2 = h - gap - h1
        w_big = int((w - gap) * .57); w_sml = w - gap - w_big
        rects = [(0, 0, w_big, h1), (w_big + gap, 0, w_sml, h1), (0, h1 + gap, w_sml, h2), (w_sml + gap, h1 + gap, w_big, h2)]
    inner = ""
    for k, (tg, tit, sub, g, _) in enumerate(cells[:4]):
        cx, cy, cw, ch = rects[k]
        fsz = min(46 if cw > w * .5 else 38, max(30, int((cw - 72) / max(1, len(tit) * .9))))
        accent = "border:1.5px solid rgba(36,92,255,.20);background:linear-gradient(180deg,#ffffff 0%,#f7f9ff 100%)" if k == 0 else ""
        inner += (f'<div class="card bc{k}" style="left:{cx}px;top:{cy}px;width:{cw}px;height:{ch}px;padding:34px 38px;display:flex;flex-direction:column;justify-content:space-between;{accent}">'
                  f'<div class="tag" style="font-size:20px;color:{"var(--b1)" if k == 0 else "var(--gry)"}">{E(tg)}</div>'
                  f'<div><div style="font-weight:900;font-size:{fsz}px;letter-spacing:-.038em;line-height:1.18">{gtext(tit, g)}</div>'
                  f'<div style="font-size:25px;font-weight:700;color:var(--gry);margin-top:8px">{E(sub)}</div></div></div>')
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    for k, (*_, tk) in enumerate(cells[:4]):
        b.js(f'tl.fromTo("#{i} .bc{k}",{{opacity:0,y:28,scale:.97,filter:"blur(6px)"}},{{opacity:1,y:0,scale:1,filter:"blur(0px)",duration:.58,ease:"expo.out"}},{tk:.3f});'
             f'tl.to("#{i} .bc{k}",{{opacity:0,y:-14,duration:.26,ease:"power2.in"}},{t + d - .28:.3f});')

def ladder(b, t, d, box=(88, 295, 904, 620), title="LINEUP", tiers=(), pick=-1, _ghost=False):
    """[Satori Graphics Isolation & Visual Weight] 라인업 사다리 목록 + 선택 등급 돌출 강조"""
    x, y, w, h = box; n = len(tiers)
    pk = (n + pick) if (isinstance(pick, int) and pick < 0) else pick
    rh = min(132, max(92, int((h - 156) / max(1, n))))
    rows = ""
    for k, (nm, val, _) in enumerate(tiers):
        rows += (f'<div class="ld{k}" style="height:{rh - 14}px;margin-bottom:14px;padding:0 36px;border-radius:24px;background:#f7f8fc;border:2px solid transparent;display:flex;align-items:center;justify-content:space-between">'
                 f'<div style="display:flex;align-items:center;gap:20px">'
                 f'<span class="tnum" style="font-size:22px;font-weight:700;color:var(--gry)">0{k + 1}</span>'
                 f'<span class="nm" style="font-weight:700;font-size:33px;color:var(--ink)">{E(nm)}</span></div>'
                 f'<span class="vl tnum" style="font-weight:900;font-size:38px">{gtext(val, "b" if k == pk else "k")}</span></div>')
    i = b.clip(t, d,
               f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px;padding:40px 48px">'
               f'<div class="tag" style="color:var(--b1)">SELECTION TIERS</div>'
               f'<div style="font-weight:900;font-size:38px;margin:4px 0 20px;letter-spacing:-.038em">{E(title)}</div>'
               f'{rows}</div>',
               f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, float_=False, ghost=_ghost)
    last_tk = t + .4
    for k, (_, _, tk) in enumerate(tiers):
        last_tk = max(last_tk, tk)
        b.js(f'tl.fromTo("#{i} .ld{k}",{{opacity:0,x:-20,filter:"blur(5px)"}},{{opacity:1,x:0,filter:"blur(0px)",duration:.5,ease:"expo.out"}},{tk:.3f});')
    if isinstance(pk, int) and 0 <= pk < n:
        ht = min(t + d - .8, last_tk + .45)
        for k in range(n):
            if k == pk:
                b.js(f'tl.to("#{i} .ld{k}",{{scale:1.025,x:8,backgroundColor:"#ffffff",borderColor:"rgba(36,92,255,.35)",boxShadow:"0 14px 32px rgba(36,92,255,.12)",duration:.55,ease:"expo.out"}},{ht:.3f});')
            else:
                b.js(f'tl.to("#{i} .ld{k}",{{opacity:.54,scale:.985,duration:.55,ease:"power2.out"}},{ht:.3f});')

def focusword(b, t, d, box=(84, 330, 912, 520), eyebrow="DESIGN PRINCIPLE", word="", sub="", g="bp", at=None, _ghost=False):
    """[Ben Marriott 106%→100% Optical Focus + Tracking] 시네마틱 자간 확장 + 광학 블러 포커스 명제 카드"""
    x, y, w, h = box; at = t + .22 if at is None else at
    fsz = min(84, max(48, int(760 / max(1, len(word) * .88))))
    i = b.clip(t, d,
               f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px;padding:52px;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center">'
               f'<div class="ey" style="font-family:PP,KR,sans-serif;font-weight:700;font-size:22px;color:var(--b1);letter-spacing:.10em;text-transform:uppercase">{E(eyebrow)}</div>'
               f'<div class="fw" style="font-weight:900;font-size:{fsz}px;letter-spacing:-.042em;line-height:1.16;margin:24px 0">{gtext(word, g)}</div>'
               f'<div class="dv" style="width:68px;height:3px;border-radius:2px;background:var(--lgt);margin-bottom:24px;transform-origin:center"></div>'
               f'<div style="height:56px;overflow:hidden"><div class="sb" style="font-size:30px;font-weight:700;color:var(--gry)">{E(sub)}</div></div></div>',
               f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, float_=True, ghost=_ghost)
    b.js(f'tl.fromTo("#{i} .ey",{{opacity:0,letterSpacing:"0.08em"}},{{opacity:1,letterSpacing:"0.26em",duration:1.4,ease:"expo.out"}},{at:.3f});'
         f'tl.fromTo("#{i} .fw",{{opacity:0,y:18,filter:"blur(5px)"}},{{opacity:1,y:0,filter:"blur(0px)",duration:.82,ease:"expo.out"}},{at + .10:.3f});'
         f'tl.fromTo("#{i} .dv",{{scaleX:0}},{{scaleX:1,duration:.5,ease:"expo.out"}},{at + .35:.3f});'
         f'tl.fromTo("#{i} .sb",{{y:50,opacity:0}},{{y:0,opacity:1,duration:.55,ease:"expo.out"}},{at + .44:.3f});')

def crossscan(b, t, d, box=(84, 330, 912, 500), tag="OPTICAL VERIFIED", text="", sub="", g="b", at=None, _ghost=False):
    """[Mhd Labs Crosshair Scan Reveal] 뷰파인더 십자선(+)이 스캔하며 핵심 스펙/문구를 현상"""
    x, y, w, h = box; at = t + .28 if at is None else at
    fsz = min(76, max(44, int(760 / max(1, len(text) * .72))))
    sw = w - 128
    brk = (f'<i style="position:absolute;left:36px;top:36px;width:22px;height:22px;border-left:3px solid var(--lgt);border-top:3px solid var(--lgt)"></i>'
           f'<i style="position:absolute;right:36px;top:36px;width:22px;height:22px;border-right:3px solid var(--lgt);border-top:3px solid var(--lgt)"></i>'
           f'<i style="position:absolute;left:36px;bottom:36px;width:22px;height:22px;border-left:3px solid var(--lgt);border-bottom:3px solid var(--lgt)"></i>'
           f'<i style="position:absolute;right:36px;bottom:36px;width:22px;height:22px;border-right:3px solid var(--lgt);border-bottom:3px solid var(--lgt)"></i>')
    i = b.clip(t, d,
               f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px">{brk}'
               f'<div class="tag" style="position:absolute;top:52px;width:100%;text-align:center;color:var(--b1)">{E(tag)}</div>'
               f'<div style="position:absolute;left:64px;top:{int(h * .36)}px;width:{sw}px;height:120px;display:flex;align-items:center;justify-content:center">'
               f'<div class="tx tnum" style="font-weight:900;font-size:{fsz}px;letter-spacing:-.035em;white-space:nowrap;clip-path:inset(0 100% 0 0)">{gtext(text, g)}</div>'
               f'<div class="ch" style="position:absolute;left:0;top:0;width:3px;height:120px;background:var(--b1);opacity:0">'
               f'<span style="position:absolute;left:-13px;top:46px;width:29px;height:29px;font-family:PP,sans-serif;font-weight:700;font-size:28px;color:var(--b1);line-height:29px;text-align:center">+</span></div></div>'
               f'<div class="sb" style="position:absolute;bottom:56px;width:100%;text-align:center;font-size:28px;font-weight:700;color:var(--gry);opacity:0">{E(sub)}</div></div>',
               f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, float_=False, ghost=_ghost)
    b.js(f'tl.set("#{i} .ch",{{opacity:1}},{at:.3f});'
         f'tl.fromTo("#{i} .ch",{{x:0}},{{x:{sw},duration:.92,ease:"power2.inOut"}},{at:.3f});'
         f'tl.fromTo("#{i} .tx",{{clipPath:"inset(0 100% 0 0)"}},{{clipPath:"inset(0 0% 0 0)",duration:.92,ease:"power2.inOut"}},{at:.3f});'
         f'tl.to("#{i} .ch",{{opacity:0,duration:.25}},{at + .90:.3f});'
         f'tl.fromTo("#{i} .sb",{{opacity:0,y:12}},{{opacity:1,y:0,duration:.48,ease:"expo.out"}},{at + .68:.3f});')

def metricpair(b, t, d, box=(84, 310, 912, 560), title="", left=("TSER", 60, "%", "b"), right=("IRER", 66, "%", "p"), at=None, caption_="", _ghost=False):
    """[1.618 Hierarchy + Unified Odometer & Track] 두 핵심 광학 수치가 좌우 대칭으로 동시 카운트업"""
    x, y, w, h = box; at = t + .32 if at is None else at
    cols = ""
    for k, (lb, val, unit, g) in enumerate([left, right]):
        gc = "p" if g == "n" else g
        cols += (f'<div class="mp{k}" style="flex:1;padding:0 44px;border-left:{2 if k else 0}px solid #eef0f6;display:flex;flex-direction:column;justify-content:center">'
                 f'<div style="font-size:26px;font-weight:700;color:var(--gry)">{E(lb)}</div>'
                 f'<div class="tnum" style="font-weight:900;font-size:116px;line-height:1.08;margin:14px 0 22px">'
                 f'<span class="n gt g-{gc}">0</span><span class="gt g-{gc}" style="font-size:48px;margin-left:4px">{E(unit)}</span></div>'
                 f'<div style="width:100%;height:20px;border-radius:10px;background:var(--trk);overflow:hidden">'
                 f'<div class="br g-{gc}" style="width:0%;height:100%;border-radius:10px"></div></div></div>')
    cap = f'<div style="position:absolute;bottom:24px;width:100%;text-align:center;font-size:21px;color:#9aa0ae">{E(caption_)}</div>' if caption_ else ""
    i = b.clip(t, d,
               f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px">'
               f'<div class="tag" style="position:absolute;left:52px;top:40px;color:var(--b1)">{E(title)}</div>'
               f'<div style="position:absolute;left:0;right:0;top:96px;bottom:56px;display:flex">{cols}</div>{cap}</div>',
               f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, float_=False, ghost=_ghost)
    for k, (_, val, _, _) in enumerate([left, right]):
        tk = at + k * .22
        pct = min(100.0, float(val))
        dec = 0 if float(val).is_integer() else 1
        b.js(f'tl.to("#{i} .mp{k} .br",{{width:"{pct:.1f}%",duration:1.35,ease:"expo.out"}},{tk:.3f});'
             f'(function(){{const o={{v:0}};const el=document.querySelector("#{i} .mp{k} .n");tl.to(o,{{v:{val},duration:1.35,ease:"expo.out",onUpdate:()=>el.textContent=o.v.toFixed({dec})}},{tk:.3f});}})();')

def stacklist(b, t, d, box=(96, 305, 888, 590), pills=(), at=None, collapse_at=None, result="", g="bp"):
    """[Pill Stack → Unified Card Collapse] 복잡한 항목들이 쌓였다가 하나의 해결책 카드로 압축 변형"""
    x, y, w, h = box; at = t + .18 if at is None else at
    collapse_at = t + d * .56 if collapse_at is None else collapse_at
    n = max(1, len(pills))
    ph = min(96, int((h - 20 * (n - 1)) / n))
    tot_h = n * ph + (n - 1) * 18
    y_start = int((h - tot_h) / 2)
    cy = int(h / 2 - ph / 2)
    pl_html = ""
    for k, s in enumerate(pills):
        py = y_start + k * (ph + 18)
        pl_html += (f'<div class="card pl{k}" style="left:44px;top:{py}px;width:{w - 88}px;height:{ph}px;border-radius:{int(ph / 2)}px;padding:0 40px;display:flex;align-items:center;justify-content:space-between">'
                    f'<span style="font-weight:700;font-size:32px;color:var(--body)">{E(s)}</span>'
                    f'<span class="tnum" style="font-size:22px;font-weight:700;color:var(--lgt)">0{k + 1}</span></div>')
    res_fsz = min(56, max(38, int(740 / max(1, len(result)))))
    res_html = (f'<div class="card rs" style="left:0;top:{int(h / 2 - 135)}px;width:{w}px;height:270px;padding:40px;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;opacity:0;border:2px solid rgba(36,92,255,.22)">'
                f'<div class="tag" style="color:var(--b1);margin-bottom:14px">ALL-IN-ONE SOLUTION</div>'
                f'<div style="font-weight:900;font-size:{res_fsz}px;letter-spacing:-.04em">{gtext(result, g)}</div></div>')
    i = b.clip(t, d, pl_html + res_html, f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    for k in range(n):
        py = y_start + k * (ph + 18)
        b.js(f'tl.fromTo("#{i} .pl{k}",{{opacity:0,y:24,filter:"blur(6px)"}},{{opacity:1,y:0,filter:"blur(0px)",duration:.46,ease:"expo.out"}},{at + k * .14:.3f});')
        if result:
            b.js(f'tl.to("#{i} .pl{k}",{{y:{cy - py},scale:.90,opacity:0,filter:"blur(8px)",duration:.52,ease:"power3.inOut"}},{collapse_at:.3f});')
    if result:
        b.js(f'tl.fromTo("#{i} .rs",{{opacity:0,scale:.92,filter:"blur(10px)"}},{{opacity:1,scale:1,filter:"blur(0px)",duration:.62,ease:"expo.out"}},{collapse_at + .28:.3f});'
             f'tl.to("#{i} .rs",{{opacity:0,y:-16,duration:.28,ease:"power2.in"}},{t + d - .30:.3f});')
    else:
        b.js(f'tl.to("#{i}",{{opacity:0,y:-16,duration:.28,ease:"power2.in"}},{t + d - .30:.3f});')

# ───────── 타자기 · 센터 텍스트 · UI 패턴 부품 ─────────
_RND = "0123456789"
def _strip(ch, k, n=7):
    import random
    r = random.Random(hash((ch, k)) & 0xffff)
    if ch.isdigit(): pool = _RND
    elif "가" <= ch <= "힣": return [ch] * n + [ch]
    elif ch.isalpha(): return [ch] * n + [ch]
    else: return None
    return [r.choice(pool) for _ in range(n)] + [ch]

def roll_html(text, cls="rl"):
    out = []
    for k, ch in enumerate(text):
        st = _strip(ch, k)
        if st is None: out.append(f'<span class="{cls} fx" style="display:inline-block">{"&nbsp;" if ch == " " else E(ch)}</span>')
        else: out.append(f'<span class="{cls} cw" style="display:inline-block;height:1.08em;overflow:hidden;vertical-align:top"><span class="sx" style="display:block">' + "".join(f'<span style="display:block;height:1.08em;line-height:1.08em">{E(c)}</span>' for c in st) + '</span></span>')
    return "".join(out)

def roll_js(b, sel, t, stagger=.07, dur=.9):
    b.js(f'document.querySelectorAll("{sel} .cw").forEach((el,k)=>{{const s=el.querySelector(".sx");const n=s.children.length;tl.fromTo(s,{{yPercent:0,filter:"blur(7px)"}},{{yPercent:-100*(n-1)/n,filter:"blur(0px)",duration:{dur},ease:"expo.out"}},{t:.3f}+k*{stagger});}});'
         f'tl.fromTo("{sel} .fx",{{opacity:0}},{{opacity:1,duration:.3,stagger:{stagger}}},{t + .3:.3f});')

def rollstat(b, t, d, x, y, w, title, cols, at=None, theme="dark", size=150, label_size=26, gap=.35):
    at = t + .4 if at is None else at; col = "#14161c" if theme == "dark" else "#fff"; sub = "rgba(20,22,28,.55)" if theme == "dark" else "rgba(255,255,255,.72)"; ln = "rgba(20,22,28,.22)" if theme == "dark" else "rgba(255,255,255,.4)"
    cw = w / len(cols)
    cs = "".join(f'<div class="cl{k}" style="position:absolute;left:{k * cw:.0f}px;top:70px;width:{cw:.0f}px;height:{size * 1.5:.0f}px;{"border-left:2px solid " + ln + ";padding-left:28px" if k else ""}"><div class="lb" style="font-family:ST,PP,KR;font-weight:500;font-size:{label_size}px;letter-spacing:.18em;color:{sub}">{E(l)}</div><div class="vv tnum" style="font-family:ST,PP,KR;font-weight:400;font-size:{size}px;line-height:1.08;color:{col};white-space:nowrap;margin-top:6px">{roll_html(v)}</div></div>' for k, (l, v) in enumerate(cols))
    i = b.clip(t, d, f'<div class="tt" style="font-family:ST,PP,KR;font-weight:500;font-size:{label_size + 2}px;letter-spacing:.22em;color:{col};white-space:nowrap">{E(title)}</div><div class="hl" style="position:absolute;left:0;top:50px;width:{w}px;height:2px;background:{ln};transform-origin:left"></div>{cs}', f"left:{x}px;top:{y}px;width:{w}px;height:{size * 1.6 + 80:.0f}px")
    b.js(f'tl.fromTo("#{i} .tt",{{opacity:0,y:14}},{{opacity:1,y:0,duration:.5,ease:"expo.out"}},{t:.3f});tl.fromTo("#{i} .hl",{{scaleX:0}},{{scaleX:1,duration:.7,ease:"power2.inOut"}},{t + .1:.3f});tl.fromTo("#{i} .lb",{{opacity:0}},{{opacity:1,duration:.4,stagger:{gap}}},{at - .2:.3f});tl.to("#{i}",{{opacity:0,duration:.35}},{t + d - .37:.3f});')
    for k in range(len(cols)): roll_js(b, f"#{i} .cl{k}", at + k * gap)

def rolltext(b, t, d, x, y, text, size=110, theme="dark", label=None, align="left", w=940, mode="type", cps=14):
    col = "#14161c" if theme == "dark" else "#fff"; sub = "rgba(20,22,28,.55)" if theme == "dark" else "rgba(255,255,255,.72)"
    lb = f'<div class="lb" style="font-family:ST,PP,KR;font-size:26px;letter-spacing:.22em;color:{sub};margin-bottom:10px">{E(label)}</div>' if label else ""
    body = roll_html(text) if mode == "roll" else "".join(f'<span class="ch" style="display:none">{"&nbsp;" if c == " " else E(c)}</span>' for c in text)
    i = b.clip(t, d, f'<div style="text-align:{align}">{lb}<div style="font-family:ST,PP,KR;font-weight:400;font-size:{size}px;line-height:1.08;color:{col};white-space:nowrap">{body}</div></div>', f"left:{x}px;top:{y}px;width:{w}px")
    b.js(f'tl.fromTo("#{i} .lb",{{opacity:0}},{{opacity:1,duration:.3}},{t:.3f});tl.to("#{i}",{{opacity:0,duration:.35}},{t + d - .37:.3f});')
    if mode == "roll": roll_js(b, f"#{i}", t + .25, .06, .8)
    else: b.js(f'tl.to("#{i} .ch",{{display:"inline",duration:.01,stagger:{1 / cps:.4f}}},{t + .25:.3f});')

def type_clicks(items, cps=14):
    out = []
    for it in items:
        if it.get("p") != "rolltext" or it.get("mode", "type") != "type": continue
        t0 = it["t"] + .25; c = it.get("cps", cps)
        for k, ch in enumerate(it["text"]):
            if ch.strip(): out.append((round(t0 + k / c, 3), .11))
        out.append((round(t0 + len(it["text"]) / c + .12, 3), .18))
    return out

def click_wav(clicks, total, path):
    import numpy as np, wave, random
    SR = 44100; au = np.zeros(int(total * SR) + SR); rng = np.random.default_rng(5); m = int(.035 * SR); n = np.arange(m)
    for tc, g in clicks:
        x = rng.standard_normal(m) * np.exp(-n / (.004 * SR)) + .4 * np.sin(2 * np.pi * 1800 * n / SR) * np.exp(-n / (.002 * SR))
        i = int(tc * SR); au[i:i + m] += x * g * (.85 + .3 * random.random())
    au = np.clip(au[:int(total * SR)], -1, 1); w = wave.open(path, "wb"); w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((au * 30000).astype(np.int16).tobytes()); w.close()

def centertext(b, t, d, y, lines, size=40, theme="dark", hold_end=True):
    col = "#14161c" if theme == "dark" else "#fff"
    ln = "".join(f'<div class="e" style="font-weight:{900 if g in ("b","p","bp","k") else 700};font-size:{size * (1.55 if g in ("b","p","bp","k") else 1):.0f}px;color:{"var(--gry)" if g == "g" else col};margin-top:16px;letter-spacing:-.035em">{gtext(s, g) if g in ("b","p","bp","n") else E(s)}</div>' for s, g in lines)
    i = b.clip(t, d, f'<div style="text-align:center"><div class="e g-b" style="width:72px;height:6px;border-radius:3px;margin:0 auto 12px"></div>{ln}</div>', f"left:0;top:{y}px;width:1080px")
    b.js(f'tl.fromTo("#{i} .e",{{opacity:0,y:24,filter:"blur(6px)"}},{{opacity:1,y:0,filter:"blur(0px)",duration:.62,stagger:.13,ease:"expo.out"}},{t:.3f});')
    if not hold_end:
        b.js(f'tl.to("#{i}",{{opacity:0,duration:.35}},{t + d - .37:.3f});')

UICSS = r"""
.ui-dark{background:rgba(20,22,28,.94);color:#fff;backdrop-filter:blur(12px)}
.ui-pill{position:absolute;border-radius:999px;display:flex;align-items:center;gap:18px;padding:0 40px;font-weight:700}
.ui-field{position:absolute;background:#fff;border-radius:22px;border:2px solid #dfe3ec}
.ui-ico{display:inline-flex;align-items:center;justify-content:center;border-radius:50%;font-weight:900;flex:none}
.ui-btn{display:flex;align-items:center;justify-content:center;border-radius:22px;font-weight:700}
.ui-sk{background:linear-gradient(90deg,#eceef3 0%,#f6f7fa 40%,#eceef3 80%);background-size:300% 100%;border-radius:14px;position:absolute}
.ui-dim{position:absolute;left:0;top:0;width:1080px;height:1920px;background:rgba(20,22,30,.36)}
.ui-row{display:flex;align-items:center;justify-content:space-between}
"""

def _in(b, sel, t, d=.68, y=32, x=0, sc=None):
    s = f",scale:{sc}" if sc else ""; e = ",scale:1" if sc else ""
    b.js(f'tl.fromTo("{sel}",{{opacity:0,y:{y},x:{x}{s}}},{{opacity:1,y:0,x:0{e},duration:{d},ease:"expo.out"}},{t:.3f});')

def _out(b, sel, tend, d=.32, y=-16):
    b.js(f'tl.to("{sel}",{{opacity:0,y:{y},duration:{d},ease:"power2.in"}},{tend - d - .02:.3f});')

def _count(b, sel, v0, v1, at, dur=1.35, dec=0):
    b.js(f'(function(){{const o={{v:{v0}}};const el=document.querySelector("{sel}");tl.to(o,{{v:{v1},duration:{dur},ease:"expo.out",onUpdate:()=>el.textContent=o.v.toFixed({dec})}},{at:.3f});}})();')

def toast(b, t, d, text, icon="✓", y=420):
    i = b.clip(t, d, f'<div class="ui-pill ui-dark" style="left:50%;transform:translateX(-50%);top:0;height:96px;font-size:35px;white-space:nowrap;box-shadow:0 18px 40px rgba(20,22,30,.22)"><span class="ui-ico" style="width:44px;height:44px;background:var(--b1);font-size:24px">{E(icon)}</span>{E(text)}</div>', f"left:0;top:{y}px;width:1080px;height:120px")
    _in(b, f"#{i} .ui-pill", t, y=-60); _out(b, f"#{i} .ui-pill", t + d, y=-30)

def snackbar(b, t, d, text, action="보기", y=1180, at=None):
    at = t + d * .6 if at is None else at
    i = b.clip(t, d, f'<div class="sb ui-dark" style="position:absolute;left:72px;top:0;width:936px;height:116px;border-radius:24px;padding:0 44px;font-size:34px;font-weight:700"><div class="ui-row" style="height:100%"><span>{E(text)}</span><span class="act" style="color:#8fb0ff;padding:12px 22px;border-radius:16px">{E(action)}</span></div></div>', f"left:0;top:{y}px;width:1080px;height:130px")
    _in(b, f"#{i} .sb", t, y=80); _out(b, f"#{i} .sb", t + d, y=50)
    b.js(f'tl.to("#{i} .act",{{backgroundColor:"rgba(143,176,255,.22)",duration:.35,ease:"power2.out"}},{at:.3f});tl.to("#{i} .act",{{backgroundColor:"rgba(143,176,255,0)",duration:.5}},{at + .4:.3f});')

def banner(b, t, d, title, text, y=360, icon="i"):
    i = b.clip(t, d, f'<div class="card bn" style="left:72px;top:0;width:936px;height:190px;border-radius:30px;overflow:hidden"><div class="bl" style="position:absolute;left:0;top:0;width:10px;height:100%;background:linear-gradient(180deg,var(--b1),var(--b2));transform-origin:top"></div><div style="position:absolute;left:52px;top:46px;display:flex;gap:28px;align-items:flex-start"><span class="ui-ico" style="width:60px;height:60px;background:#e6ecff;color:var(--b1);font-size:32px">{E(icon)}</span><div><div style="font-weight:900;font-size:38px">{E(title)}</div><div style="font-size:29px;color:var(--gry);margin-top:10px">{E(text)}</div></div></div></div>', f"left:0;top:{y}px;width:1080px;height:200px")
    _in(b, f"#{i} .bn", t, y=-44); _out(b, f"#{i} .bn", t + d)
    b.js(f'tl.fromTo("#{i} .bl",{{scaleY:0}},{{scaleY:1,duration:.8,ease:"expo.out"}},{t + .22:.3f});')

def modal(b, t, d, title, body, ok="확인", cancel="닫기", at=None):
    at = t + d - 1.0 if at is None else at
    i = b.clip(t, d, f'<div class="ui-dim"></div><div class="card md" style="left:140px;top:640px;width:800px;padding:64px 60px 50px;border-radius:42px;text-align:center"><div style="font-weight:900;font-size:48px">{E(title)}</div><div style="font-size:31px;color:var(--gry);line-height:1.5;margin-top:22px">{E(body)}</div><div style="display:flex;gap:20px;margin-top:46px"><div class="ui-btn" style="flex:1;height:100px;background:#eff1f5;color:var(--gry);font-size:33px">{E(cancel)}</div><div class="ui-btn ok" style="flex:1;height:100px;background:linear-gradient(90deg,var(--b1),var(--b2));color:#fff;font-size:33px">{E(ok)}</div></div></div>', "left:0;top:0;width:1080px;height:1920px;z-index:10")
    b.js(f'tl.fromTo("#{i} .ui-dim",{{opacity:0}},{{opacity:1,duration:.5,ease:"power2.out"}},{t:.3f});tl.to("#{i} .ui-dim",{{opacity:0,duration:.4}},{t + d - .42:.3f});')
    _in(b, f"#{i} .md", t + .12, y=28, sc=.97); _out(b, f"#{i} .md", t + d, y=10)
    b.js(f'tl.to("#{i} .ok",{{scale:.96,duration:.16,ease:"power2.out"}},{at:.3f});tl.to("#{i} .ok",{{scale:1,duration:.28,ease:"expo.out"}},{at + .18:.3f});')

def bottomsheet(b, t, d, title, rows, top=980, stagger=.15):
    rh = "".join(f'<div class="r{k} ui-row" style="height:96px;border-top:1.5px solid #eceef3;font-size:34px"><span style="color:var(--gry)">{E(a)}</span><span style="font-weight:900">{E(v)}</span></div>' for k, (a, v) in enumerate(rows))
    h = 200 + 96 * len(rows) + 120
    i = b.clip(t, d, f'<div class="ui-dim"></div><div class="sh" style="position:absolute;left:0;top:{top}px;width:1080px;height:{h + 400}px;background:#fff;border-radius:46px 46px 0 0;box-shadow:0 -20px 60px rgba(40,50,80,.14);padding:30px 80px"><div style="width:84px;height:8px;border-radius:4px;background:#d7dbe3;margin:0 auto 44px"></div><div style="font-weight:900;font-size:44px;margin-bottom:26px">{E(title)}</div>{rh}</div>', "left:0;top:0;width:1080px;height:1920px;z-index:10")
    b.js(f'tl.fromTo("#{i} .ui-dim",{{opacity:0}},{{opacity:.65,duration:.5}},{t:.3f});tl.to("#{i} .ui-dim",{{opacity:0,duration:.4}},{t + d - .42:.3f});')
    b.js(f'tl.fromTo("#{i} .sh",{{y:860}},{{y:0,duration:.8,ease:"expo.out"}},{t:.3f});tl.to("#{i} .sh",{{y:860,duration:.45,ease:"power2.in"}},{t + d - .47:.3f});')
    for k in range(len(rows)): _in(b, f"#{i} .r{k}", t + .45 + stagger * k, d=.55, y=20)

def inlineerror(b, t, d, label, value, error, fixed=None, box=(140, 520, 800, 0), at=None, fix_at=None):
    x, y, w, _ = box; at = t + .85 if at is None else at; fix_at = at + 1.5 if fix_at is None else fix_at
    fx = f'<span class="fv" style="position:absolute;left:40px;top:62px;opacity:0;font-size:38px;font-weight:700">{E(fixed)}</span>' if fixed else ""
    i = b.clip(t, d, f'<div style="font-size:26px;color:var(--gry);font-weight:700;margin:0 0 14px 8px">{E(label)}</div><div class="ui-field fd" style="position:relative;width:{w}px;height:128px"><span class="v0" style="position:absolute;left:40px;top:38px;font-size:38px;font-weight:700">{E(value)}</span>{fx}<span class="ck ui-ico" style="position:absolute;right:34px;top:34px;width:58px;height:58px;background:var(--b1);color:#fff;font-size:30px;opacity:0">✓</span></div><div class="er" style="margin:16px 0 0 8px;font-size:26px;color:#7c4dff;font-weight:700;opacity:0">{E(error)}</div>', f"left:{x}px;top:{y}px;width:{w}px;height:300px")
    _in(b, f"#{i}", t); _out(b, f"#{i}", t + d)
    b.js(f'tl.to("#{i} .fd",{{borderColor:"#7c4dff",duration:.35}},{at:.3f});tl.fromTo("#{i} .er",{{opacity:0,y:-8}},{{opacity:1,y:0,duration:.45,ease:"expo.out"}},{at:.3f});')
    if fixed:
        b.js(f'tl.to("#{i} .v0",{{opacity:0,duration:.25}},{fix_at:.3f});tl.fromTo("#{i} .fv",{{opacity:0,y:10}},{{opacity:1,y:-24,duration:.48,ease:"expo.out"}},{fix_at + .18:.3f});tl.to("#{i} .fd",{{borderColor:"#245cff",duration:.35}},{fix_at + .18:.3f});tl.to("#{i} .er",{{opacity:0,duration:.25}},{fix_at:.3f});tl.fromTo("#{i} .ck",{{opacity:0,scale:.7}},{{opacity:1,scale:1,duration:.5,ease:"expo.out"}},{fix_at + .42:.3f});')

def tooltip(b, t, d, x, y, text, side="top", at=None):
    at = t + .45 if at is None else at; up = side == "top"
    tw = 44 + 29 * len(text)
    bx, by = max(40, min(1040 - tw, x - tw / 2)), (y - 148 if up else y + 48)
    ar = f'<i style="position:absolute;left:{x - bx - 14}px;{"bottom:-14px" if up else "top:-14px"};border-left:14px solid transparent;border-right:14px solid transparent;{"border-top" if up else "border-bottom"}:16px solid rgba(20,22,28,.94)"></i>'
    i = b.clip(t, d, f'<div class="dot" style="position:absolute;left:{x - 15}px;top:{y - 15}px;width:30px;height:30px;border-radius:50%;background:var(--b1)"></div><div class="rp" style="position:absolute;left:{x - 15}px;top:{y - 15}px;width:30px;height:30px;border-radius:50%;border:2.5px solid var(--b1)"></div><div class="tt ui-dark" style="position:absolute;left:{bx}px;top:{by}px;width:{tw}px;height:96px;border-radius:22px;display:flex;align-items:center;justify-content:center;font-size:32px;font-weight:700">{E(text)}{ar}</div>', "left:0;top:0;width:1080px;height:1920px")
    _in(b, f"#{i} .dot", t, y=0, sc=.5); _out(b, f"#{i} .dot", t + d, y=0)
    b.js(f'tl.fromTo("#{i} .rp",{{scale:1,opacity:.75}},{{scale:3.0,opacity:0,duration:1.6,ease:"power2.out",repeat:{max(0, int(d / 1.6) - 1)}}},{t + .2:.3f});')
    _in(b, f"#{i} .tt", at, y=(16 if up else -16)); _out(b, f"#{i} .tt", t + d, y=0)

def coachmark(b, t, d, cx, cy, r, title, text, step="1 / 3", card_y=None):
    card_y = cy + r + 60 if card_y is None else card_y
    i = b.clip(t, d, f'<div class="sp" style="position:absolute;left:{cx - r}px;top:{cy - r}px;width:{2 * r}px;height:{2 * r}px;border-radius:50%;box-shadow:0 0 0 2400px rgba(14,16,24,.58);border:3px solid rgba(255,255,255,.9)"></div><div class="cm card" style="left:110px;top:{card_y}px;width:860px;padding:44px 50px;border-radius:36px"><div class="tag" style="color:var(--b1)">{E(step)}</div><div style="font-weight:900;font-size:42px;margin-top:10px">{E(title)}</div><div style="font-size:29px;color:var(--gry);margin-top:12px;line-height:1.5">{E(text)}</div></div>', "left:0;top:0;width:1080px;height:1920px;z-index:10")
    b.js(f'tl.fromTo("#{i} .sp",{{opacity:0,scale:2.2}},{{opacity:1,scale:1,duration:.9,ease:"expo.out"}},{t:.3f});tl.to("#{i} .sp",{{scale:1.05,duration:1.4,yoyo:true,repeat:{max(1, int(d / 1.4) - 2)},ease:"sine.inOut"}},{t + .9:.3f});tl.to("#{i} .sp",{{opacity:0,duration:.4}},{t + d - .42:.3f});')
    _in(b, f"#{i} .cm", t + .4); _out(b, f"#{i} .cm", t + d)

def badge(b, t, d, x, y, text="NEW", count=None, at=None):
    at = t if at is None else at
    inner = f'<span class="n">0</span>' if count is not None else E(text)
    i = b.clip(t, d, f'<div class="bg" style="position:absolute;left:0;top:0;height:62px;min-width:62px;padding:0 22px;border-radius:31px;background:linear-gradient(90deg,var(--b1),var(--b2));color:#fff;font-weight:900;font-size:30px;display:flex;align-items:center;justify-content:center;box-shadow:0 10px 24px rgba(36,92,255,.28)">{inner}</div>', f"left:{x}px;top:{y}px;width:300px;height:80px")
    _in(b, f"#{i} .bg", at, y=0, sc=.6); _out(b, f"#{i} .bg", t + d, y=0)
    if count is not None: _count(b, f"#{i} .n", 0, count, at + .18, 1.0)

def spinner(b, t, d, label="분석 중", y=640, done=None, done_at=None):
    done_at = t + d - 1.4 if done_at is None else done_at
    dn = f'<div class="dn" style="position:absolute;top:0;left:0;width:100%;text-align:center;opacity:0"><span class="ui-ico" style="width:144px;height:144px;background:linear-gradient(135deg,var(--b1),var(--b2));color:#fff;font-size:74px">✓</span><div style="font-weight:900;font-size:42px;margin-top:38px">{E(done)}</div></div>' if done else ""
    i = b.clip(t, d, f'<div class="sp" style="position:absolute;left:468px;top:0;width:144px;height:144px;border-radius:50%;border:11px solid #e7eaf1;border-top-color:var(--b1);border-right-color:var(--b2)"></div><div class="lb" style="position:absolute;top:186px;width:100%;text-align:center;font-weight:700;font-size:36px;color:var(--gry)">{E(label)}<span class="d1">.</span><span class="d2">.</span><span class="d3">.</span></div>{dn}', f"left:0;top:{y}px;width:1080px;height:340px")
    _in(b, f"#{i} .sp", t, y=0, sc=.75); _in(b, f"#{i} .lb", t + .18, y=14)
    b.js(f'tl.to("#{i} .sp",{{rotation:360*{max(1, int(d / .9))},duration:{d},ease:"none"}},{t:.3f});')
    for k in (1, 2, 3): b.js(f'tl.fromTo("#{i} .d{k}",{{opacity:.15}},{{opacity:1,duration:.4,yoyo:true,repeat:{max(1, int(d / .8))},ease:"sine.inOut"}},{t + .15 * k:.3f});')
    if done:
        b.js(f'tl.to(["#{i} .sp","#{i} .lb"],{{opacity:0,duration:.35}},{done_at:.3f});tl.fromTo("#{i} .dn",{{opacity:0,y:18}},{{opacity:1,y:0,duration:.65,ease:"expo.out"}},{done_at + .25:.3f});')
    _out(b, f"#{i}", t + d)

def skeleton(b, t, d, box, title, lines, at=None, img=True, _ghost=False):
    x, y, w, h = box; at = t + 1.3 if at is None else at
    sk = (f'<div class="ui-sk" style="left:40px;top:40px;width:{w - 80}px;height:{h * .42:.0f}px;border-radius:26px"></div>' if img else "") + "".join(
        f'<div class="ui-sk" style="left:40px;top:{(h * .42 + 80 if img else 50) + k * 62:.0f}px;width:{(w - 80) * (0.9 if k == 0 else 0.7 - 0.12 * (k % 2)):.0f}px;height:{38 if k == 0 else 28}px"></div>' for k in range(len(lines) + 1))
    ct = (f'<div style="position:absolute;left:40px;top:40px;width:{w - 80}px;height:{h * .42:.0f}px;border-radius:26px;background:linear-gradient(135deg,#e6ecff,#efe6ff)"></div>' if img else "") + f'<div style="position:absolute;left:40px;top:{h * .42 + 70 if img else 44:.0f}px;width:{w - 80}px"><div style="font-weight:900;font-size:42px">{E(title)}</div>' + "".join(f'<div style="font-size:29px;color:var(--gry);margin-top:14px">{E(s)}</div>' for s in lines) + "</div>"
    i = b.clip(t, d, f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px;overflow:hidden"><div class="sk">{sk}</div><div class="ct" style="opacity:0">{ct}</div></div>', f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, float_=False, ghost=_ghost)
    b.js(f'tl.fromTo("#{i} .ui-sk",{{backgroundPosition:"100% 0"}},{{backgroundPosition:"-100% 0",duration:1.1,repeat:{max(1, int((at - t) / 1.1))},ease:"none"}},{t:.3f});tl.to("#{i} .sk",{{opacity:0,duration:.45}},{at:.3f});tl.fromTo("#{i} .ct",{{opacity:0,y:12}},{{opacity:1,y:0,duration:.6,ease:"expo.out"}},{at + .12:.3f});')

def progress(b, t, d, box, label, pct=100, steps=None, at=None, dur=2.2, _ghost=False):
    x, y, w, h = box; at = t + .35 if at is None else at
    st = ""
    if steps:
        st = f'<div style="position:absolute;left:52px;top:198px;width:{w - 104}px;display:flex;justify-content:space-between">' + "".join(f'<div class="s{k}" style="text-align:center;font-size:27px;font-weight:700;color:var(--lgt)"><div class="sd" style="width:24px;height:24px;border-radius:50%;background:#e3e6ee;margin:0 auto 14px"></div>{E(s)}</div>' for k, s in enumerate(steps)) + "</div>"
    i = b.clip(t, d, f'<div class="card {"ghost" if _ghost else ""}" style="left:0;top:0;width:{w}px;height:{h}px"><div class="ui-row" style="position:absolute;left:52px;top:44px;width:{w - 104}px"><span class="tag">{E(label)}</span><span style="font-weight:900;font-size:50px" class="gt g-b tnum"><span class="n">0</span>%</span></div><div style="position:absolute;left:52px;top:128px;width:{w - 104}px;height:18px;border-radius:9px;background:var(--trk);overflow:hidden"><div class="fl" style="width:0%;height:100%;border-radius:9px;background:linear-gradient(90deg,var(--b1),var(--b2))"></div></div>{st}</div>', f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, float_=False, ghost=_ghost)
    b.js(f'tl.to("#{i} .fl",{{width:"{pct:.1f}%",duration:{dur},ease:"expo.out"}},{at:.3f});'); _count(b, f"#{i} .n", 0, pct, at, dur)
    if steps:
        for k in range(len(steps)):
            tk = at + dur * (k + .4) / len(steps)
            b.js(f'tl.to("#{i} .s{k}",{{color:"#14161c",duration:.35}},{tk:.3f});tl.to("#{i} .s{k} .sd",{{backgroundColor:"#245cff",scale:1.15,duration:.45,ease:"expo.out"}},{tk:.3f});')

def inputfield(b, t, d, box, label, text, cps=12, at=None, ok=True):
    x, y, w, _ = box; at = t + .55 if at is None else at
    i = b.clip(t, d, f'<div class="ui-field fd" style="left:0;top:0;width:{w}px;height:148px"><span class="lb" style="position:absolute;left:40px;top:50px;font-size:36px;color:var(--gry);transform-origin:left top">{E(label)}</span><span class="tx" style="position:absolute;left:40px;top:68px;font-size:40px;font-weight:700"></span><span class="cu" style="position:absolute;top:70px;width:3.5px;height:46px;background:var(--b1);opacity:0"></span><span class="ck ui-ico" style="position:absolute;right:36px;top:44px;width:60px;height:60px;background:var(--b1);color:#fff;font-size:30px;opacity:0">✓</span></div>', f"left:{x}px;top:{y}px;width:{w}px;height:160px")
    _in(b, f"#{i} .fd", t); _out(b, f"#{i} .fd", t + d)
    b.js(f'tl.to("#{i} .fd",{{borderColor:"#245cff",boxShadow:"0 0 0 8px rgba(36,92,255,.10)",duration:.35}},{at:.3f});tl.to("#{i} .lb",{{y:-32,scale:.68,color:"#245cff",duration:.45,ease:"expo.out"}},{at:.3f});tl.to("#{i} .cu",{{opacity:1,duration:.2}},{at + .25:.3f});')
    s = json.dumps(text, ensure_ascii=False); T = len(text) / cps
    b.js(f'(function(){{const o={{n:0}};const el=document.querySelector("#{i} .tx");const cu=document.querySelector("#{i} .cu");const s={s};tl.to(o,{{n:s.length,duration:{T:.2f},ease:"none",onUpdate:()=>{{el.textContent=s.slice(0,Math.round(o.n));cu.style.left=(44+el.offsetWidth)+"px";}}}},{at + .45:.3f});}})();')
    if ok: b.js(f'tl.to("#{i} .cu",{{opacity:0,duration:.2}},{at + .55 + T:.3f});tl.fromTo("#{i} .ck",{{opacity:0,scale:.65}},{{opacity:1,scale:1,duration:.5,ease:"expo.out"}},{at + .65 + T:.3f});')

def toggles(b, t, d, box, items, title=None):
    x, y, w, _ = box; th = f'<div class="tag" style="padding:40px 50px 10px">{E(title)}</div>' if title else ""
    rows = "".join(f'<div class="ui-row" style="height:118px;padding:0 50px;border-top:{0 if k == 0 and not title else 1.5}px solid #eceef3;font-size:35px;font-weight:700"><span>{E(a)}</span><span class="tg{k}" style="position:relative;width:116px;height:66px;border-radius:33px;background:#dfe2ea"><i class="kn" style="position:absolute;left:6px;top:6px;width:54px;height:54px;border-radius:50%;background:#fff;box-shadow:0 4px 10px rgba(0,0,0,.14)"></i></span></div>' for k, (a, _) in enumerate(items))
    h = (90 if title else 0) + 118 * len(items) + 20
    i = b.clip(t, d, f'<div class="card" style="left:0;top:0;width:{w}px;height:{h}px">{th}{rows}</div>', f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    _in(b, f"#{i} .card", t); _out(b, f"#{i} .card", t + d)
    for k, (_, tk) in enumerate(items):
        b.js(f'tl.to("#{i} .tg{k}",{{backgroundColor:"#245cff",duration:.42,ease:"expo.out"}},{tk:.3f});tl.to("#{i} .tg{k} .kn",{{x:50,duration:.42,ease:"expo.out"}},{tk:.3f});')

def segmented(b, t, d, options, seq, y=520, w=900):
    n = len(options); cw = (w - 20) / n
    opts = "".join(f'<div class="o{k}" style="position:absolute;left:{10 + k * cw:.0f}px;top:10px;width:{cw:.0f}px;height:100px;display:flex;align-items:center;justify-content:center;font-size:33px;font-weight:700;color:var(--gry)">{E(o)}</div>' for k, o in enumerate(options))
    i = b.clip(t, d, f'<div class="sg" style="position:absolute;left:{(1080 - w) / 2:.0f}px;top:0;width:{w}px;height:120px;border-radius:60px;background:#e9ecf2"><div class="ind" style="position:absolute;left:10px;top:10px;width:{cw:.0f}px;height:100px;border-radius:50px;background:#fff;box-shadow:0 8px 20px rgba(40,50,80,.12)"></div>{opts}</div>', f"left:0;top:{y}px;width:1080px;height:130px")
    _in(b, f"#{i} .sg", t); _out(b, f"#{i} .sg", t + d)
    k0 = seq[0][0] if seq else 0
    b.js(f'tl.set("#{i} .ind",{{x:{k0 * cw:.0f}}},{t:.3f});tl.set("#{i} .o{k0}",{{color:"#245cff"}},{t:.3f});')
    prev = k0
    for k, tk in seq[1:]:
        b.js(f'tl.to("#{i} .ind",{{x:{k * cw:.0f},duration:.55,ease:"expo.out"}},{tk:.3f});tl.to("#{i} .o{prev}",{{color:"#727785",duration:.35}},{tk:.3f});tl.to("#{i} .o{k}",{{color:"#245cff",duration:.35}},{tk + .15:.3f});'); prev = k

def rangeslider(b, t, d, box, label, vmin, vmax, value, unit="", at=None, start=None):
    x, y, w, _ = box; at = t + .45 if at is None else at; start = vmin if start is None else start
    L = w - 120; p0 = (start - vmin) / (vmax - vmin); p1 = (value - vmin) / (vmax - vmin)
    i = b.clip(t, d, f'<div class="card" style="left:0;top:0;width:{w}px;height:280px"><div class="ui-row" style="position:absolute;left:60px;top:46px;width:{L}px"><span class="tag">{E(label)}</span><span style="font-weight:900;font-size:58px" class="gt g-b tnum"><span class="n">{start}</span>{E(unit)}</span></div><div style="position:absolute;left:60px;top:176px;width:{L}px;height:14px;border-radius:7px;background:var(--trk)"><div class="fl" style="width:{p0 * 100:.1f}%;height:100%;border-radius:7px;background:linear-gradient(90deg,var(--b1),var(--b2))"></div><div class="kb" style="position:absolute;left:-28px;top:-21px;width:56px;height:56px;border-radius:50%;background:#fff;border:4px solid var(--b1);box-shadow:0 6px 16px rgba(36,92,255,.26);transform:translateX({p0 * L:.0f}px)"></div></div><div class="ui-row tnum" style="position:absolute;left:60px;top:214px;width:{L}px;font-size:23px;color:var(--lgt);font-weight:700"><span>{vmin}{E(unit)}</span><span>{vmax}{E(unit)}</span></div></div>', f"left:{x}px;top:{y}px;width:{w}px;height:290px")
    _in(b, f"#{i} .card", t); _out(b, f"#{i} .card", t + d)
    b.js(f'tl.to("#{i} .fl",{{width:"{p1 * 100:.1f}%",duration:1.45,ease:"expo.out"}},{at:.3f});tl.to("#{i} .kb",{{x:{p1 * L:.0f},duration:1.45,ease:"expo.out"}},{at:.3f});'); _count(b, f"#{i} .n", start, value, at, 1.45)

def chat(b, t, d, msgs, top=380, cps=22):
    y = 0; html = ""; js = []
    for k, (who, txt, tk) in enumerate(msgs):
        me = who == "user"; lines = max(1, int(len(txt) / 15) + 1); hgt = 60 + 52 * lines
        st = "right:72px;background:linear-gradient(90deg,var(--b1),var(--b2));color:#fff;border-radius:38px 38px 10px 38px" if me else "left:72px;background:#fff;color:var(--ink);border-radius:38px 38px 38px 10px;box-shadow:0 14px 34px rgba(40,50,80,.10)"
        av = "" if me else f'<div class="av{k} tag" style="position:absolute;left:76px;top:{y}px;font-size:21px;color:var(--b1)">AI</div>'
        yy = y + (0 if me else 38)
        html += av + f'<div class="m{k}" style="position:absolute;top:{yy}px;{st};max-width:760px;padding:28px 38px;font-size:35px;font-weight:700;line-height:1.45"><span class="tx">{"" if not me else E(txt)}</span>' + ("" if me else '<span class="dots" style="letter-spacing:8px">● ● ●</span>') + "</div>"
        _in(b, f"#__ID__ .m{k}", tk, d=.55, y=22)
        if not me:
            _in(b, f"#__ID__ .av{k}", tk, d=.45, y=8)
            js.append((k, txt, tk))
        y = yy + hgt + 32
    i = b.clip(t, d, html, f"left:0;top:{top}px;width:1080px;height:{y + 40}px")
    b.j = [s.replace("__ID__", i) for s in b.j]
    for k, txt, tk in js:
        s = json.dumps(txt, ensure_ascii=False); T = len(txt) / cps
        b.js(f'tl.fromTo("#{i} .m{k} .dots",{{opacity:.25}},{{opacity:1,duration:.38,yoyo:true,repeat:3,ease:"sine.inOut"}},{tk + .1:.3f});tl.to("#{i} .m{k} .dots",{{opacity:0,duration:.01}},{tk + 1.2:.3f});tl.set("#{i} .m{k} .dots",{{display:"none"}},{tk + 1.22:.3f});')
        b.js(f'(function(){{const o={{n:0}};const el=document.querySelector("#{i} .m{k} .tx");const s={s};tl.to(o,{{n:s.length,duration:{T:.2f},ease:"none",onUpdate:()=>el.textContent=s.slice(0,Math.round(o.n))}},{tk + 1.25:.3f});}})();')
    _out(b, f"#{i}", t + d)

def emptystate(b, t, d, title, sub, btn=None, y=560, icon="⌕"):
    bt = f'<div class="bt ui-btn" style="margin:44px auto 0;width:400px;height:104px;background:linear-gradient(90deg,var(--b1),var(--b2));color:#fff;font-size:34px">{E(btn)}</div>' if btn else ""
    i = b.clip(t, d, f'<div class="ic ui-ico" style="display:flex;margin:0 auto;width:210px;height:210px;background:#eef1f7;color:#a9b0c0;font-size:112px">{E(icon)}</div><div class="t1" style="text-align:center;font-weight:900;font-size:48px;margin-top:46px">{E(title)}</div><div class="t2" style="text-align:center;font-size:31px;color:var(--gry);margin-top:16px;line-height:1.5">{E(sub)}</div>{bt}', f"left:0;top:{y}px;width:1080px;height:700px")
    _in(b, f"#{i} .ic", t, y=20, sc=.9); _in(b, f"#{i} .t1", t + .24); _in(b, f"#{i} .t2", t + .4)
    if btn: _in(b, f"#{i} .bt", t + .65)
    b.js(f'tl.to("#{i} .ic",{{y:-6,duration:2.2,yoyo:true,repeat:{max(1, int(d / 2.2))},ease:"sine.inOut"}},{t + .8:.3f});'); _out(b, f"#{i}", t + d)

def tap(b, t, d, x, y, at=None, n=1):
    at = t if at is None else at
    i = b.clip(t, d, f'<div class="f" style="position:absolute;left:-38px;top:-38px;width:76px;height:76px;border-radius:50%;background:rgba(36,92,255,.26);border:3px solid rgba(255,255,255,.9)"></div><div class="w" style="position:absolute;left:-38px;top:-38px;width:76px;height:76px;border-radius:50%;border:2.5px solid var(--b1)"></div>', f"left:{x}px;top:{y}px;width:1px;height:1px")
    for k in range(n):
        tk = at + k * .85
        b.js(f'tl.fromTo("#{i} .f",{{opacity:0,scale:1.25}},{{opacity:1,scale:.88,duration:.28,ease:"expo.out"}},{tk:.3f});tl.to("#{i} .f",{{opacity:0,scale:1,duration:.38}},{tk + .42:.3f});tl.fromTo("#{i} .w",{{opacity:.85,scale:.8}},{{opacity:0,scale:2.7,duration:.85,ease:"expo.out"}},{tk + .08:.3f});')

def swipecards(b, t, d, cards, y=420, h=560, dwell=1.6):
    n = len(cards)
    html = "".join(f'<div class="cd{k} card" style="left:140px;top:{k * 20}px;width:800px;height:{h}px;z-index:{n - k};padding:58px;transform:scale({1 - .045 * k})"><div class="tag">{k + 1:02d} / {n:02d}</div><div style="font-weight:900;font-size:54px;margin-top:28px">{gtext(a, "b")}</div><div style="font-size:31px;color:var(--gry);margin-top:22px;line-height:1.5">{E(s)}</div></div>' for k, (a, s) in enumerate(cards))
    i = b.clip(t, d, html, f"left:0;top:{y}px;width:1080px;height:{h + 120}px")
    _in(b, f"#{i}", t); _out(b, f"#{i}", t + d)
    for k in range(n - 1):
        tk = t + .8 + dwell * (k + 1) - .6
        b.js(f'tl.to("#{i} .cd{k}",{{x:-1100,rotation:-11,opacity:0,duration:.75,ease:"power3.in"}},{tk:.3f});')
        for j in range(k + 1, n): b.js(f'tl.to("#{i} .cd{j}",{{y:{-20 * (k + 1)},scale:{1 - .045 * (j - k - 1)},duration:.65,ease:"expo.out"}},{tk + .25:.3f});')

def tabbar(b, t, d, tabs, seq, y=1170, icons=None):
    n = len(tabs); w = 936; cw = w / n; icons = icons or ["●"] * n
    opts = "".join(f'<div class="o{k}" style="position:absolute;left:{k * cw:.0f}px;top:0;width:{cw:.0f}px;height:146px;text-align:center;color:var(--lgt);font-weight:700;font-size:25px;padding-top:28px"><div style="font-size:38px;margin-bottom:10px">{E(icons[k])}</div>{E(tb)}</div>' for k, tb in enumerate(tabs))
    i = b.clip(t, d, f'<div class="tb card" style="left:72px;top:0;width:{w}px;height:146px;border-radius:42px"><div class="ind" style="position:absolute;left:{cw / 2 - 28:.0f}px;top:0;width:56px;height:5px;border-radius:3px;background:var(--b1)"></div>{opts}</div>', f"left:0;top:{y}px;width:1080px;height:166px")
    _in(b, f"#{i} .tb", t, y=54); _out(b, f"#{i} .tb", t + d, y=36)
    k0 = seq[0][0] if seq else 0
    b.js(f'tl.set("#{i} .ind",{{x:{k0 * cw:.0f}}},{t:.3f});tl.set("#{i} .o{k0}",{{color:"#245cff"}},{t:.3f});'); prev = k0
    for k, tk in seq[1:]:
        b.js(f'tl.to("#{i} .ind",{{x:{k * cw:.0f},duration:.55,ease:"expo.out"}},{tk:.3f});tl.to("#{i} .o{prev}",{{color:"#c5cad6",duration:.35}},{tk:.3f});tl.to("#{i} .o{k}",{{color:"#245cff",duration:.35}},{tk + .15:.3f});'); prev = k

def carousel(b, t, d, box, slides, dwell=1.8):
    x, y, w, h = box; n = len(slides)
    sl = ""
    for k, (a, s, img) in enumerate(slides):
        top = f'<div style="height:{h * .55:.0f}px;border-radius:28px;overflow:hidden;background:linear-gradient(135deg,#e6ecff,#efe6ff)">' + (f'<img src="assets/{img}" style="width:100%;height:100%;object-fit:cover">' if img else "") + "</div>"
        sl += f'<div class="card" style="left:{k * (w + 40)}px;top:0;width:{w}px;height:{h}px;padding:30px">{top}<div style="font-weight:900;font-size:44px;margin-top:32px">{E(a)}</div><div style="font-size:29px;color:var(--gry);margin-top:12px">{E(s)}</div></div>'
    dots = "".join(f'<i class="dt{k}" style="display:inline-block;width:14px;height:14px;border-radius:7px;margin:0 7px;background:{"#245cff" if k == 0 else "#d5d9e2"}"></i>' for k in range(n))
    i = b.clip(t, d, f'<div class="tr" style="position:absolute;left:40px;top:40px;width:{n * (w + 40)}px;height:{h}px">{sl}</div><div style="position:absolute;left:40px;top:{h + 68}px;width:{w}px;text-align:center">{dots}</div>', f"left:{x - 40}px;top:{y - 40}px;width:{w + 80}px;height:{h + 140}px;overflow:hidden;padding:40px")
    _in(b, f"#{i}", t); _out(b, f"#{i}", t + d)
    for k in range(1, n):
        tk = t + .8 + dwell * k - .6
        b.js(f'tl.to("#{i} .tr",{{x:{-k * (w + 40)},duration:.75,ease:"power3.inOut"}},{tk:.3f});tl.to("#{i} .dt{k - 1}",{{backgroundColor:"#d5d9e2",width:14,duration:.35}},{tk:.3f});tl.to("#{i} .dt{k}",{{backgroundColor:"#245cff",width:38,duration:.45}},{tk + .18:.3f});')
    b.js(f'tl.set("#{i} .dt0",{{width:38}},{t:.3f});')

def dropdown(b, t, d, box, label, options, pick, at=None):
    x, y, w, _ = box; at = t + .45 if at is None else at; n = len(options)
    li = "".join(f'<div class="li{k} ui-row" style="height:98px;padding:0 44px;font-size:33px;font-weight:700;color:var(--ink)"><span>{E(o)}</span><span class="tk" style="color:var(--b1);opacity:0">✓</span></div>' for k, o in enumerate(options))
    i = b.clip(t, d, f'<div style="font-size:26px;color:var(--gry);font-weight:700;margin:0 0 14px 8px">{E(label)}</div><div class="ui-field fd" style="position:relative;width:{w}px;height:118px;display:flex;align-items:center;padding:0 44px;font-size:36px;font-weight:700"><span class="vl" style="color:var(--lgt)">선택</span><span class="cv" style="position:absolute;right:44px;font-size:28px;color:var(--gry)">▼</span></div><div class="ls card" style="position:relative;left:0;top:14px;width:{w}px;border-radius:26px;overflow:hidden;transform-origin:top;padding:10px 0">{li}</div>', f"left:{x}px;top:{y}px;width:{w}px;height:{200 + 98 * n}px")
    _in(b, f"#{i}", t); _out(b, f"#{i}", t + d)
    b.js(f'tl.set("#{i} .ls",{{opacity:0,scaleY:.92}},{t:.3f});tl.to("#{i} .fd",{{borderColor:"#245cff",duration:.3}},{at:.3f});tl.to("#{i} .cv",{{rotation:180,duration:.38}},{at:.3f});tl.to("#{i} .ls",{{opacity:1,scaleY:1,duration:.48,ease:"expo.out"}},{at + .08:.3f});')
    hk = at + .65
    b.js(f'tl.to("#{i} .li{pick}",{{backgroundColor:"#eef2ff",duration:.32}},{hk:.3f});tl.to("#{i} .li{pick} .tk",{{opacity:1,duration:.28}},{hk + .18:.3f});')
    s = json.dumps(options[pick], ensure_ascii=False)
    b.js(f'tl.to("#{i} .ls",{{opacity:0,scaleY:.94,duration:.36,ease:"power2.in"}},{hk + .75:.3f});tl.to("#{i} .cv",{{rotation:0,duration:.36}},{hk + .75:.3f});tl.to("#{i} .vl",{{opacity:0,duration:.14}},{hk + .84:.3f});(function(){{const el=document.querySelector("#{i} .vl");tl.set(el,{{textContent:{s},color:"#14161c"}},{hk + .98:.3f});}})();tl.to("#{i} .vl",{{opacity:1,duration:.28}},{hk + 1.0:.3f});')


# ───────── 그림 부품 (2026-11-25 · 장면마다 다른 그림이 나오도록) ─────────
# 예전에 장면마다 직접 그리던 개념도(보온병 · 온도 곡선 · 필름 단면 · 파장 곡선 · 차량 평면도 · 열 흐름 · 세로 막대 · 게이지 · 도넛)를 부품으로.
# 색: 블루(#245cff) · 보라(#7c4dff) · 무채색만. 모든 선은 서서히 그려지고 숫자는 0부터 올라간다.
def _plen(P):
    return sum(((P[k][0] - P[k - 1][0]) ** 2 + (P[k][1] - P[k - 1][1]) ** 2) ** .5 for k in range(1, len(P)))

def _path(P):
    return "M%.1f %.1f " % P[0] + " ".join("L%.1f %.1f" % p for p in P[1:])

def _icard(b, t, d, box, svg, tag="", title="", extra=""):
    x, y, w, h = box
    hd = (f'<div class="tag" style="position:absolute;left:54px;top:38px;color:var(--b1)">{E(tag)}</div>' if tag else "") + \
         (f'<div style="position:absolute;left:54px;top:{70 if tag else 40}px;font-weight:900;font-size:36px;letter-spacing:-.035em">{E(title)}</div>' if title else "")
    i = b.clip(t, d, f'<div class="card" style="left:0;top:0;width:{w}px;height:{h}px;overflow:hidden">{svg}{hd}{extra}</div>', f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, float_=False)
    return i

_ARROW = '<marker id="{id}" viewBox="0 0 10 10" refX="7" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" fill="{c}"/></marker>'

def _draw(b, sel, L, at, dur=.9, ease="power2.inOut"):
    b.js(f'tl.fromTo("{sel}",{{strokeDashoffset:{L:.0f}}},{{strokeDashoffset:0,duration:{dur},ease:"{ease}"}},{at:.3f});')

def thermos(b, t, d, box=(84, 300, 912, 640), mode="winter", tag="THERMOS PRINCIPLE", title="", inside="실내 온기", outside="바깥 냉기", note="", at=None):
    """보온병 단면: 안쪽 금속 코팅이 열을 되돌려 보낸다. mode=winter(안의 온기가 밖으로 못 나감) · summer(밖의 열기가 안으로 못 들어옴)"""
    x, y, w, h = box; at = t + .5 if at is None else at
    cx = w / 2; top = 150; bot = h - 60; bw = 230
    mk = b.id("mk"); mk2 = b.id("mk")
    body = (f'<rect x="{cx - bw / 2}" y="{top + 40}" width="{bw}" height="{bot - top - 40}" rx="46" fill="#f6f8fc" stroke="#c9cfdc" stroke-width="4"/>'
            f'<rect class="mt" x="{cx - bw / 2 + 18}" y="{top + 58}" width="{bw - 36}" height="{bot - top - 76}" rx="34" fill="none" stroke="url(#{mk}g)" stroke-width="9" stroke-dasharray="2000" stroke-dashoffset="2000"/>'
            f'<rect x="{cx - 70}" y="{top}" width="140" height="48" rx="14" fill="#dfe4ee"/>')
    arrows = []; L = 0
    for k in range(3):
        yy = top + 120 + k * (bot - top - 200) / 2
        if mode == "winter":
            for s in (-1, 1):
                P = [(cx + s * 30, yy), (cx + s * (bw / 2 - 26), yy + 18), (cx + s * 40, yy + 46)]
                arrows.append((P, "#7c4dff"))
        else:
            for s in (-1, 1):
                P = [(cx + s * (bw / 2 + 170), yy - 10), (cx + s * (bw / 2 + 4), yy + 12), (cx + s * (bw / 2 + 150), yy + 46)]
                arrows.append((P, "#7c4dff"))
    asvg = ""
    for n, (P, c) in enumerate(arrows):
        Ln = _plen(P) + 10; L = max(L, Ln)
        asvg += f'<path class="ar{n}" d="{_path(P)}" fill="none" stroke="{c}" stroke-width="5" stroke-linecap="round" stroke-linejoin="round" marker-end="url(#{mk2})" stroke-dasharray="{Ln:.0f}" stroke-dashoffset="{Ln:.0f}"/>'
    glow = f'<circle class="gw" cx="{cx}" cy="{(top + bot) / 2 + 20}" r="{bw / 2 - 40}" fill="url(#{mk}r)" opacity="0"/>' if mode == "winter" else ""
    svg = (f'<svg width="{w}" height="{h}" style="position:absolute;left:0;top:0"><defs>'
           f'<linearGradient id="{mk}g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#9fb4e8"/><stop offset=".5" stop-color="#245cff"/><stop offset="1" stop-color="#b9c6ea"/></linearGradient>'
           f'<radialGradient id="{mk}r"><stop offset="0" stop-color="#7c4dff" stop-opacity=".22"/><stop offset="1" stop-color="#7c4dff" stop-opacity="0"/></radialGradient>'
           + _ARROW.format(id=mk2, c="#7c4dff") + f'</defs>{glow}{body}{asvg}</svg>')
    lab = (f'<div class="lb" style="position:absolute;left:54px;bottom:54px;font-weight:700;font-size:28px;color:var(--gry)">{E(outside)}</div>'
           f'<div class="lb" style="position:absolute;right:54px;bottom:54px;font-weight:900;font-size:30px;color:var(--b2)">{E(inside)}</div>'
           f'<div class="lb" style="position:absolute;left:{cx + bw / 2 + 24}px;top:{top + 70}px;padding:6px 16px;border-radius:99px;background:rgba(36,92,255,.10);font-weight:700;font-size:22px;color:var(--b1)">금속 코팅</div>')
    nt = f'<div class="lb" style="position:absolute;left:0;right:0;bottom:16px;text-align:center;font-size:21px;color:#9aa0ae">{E(note)}</div>' if note else ""
    i = _icard(b, t, d, box, svg, tag, title, lab + nt)
    _draw(b, f"#{i} .mt", 2000, t + .25, 1.1)
    if mode == "winter": b.js(f'tl.to("#{i} .gw",{{opacity:1,duration:1.2,ease:"sine.inOut"}},{at - .3:.3f});tl.to("#{i} .gw",{{scale:1.06,transformOrigin:"50% 50%",duration:1.6,yoyo:true,repeat:{max(1, int(d / 1.6))},ease:"sine.inOut"}},{at + .9:.3f});')
    for n in range(len(arrows)): _draw(b, f"#{i} .ar{n}", 400, at + .12 * n, .9)
    b.js(f'tl.fromTo("#{i} .lb",{{opacity:0,y:10}},{{opacity:1,y:0,duration:.5,stagger:.1,ease:"expo.out"}},{at + .5:.3f});')

def tempcurve(b, t, d, box=(84, 300, 912, 640), title="", series=(), xlabels=(), ymin=0, ymax=30, unit="℃", at=None, dur=2.0, delta="", caption_="", tag="TEMPERATURE"):
    """시간에 따른 온도 XY 곡선 2개 비교. series=[["맨유리",[값...]],["LX",[값...]]] (첫째 회색 · 둘째 파랑)"""
    x, y, w, h = box; at = t + .5 if at is None else at
    X0, X1, Y0, Y1 = 96, w - 150, h - 96, 150
    n = max(len(s[1]) for s in series) if series else 2
    px = lambda k: X0 + (X1 - X0) * k / max(1, n - 1)
    py = lambda v: Y0 - (Y0 - Y1) * (v - ymin) / max(1e-6, ymax - ymin)
    grid = "".join(f'<line x1="{X0}" x2="{X1}" y1="{py(ymin + (ymax - ymin) * g / 4):.0f}" y2="{py(ymin + (ymax - ymin) * g / 4):.0f}" stroke="#eef0f6" stroke-width="2"/><text x="{X0 - 16}" y="{py(ymin + (ymax - ymin) * g / 4) + 7:.0f}" font-size="20" fill="#9aa0ae" text-anchor="end" font-family="PP">{ymin + (ymax - ymin) * g / 4:g}</text>' for g in range(5))
    xl = "".join(f'<text x="{px(k):.0f}" y="{Y0 + 36}" font-size="21" font-weight="700" fill="#727785" text-anchor="middle" font-family="KR">{E(s)}</text>' for k, s in enumerate(xlabels))
    lines = ""; ends = ""
    for k, (nm, vals) in enumerate(series):
        P = [(px(j), py(v)) for j, v in enumerate(vals)]; Lk = _plen(P) + 20
        col = "#b3b9c6" if k == 0 else "#245cff"
        lines += f'<path class="cv{k}" d="{_path(P)}" fill="none" stroke="{col}" stroke-width="{6 if k else 5}" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="{Lk:.0f}" stroke-dashoffset="{Lk:.0f}"/>'
        lines += f'<circle class="ce{k}" cx="{P[-1][0]:.1f}" cy="{P[-1][1]:.1f}" r="9" fill="{col}" stroke="#fff" stroke-width="3.5" opacity="0"/>'
        ends += f'<div class="el{k}" style="position:absolute;left:{X1 + 22}px;top:{P[-1][1] - 22:.0f}px;font-weight:{900 if k else 700};font-size:{26 if k else 23}px;color:{"var(--b1)" if k else "#9aa0ae"};white-space:nowrap;opacity:0">{E(nm)}<br><span class="tnum">{vals[-1]:g}{E(unit)}</span></div>'
    svg = f'<svg width="{w}" height="{h}" style="position:absolute;left:0;top:0">{grid}<path d="M{X0} {Y1 - 20} L{X0} {Y0} L{X1 + 10} {Y0}" stroke="#d5d9e4" stroke-width="2.5" fill="none"/>{xl}{lines}</svg>'
    dl = f'<div class="dl" style="position:absolute;right:54px;top:40px;padding:8px 20px;border-radius:99px;background:rgba(36,92,255,.10);font-weight:900;font-size:26px;color:var(--b1);opacity:0">{E(delta)}</div>' if delta else ""
    cp = f'<div style="position:absolute;left:54px;bottom:16px;font-size:20px;color:#9aa0ae">{E(caption_)}</div>' if caption_ else ""
    i = _icard(b, t, d, box, svg, tag, title, ends + dl + cp)
    for k in range(len(series)):
        tk = at + k * .35
        b.js(f'tl.to("#{i} .cv{k}",{{strokeDashoffset:0,duration:{dur},ease:"power2.inOut"}},{tk:.3f});')
        b.js(f'tl.to("#{i} .ce{k}",{{opacity:1,duration:.3}},{tk + dur - .1:.3f});tl.fromTo("#{i} .el{k}",{{opacity:0,x:-10}},{{opacity:1,x:0,duration:.5,ease:"expo.out"}},{tk + dur - .05:.3f});')
    if delta: b.js(f'tl.fromTo("#{i} .dl",{{opacity:0,y:-8}},{{opacity:1,y:0,duration:.6,ease:"expo.out"}},{at + dur + .5:.3f});')

def filmlayers(b, t, d, box=(84, 300, 912, 640), title="", layers=(), tag="FILM STRUCTURE", at=None, gap=.28, badge=""):
    """필름 단면: 층이 위에서부터 하나씩 쌓인다. layers=[["이름","m"|"c"|"a"|"d"|"h"], ...] m 금속 · c 투명 PET · a 접착 · d 염료 · h 하드코팅"""
    x, y, w, h = box; at = t + .45 if at is None else at
    fills = {"m": "linear-gradient(90deg,#aebde6,#245cff 50%,#c3cdea)", "c": "#e9edf6", "a": "#f2efe6", "d": "#3a3d48", "h": "#f7f9fd"}
    n = max(1, len(layers)); top = 150; lh = min(62, int((h - top - 80) / n) - 10)
    rows = ""
    for k, (nm, kd) in enumerate(layers):
        yy = top + k * (lh + 10)
        bd = "border:2px solid #dde2ec;" if kd in ("h", "c") else ""
        rows += (f'<div class="ly{k}" style="position:absolute;left:54px;top:{yy}px;width:{w * .52:.0f}px;height:{lh}px;border-radius:12px;background:{fills.get(kd, "#e9edf6")};{bd}transform-origin:left"></div>'
                 f'<div class="lt{k}" style="position:absolute;left:{w * .52 + 84:.0f}px;top:{yy + lh / 2 - 19:.0f}px;font-weight:{900 if kd == "m" else 700};font-size:30px;color:{"var(--b1)" if kd == "m" else "var(--body)"};white-space:nowrap">{E(nm)}</div>'
                 f'<div class="lk{k}" style="position:absolute;left:{w * .52 + 60:.0f}px;top:{yy + lh / 2:.0f}px;width:16px;height:2px;background:#cbd1de"></div>')
    bg = f'<div class="bgd" style="position:absolute;right:54px;top:40px;padding:8px 20px;border-radius:99px;background:rgba(36,92,255,.10);font-weight:900;font-size:24px;color:var(--b1);opacity:0">{E(badge)}</div>' if badge else ""
    i = _icard(b, t, d, box, "", tag, title, rows + bg)
    for k in range(n):
        tk = at + k * gap
        b.js(f'tl.fromTo("#{i} .ly{k}",{{scaleX:0,opacity:0}},{{scaleX:1,opacity:1,duration:.7,ease:"expo.out"}},{tk:.3f});'
             f'tl.fromTo(["#{i} .lt{k}","#{i} .lk{k}"],{{opacity:0,x:-12}},{{opacity:1,x:0,duration:.5,ease:"expo.out"}},{tk + .2:.3f});')
    if badge: b.js(f'tl.fromTo("#{i} .bgd",{{opacity:0,y:-8}},{{opacity:1,y:0,duration:.6,ease:"expo.out"}},{at + n * gap + .3:.3f});')

def spectrumcurve(b, t, d, box=(84, 300, 912, 640), title="", pts=(), at=None, dur=2.2, tag="SPECTRUM", caption_="개념도", xmax=2500):
    """파장별 투과율 XY 곡선: 가시광선 띠(380~780nm)는 옅은 무지개, 적외선 구간은 회색. pts=[[nm,투과율%], ...]"""
    x, y, w, h = box; at = t + .5 if at is None else at
    X0, X1, Y0, Y1 = 96, w - 56, h - 100, 150
    px = lambda nm: X0 + (X1 - X0) * (nm - 300) / (xmax - 300); py = lambda v: Y0 - (Y0 - Y1) * v / 100
    gid = b.id("sg")
    band = f'<rect class="vb" x="{px(380):.0f}" y="{Y1}" width="{px(780) - px(380):.0f}" height="{Y0 - Y1}" fill="url(#{gid})" opacity="0"/>'
    ir = f'<rect class="ib" x="{px(780):.0f}" y="{Y1}" width="{X1 - px(780):.0f}" height="{Y0 - Y1}" fill="#f3f4f8" opacity="0"/>'
    grid = "".join(f'<line x1="{X0}" x2="{X1}" y1="{py(v):.0f}" y2="{py(v):.0f}" stroke="#eef0f6" stroke-width="2"/><text x="{X0 - 14}" y="{py(v) + 7:.0f}" font-size="20" fill="#9aa0ae" text-anchor="end" font-family="PP">{v}</text>' for v in (0, 25, 50, 75, 100))
    xt = "".join(f'<text x="{px(nm):.0f}" y="{Y0 + 34}" font-size="20" fill="#9aa0ae" text-anchor="middle" font-family="PP">{nm}</text>' for nm in (380, 780, 1500, xmax))
    P = [(px(a), py(v)) for a, v in pts] if pts else [(X0, Y0), (X1, Y0)]; L = _plen(P) + 20
    svg = (f'<svg width="{w}" height="{h}" style="position:absolute;left:0;top:0"><defs><linearGradient id="{gid}"><stop offset="0" stop-color="#8b5cf6" stop-opacity=".16"/><stop offset=".3" stop-color="#245cff" stop-opacity=".16"/><stop offset=".55" stop-color="#14b8a6" stop-opacity=".14"/><stop offset=".8" stop-color="#eab308" stop-opacity=".12"/><stop offset="1" stop-color="#ef4444" stop-opacity=".12"/></linearGradient></defs>'
           f'{ir}{band}{grid}<path d="M{X0} {Y1 - 16} L{X0} {Y0} L{X1} {Y0}" stroke="#d5d9e4" stroke-width="2.5" fill="none"/>{xt}'
           f'<path class="sc" d="{_path(P)}" fill="none" stroke="#245cff" stroke-width="6" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="{L:.0f}" stroke-dashoffset="{L:.0f}"/></svg>')
    lab = (f'<div class="bl" style="position:absolute;left:{px(380) + 10:.0f}px;top:{Y1 + 12}px;font-weight:700;font-size:21px;color:var(--b1);opacity:0">가시광선</div>'
           f'<div class="bl" style="position:absolute;left:{px(1100):.0f}px;top:{Y1 + 12}px;font-weight:700;font-size:21px;color:#9aa0ae;opacity:0">적외선(열)</div>'
           f'<div style="position:absolute;right:56px;bottom:20px;font-size:19px;color:#9aa0ae">파장(nm) · {E(caption_)}</div>'
           f'<div style="position:absolute;left:30px;top:{Y1 - 46}px;font-size:19px;color:#9aa0ae">투과율(%)</div>')
    i = _icard(b, t, d, box, svg, tag, title, lab)
    b.js(f'tl.to(["#{i} .vb","#{i} .ib"],{{opacity:1,duration:.7,stagger:.15}},{t + .3:.3f});tl.to("#{i} .bl",{{opacity:1,duration:.5,stagger:.12}},{t + .6:.3f});'
         f'tl.to("#{i} .sc",{{strokeDashoffset:0,duration:{dur},ease:"power2.inOut"}},{at:.3f});')

_CAR = {  # 차량 평면도 유리 위치 (가로 420 · 세로 760 기준)
    "front": (60, 150, 300, 110, 30), "side1": (22, 290, 34, 150, 10), "side1r": (364, 290, 34, 150, 10),
    "side2": (22, 460, 34, 150, 10), "side2r": (364, 460, 34, 150, 10), "roof": (90, 290, 240, 270, 26), "rear": (80, 600, 260, 90, 26)}

def cartop(b, t, d, box=(84, 290, 912, 680), zones=(), tag="TINT MAP", title=""):
    """차량 평면도: 유리 위치마다 농도만큼 어두워지고 이름표가 붙는다. zones=[["front"|"side1"|"side2"|"roof"|"rear","LX 40",시각], ...]"""
    x, y, w, h = box; cw, chh = 420, 760; s = min((h - 150) / chh, 1.0); ox = 90; oy = 120
    car = (f'<rect x="10" y="40" width="400" height="690" rx="150" fill="#f4f6fb" stroke="#cfd5e2" stroke-width="5"/>'
           f'<rect x="0" y="230" width="20" height="70" rx="8" fill="#cfd5e2"/><rect x="400" y="230" width="20" height="70" rx="8" fill="#cfd5e2"/>')
    gl = ""; labels = ""
    for k, (key, lab, _) in enumerate(zones):
        ks = [key] if key not in ("side1", "side2") else [key, key + "r"]
        m = re.search(r"(\d+)", lab); pct = int(m.group(1)) if m else 50
        op = max(.18, min(.92, 1 - pct / 100))
        for kk in ks:
            gx, gy, gw, gh, gr = _CAR[kk]
            gl += f'<rect class="z{k}" x="{gx}" y="{gy}" width="{gw}" height="{gh}" rx="{gr}" fill="#1c2233" opacity="0" data-op="{op:.2f}"/>'
            gl += f'<rect x="{gx}" y="{gy}" width="{gw}" height="{gh}" rx="{gr}" fill="none" stroke="#c3cad8" stroke-width="3"/>'
        gx, gy, gw, gh, _ = _CAR[ks[-1]]
        lx = ox + (gx + gw) * s + 40; ly = oy + (gy + gh / 2) * s - 24
        labels += (f'<div class="zl{k}" style="position:absolute;left:{max(lx, ox + 440 * s):.0f}px;top:{ly:.0f}px;display:flex;align-items:center;gap:14px;opacity:0">'
                   f'<span style="width:40px;height:2px;background:#cbd1de"></span><span style="font-weight:700;font-size:24px;color:var(--gry)">{E({"front": "전면", "side1": "1열", "side2": "2열 · 후면", "roof": "루프", "rear": "후면 유리"}.get(key, key))}</span>'
                   f'<span style="font-weight:900;font-size:32px;color:var(--b1)">{E(lab)}</span></div>')
    svg = f'<svg width="{w}" height="{h}" style="position:absolute;left:0;top:0"><g transform="translate({ox},{oy:.0f}) scale({s:.3f})">{car}{gl}</g></svg>'
    i = _icard(b, t, d, box, svg, tag, title, labels)
    for k, (_, _, tk) in enumerate(zones):
        b.js(f'document.querySelectorAll("#{i} .z{k}").forEach(el=>tl.to(el,{{opacity:+el.dataset.op,duration:.8,ease:"power2.inOut"}},{tk:.3f}));'
             f'tl.fromTo("#{i} .zl{k}",{{opacity:0,x:-14}},{{opacity:1,x:0,duration:.55,ease:"expo.out"}},{tk + .25:.3f});')

def heatflow(b, t, d, box=(84, 300, 912, 640), mode="summer", tag="HEAT PATH", title="", outside="바깥", inside="실내", film="LX 금속층", at=None, passed=1):
    """유리 단면에서 열이 흐르는 길: summer = 바깥 태양열이 필름에서 반사, winter = 실내 난방열이 필름에서 다시 실내로. passed=통과하는 가는 화살표 수"""
    x, y, w, h = box; at = t + .45 if at is None else at
    gx = w * .5; top = 150; bot = h - 80; mk = b.id("hm")
    glass = (f'<rect x="{gx - 14}" y="{top}" width="28" height="{bot - top}" rx="8" fill="#e6ecfa" stroke="#c3cde6" stroke-width="2.5"/>'
             f'<rect class="fm" x="{gx + (14 if mode == "summer" else -22)}" y="{top}" width="8" height="{bot - top}" rx="4" fill="#245cff" transform-origin="{gx} {top}"/>')
    src = -1 if mode == "summer" else 1   # 열이 오는 쪽 (-1 왼쪽 바깥, +1 오른쪽 실내)
    wall = gx + (8 if mode == "summer" else -8) * 1
    arr = ""; n = 4
    for k in range(n):
        yy = top + 50 + k * (bot - top - 100) / (n - 1)
        sx = gx + src * (w * .4); P = [(sx, yy - 30), (gx + src * 22, yy), (sx + -src * -10, yy + 34)]
        P = [(sx, yy - 34), (gx + src * 26, yy), (gx + src * (w * .36), yy + 38)]
        L = _plen(P) + 10
        arr += f'<path class="h{k}" d="{_path(P)}" fill="none" stroke="#7c4dff" stroke-width="5.5" stroke-linecap="round" stroke-linejoin="round" marker-end="url(#{mk})" stroke-dasharray="{L:.0f}" stroke-dashoffset="{L:.0f}"/>'
    for k in range(passed):
        yy = (top + bot) / 2 + 10
        P = [(gx + src * (w * .4), yy + 80), (gx - src * (w * .3), yy + 80)]; L = _plen(P) + 10
        arr += f'<path class="p{k}" d="{_path(P)}" fill="none" stroke="#c4b5fd" stroke-width="3" stroke-dasharray="6 10" stroke-linecap="round" opacity="0"/>'
    svg = f'<svg width="{w}" height="{h}" style="position:absolute;left:0;top:0"><defs>{_ARROW.format(id=mk, c="#7c4dff")}</defs>{glass}{arr}</svg>'
    lab = (f'<div class="lb" style="position:absolute;left:54px;bottom:30px;font-weight:{900 if mode == "summer" else 700};font-size:28px;color:{"var(--b2)" if mode == "summer" else "var(--gry)"}">{E(outside)}</div>'
           f'<div class="lb" style="position:absolute;right:54px;bottom:30px;font-weight:{900 if mode == "winter" else 700};font-size:28px;color:{"var(--b2)" if mode == "winter" else "var(--gry)"}">{E(inside)}</div>'
           f'<div class="lb" style="position:absolute;left:{gx - 100:.0f}px;width:200px;text-align:center;bottom:30px;padding:6px 0;border-radius:99px;background:rgba(36,92,255,.10);font-weight:700;font-size:22px;color:var(--b1)">{E(film)}</div>')
    i = _icard(b, t, d, box, svg, tag, title, lab)
    b.js(f'tl.fromTo("#{i} .fm",{{scaleY:0}},{{scaleY:1,duration:.8,ease:"expo.out"}},{t + .3:.3f});')
    for k in range(n): b.js(f'tl.to("#{i} .h{k}",{{strokeDashoffset:0,duration:1.0,ease:"power2.inOut"}},{at + k * .16:.3f});')
    for k in range(passed): b.js(f'tl.to("#{i} .p{k}",{{opacity:1,duration:.6}},{at + .9:.3f});')
    b.js(f'tl.fromTo("#{i} .lb",{{opacity:0,y:8}},{{opacity:1,y:0,duration:.5,stagger:.1,ease:"expo.out"}},{at + .3:.3f});')

def colbars(b, t, d, box=(84, 300, 912, 640), title="", bars=(), vmax=100, unit="", ticks=(), hi=-1, tag="COMPARISON", caption_=""):
    """세로 막대 XY 그래프: 축 → 눈금 → 막대가 차례로 자라며 숫자 카운트. hi=강조 막대 번호(파랑), 나머지 회색. bars=[["라벨",값,시각], ...]"""
    x, y, w, h = box; X0, X1, Y0, Y1 = 96, w - 56, h - 96, 160
    n = max(1, len(bars)); hi = n + hi if hi < 0 else hi; slot = (X1 - X0) / n; bw = min(120, slot * .5)
    py = lambda v: Y0 - (Y0 - Y1) * v / vmax
    grid = "".join(f'<div style="position:absolute;left:{X0}px;right:56px;top:{py(v):.0f}px;height:2px;background:#eef0f6"></div><div class="tnum" style="position:absolute;left:{X0 - 60}px;width:46px;text-align:right;top:{py(v) - 13:.0f}px;font-size:20px;color:#9aa0ae">{v}</div>' for v in ticks)
    cols = ""
    for k, (lb, v, _) in enumerate(bars):
        cx = X0 + slot * (k + .5); bh = (Y0 - Y1) * min(v, vmax) / vmax; strong = k == hi
        cols += (f'<div class="cb{k}" style="position:absolute;left:{cx - bw / 2:.0f}px;top:{Y0 - bh:.0f}px;width:{bw:.0f}px;height:{bh:.0f}px;border-radius:14px 14px 4px 4px;background:{"linear-gradient(180deg,var(--b2),var(--b1))" if strong else "#d9dee8"};transform-origin:bottom;transform:scaleY(0)"></div>'
                 f'<div class="cv{k}" style="position:absolute;left:{cx - 90:.0f}px;width:180px;text-align:center;top:{Y0 - bh - 52:.0f}px;font-weight:900;font-size:{36 if strong else 30}px;color:{"var(--b1)" if strong else "#8a90a0"};opacity:0"><span class="n">0</span><span style="font-size:20px;margin-left:3px">{E(unit)}</span></div>'
                 f'<div style="position:absolute;left:{cx - slot / 2:.0f}px;width:{slot:.0f}px;text-align:center;top:{Y0 + 16}px;font-weight:{900 if strong else 700};font-size:24px;color:{"var(--ink)" if strong else "var(--gry)"}">{E(lb)}</div>')
    ax = f'<div class="ax" style="position:absolute;left:{X0}px;right:56px;top:{Y0}px;height:3px;background:#cfd5e2;transform-origin:left"></div>'
    cp = f'<div style="position:absolute;right:56px;bottom:14px;font-size:19px;color:#9aa0ae">{E(caption_)}</div>' if caption_ else ""
    i = _icard(b, t, d, box, "", tag, title, grid + ax + cols + cp)
    b.js(f'tl.fromTo("#{i} .ax",{{scaleX:0}},{{scaleX:1,duration:.7,ease:"expo.out"}},{t + .25:.3f});')
    for k, (_, v, tk) in enumerate(bars):
        dec = 0 if float(v).is_integer() else 1
        b.js(f'tl.to("#{i} .cb{k}",{{scaleY:1,duration:1.2,ease:"power3.out"}},{tk:.3f});tl.to("#{i} .cv{k}",{{opacity:1,duration:.3}},{tk + .1:.3f});'
             f'(function(){{const o={{v:0}};const el=document.querySelector("#{i} .cv{k} .n");tl.to(o,{{v:{v},duration:1.2,ease:"power3.out",onUpdate:()=>el.textContent=o.v.toFixed({dec})}},{tk:.3f});}})();')

def dial(b, t, d, box=(140, 300, 800, 600), label="", value=0, vmax=100, unit="%", at=None, sub="", tag="GAUGE"):
    """반원 계기판: 바늘이 돌아가며 수치가 올라간다"""
    x, y, w, h = box; at = t + .45 if at is None else at
    cx, cy, R = w / 2, h - 210, min(w * .34, h - 300)
    import math
    arc = lambda a0, a1: f"M{cx + R * math.cos(math.pi * (1 - a0)):.1f} {cy - R * math.sin(math.pi * (1 - a0)):.1f} A{R:.0f} {R:.0f} 0 0 1 {cx + R * math.cos(math.pi * (1 - a1)):.1f} {cy - R * math.sin(math.pi * (1 - a1)):.1f}"
    L = math.pi * R; f = min(1, value / vmax); gid = b.id("dg")
    ticks = "".join(f'<line x1="{cx + (R - 44) * math.cos(math.pi * (1 - k / 10)):.1f}" y1="{cy - (R - 44) * math.sin(math.pi * (1 - k / 10)):.1f}" x2="{cx + (R - 30) * math.cos(math.pi * (1 - k / 10)):.1f}" y2="{cy - (R - 30) * math.sin(math.pi * (1 - k / 10)):.1f}" stroke="#cfd5e2" stroke-width="3"/>' for k in range(11))
    svg = (f'<svg width="{w}" height="{h}" style="position:absolute;left:0;top:0"><defs><linearGradient id="{gid}"><stop offset="0" stop-color="#245cff"/><stop offset="1" stop-color="#7c4dff"/></linearGradient></defs>'
           f'<path d="{arc(0, 1)}" fill="none" stroke="#edf0f6" stroke-width="30" stroke-linecap="round"/>'
           f'<path class="da" d="{arc(0, 1)}" fill="none" stroke="url(#{gid})" stroke-width="30" stroke-linecap="round" stroke-dasharray="{L:.0f}" stroke-dashoffset="{L:.0f}"/>{ticks}'
           f'<line class="nd" x1="{cx}" y1="{cy}" x2="{cx - R + 70:.0f}" y2="{cy}" stroke="#14161c" stroke-width="7" stroke-linecap="round"/><circle cx="{cx}" cy="{cy}" r="16" fill="#14161c"/></svg>')
    txt = (f'<div style="position:absolute;left:0;right:0;top:{cy + 24:.0f}px;text-align:center;font-weight:900;font-size:80px" class="tnum"><span class="n gt g-b">0</span><span class="gt g-b" style="font-size:40px">{E(unit)}</span></div>'
           f'<div style="position:absolute;left:0;right:0;top:40px;text-align:center" class="tag">{E(label)}</div>'
           f'<div style="position:absolute;left:0;right:0;bottom:22px;text-align:center;font-size:24px;font-weight:700;color:var(--gry)">{E(sub)}</div>')
    i = _icard(b, t, d, box, svg, "", "", txt)
    dec = 0 if float(value).is_integer() else 1
    b.js(f'tl.to("#{i} .da",{{strokeDashoffset:{L * (1 - f):.0f},duration:1.6,ease:"power3.out"}},{at:.3f});'
         f'tl.fromTo("#{i} .nd",{{rotation:0,svgOrigin:"{cx} {cy}"}},{{rotation:{180 * f:.1f},svgOrigin:"{cx} {cy}",duration:1.6,ease:"power3.out"}},{at:.3f});'
         f'(function(){{const o={{v:0}};const el=document.querySelector("#{i} .n");tl.to(o,{{v:{value},duration:1.6,ease:"power3.out",onUpdate:()=>el.textContent=o.v.toFixed({dec})}},{at:.3f});}})();')

def donut(b, t, d, box=(84, 300, 912, 620), title="", parts=(), at=None, center="", tag="BREAKDOWN", caption_=""):
    """도넛 비율: 조각이 차례로 그려지고 오른쪽 범례 숫자가 올라간다. parts=[["반사",45,"b"],["흡수",25,"p"],["투과",30,"g"]]"""
    x, y, w, h = box; at = t + .45 if at is None else at
    import math
    cx, cy, R = w * .3, h / 2 + 30, min(w * .2, h * .3); C = 2 * math.pi * R
    col = {"b": "#245cff", "p": "#7c4dff", "g": "#cfd5e2", "k": "#3a3f4c"}
    tot = sum(p[1] for p in parts) or 1; acc = 0; segs = ""; leg = ""
    for k, (nm, v, g) in enumerate(parts):
        ln = C * v / tot
        segs += f'<circle class="sg{k}" cx="{cx:.0f}" cy="{cy:.0f}" r="{R:.0f}" fill="none" stroke="{col.get(g, "#cfd5e2")}" stroke-width="54" stroke-dasharray="0 {C:.0f}" transform="rotate({-90 + 360 * acc / tot:.1f} {cx:.0f} {cy:.0f})" data-l="{ln - 4:.0f}"/>'
        acc += v
        leg += (f'<div class="lg{k}" style="position:absolute;left:{w * .56:.0f}px;top:{cy - 90 + k * 80:.0f}px;display:flex;align-items:center;gap:18px;opacity:0">'
                f'<span style="width:22px;height:22px;border-radius:6px;background:{col.get(g, "#cfd5e2")}"></span><span style="font-weight:700;font-size:30px;color:var(--body);width:150px">{E(nm)}</span>'
                f'<span class="tnum" style="font-weight:900;font-size:40px;color:{col.get(g) if g in "bp" else "var(--ink)"}"><span class="n">0</span><span style="font-size:22px">%</span></span></div>')
    ctr = f'<div style="position:absolute;left:{cx - 120:.0f}px;width:240px;top:{cy - 26:.0f}px;text-align:center;font-weight:900;font-size:36px">{E(center)}</div>' if center else ""
    cp = f'<div style="position:absolute;right:56px;bottom:16px;font-size:19px;color:#9aa0ae">{E(caption_)}</div>' if caption_ else ""
    svg = f'<svg width="{w}" height="{h}" style="position:absolute;left:0;top:0"><circle cx="{cx:.0f}" cy="{cy:.0f}" r="{R:.0f}" fill="none" stroke="#f0f2f7" stroke-width="54"/>{segs}</svg>'
    i = _icard(b, t, d, box, svg, tag, title, ctr + leg + cp)
    for k, (_, v, _) in enumerate(parts):
        tk = at + k * .45
        b.js(f'(function(){{const el=document.querySelector("#{i} .sg{k}");const o={{v:0}};const L=+el.dataset.l;tl.to(o,{{v:L,duration:.9,ease:"power2.inOut",onUpdate:()=>el.setAttribute("stroke-dasharray",o.v+" {C:.0f}")}},{tk:.3f});}})();'
             f'tl.fromTo("#{i} .lg{k}",{{opacity:0,x:-10}},{{opacity:1,x:0,duration:.5,ease:"expo.out"}},{tk:.3f});')
        _count(b, f"#{i} .lg{k} .n", 0, v, tk, .9)

ILLUS_PARTS = dict(thermos=thermos, tempcurve=tempcurve, filmlayers=filmlayers, spectrumcurve=spectrumcurve, cartop=cartop,
                   heatflow=heatflow, colbars=colbars, dial=dial, donut=donut)

PRO_PARTS = dict(splitline=splitline, morphcard=morphcard, bento=bento, ladder=ladder,
                 focusword=focusword, crossscan=crossscan, metricpair=metricpair, stacklist=stacklist)

UI_PARTS = dict(toast=toast, snackbar=snackbar, banner=banner, modal=modal, bottomsheet=bottomsheet, inlineerror=inlineerror, tooltip=tooltip,
                coachmark=coachmark, badge=badge, spinner=spinner, skeleton=skeleton, progress=progress, inputfield=inputfield, toggles=toggles,
                segmented=segmented, rangeslider=rangeslider, chat=chat, emptystate=emptystate, tap=tap, swipecards=swipecards, tabbar=tabbar,
                carousel=carousel, dropdown=dropdown)

PARTS = dict(sharedcard=sharedcard, centertext=centertext, rollstat=rollstat, rolltext=rolltext, header=header, logo=logo, bgword=bgword, caption=caption, kinetic=kinetic, titlecard=titlecard, strike=strike, checklist=checklist,
             hbars=hbars, xyline=xyline, counter=counter, ring=ring, seesaw=seesaw, steps=steps, versus=versus, photo=photo, spectrum=spectrum,
             waves=waves, timeline=timeline, typeline=typeline, receipt=receipt, slot=slot, compare=compare, endcard=endcard)
PARTS.update(UI_PARTS)
PARTS.update(PRO_PARTS)
PARTS.update(ILLUS_PARTS)

def _prepare_items(raw_items, overlay=False):
    items = [dict(x) for x in raw_items]
    if overlay: return items
    cands = [it for it in items if it.get("p") in MORPH_PARTS and not it.get("paper", False)
             and isinstance(it.get("box"), (list, tuple)) and len(it["box"]) == 4 and it["box"][3] > 0]
    cands.sort(key=lambda x: x["t"])
    chains, cur = [], []
    for it in cands:
        if cur and abs(it["t"] - (cur[-1]["t"] + cur[-1]["d"])) <= 0.45:
            cur.append(it)
        else:
            if len(cur) >= 2: chains.append(cur)
            cur = [it]
    if len(cur) >= 2: chains.append(cur)
    shared = []
    for ch in chains:
        for it in ch: it["_ghost"] = True
        t0 = ch[0]["t"]; t1 = ch[-1]["t"] + ch[-1]["d"]
        shared.append(dict(p="sharedcard", t=round(t0, 3), d=round(t1 - t0, 3), chain=[dict(t=c["t"], d=c["d"], box=c["box"]) for c in ch]))
    return shared + items

# ───────── 조립 · 폰트 · 렌더 ─────────
# ───────── Swiss Editorial Full-Canvas Kinetic Engine (style:"editorial") ─────────
ED_CSS = r"""
.ed-grid{position:absolute;inset:210px 56px 210px 56px;border-top:1.5px solid rgba(20,22,28,.10);border-bottom:1.5px solid rgba(20,22,28,.10);pointer-events:none}
.ed-grid::before{content:"";position:absolute;inset:0;background-image:linear-gradient(90deg,rgba(20,22,28,.045) 1px,transparent 1px);background-size:322px 100%}
.ed-meta{font-family:PP,KR,sans-serif;font-size:20px;font-weight:700;letter-spacing:.20em;color:var(--b1);display:flex;justify-content:space-between;align-items:center}
.ed-kwrap{position:absolute;left:72px;width:936px}
.ed-sent{position:absolute;left:0;top:0;width:100%}
.ed-row{display:block;font-weight:900;font-size:66px;line-height:1.22;letter-spacing:-.042em;margin-bottom:8px;white-space:nowrap}
.ed-m{display:inline-block;overflow:hidden;vertical-align:bottom;padding:12px 8px;margin:-12px -8px}
.ed-w{display:inline-block;will-change:transform,opacity,filter}
.ed-hl{position:relative;display:inline-block;padding:0 8px}
.ed-hl .eb{position:absolute;left:-2px;right:-2px;top:14%;bottom:6%;border-radius:12px;background:rgba(36,92,255,.13);transform-origin:left}
.ed-hl .ep{position:absolute;top:6%;bottom:0;width:3.5px;border-radius:2px;background:var(--b1)}
.ed-hl .ep.r{background:var(--b2);left:0%}
.ed-hl .ep.l{left:-4px}
.ed-hl em{position:relative;z-index:1;font-style:normal}
.ed-dark .ed-row{color:#fff}
.ed-dark .ed-hl .eb{background:rgba(124,77,255,.28)}
"""

def _ed_type_html(caps):
    sents = []
    for si, rows in enumerate(caps):
        rhtml = []
        for r in rows:
            toks = []
            for tx, st in r:
                glue = tx.startswith("~"); tx = tx.lstrip("~")
                if st in ("b", "p", "n", "bp"):
                    hp = f'<span class="ed-hl"><i class="eb"></i><i class="ep l"></i><i class="ep r"></i><em class="gt g-{st if st != "n" else "b"}">{E(tx)}</em></span>'
                    if glue and toks: toks[-1] += hp
                    else: toks.append(hp)
                else:
                    for idx, w in enumerate(tx.split(" ")):
                        if not w: continue
                        s = f'<span class="gry">{E(w)}</span>' if st == "g" else E(w)
                        if idx == 0 and glue and toks: toks[-1] += s
                        else: toks.append(s)
            rhtml.append('<span class="ed-row">' + " ".join(f'<span class="ed-m"><span class="ed-w">{tk}</span></span>' for tk in toks) + "</span>")
        sents.append(f'<div class="ed-sent es{si}" style="opacity:{1 if si == 0 else 0}">{"".join(rhtml)}</div>')
    return "".join(sents)

def _ed_type_js(b, cid, t, d, caps, stimes):
    for si in range(len(caps)):
        ts = stimes[si] if si < len(stimes) else t + si * 2.8
        te = (stimes[si + 1] - 0.08) if si + 1 < len(caps) else (t + d - 0.24)
        if si > 0:
            b.js(f'tl.set("#{cid} .es{si}",{{opacity:1}},{ts:.3f});')
        b.js(f'tl.fromTo("#{cid} .es{si} .ed-w",{{yPercent:115,opacity:0,filter:"blur(4px)"}},{{yPercent:0,opacity:1,filter:"blur(0px)",duration:.56,ease:"expo.out",stagger:.055}},{ts:.3f});'
             f'tl.fromTo("#{cid} .es{si} .eb",{{scaleX:0}},{{scaleX:1,duration:.54,ease:"expo.out"}},{ts + .16:.3f});'
             f'tl.fromTo("#{cid} .es{si} .ep.l",{{scaleY:0,opacity:0}},{{scaleY:1,opacity:1,duration:.24,ease:"expo.out"}},{ts + .14:.3f});'
             f'tl.fromTo("#{cid} .es{si} .ep.r",{{left:"0%",opacity:0}},{{left:"100%",opacity:1,duration:.54,ease:"expo.out"}},{ts + .16:.3f});'
             f'tl.to("#{cid} .es{si} .ep",{{opacity:0,duration:.25}},{ts + .82:.3f});'
             f'tl.to("#{cid} .es{si}",{{y:-18,opacity:0,filter:"blur(6px)",duration:.24,ease:"power2.in"}},{max(ts + .6, te):.3f});')

def _ed_cam(b, cid, t, d, x0=0, y0=28, s0=1.05, r0=0):
    b.js(f'tl.fromTo("#{cid}",{{opacity:0,x:{x0},y:{y0},scale:{s0},rotation:{r0},filter:"blur(4px)"}},{{opacity:1,x:0,y:0,scale:1,rotation:0,filter:"blur(0px)",duration:.64,ease:"expo.out"}},{t:.3f});'
         f'tl.to("#{cid}",{{scale:1.018,y:-6,duration:{max(.8, d - .9):.2f},ease:"sine.inOut"}},{t + .64:.3f});'
         f'tl.to("#{cid}",{{opacity:0,scale:.96,y:-34,filter:"blur(4px)",duration:.26,ease:"power2.in"}},{t + d - .28:.3f});')

def ed_split(b, t, d, no="01", q_tag="", q_txt="", a_tag="", t_high="23°C", t_low="-5°C", rule="", caps=(), stimes=()):
    s2 = stimes[1] if len(stimes) > 1 else t + d * .48
    html = (f'<div class="ed-grid"></div>'
            f'<div class="ed-meta" style="position:absolute;left:72px;right:72px;top:234px"><span>{E(no)}</span><span>THERMAL VECTOR</span></div>'
            f'<div class="ed-kwrap" style="top:296px">{_ed_type_html(caps)}</div>'
            f'<div class="bx1" style="position:absolute;left:72px;top:560px;width:936px;height:280px;border-radius:34px;background:#eef1f8;padding:42px 50px;overflow:hidden">'
            f'<div class="tag">{E(q_tag)}</div><div style="font-weight:900;font-size:48px;color:var(--gry);margin-top:16px">{E(q_txt)}</div>'
            f'<div class="sl" style="position:absolute;left:44px;right:44px;top:154px;height:6px;background:var(--b2);border-radius:3px;transform-origin:left"></div></div>'
            f'<div class="bx2 card" style="left:72px;top:876px;width:936px;height:680px;padding:52px;overflow:hidden;border:2px solid rgba(36,92,255,.18)">'
            f'<div class="tag" style="color:var(--b1)">{E(a_tag)}</div>'
            f'<div style="display:flex;align-items:center;justify-content:space-between;margin-top:64px">'
            f'<div><div style="font-size:24px;font-weight:700;color:var(--gry)">HIGH TEMP</div><div class="tnum gt g-p" style="font-size:104px;font-weight:900">{E(t_high)}</div></div>'
            f'<div style="flex:1;margin:0 36px;height:10px;border-radius:5px;background:#e6ebf5;position:relative;overflow:hidden"><div class="vec g-b" style="width:100%;height:100%;transform-origin:left"></div></div>'
            f'<div style="text-align:right"><div style="font-size:24px;font-weight:700;color:var(--gry)">LOW TEMP</div><div class="tnum gt g-b" style="font-size:104px;font-weight:900">{E(t_low)}</div></div></div>'
            f'<div class="rl" style="margin-top:78px;padding:28px 36px;border-radius:22px;background:#f4f7ff;font-size:36px;font-weight:900;text-align:center;color:var(--b1)">{E(rule)}</div></div>')
    i = b.clip(t, d, html, "left:0;top:0;width:1080px;height:1920px")
    _ed_cam(b, i, t, d, y0=40, s0=1.06); _ed_type_js(b, i, t, d, caps, stimes)
    b.js(f'tl.fromTo("#{i} .bx1",{{opacity:0,y:30}},{{opacity:1,y:0,duration:.55,ease:"expo.out"}},{t + .18:.3f});'
         f'tl.fromTo("#{i} .sl",{{scaleX:0}},{{scaleX:1,duration:.5,ease:"expo.out"}},{s2 - .15:.3f});'
         f'tl.to("#{i} .bx1",{{opacity:.48,scale:.97,duration:.5}},{s2:.3f});'
         f'tl.fromTo("#{i} .bx2",{{opacity:0,y:70,scale:.95}},{{opacity:1,y:0,scale:1,duration:.68,ease:"expo.out"}},{s2:.3f});'
         f'tl.fromTo("#{i} .vec",{{scaleX:0}},{{scaleX:1,duration:.9,ease:"expo.out"}},{s2 + .25:.3f});'
         f'tl.fromTo("#{i} .rl",{{opacity:0,y:18}},{{opacity:1,y:0,duration:.5,ease:"expo.out"}},{s2 + .5:.3f});')

def ed_temp(b, t, d, no="02", bare=(), lx=(), xlabels=(), badge="", caps=(), stimes=()):
    W0, H0 = 936, 760; X0, X1, Y0, Y1 = 76, 876, 640, 110; vmax = 26.0
    pts_b = [(X0 + (X1 - X0) * k / max(1, len(bare) - 1), Y0 - (Y0 - Y1) * v / vmax) for k, v in enumerate(bare)]
    pts_l = [(X0 + (X1 - X0) * k / max(1, len(lx) - 1), Y0 - (Y0 - Y1) * v / vmax) for k, v in enumerate(lx)]
    pb = "M%.1f %.1f " % pts_b[0] + " ".join("L%.1f %.1f" % p for p in pts_b[1:])
    pl = "M%.1f %.1f " % pts_l[0] + " ".join("L%.1f %.1f" % p for p in pts_l[1:])
    poly = " ".join(f"{x:.1f},{y:.1f}" for x, y in pts_l + list(reversed(pts_b)))
    grid = "".join(f'<line x1="{X0}" y1="{Y1 + (Y0 - Y1) * g / 4:.0f}" x2="{X1}" y2="{Y1 + (Y0 - Y1) * g / 4:.0f}" stroke="rgba(20,22,28,.07)" stroke-width="2"/>' for g in range(5))
    xlab = "".join(f'<text x="{pts_b[k][0]:.1f}" y="{Y0 + 48}" font-size="24" font-weight="700" fill="#727785" text-anchor="middle" font-family="KR">{E(xl)}</text>' for k, xl in enumerate(xlabels))
    html = (f'<div class="ed-grid"></div>'
            f'<div class="ed-meta" style="position:absolute;left:72px;right:72px;top:234px"><span>{E(no)}</span><span>CABIN HEAT RETENTION</span></div>'
            f'<div class="ed-kwrap" style="top:296px">{_ed_type_html(caps)}</div>'
            f'<div style="position:absolute;left:72px;top:580px;width:{W0}px;height:980px">'
            f'<svg width="{W0}" height="{H0}" style="overflow:visible">{grid}'
            f'<polygon class="shd" points="{poly}" fill="rgba(36,92,255,.12)" opacity="0"/>'
            f'<path class="cb" d="{pb}" stroke="#9aa2b4" stroke-width="7" stroke-dasharray="14 12" fill="none"/>'
            f'<path class="cl" d="{pl}" stroke="#245cff" stroke-width="11" stroke-linecap="round" fill="none" stroke-dasharray="1400" stroke-dashoffset="1400"/>'
            f'<circle class="dl" cx="{pts_l[-1][0]:.1f}" cy="{pts_l[-1][1]:.1f}" r="14" fill="#245cff" stroke="#fff" stroke-width="5"/>'
            f'<circle class="db" cx="{pts_b[-1][0]:.1f}" cy="{pts_b[-1][1]:.1f}" r="12" fill="#9aa2b4" stroke="#fff" stroke-width="4"/>'
            f'{xlab}</svg>'
            f'<div class="lb1 card" style="right:10px;top:{pts_l[-1][1] - 92:.0f}px;padding:16px 28px;border-radius:22px;font-weight:900;font-size:34px;color:var(--b1)">SOLAR GARD LX · {lx[-1]}°C</div>'
            f'<div class="lb2" style="position:absolute;right:16px;top:{pts_b[-1][1] + 22:.0f}px;font-weight:700;font-size:30px;color:var(--gry)">맨유리 · {bare[-1]}°C 급락</div>'
            f'<div style="position:absolute;left:0;bottom:80px;padding:14px 28px;border-radius:99px;background:rgba(36,92,255,.09);font-weight:700;font-size:25px;color:var(--b1)">{E(badge)}</div></div>')
    i = b.clip(t, d, html, "left:0;top:0;width:1080px;height:1920px")
    _ed_cam(b, i, t, d, x0=50, y0=0, s0=1.04); _ed_type_js(b, i, t, d, caps, stimes)
    b.js(f'tl.fromTo("#{i} .cb",{{opacity:0}},{{opacity:1,duration:.8}},{t + .3:.3f});'
         f'tl.to("#{i} .cl",{{strokeDashoffset:0,duration:2.1,ease:"power2.out"}},{t + .4:.3f});'
         f'tl.to("#{i} .shd",{{opacity:1,duration:.9}},{t + 1.3:.3f});'
         f'tl.fromTo(["#{i} .dl","#{i} .db","#{i} .lb1","#{i} .lb2"],{{opacity:0,y:16}},{{opacity:1,y:0,duration:.55,stagger:.1,ease:"expo.out"}},{t + 1.9:.3f});')

def ed_thermos(b, t, d, no="03", in_label="", out_label="", wall="", caps=(), stimes=()):
    rays_in = "".join(f'<path class="ri" d="M210 {180 + k * 140} L445 {235 + k * 140} L210 {290 + k * 140}" stroke="#7c4dff" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" fill="none" stroke-dasharray="600" stroke-dashoffset="600"/>' for k in range(3))
    rays_out = "".join(f'<path class="ro" d="M730 {180 + k * 140} L495 {235 + k * 140} L730 {290 + k * 140}" stroke="#245cff" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" fill="none" stroke-dasharray="600" stroke-dashoffset="600"/>' for k in range(3))
    html = (f'<div class="ed-grid"></div>'
            f'<div class="ed-meta" style="position:absolute;left:72px;right:72px;top:234px"><span>{E(no)}</span><span>VACUUM METAL BARRIER</span></div>'
            f'<div class="ed-kwrap" style="top:296px">{_ed_type_html(caps)}</div>'
            f'<div style="position:absolute;left:72px;top:580px;width:936px;height:980px">'
            f'<svg width="936" height="760" style="overflow:visible">'
            f'<rect x="90" y="90" width="355" height="560" rx="40" fill="rgba(124,77,255,.06)"/>'
            f'<rect x="495" y="90" width="355" height="560" rx="40" fill="rgba(36,92,255,.06)"/>'
            f'<rect class="mw" x="452" y="60" width="36" height="620" rx="18" fill="url(#g_wall)"/>'
            f'<defs><linearGradient id="g_wall" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#245cff"/><stop offset="100%" stop-color="#7c4dff"/></linearGradient></defs>'
            f'{rays_in}{rays_out}</svg>'
            f'<div style="position:absolute;left:110px;top:118px;font-weight:900;font-size:32px;color:var(--b2)">{E(in_label)}</div>'
            f'<div style="position:absolute;right:110px;top:118px;font-weight:900;font-size:32px;color:var(--b1)">{E(out_label)}</div>'
            f'<div class="card" style="left:218px;bottom:140px;width:500px;height:94px;border-radius:47px;display:flex;align-items:center;justify-content:center;font-family:PP,sans-serif;font-weight:700;font-size:24px;letter-spacing:.16em;color:var(--b1)">{E(wall)}</div></div>')
    i = b.clip(t, d, html, "left:0;top:0;width:1080px;height:1920px")
    _ed_cam(b, i, t, d, x0=-45, y0=15, s0=1.05); _ed_type_js(b, i, t, d, caps, stimes)
    b.js(f'tl.fromTo("#{i} .mw",{{scaleY:0,transformOrigin:"50% 50%"}},{{scaleY:1,duration:.65,ease:"expo.out"}},{t + .2:.3f});'
         f'tl.to("#{i} .ri",{{strokeDashoffset:0,duration:1.3,stagger:.18,ease:"power2.out"}},{t + .5:.3f});'
         f'tl.to("#{i} .ro",{{strokeDashoffset:0,duration:1.3,stagger:.18,ease:"power2.out"}},{t + .9:.3f});')

def ed_odometer(b, t, d, no="04", label="", val=20, unit="%", layers=(), caps=(), stimes=()):
    lays = "".join(
        f'<div class="ly{k}" style="height:68px;margin-bottom:12px;border-radius:20px;padding:0 36px;display:flex;align-items:center;justify-content:space-between;'
        f'background:{"linear-gradient(90deg,#245cff,#7c4dff);color:#fff" if "METAL" in s else "#fff;color:var(--ink);border:1.5px solid rgba(20,22,28,.08)"}">'
        f'<span style="font-family:PP,sans-serif;font-weight:700;font-size:24px;letter-spacing:.14em">{E(s)}</span>'
        f'<span style="font-size:22px;font-weight:700;opacity:.8">{"열반사 핵심층" if "METAL" in s else "광학 보호층"}</span></div>'
        for k, s in enumerate(layers))
    html = (f'<div class="ed-grid"></div>'
            f'<div class="ed-meta" style="position:absolute;left:72px;right:72px;top:234px"><span>{E(no)}</span><span>{E(label)}</span></div>'
            f'<div class="ed-kwrap" style="top:296px">{_ed_type_html(caps)}</div>'
            f'<div class="numbox" style="position:absolute;left:72px;top:545px;width:936px;text-align:center">'
            f'<div class="tnum" style="font-weight:900;font-size:260px;line-height:1;letter-spacing:-.05em">'
            f'<span class="gt g-bp">+</span><span class="n gt g-bp">0</span><span class="gt g-b" style="font-size:120px">{E(unit)}</span></div></div>'
            f'<div style="position:absolute;left:72px;top:885px;width:936px">{lays}</div>')
    i = b.clip(t, d, html, "left:0;top:0;width:1080px;height:1920px")
    _ed_cam(b, i, t, d, y0=50, s0=1.08); _ed_type_js(b, i, t, d, caps, stimes)
    b.js(f'tl.fromTo("#{i} .numbox",{{scale:.96,opacity:0,filter:"blur(5px)"}},{{scale:1,opacity:1,filter:"blur(0px)",duration:.75,ease:"expo.out"}},{t + .35:.3f});'
         f'(function(){{const o={{v:0}};const el=document.querySelector("#{i} .n");tl.to(o,{{v:{val},duration:1.5,ease:"expo.out",onUpdate:()=>el.textContent=Math.round(o.v)}},{t + .45:.3f});}})();')
    for k in range(len(layers)):
        b.js(f'tl.fromTo("#{i} .ly{k}",{{opacity:0,y:26}},{{opacity:1,y:0,duration:.48,ease:"expo.out"}},{t + .85 + k * .11:.3f});')

def ed_bento(b, t, d, no="05", main_tit="", main_sub="", summer=("", "", ""), winter=("", "", ""), caps=(), stimes=()):
    s2 = stimes[1] if len(stimes) > 1 else t + d * .5
    bars = "".join(f'<div class="bb{k}" style="flex:1;height:78px;border-radius:14px;background:#e6ebf5;overflow:hidden"><div class="bf g-b" style="width:100%;height:100%;transform-origin:bottom"></div></div>' for k in range(8))
    html = (f'<div class="ed-grid"></div>'
            f'<div class="ed-meta" style="position:absolute;left:72px;right:72px;top:234px"><span>{E(no)}</span><span>ALL-SEASON EV THERMAL</span></div>'
            f'<div class="ed-kwrap" style="top:296px">{_ed_type_html(caps)}</div>'
            f'<div class="b0 card" style="left:72px;top:575px;width:936px;height:430px;padding:48px 54px;display:flex;flex-direction:column;justify-content:space-between">'
            f'<div><div class="tag" style="color:var(--b1)">BATTERY &amp; HVAC DEFENSE</div>'
            f'<div style="font-weight:900;font-size:54px;margin-top:10px">{gtext(main_tit, "b")}</div>'
            f'<div style="font-size:30px;font-weight:700;color:var(--gry);margin-top:8px">{E(main_sub)}</div></div>'
            f'<div style="display:flex;gap:14px">{bars}</div></div>'
            f'<div class="b1 card" style="left:72px;top:1035px;width:454px;height:470px;padding:44px;display:flex;flex-direction:column;justify-content:space-between">'
            f'<div class="tag">{E(summer[0])}</div><div><div style="font-weight:900;font-size:40px">{E(summer[1])}</div>'
            f'<div style="font-size:28px;font-weight:700;color:var(--gry);margin-top:12px">{E(summer[2])}</div></div></div>'
            f'<div class="b2 card" style="left:554px;top:1035px;width:454px;height:470px;padding:44px;display:flex;flex-direction:column;justify-content:space-between;border:2px solid rgba(124,77,255,.26)">'
            f'<div class="tag" style="color:var(--b2)">{E(winter[0])}</div><div><div style="font-weight:900;font-size:40px">{gtext(winter[1], "p")}</div>'
            f'<div style="font-size:28px;font-weight:700;color:var(--gry);margin-top:12px">{E(winter[2])}</div></div></div>')
    i = b.clip(t, d, html, "left:0;top:0;width:1080px;height:1920px")
    _ed_cam(b, i, t, d, x0=40, y0=20, s0=1.04); _ed_type_js(b, i, t, d, caps, stimes)
    b.js(f'tl.fromTo("#{i} .b0",{{opacity:0,y:40}},{{opacity:1,y:0,duration:.6,ease:"expo.out"}},{t + .22:.3f});'
         f'tl.fromTo("#{i} .bf",{{scaleY:0}},{{scaleY:1,duration:.55,stagger:.06,ease:"expo.out"}},{t + .45:.3f});'
         f'tl.fromTo(["#{i} .b1","#{i} .b2"],{{opacity:0,y:44}},{{opacity:1,y:0,duration:.6,stagger:.14,ease:"expo.out"}},{s2 - .1:.3f});')

def ed_night(b, t, d, no="06", model="", val=6, sub="", caps=(), stimes=()):
    """원형 아이리스 다크모드 반전(#0D1017) + 십자선 레이저 스캔 야간 시야 뷰파인더"""
    html = (f'<div class="dk ed-dark" style="position:absolute;left:36px;top:214px;width:1008px;height:1460px;border-radius:46px;background:#0d1017;overflow:hidden;clip-path:circle(0% at 50% 50%)">'
            f'<div class="ed-meta" style="position:absolute;left:48px;right:48px;top:40px;color:#8fb0ff"><span>{E(no)}</span><span>{E(model)}</span></div>'
            f'<div class="ed-kwrap" style="left:48px;width:912px;top:106px">{_ed_type_html(caps)}</div>'
            f'<div style="position:absolute;left:48px;top:420px;width:912px;height:760px;border-radius:36px;border:1.5px solid rgba(255,255,255,.12);background:radial-gradient(circle at 50% 35%,rgba(36,92,255,.20),rgba(13,16,23,.95));overflow:hidden">'
            f'<div class="gh" style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;filter:blur(16px);opacity:.65">'
            f'<div style="width:420px;height:120px;border-radius:60px;background:linear-gradient(90deg,#ec4e94,#7c4dff)"></div></div>'
            f'<div class="scn" style="position:absolute;top:0;bottom:0;left:0;width:4px;background:#5983ff;box-shadow:0 0 28px #245cff"></div>'
            f'<div style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center">'
            f'<div style="font-family:PP,sans-serif;font-size:22px;font-weight:700;letter-spacing:.24em;color:#8fb0ff">INTERNAL REFLECTANCE</div>'
            f'<div class="tnum" style="font-weight:900;font-size:230px;color:#fff;line-height:1.05;margin-top:10px"><span class="n">20</span><span style="font-size:100px;color:#5983ff">%</span></div>'
            f'<div style="font-size:30px;font-weight:700;color:rgba(255,255,255,.72);margin-top:18px">{E(sub)}</div></div></div></div>')
    i = b.clip(t, d, html, "left:0;top:0;width:1080px;height:1920px")
    _ed_type_js(b, i, t, d, caps, stimes)
    b.js(f'tl.to("#{i} .dk",{{clipPath:"circle(100% at 50% 50%)",duration:.85,ease:"expo.inOut"}},{t:.3f});'
         f'tl.fromTo("#{i} .scn",{{x:0}},{{x:912,duration:1.5,ease:"power2.inOut"}},{t + .45:.3f});'
         f'tl.to("#{i} .gh",{{opacity:.06,duration:1.3,ease:"power2.out"}},{t + .55:.3f});'
         f'(function(){{const o={{v:18}};const el=document.querySelector("#{i} .n");tl.to(o,{{v:{val},duration:1.4,ease:"expo.out",onUpdate:()=>el.textContent=Math.round(o.v)}},{t + .45:.3f});}})();'
         f'tl.to("#{i} .dk",{{clipPath:"circle(0% at 50% 50%)",duration:.45,ease:"power2.in"}},{t + d - .46:.3f});')

def ed_verdict(b, t, d, no="07", left="", right="", sub="", caps=(), stimes=()):
    html = (f'<div class="ed-grid"></div>'
            f'<div class="ed-meta" style="position:absolute;left:72px;right:72px;top:234px"><span>{E(no)}</span><span>CONCLUSION</span></div>'
            f'<div class="ed-kwrap" style="top:296px">{_ed_type_html(caps)}</div>'
            f'<div style="position:absolute;left:72px;top:620px;width:936px;height:860px">'
            f'<div class="bm" style="position:absolute;left:88px;top:360px;width:760px;height:10px;border-radius:5px;background:#cbd1de;transform-origin:50% 50%">'
            f'<div class="card" style="left:-40px;top:-165px;width:360px;height:134px;display:flex;align-items:center;justify-content:center;font-size:34px;font-weight:700;color:var(--gry)">{E(left)}</div>'
            f'<div class="card" style="right:-40px;top:-175px;width:390px;height:148px;display:flex;align-items:center;justify-content:center;font-size:38px;font-weight:900;border:2.5px solid rgba(36,92,255,.28)">{gtext(right, "b")}</div></div>'
            f'<svg width="160" height="170" style="position:absolute;left:388px;top:368px"><path d="M80 8 L144 152 L16 152 Z" fill="#e6ebf5"/></svg>'
            f'<div style="position:absolute;bottom:140px;width:100%;text-align:center;font-size:32px;font-weight:700;color:var(--gry)">{E(sub)}</div></div>')
    i = b.clip(t, d, html, "left:0;top:0;width:1080px;height:1920px")
    _ed_cam(b, i, t, d, y0=30, s0=1.05); _ed_type_js(b, i, t, d, caps, stimes)
    b.js(f'tl.fromTo("#{i} .bm",{{rotation:-8}},{{rotation:9,duration:1.3,ease:"power3.inOut"}},{t + .25:.3f});')

CSS += ED_CSS
ED_PARTS = dict(ed_split=ed_split, ed_temp=ed_temp, ed_thermos=ed_thermos, ed_odometer=ed_odometer, ed_bento=ed_bento, ed_night=ed_night, ed_verdict=ed_verdict)
PARTS.update(ED_PARTS)

def build(spec, D, overlay=False):
    b_stg = B(); top_h = []   # 한 카운터로 id·트랙 번호를 매겨 클립끼리 트랙이 겹치지 않게(겹치면 헤더·로고가 중간에 사라짐)
    for it in _prepare_items(spec["items"], overlay):
        it = dict(it); p = it.pop("p"); n0 = len(b_stg.h)
        PARTS[p](b_stg, **it)
        if p in ("header", "logo"): top_h += b_stg.h[n0:]; del b_stg.h[n0:]
    b_top = B(); b_top.h = top_h
    js_all = b_stg.j
    if spec.get("zoomcut"):   # 장면 전환 순간 확대 + 블러(기본 끔 — 마틴: 화려한 펀치 줌 전환은 어색하다)
        cut_times = sorted({round(it["t"], 3) for it in spec["items"] if it.get("p") not in ("header", "logo", "bgword", "caption") and it.get("t", 0) > 0.6})
        for tc in cut_times:
            js_all.append(f'tl.to("#stage",{{scale:1.036,filter:"blur(2.5px)",duration:.16,ease:"power2.in"}},{tc - .16:.3f});'
                          f'tl.to("#stage",{{scale:1,filter:"blur(0px)",duration:.42,ease:"expo.out"}},{tc:.3f});')
    dur = spec["dur"]; bg = "transparent" if overlay else spec.get("bg", "#f4f6fa")
    html = f'''<!doctype html><html lang="ko"><head><meta charset="UTF-8"><meta name="viewport" content="width=1080, height=1920">
<script src="assets/gsap.min.js"></script><style>{CSS}{UICSS}{CAPTION_PRO_CSS}:root{{--bg:{bg}}}</style></head><body>{SVG_DEFS}
<div id="root" data-composition-id="main" data-start="0" data-duration="{dur:.3f}" data-width="1080" data-height="1920">
<div id="stage">{"".join(b_stg.h)}</div>{"".join(b_top.h)}</div>
<script>const tl=gsap.timeline({{paused:true}});{"".join(js_all)}
window.__timelines["main"]=tl;tl.seek(0);</script></body></html>'''
    os.makedirs(os.path.join(D, "assets", "fonts"), exist_ok=True)
    for f in os.listdir(os.path.join(KIT, "assets")):
        if f != "fonts": shutil.copy(os.path.join(KIT, "assets", f), os.path.join(D, "assets", f))
    for f in spec.get("files", []): shutil.copy(f, os.path.join(D, "assets", os.path.basename(f)))
    for f in ("package.json", "hyperframes.json"): shutil.copy(os.path.join(KIT, f), os.path.join(D, f))
    open(os.path.join(D, "index.html"), "w", encoding="utf-8").write(html)
    fonts(html, D)
    return html

def kr_font(w):
    from fontTools.ttLib import TTCollection, TTFont
    p = f"/usr/share/fonts/opentype/noto/NotoSansCJK-{w}.ttc"
    if os.path.exists(p): return [f for f in TTCollection(p).fonts if "KR" in f["name"].getDebugName(1)][0]
    for dd in (os.environ.get("MOTIF_FONT_DIR", ""), os.path.expanduser("~/mk/fonts"), os.path.expanduser("~/Library/Fonts"), "/Library/Fonts"):
        for nm in (f"NotoSansCJKkr-{w}.otf", f"NotoSansKR-{w}.otf", f"NotoSansKR-{w}.ttf"):
            q = os.path.join(dd, nm)
            if dd and os.path.exists(q): return TTFont(q)
    raise SystemExit(f"한글 폰트(NotoSansCJKkr-{w}.otf)를 찾지 못했습니다. setup_mac.sh를 다시 실행하세요.")

def fonts(html, D):
    from fontTools.ttLib import TTFont
    from fontTools import subset
    txt = H.unescape(re.sub(r"<[^>]+>", "", html.split("<body>")[1]))
    text = "".join(sorted(set(txt) | set("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz%/.,+-×=·~✓●⌕▼—→ ")))
    def sub(font_obj, dst):
        o = subset.Options(); o.flavor = "woff2"; tmp = f"/tmp/_hf_{os.path.basename(dst)}.otf"; font_obj.save(tmp)
        f = subset.load_font(tmp, o); s = subset.Subsetter(o); s.populate(text=text); s.subset(f); subset.save_font(f, dst, o)
    for src, dst in [("Regular", "kr-regular"), ("Bold", "kr-bold"), ("Black", "kr-black")]:
        sub(kr_font(src), os.path.join(D, "assets", "fonts", dst + ".woff2"))
    sub(TTFont(os.path.join(KIT, "assets", "NanumMyeongjo-ExtraBold.ttf")), os.path.join(D, "assets", "fonts", "tw-ko.woff2"))
    sub(TTFont(os.path.join(KIT, "assets", "SpecialElite-Regular.ttf")), os.path.join(D, "assets", "fonts", "tw-en.woff2"))
    for src, dst in [("Poppins-Medium.ttf", "pp-medium"), ("Poppins-Bold.ttf", "pp-bold"), ("Stylish-Regular.ttf", "stylish")]:
        sub(TTFont(os.path.join(KIT, "assets", src)), os.path.join(D, "assets", "fonts", dst + ".woff2"))

def render(D, out, overlay=False, quality="high"):
    env = dict(os.environ, DO_NOT_TRACK="1")
    if overlay:
        fr = os.path.join(D, "frames"); shutil.rmtree(fr, ignore_errors=True)
        subprocess.run(["npx", "--yes", "hyperframes@0.9.65", "render", "--format", "png-sequence", "--fps", "30", "--output", fr], cwd=D, env=env, check=True)
        return fr
    subprocess.run(["npx", "--yes", "hyperframes@0.9.65", "render", "--quality", quality, "--fps", "30", "--output", os.path.abspath(out)], cwd=D, env=env, check=True)
    return out

if __name__ == "__main__":
    ns = {}; exec(open(sys.argv[1], encoding="utf-8").read(), ns); spec = ns["SPEC"]
    overlay = "--overlay" in sys.argv; D = os.path.abspath(spec.get("dir", "/tmp/hf/job"))
    build(spec, D, overlay)
    if "--build" in sys.argv: print("built", D); sys.exit()
    print(render(D, sys.argv[2], overlay, "draft" if "--draft" in sys.argv else "high"))
