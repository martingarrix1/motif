"""MOTIF HyperFrames 부품 키트 (2026-11-22)
릴스 한 편 = spec(dict) 하나. 부품 이름과 글자·시간만 적으면 index.html을 만들고 렌더링한다.
사용: python3 hfkit.py spec.py out.mp4 [--overlay]   (spec.py 안에 SPEC = {...})
      --overlay : 배경 투명 PNG 시퀀스(플로우 영상 위에 겹칠 때)
부품 목록과 인자는 PARTS.md 참고.
"""
import json, os, re, sys, shutil, subprocess, html as H
KIT = os.path.dirname(os.path.abspath(__file__))
W, HH = 1080, 1920
E = H.escape

# ───────── 공통 CSS ─────────
CSS = r"""
@font-face{font-family:KR;font-weight:400;src:url(assets/fonts/kr-regular.woff2) format("woff2")}
@font-face{font-family:KR;font-weight:700;src:url(assets/fonts/kr-bold.woff2) format("woff2")}
@font-face{font-family:KR;font-weight:900;src:url(assets/fonts/kr-black.woff2) format("woff2")}
@font-face{font-family:ST;src:url(assets/fonts/stylish.woff2) format("woff2")}
@font-face{font-family:PP;font-weight:500;src:url(assets/fonts/pp-medium.woff2) format("woff2")}
@font-face{font-family:PP;font-weight:700;src:url(assets/fonts/pp-bold.woff2) format("woff2")}
@font-face{font-family:TWK;src:url(assets/fonts/tw-ko.woff2) format("woff2")}
@font-face{font-family:TWE;src:url(assets/fonts/tw-en.woff2) format("woff2")}
*{margin:0;padding:0;box-sizing:border-box}
html,body{width:1080px;height:1920px;overflow:hidden;background:var(--bg)}
:root{--bg:#f5f6f9;--ink:#16171c;--gry:#767a84;--lgt:#c6cad4;--b1:#245cff;--b2:#8052f2;--b3:#ec4e94;--n1:#ec5c42;--n2:#fa963c;--paper:#fcfaf5;--tw:#262422;--twb:#2240aa;--twr:#962834}
#root{position:relative;width:1080px;height:1920px;font-family:KR,sans-serif;color:var(--ink)}
.clip{position:absolute}
.card{position:absolute;background:#fff;border-radius:40px;box-shadow:0 26px 60px rgba(60,70,100,.16),0 4px 14px rgba(60,70,100,.06)}
.paper{background:var(--paper);border-radius:26px}
.g-b{background:linear-gradient(90deg,var(--b1),var(--b2))}.g-p{background:linear-gradient(90deg,var(--b2),var(--b3))}
.g-n{background:linear-gradient(90deg,var(--n1),var(--n2))}.g-bp{background:linear-gradient(90deg,var(--b1),var(--b2),var(--b3))}
.gt{-webkit-background-clip:text;background-clip:text;color:transparent}
.tag{font-weight:700;font-size:26px;color:var(--gry);letter-spacing:.06em}
.tagline{display:inline-block;width:64px;height:3px;background:var(--b1);vertical-align:middle;margin-left:14px;transform-origin:left}
.cap{left:72px;width:940px;font-weight:900;line-height:1.38}
.cap .row{display:block;white-space:nowrap}
.k{position:relative;display:inline-block}
.k .band{position:absolute;left:-6px;right:-6px;top:52%;bottom:2%;border-radius:8px;transform-origin:left;z-index:0}
.k em{position:relative;z-index:1;font-style:normal}
.band.b{background:#d6e0ff}.band.p{background:#f0dcf6}.band.n{background:#ffe2d6}.band.bp{background:#e2defc}
.gry{color:var(--gry)}
.bgw{font-weight:900;font-size:330px;color:#e2e7f3;white-space:nowrap;top:1330px;left:640px}
.tw{font-family:TWE,TWK,serif;color:var(--tw)}
.twk{font-family:TWK,TWE,serif}
.cursor{display:inline-block;width:.5em;height:.9em;background:var(--twb);vertical-align:-.1em;margin-left:6px;opacity:.85}
.ink{filter:url(#ink)}
"""
SVG_DEFS = """<svg width="0" height="0" style="position:absolute"><filter id="ink"><feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" seed="3"/><feColorMatrix values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 -1.0 1.4"/><feComposite in="SourceGraphic" operator="in"/><feGaussianBlur stdDeviation="0.35"/></filter></svg>"""

class B:
    """html·js 조각을 모은다"""
    def __init__(s): s.h = []; s.j = []; s.n = 0
    def id(s, p="e"): s.n += 1; return f"{p}{s.n}"
    def clip(s, t, d, inner, style="", cls=""):
        i = s.id("c"); s.h.append(f'<div id="{i}" class="clip {cls}" data-start="{t:.3f}" data-duration="{d:.3f}" data-track-index="{s.n}" style="{style}">{inner}</div>'); return i
    def js(s, code): s.j.append(code)

def gtext(txt, g="b", tag="span", cls=""):
    return f'<{tag} class="gt g-{g} {cls}">{E(txt)}</{tag}>'

def popin(b, sel, t, d=0.6, y=70, float_=True, out=None):
    b.js(f'tl.fromTo("{sel}",{{opacity:0,y:{y},scale:.94}},{{opacity:1,y:0,scale:1,duration:{d},ease:"back.out(1.6)"}},{t:.3f});')
    if float_: b.js(f'tl.to("{sel}",{{y:-9,duration:2.4,ease:"sine.inOut",yoyo:true,repeat:5}},{t + d:.3f});')
    if out is not None: b.js(f'tl.to("{sel}",{{opacity:0,y:-20,duration:.3,ease:"power2.in"}},{out - 0.32:.3f});')

# ───────── 부품 ─────────
def header(b, t, d, title, left="MOTIF", right="SOLAR GARD LX"):
    sp = lambda x: "&nbsp;".join(E(x))
    b.clip(t, d, f'<div style="position:absolute;left:44px;top:92px;width:8px;height:48px;border-radius:3px;background:var(--b1)"></div>'
                 f'<div style="position:absolute;left:68px;top:88px;font-weight:700;font-size:40px">{E(title)}</div>'
                 f'<div style="position:absolute;left:48px;top:164px;font-weight:700;font-size:20px;color:#3c3e46">{sp(left)}</div>'
                 f'<div style="position:absolute;right:48px;top:164px;font-size:20px;color:#787c86">{sp(right)}</div>', "left:0;top:0;width:1080px;height:220px")

def logo(b, t, d, name="motif", w=150, y=1780):
    src = {"motif": "motif_logo_dark.png", "motif_w": "motif_logo_light.png", "lxsg": "lxsg_ink_dark.png", "lxsg_w": "lxsg_ink_light.png", "thelx": "thelx_ink_dark.png"}[name]
    b.clip(t, d, f'<img src="assets/{src}" style="width:{w}px;display:block">', f"left:{540 - w / 2}px;top:{y}px;transform:translateY(-50%)")

def bgword(b, t, d, word):
    i = b.clip(t, d, f'<div class="w">{E(word)}</div>', "", "bgw")
    b.js(f'tl.fromTo("#{i} .w",{{opacity:0,x:40}},{{opacity:.9,x:0,duration:.9,ease:"power2.out"}},{t:.3f});tl.to("#{i} .w",{{x:-44*{d:.2f},duration:{d:.2f},ease:"none"}},{t:.3f});')

def caption(b, t, d, rows, y=1060, size=64):
    """rows=[[('글','b'),('~붙는말',None)], ...]  스타일: None 검정 · 'g' 회색 · 'b'/'p'/'n'/'bp' 그라데이션+형광펜"""
    out = []
    for r in rows:
        seg = []
        for k, (tx, st) in enumerate(r):
            glue = tx.startswith("~"); tx = tx.lstrip("~")
            sp = "" if (glue or k == 0) else " "
            if st in ("b", "p", "n", "bp"): seg.append(f'{sp}<span class="k"><i class="band {st}"></i><em class="gt g-{st}">{E(tx)}</em></span>')
            elif st == "g": seg.append(f'{sp}<span class="gry">{E(tx)}</span>')
            else: seg.append(f"{sp}{E(tx)}")
        out.append(f'<span class="row">{"".join(seg)}</span>')
    i = b.clip(t, d, "".join(out), f"top:{y}px;font-size:{size}px", "cap")
    b.js(f'tl.fromTo("#{i} .row",{{opacity:0,y:34}},{{opacity:1,y:0,duration:.5,ease:"power3.out",stagger:.14}},{t:.3f});'
         f'tl.fromTo("#{i} .band",{{scaleX:0}},{{scaleX:1,duration:.5,ease:"power2.out",stagger:.1}},{t + .3:.3f});'
         f'tl.to("#{i}",{{opacity:0,duration:.22}},{t + d - .24:.3f});')

def kinetic(b, t, d, words, y=700, size=120, g="bp"):
    """후킹용: 단어가 하나씩 튀어 들어온다. words=[('썬팅',None),('3년','n')]"""
    inner = "".join(f'<span class="wd" style="display:inline-block;margin-right:.25em">{gtext(w, s) if s else E(w)}</span>' for w, s in words)
    i = b.clip(t, d, inner, f"left:72px;top:{y}px;width:940px;font-weight:900;font-size:{size}px;line-height:1.2")
    b.js(f'tl.fromTo("#{i} .wd",{{opacity:0,y:60,scale:1.25}},{{opacity:1,y:0,scale:1,duration:.45,ease:"back.out(2)",stagger:.16}},{t:.3f});tl.to("#{i}",{{opacity:0,duration:.25}},{t + d - .27:.3f});')

def titlecard(b, t, d, box, tag, lines, size=80, paper=False):
    """lines=[('글','b'), ...] 태그 + 큰 그라데이션 글씨 카드"""
    x, y, w, h = box
    ln = "".join(f'<div class="ln" style="font-size:{size}px;font-weight:900;line-height:1.18">{gtext(s, g) if g else E(s)}</div>' for s, g in lines)
    i = b.clip(t, d, f'<div class="card {"paper" if paper else ""}" style="left:0;top:0;width:{w}px;height:{h}px;padding:40px 44px"><div class="tag">{E(tag)}<span class="tagline"></span></div><div style="margin-top:14px">{ln}</div></div>', f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d)
    b.js(f'tl.fromTo("#{i} .tagline",{{scaleX:0}},{{scaleX:1,duration:.6}},{t + .2:.3f});tl.fromTo("#{i} .ln",{{opacity:0,y:24}},{{opacity:1,y:0,duration:.45,stagger:.12}},{t + .2:.3f});')

def strike(b, t, d, box, text, at, to=None, to_g="bp", size=52):
    """취소선이 그어지는 카드. to='새 단어'면 아래에 새 카드가 튀어 나온다"""
    x, y, w, h = box
    inner = f'<div class="card" style="left:0;top:0;width:{w}px;height:{h}px;display:flex;align-items:center;justify-content:center"><span style="position:relative;font-weight:900;font-size:{size}px;color:var(--gry)">{E(text)}<i class="st" style="position:absolute;left:-16px;right:-16px;top:52%;height:7px;background:var(--b3);border-radius:4px;transform-origin:left"></i></span></div>'
    if to: inner += f'<div class="card nw" style="left:30px;top:{h + 40}px;width:{w - 60}px;height:{h + 20}px;display:flex;align-items:center;justify-content:center">{gtext(to, to_g)}</div>'
    i = b.clip(t, d, inner, f"left:{x}px;top:{y}px;width:{w}px;height:{2 * h + 80}px;font-size:{size + 14}px;font-weight:900")
    popin(b, f"#{i} .card:first-child", t, out=t + d, float_=False)
    b.js(f'tl.fromTo("#{i} .st",{{scaleX:0}},{{scaleX:1,duration:.5,ease:"power2.inOut"}},{at:.3f});')
    if to: popin(b, f"#{i} .nw", at + .45, out=t + d)

def checklist(b, t, d, box, title, items):
    """items=[('품목', 체크시각), ...]"""
    x, y, w, h = box
    rows = "".join(f'<div class="ci" style="display:flex;align-items:center;gap:22px;height:78px"><span class="cb" style="position:relative;width:46px;height:46px;border-radius:50%;border:3px solid var(--lgt)"><svg viewBox="0 0 46 46" style="position:absolute;left:-3px;top:-3px;width:46px;height:46px"><circle class="cf" cx="23" cy="23" r="23" fill="#245cff"/><path class="ck" d="M13 24 L20 31 L33 16" stroke="#fff" stroke-width="5" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="40" stroke-dashoffset="40"/></svg></span><span class="cl" style="font-weight:700;font-size:36px;color:var(--lgt)">{E(n)}</span></div>' for n, _ in items)
    i = b.clip(t, d, f'<div class="card" style="left:0;top:0;width:{w}px;height:{h}px;padding:44px 56px"><div class="tag" style="color:var(--b1)">PACKAGE</div><div style="font-weight:900;font-size:46px;margin:6px 0 18px">{gtext(title, "b")}</div>{rows}</div>', f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d)
    for k, (_, tk) in enumerate(items):
        b.js(f'tl.fromTo("#{i} .ci:nth-child({k + 3}) .cf",{{scale:0,transformOrigin:"50% 50%"}},{{scale:1,duration:.35,ease:"back.out(2)"}},{tk:.3f});'
             f'tl.to("#{i} .ci:nth-child({k + 3}) .ck",{{strokeDashoffset:0,duration:.35}},{tk + .15:.3f});'
             f'tl.to("#{i} .ci:nth-child({k + 3}) .cl",{{color:"#16171c",duration:.25}},{tk:.3f});')

def hbars(b, t, d, box, title, rows, vmax, unit="", ticks=(), gcls=("b", "b", "b")):
    """rows=[('라벨', 값, 시작시각), ...] 가로 막대가 자라며 숫자가 올라간다"""
    x, y, w, h = box; bw = w - 300
    rs = "".join(f'<div class="hr" style="position:relative;height:118px"><div style="font-weight:700;font-size:32px">{E(l)}</div><div class="bar g-{gcls[min(k, len(gcls) - 1)]}" style="position:absolute;left:0;top:50px;height:38px;width:{bw * v / vmax:.0f}px;border-radius:19px;transform-origin:left"></div><div class="vl" style="position:absolute;left:{bw * v / vmax + 18:.0f}px;top:44px;font-weight:900;font-size:40px;color:var(--b1)"><span class="n">0</span>{E(unit)}</div></div>' for k, (l, v, _) in enumerate(rows))
    tk = "".join(f'<div style="position:absolute;left:{56 + bw * v / vmax:.0f}px;bottom:30px;font-size:22px;color:#a0a4ac;transform:translateX(-50%)">{v}</div>' for v in ticks)
    i = b.clip(t, d, f'<div class="card" style="left:0;top:0;width:{w}px;height:{h}px;padding:44px 56px"><div class="tag">{E(title)}</div><div style="position:absolute;left:56px;top:110px;bottom:70px;border-left:3px solid var(--lgt)"></div><div style="position:absolute;left:56px;right:56px;bottom:70px;border-top:3px solid var(--lgt)"></div><div style="margin-top:36px">{rs}</div>{tk}</div>', f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, float_=False)
    for k, (_, v, tk_) in enumerate(rows):
        b.js(f'tl.fromTo("#{i} .hr:nth-child({k + 1})",{{opacity:0}},{{opacity:1,duration:.25}},{tk_:.3f});'
             f'tl.fromTo("#{i} .hr:nth-child({k + 1}) .bar",{{scaleX:0}},{{scaleX:1,duration:1,ease:"power3.out"}},{tk_:.3f});'
             f'tl.fromTo("#{i} .hr:nth-child({k + 1}) .vl",{{x:-{bw * v / vmax:.0f}}},{{x:0,duration:1,ease:"power3.out"}},{tk_:.3f});'
             f'(function(){{const o={{v:0}};const el=document.querySelector("#{i} .hr:nth-child({k + 1}) .n");tl.to(o,{{v:{v},duration:1,ease:"power3.out",onUpdate:()=>el.textContent=Math.round(o.v)}},{tk_:.3f});}})();')

def xyline(b, t, d, box, title, pts, vmax, at, dur=2.6, thr=None, thr_label="", caption_="", over_label=""):
    """XY 꺾은선: pts=[('라벨',값),...] 선이 그려지며 점이 찍힌다. thr=기준 점선(넘는 점은 빨간색)"""
    x, y, w, h = box; X0, X1, Y0, Y1 = 90, w - 60, h - 110, 120
    n = len(pts); P = [(X0 + 30 + (X1 - X0 - 60) * k / (n - 1), Y0 - (Y0 - Y1) * v / vmax) for k, (_, v) in enumerate(pts)]
    path = "M%.0f %.0f " % (X0, Y0) + " ".join("L%.0f %.0f" % p for p in P)
    L = sum(((P[k][0] - (P[k - 1][0] if k else X0)) ** 2 + (P[k][1] - (P[k - 1][1] if k else Y0)) ** 2) ** .5 for k in range(n))
    dots = "".join(f'<circle class="dt" cx="{p[0]:.0f}" cy="{p[1]:.0f}" r="10" fill="{"#ec5c42" if thr is not None and pts[k][1] > thr else "#245cff"}"/>' for k, p in enumerate(P))
    xl = "".join(f'<text x="{p[0]:.0f}" y="{Y0 + 40}" font-size="22" fill="#767a84" text-anchor="middle" font-family="KR">{E(pts[k][0])}</text>' for k, p in enumerate(P))
    th = ""
    if thr is not None:
        ty = Y0 - (Y0 - Y1) * thr / vmax
        th = f'<line class="th" x1="{X0}" y1="{ty:.0f}" x2="{X1}" y2="{ty:.0f}" stroke="#767a84" stroke-width="3" stroke-dasharray="14 12"/><text class="thl" x="{X1}" y="{ty - 16:.0f}" font-size="24" fill="#767a84" text-anchor="end" font-family="KR">{E(thr_label)}</text>'
    svg = f'<svg width="{w}" height="{h}" style="position:absolute;left:0;top:0"><path d="M{X0} {Y1 - 20} L{X0} {Y0} L{X1} {Y0}" stroke="#c6cad4" stroke-width="3" fill="none"/>{th}<path class="ln" d="{path}" stroke="#245cff" stroke-width="8" fill="none" stroke-linejoin="round" stroke-linecap="round" stroke-dasharray="{L:.0f}" stroke-dashoffset="{L:.0f}"/>{dots}{xl}</svg>'
    ol = f'<div class="ov" style="position:absolute;right:60px;top:{P[-1][1] - 70:.0f}px;font-weight:700;font-size:26px;color:var(--n1)">{E(over_label)}</div>' if over_label else ""
    i = b.clip(t, d, f'<div class="card" style="left:0;top:0;width:{w}px;height:{h}px"><div style="position:absolute;left:0;right:0;top:44px;text-align:center;font-size:24px;color:var(--gry)">{E(title)}</div>{svg}{ol}<div style="position:absolute;left:0;right:0;bottom:22px;text-align:center;font-size:22px;color:#a0a4ac">{E(caption_)}</div></div>', f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, float_=False)
    if thr is not None: b.js(f'tl.fromTo("#{i} .th,#{i} .thl",{{opacity:0}},{{opacity:1,duration:.5}},{at - .3:.3f});')
    b.js(f'tl.to("#{i} .ln",{{strokeDashoffset:0,duration:{dur},ease:"power1.inOut"}},{at:.3f});')
    for k in range(n): b.js(f'tl.fromTo("#{i} .dt:nth-of-type({k + 1})",{{scale:0,transformOrigin:"50% 50%",transformBox:"fill-box"}},{{scale:1,duration:.3,ease:"back.out(2.5)"}},{at + dur * (k + 1) / n - .1:.3f});')
    if over_label: b.js(f'tl.fromTo("#{i} .ov",{{opacity:0,y:10}},{{opacity:1,y:0,duration:.4}},{at + dur - .2:.3f});')

def counter(b, t, d, box, label, v0, v1, unit="", g="bp", at=None, bar=None, size=200, caption_=""):
    """큰 숫자 카운트 (+ 아래 막대 선택: bar=(최댓값))"""
    x, y, w, h = box; at = t + .4 if at is None else at
    br = f'<div style="position:absolute;left:60px;right:60px;bottom:70px;height:26px;border-radius:13px;background:#eef0f5"><div class="br g-{g}" style="height:100%;width:{100 * v1 / bar:.1f}%;border-radius:13px;transform-origin:left"></div></div>' if bar else ""
    i = b.clip(t, d, f'<div class="card" style="left:0;top:0;width:{w}px;height:{h}px;text-align:center;padding-top:48px"><div class="tag">{E(label)}</div><div style="font-weight:900;font-size:{size}px;line-height:1.1">{f"<span class=\"gt g-{g} n\">{v0}</span>"}<span class="gt g-{g}" style="font-size:{size * .45:.0f}px">{E(unit)}</span></div><div style="font-size:26px;color:var(--gry)">{E(caption_)}</div>{br}</div>', f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d)
    dec = 0 if float(v1).is_integer() else 1
    b.js(f'(function(){{const o={{v:{v0}}};const el=document.querySelector("#{i} .n");tl.to(o,{{v:{v1},duration:1.3,ease:"power3.out",onUpdate:()=>el.textContent=o.v.toFixed({dec})}},{at:.3f});}})();')
    if bar: b.js(f'tl.fromTo("#{i} .br",{{scaleX:0}},{{scaleX:1,duration:1.3,ease:"power3.out"}},{at:.3f});')

def ring(b, t, d, box, label, pct, at=None, g=("#245cff", "#8052f2"), sub=""):
    """원형 게이지가 차오른다"""
    x, y, w, h = box; at = t + .4 if at is None else at; R = min(w, h) * .32; C = 2 * 3.14159 * R
    gid = b.id("rg")
    svg = f'<svg width="{w}" height="{h}" style="position:absolute;left:0;top:0"><defs><linearGradient id="{gid}"><stop offset="0" stop-color="{g[0]}"/><stop offset="1" stop-color="{g[1]}"/></linearGradient></defs><circle cx="{w / 2}" cy="{h / 2 + 20}" r="{R:.0f}" stroke="#eef0f5" stroke-width="34" fill="none"/><circle class="rr" cx="{w / 2}" cy="{h / 2 + 20}" r="{R:.0f}" stroke="url(#{gid})" stroke-width="34" fill="none" stroke-linecap="round" stroke-dasharray="{C:.0f}" stroke-dashoffset="{C:.0f}" transform="rotate(-90 {w / 2} {h / 2 + 20})"/></svg>'
    i = b.clip(t, d, f'<div class="card" style="left:0;top:0;width:{w}px;height:{h}px">{svg}<div class="tag" style="position:absolute;top:40px;width:100%;text-align:center">{E(label)}</div><div style="position:absolute;top:{h / 2 - 50}px;width:100%;text-align:center;font-weight:900;font-size:100px"><span class="n gt g-b">0</span><span class="gt g-b" style="font-size:50px">%</span></div><div style="position:absolute;top:{h / 2 + 60}px;width:100%;text-align:center;font-size:26px;color:var(--gry)">{E(sub)}</div></div>', f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d)
    b.js(f'tl.to("#{i} .rr",{{strokeDashoffset:{C * (1 - pct / 100):.0f},duration:1.4,ease:"power3.out"}},{at:.3f});(function(){{const o={{v:0}};const el=document.querySelector("#{i} .n");tl.to(o,{{v:{pct},duration:1.4,ease:"power3.out",onUpdate:()=>el.textContent=Math.round(o.v)}},{at:.3f});}})();')

def seesaw(b, t, d, left, right, y=380, note="", lg="b", rg="n"):
    """시소: 두 가치가 번갈아 기운다"""
    i = b.clip(t, d, f'<div class="bm" style="position:absolute;left:230px;top:{y + 190}px;width:620px;height:12px;background:var(--ink);border-radius:6px;transform-origin:50% 50%">'
                     f'<div class="card" style="left:-150px;top:-150px;width:300px;height:110px;display:flex;align-items:center;justify-content:center;font-weight:900;font-size:50px">{gtext(left, lg)}</div>'
                     f'<div class="card" style="left:470px;top:-150px;width:300px;height:110px;display:flex;align-items:center;justify-content:center;font-weight:900;font-size:50px">{gtext(right, rg)}</div></div>'
                     f'<div style="position:absolute;left:480px;top:{y + 200}px;width:0;height:0;border-left:60px solid transparent;border-right:60px solid transparent;border-bottom:190px solid var(--ink)"></div>'
                     f'<div style="position:absolute;left:0;width:1080px;top:{y + 420}px;text-align:center;font-size:30px;color:var(--gry)">{E(note)}</div>', "left:0;top:0;width:1080px;height:1000px")
    b.js(f'tl.fromTo("#{i}",{{opacity:0,y:50}},{{opacity:1,y:0,duration:.6,ease:"back.out(1.5)"}},{t:.3f});tl.fromTo("#{i} .bm",{{rotation:-10}},{{rotation:10,duration:1.3,ease:"sine.inOut",yoyo:true,repeat:{max(1, int(d / 1.3))}}},{t:.3f});tl.to("#{i}",{{opacity:0,duration:.3}},{t + d - .32:.3f});')

def steps(b, t, d, items, y=340, gap=210):
    """단계 카드가 화살표로 이어진다. items=[('글','b',시각), ...]"""
    inner = ""
    for k, (s, g, tk) in enumerate(items):
        inner += f'<div class="st{k} card" style="left:230px;top:{y + k * gap}px;width:620px;height:140px;display:flex;align-items:center;justify-content:center;font-weight:900;font-size:56px"><span style="position:absolute;left:40px;font-size:28px;color:var(--lgt)">0{k + 1}</span>{gtext(s, g)}</div>'
        if k: inner += f'<div class="ar{k}" style="position:absolute;left:534px;top:{y + k * gap - 62}px;width:12px;height:46px;background:var(--b1);border-radius:6px"><i style="position:absolute;left:-10px;bottom:-14px;border-left:16px solid transparent;border-right:16px solid transparent;border-top:20px solid var(--b1)"></i></div>'
    i = b.clip(t, d, inner, "left:0;top:0;width:1080px;height:1200px")
    for k, (_, _, tk) in enumerate(items):
        popin(b, f"#{i} .st{k}", tk, out=t + d, float_=False)
        if k: b.js(f'tl.fromTo("#{i} .ar{k}",{{opacity:0,scaleY:0,transformOrigin:"50% 0"}},{{opacity:1,scaleY:1,duration:.35}},{tk - .15:.3f});tl.to("#{i} .ar{k}",{{opacity:0,duration:.3}},{t + d - .32:.3f});')

def versus(b, t, d, a, bb, y=380, at2=None):
    """두 카드 비교: a=('라벨','값','부제',grad)"""
    at2 = t + .7 if at2 is None else at2; inner = ""
    for k, (lab, val, sub, g) in enumerate([a, bb]):
        x = 96 + k * 468
        inner += f'<div class="v{k} card" style="left:{x}px;top:{y}px;width:420px;height:420px;text-align:center;padding-top:60px"><div class="tag">{E(lab)}</div><div style="font-weight:900;font-size:120px;line-height:1.3">{gtext(val, g)}</div><div style="font-size:28px;color:var(--gry)">{E(sub)}</div></div>'
    inner += f'<div class="vs" style="position:absolute;left:500px;top:{y + 170}px;width:80px;height:80px;border-radius:50%;background:var(--ink);color:#fff;font-weight:900;font-size:30px;display:flex;align-items:center;justify-content:center">VS</div>'
    i = b.clip(t, d, inner, "left:0;top:0;width:1080px;height:1000px")
    popin(b, f"#{i} .v0", t, out=t + d); popin(b, f"#{i} .v1", at2, out=t + d)
    b.js(f'tl.fromTo("#{i} .vs",{{scale:0}},{{scale:1,duration:.4,ease:"back.out(3)"}},{at2 + .3:.3f});tl.to("#{i} .vs",{{opacity:0,duration:.3}},{t + d - .32:.3f});')

def photo(b, t, d, box, src, badge=None, label=None, zoom=1.08):
    """실차 사진 카드(느린 확대) + 배지 + 왼쪽 위 라벨. src는 assets/ 안 파일"""
    x, y, w, h = box
    bd = f'<div class="bd card" style="right:-20px;bottom:-30px;padding:16px 30px;border-radius:30px;font-weight:900;font-size:50px">{gtext(badge, "b")}</div>' if badge else ""
    lb = f'<div style="position:absolute;left:24px;top:24px;padding:8px 22px;border-radius:24px;background:rgba(20,20,24,.75);color:#fff;font-weight:700;font-size:26px">{E(label)}</div>' if label else ""
    i = b.clip(t, d, f'<div class="card" style="left:0;top:0;width:{w}px;height:{h}px;overflow:visible"><div style="position:absolute;inset:0;border-radius:40px;overflow:hidden"><img class="ph" src="assets/{src}" style="width:100%;height:100%;object-fit:cover"></div>{lb}{bd}</div>', f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, float_=False)
    b.js(f'tl.fromTo("#{i} .ph",{{scale:1}},{{scale:{zoom},duration:{d},ease:"none"}},{t:.3f});')
    if badge: b.js(f'tl.fromTo("#{i} .bd",{{opacity:0,scale:.6}},{{opacity:1,scale:1,duration:.45,ease:"back.out(2.5)"}},{t + .8:.3f});')

def spectrum(b, t, d, y=380, pass_label="가시광선 · 통과", block_label="태양에너지 · 차단", at=None):
    """스펙트럼 막대: 왼쪽(가시광선)은 선이 통과, 오른쪽(적외선)은 막힌다"""
    at = t + .6 if at is None else at
    lines = "".join(f'<div class="sl" style="position:absolute;left:{170 + k * 70}px;top:{y + 80}px;width:6px;height:240px;background:{c};border-radius:3px;transform-origin:top"></div>' for k, c in enumerate(["#8a5cf0", "#3c78fa", "#3cbe6e", "#f0c432"]))
    blocks = "".join(f'<div class="bl" style="position:absolute;left:{640 + k * 80}px;top:{y + 80}px;width:6px;height:90px;background:#ec5c42;border-radius:3px;transform-origin:top"></div><div class="bx" style="position:absolute;left:{628 + k * 80}px;top:{y + 175}px;font-weight:900;font-size:34px;color:#ec5c42">×</div>' for k in range(3))
    i = b.clip(t, d, f'<div class="sp" style="position:absolute;left:120px;top:{y}px;width:840px;height:64px;border-radius:32px;background:linear-gradient(90deg,#965ae6,#3c78fa,#3cbe6e,#f0c432,#f05046,#a02c2c)"></div>'
                     f'<div style="position:absolute;left:120px;top:{y - 50}px;font-size:26px;color:var(--gry)">가시광선</div><div style="position:absolute;right:120px;top:{y - 50}px;font-size:26px;color:var(--n1)">근적외선</div>{lines}{blocks}'
                     f'<div class="pl" style="position:absolute;left:150px;top:{y + 350}px;font-weight:900;font-size:32px;color:var(--b1)">{E(pass_label)}</div><div class="pl" style="position:absolute;right:120px;top:{y + 350}px;font-weight:900;font-size:32px;color:var(--n1)">{E(block_label)}</div>', "left:0;top:0;width:1080px;height:1000px")
    b.js(f'tl.fromTo("#{i} .sp",{{scaleX:0,transformOrigin:"left"}},{{scaleX:1,duration:.7,ease:"power3.out"}},{t:.3f});tl.fromTo("#{i} .sl,#{i} .bl",{{scaleY:0}},{{scaleY:1,duration:.6,stagger:.08}},{at:.3f});tl.fromTo("#{i} .bx,#{i} .pl",{{opacity:0}},{{opacity:1,duration:.4,stagger:.08}},{at + .6:.3f});tl.to("#{i}",{{opacity:0,duration:.3}},{t + d - .32:.3f});')

def waves(b, t, d, y=360, glass="Tinted Glass", passed=True, note_l="태양에너지", note_r="그대로 통과"):
    """파동이 유리판을 지나가는(또는 막히는) 개념도"""
    wv = ""
    for k in range(4):
        L = 900 if passed or k == 0 else 470
        p = "M60 0 " + " ".join(f"Q{60 + j * 40 + 20} {(-14 if j % 2 == 0 else 14)} {60 + (j + 1) * 40} 0" for j in range(int((L - 60) / 40)))
        wv += f'<svg class="wv" width="1000" height="40" style="position:absolute;left:40px;top:{y + 80 + k * 80}px;overflow:visible"><path d="{p}" transform="translate(0,20)" stroke="#ec5c42" stroke-width="4" fill="none" stroke-dasharray="1200" stroke-dashoffset="1200"/></svg>'
    i = b.clip(t, d, f'<div class="gl" style="position:absolute;left:500px;top:{y + 40}px;width:40px;height:360px;border-radius:8px;background:#9ccdaf;border:3px solid #6aa784"></div>{wv}'
                     f'<div style="position:absolute;left:470px;top:{y + 420}px;font-weight:700;font-size:26px;color:#4e9268">{E(glass)}</div><div style="position:absolute;left:60px;top:{y}px;font-weight:700;font-size:26px;color:var(--n1)">{E(note_l)}</div><div class="nr card" style="right:70px;top:{y - 20}px;padding:10px 24px;border-radius:24px;font-weight:700;font-size:26px;color:var(--n1)">{E(note_r)}</div>', "left:0;top:0;width:1080px;height:1000px")
    b.js(f'tl.fromTo("#{i} .gl",{{opacity:0,scaleY:.3}},{{opacity:1,scaleY:1,duration:.5,ease:"back.out(1.5)"}},{t:.3f});tl.to("#{i} .wv path",{{strokeDashoffset:0,duration:1.8,ease:"none",stagger:.25}},{t + .3:.3f});tl.fromTo("#{i} .nr",{{opacity:0,scale:.7}},{{opacity:1,scale:1,duration:.4,ease:"back.out(2)"}},{t + 1.6:.3f});tl.to("#{i}",{{opacity:0,duration:.3}},{t + d - .32:.3f});')

def timeline(b, t, d, items, y=360):
    """세로 타임라인: items=[('시점','내용',시각), ...]"""
    inner = f'<div class="tl0" style="position:absolute;left:180px;top:{y}px;width:6px;height:{len(items) * 150}px;background:var(--lgt);border-radius:3px;transform-origin:top"></div>'
    for k, (a, s, tk) in enumerate(items):
        inner += f'<div class="ti{k}" style="position:absolute;left:150px;top:{y + k * 150}px;width:800px;height:120px"><span style="position:absolute;left:12px;top:30px;width:42px;height:42px;border-radius:50%;background:var(--b1);border:8px solid #dbe4ff"></span><div class="card" style="left:100px;top:0;width:690px;height:110px;padding:18px 34px"><div class="tag">{E(a)}</div><div style="font-weight:900;font-size:40px">{E(s)}</div></div></div>'
    i = b.clip(t, d, inner, "left:0;top:0;width:1080px;height:1200px")
    b.js(f'tl.fromTo("#{i} .tl0",{{scaleY:0}},{{scaleY:1,duration:{max(.6, items[-1][2] - t):.2f},ease:"none"}},{t:.3f});')
    for k, (_, _, tk) in enumerate(items): popin(b, f"#{i} .ti{k}", tk, out=t + d, float_=False, y=40)

def typeline(b, t, d, box, lines, size=64, cps=12, paper=True, tag=None):
    """타자기 카드: lines=[('글','ink'|'blue'|'red'), ...] 한 글자씩 찍히고 커서가 깜빡인다"""
    x, y, w, h = box; col = {"ink": "var(--tw)", "blue": "var(--twb)", "red": "var(--twr)"}
    ls = "".join(f'<div class="tl{k} ink" style="font-size:{size}px;line-height:1.3;color:{col[c]};white-space:nowrap">' + "".join(f'<span class="ch" style="display:none">{E(ch) if ch != " " else "&nbsp;"}</span>' for ch in s) + '</div>' for k, (s, c) in enumerate(lines))
    ls = ls.replace("</div>", '<span class="cursor" style="display:none"></span></div>')
    tg = f'<div class="ink" style="font-family:TWE;font-size:28px;color:var(--gry);margin-bottom:14px">{E(tag)}</div>' if tag else ""
    i = b.clip(t, d, f'<div class="card {"paper" if paper else ""} tw" style="left:0;top:0;width:{w}px;height:{h}px;padding:40px 44px">{tg}{ls}</div>', f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, float_=False)
    ts = t + .35
    for k, (s, _) in enumerate(lines):
        b.js(f'tl.set("#{i} .cursor",{{display:"none"}},{ts:.3f});tl.set("#{i} .tl{k} .cursor",{{display:"inline-block"}},{ts:.3f});tl.to("#{i} .tl{k} .ch",{{display:"inline",duration:.01,stagger:{1 / cps:.3f}}},{ts:.3f});'); ts += len(s) / cps + .2
    b.js(f'tl.fromTo("#{i} .cursor",{{opacity:0}},{{opacity:.85,duration:.01,repeat:{int(d * 2.4)},yoyo:true,repeatDelay:.4}},{t:.3f});')
    return ts

def receipt(b, t, d, box, title, rows, cps=40, red_last=True):
    """타자기 영수증: rows=[('품목','가격'), ...] 품목 → 점선 → 가격이 찍힌다"""
    x, y, w, h = box; inner = f'<div class="ink" style="font-family:TWE;font-size:30px;color:var(--gry);margin-bottom:26px">{E(title)}</div>'
    for k, (n, v) in enumerate(rows):
        c = "var(--twr)" if red_last and k == len(rows) - 1 else "var(--tw)"
        inner += f'<div class="r{k} ink" style="display:flex;align-items:center;height:96px;font-size:42px;color:{c}"><span class="nm">' + "".join(f'<span class="ch" style="display:none">{E(ch) if ch != " " else "&nbsp;"}</span>' for ch in n) + f'</span><span class="dl" style="flex:1;margin:0 18px;border-bottom:4px dotted #c6cad4;transform-origin:left"></span><span class="vv">' + "".join(f'<span class="ch" style="display:none">{E(ch) if ch != " " else "&nbsp;"}</span>' for ch in v) + '</span></div>'
    i = b.clip(t, d, f'<div class="card paper tw" style="left:0;top:0;width:{w}px;height:{h}px;padding:44px 50px">{inner}</div>', f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, float_=False)
    ts = t + .3
    for k, (n, v) in enumerate(rows):
        b.js(f'tl.to("#{i} .r{k} .nm .ch",{{display:"inline",duration:.01,stagger:{1 / cps:.3f}}},{ts:.3f});tl.fromTo("#{i} .r{k} .dl",{{scaleX:0}},{{scaleX:1,duration:.22}},{ts + len(n) / cps:.3f});tl.to("#{i} .r{k} .vv .ch",{{display:"inline",duration:.01,stagger:{1 / cps:.3f}}},{ts + len(n) / cps + .22:.3f});')
        ts += (len(n) + len(v)) / cps + .34
    return ts

def slot(b, t, d, box, label, value, unit="", at=None, g="bp"):
    """슬롯머신처럼 숫자가 굴러 멈춘다(자릿수별)"""
    x, y, w, h = box; at = t + .4 if at is None else at; digs = str(value); S = 170
    cols = "".join(f'<span style="display:inline-block;height:{S * 1.15:.0f}px;overflow:hidden;vertical-align:top"><span class="dg{k}" style="display:block">' + "".join(f'<span class="gt g-{g}" style="display:block;height:{S * 1.15:.0f}px;line-height:{S * 1.15:.0f}px">{(int(c) + j) % 10 if c.isdigit() else c}</span>' for j in range(10, -1, -1)) + '</span></span>' for k, c in enumerate(digs))
    i = b.clip(t, d, f'<div class="card" style="left:0;top:0;width:{w}px;height:{h}px;text-align:center;padding-top:44px"><div class="tag">{E(label)}</div><div style="font-weight:900;font-size:{S}px">{cols}<span class="gt g-{g}" style="font-size:{S * .4:.0f}px">{E(unit)}</span></div></div>', f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, float_=False)
    for k, c in enumerate(digs):
        if c.isdigit(): b.js(f'tl.fromTo("#{i} .dg{k}",{{y:0}},{{y:-{S * 1.15 * 10:.0f},duration:{1.1 + k * .25:.2f},ease:"power4.out"}},{at:.3f});')

def compare(b, t, d, box, left, right, at=None):
    """좌우 비교 슬라이더(이전/이후): left/right=('라벨','assets 이미지')"""
    x, y, w, h = box; at = t + .5 if at is None else at
    i = b.clip(t, d, f'<div class="card" style="left:0;top:0;width:{w}px;height:{h}px;overflow:hidden"><img src="assets/{right[1]}" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover"><div class="lf" style="position:absolute;inset:0;clip-path:inset(0 0% 0 0)"><img src="assets/{left[1]}" style="width:{w}px;height:{h}px;object-fit:cover"></div><div class="hd" style="position:absolute;top:0;bottom:0;left:0;width:6px;background:#fff;box-shadow:0 0 12px rgba(0,0,0,.3)"></div><div style="position:absolute;left:24px;top:24px;padding:8px 20px;border-radius:22px;background:rgba(20,20,24,.75);color:#fff;font-weight:700;font-size:26px">{E(left[0])}</div><div style="position:absolute;right:24px;top:24px;padding:8px 20px;border-radius:22px;background:var(--b1);color:#fff;font-weight:700;font-size:26px">{E(right[0])}</div></div>', f"left:{x}px;top:{y}px;width:{w}px;height:{h}px")
    popin(b, f"#{i} .card", t, out=t + d, float_=False)
    b.js(f'tl.fromTo("#{i} .lf",{{clipPath:"inset(0 0% 0 0)"}},{{clipPath:"inset(0 50% 0 0)",duration:1.2,ease:"power3.inOut"}},{at:.3f});tl.fromTo("#{i} .hd",{{x:{w}}},{{x:{w * .5:.0f},duration:1.2,ease:"power3.inOut"}},{at:.3f});')

def endcard(b, t, d, logo_="motif", lines=("솔라가드 THE LX 전주 유일 공식 특화샵",), phone="010-4814-4506", addr="전주 덕진구 정여립로 1104", big=None):
    src = {"motif": "motif_logo_dark.png", "lxsg": "lxsg_ink_dark.png"}[logo_]
    ln = "".join(f'<div class="e" style="font-weight:700;font-size:38px;margin-top:26px">{E(s)}</div>' for s in lines)
    mid = f'<div class="e" style="font-size:32px;color:var(--gry);margin-top:44px">시공 및 예약 문의</div><div class="e" style="font-weight:900;font-size:100px">{gtext(phone, "bp")}</div><div class="e" style="font-size:32px;color:var(--gry)">{E(addr)}</div>' if phone else ""
    bg = f'<div class="e" style="font-weight:900;font-size:76px;margin-top:40px">{gtext(big, "bp")}</div>' if big else ""
    i = b.clip(t, d, f'<div style="position:absolute;left:0;top:560px;width:1080px;text-align:center"><img class="e" src="assets/{src}" style="width:{460 if logo_ == "motif" else 380}px"><div class="e g-b" style="width:90px;height:8px;margin:34px auto 0;border-radius:4px"></div>{ln}{bg}{mid}</div>', "left:0;top:0;width:1080px;height:1920px")
    b.js(f'tl.fromTo("#{i} .e",{{opacity:0,y:30}},{{opacity:1,y:0,duration:.6,stagger:.12,ease:"power3.out"}},{t:.3f});tl.to("#{i}",{{opacity:0,duration:1.0}},{t + d - 1.05:.3f});')

_RND = "0123456789"
def _strip(ch, k, n=7):
    """굴러갈 글자 띠: 무작위 글자 n개 + 마지막에 목표 글자"""
    import random
    r = random.Random(hash((ch, k)) & 0xffff)
    if ch.isdigit(): pool = _RND
    elif "가" <= ch <= "힣": return [ch] * n + [ch]   # 한글은 엉뚱한 낱말이 보이지 않게 같은 글자가 블러로 굴러 내려온다
    elif ch.isalpha(): return [ch] * n + [ch]   # 영문도 칸 너비가 흔들리지 않게 같은 글자로
    else: return None
    return [r.choice(pool) for _ in range(n)] + [ch]

def roll_html(text, cls="rl"):
    """글자마다 세로로 굴러 내려와 멈추는 칸(블러와 함께)"""
    out = []
    for k, ch in enumerate(text):
        st = _strip(ch, k)
        if st is None: out.append(f'<span class="{cls} fx" style="display:inline-block">{"&nbsp;" if ch == " " else E(ch)}</span>')
        else: out.append(f'<span class="{cls} cw" style="display:inline-block;height:1.08em;overflow:hidden;vertical-align:top"><span class="sx" style="display:block">' + "".join(f'<span style="display:block;height:1.08em;line-height:1.08em">{E(c)}</span>' for c in st) + '</span></span>')
    return "".join(out)

def roll_js(b, sel, t, stagger=.07, dur=.9):
    b.js(f'document.querySelectorAll("{sel} .cw").forEach((el,k)=>{{const s=el.querySelector(".sx");const n=s.children.length;tl.fromTo(s,{{yPercent:0,filter:"blur(7px)"}},{{yPercent:-100*(n-1)/n,filter:"blur(0px)",duration:{dur},ease:"power3.out"}},{t:.3f}+k*{stagger});}});'
         f'tl.fromTo("{sel} .fx",{{opacity:0}},{{opacity:1,duration:.3,stagger:{stagger}}},{t + .3:.3f});')

def rollstat(b, t, d, x, y, w, title, cols, at=None, theme="dark", size=150, label_size=26, gap=.35):
    """수치 패널: 'FRONT — SOLAR GARD LX 40' 줄 + 칸별 라벨/큰 숫자(글자마다 블러 굴림). cols=[('TSER','61'),...]  theme dark=검정 글씨 · light=흰 글씨"""
    at = t + .4 if at is None else at; col = "#16171c" if theme == "dark" else "#fff"; sub = "rgba(22,23,28,.55)" if theme == "dark" else "rgba(255,255,255,.72)"; ln = "rgba(22,23,28,.22)" if theme == "dark" else "rgba(255,255,255,.4)"
    cw = w / len(cols)
    cs = "".join(f'<div class="cl{k}" style="position:absolute;left:{k * cw:.0f}px;top:70px;width:{cw:.0f}px;height:{size * 1.5:.0f}px;{"border-left:2px solid " + ln + ";padding-left:28px" if k else ""}"><div class="lb" style="font-family:ST,PP,KR;font-weight:500;font-size:{label_size}px;letter-spacing:.18em;color:{sub}">{E(l)}</div><div class="vv" style="font-family:ST,PP,KR;font-weight:400;font-size:{size}px;line-height:1.08;color:{col};white-space:nowrap;margin-top:6px">{roll_html(v)}</div></div>' for k, (l, v) in enumerate(cols))
    i = b.clip(t, d, f'<div class="tt" style="font-family:ST,PP,KR;font-weight:500;font-size:{label_size + 2}px;letter-spacing:.22em;color:{col};white-space:nowrap">{E(title)}</div><div class="hl" style="position:absolute;left:0;top:50px;width:{w}px;height:2px;background:{ln};transform-origin:left"></div>{cs}', f"left:{x}px;top:{y}px;width:{w}px;height:{size * 1.6 + 80:.0f}px")
    b.js(f'tl.fromTo("#{i} .tt",{{opacity:0,y:14}},{{opacity:1,y:0,duration:.5,ease:"power2.out"}},{t:.3f});tl.fromTo("#{i} .hl",{{scaleX:0}},{{scaleX:1,duration:.7,ease:"power2.inOut"}},{t + .1:.3f});tl.fromTo("#{i} .lb",{{opacity:0}},{{opacity:1,duration:.4,stagger:{gap}}},{at - .2:.3f});tl.to("#{i}",{{opacity:0,duration:.35}},{t + d - .37:.3f});')
    for k in range(len(cols)): roll_js(b, f"#{i} .cl{k}", at + k * gap)

def rolltext(b, t, d, x, y, text, size=110, theme="dark", label=None, align="left", w=940):
    """큰 글씨(한글 포함)가 글자마다 블러와 함께 굴러 내려와 맞춰짐 + 위 작은 라벨"""
    col = "#16171c" if theme == "dark" else "#fff"; sub = "rgba(22,23,28,.55)" if theme == "dark" else "rgba(255,255,255,.72)"
    lb = f'<div class="lb" style="font-family:ST,PP,KR;font-weight:500;font-size:26px;letter-spacing:.22em;color:{sub};margin-bottom:10px">{E(label)}</div>' if label else ""
    i = b.clip(t, d, f'<div style="text-align:{align}">{lb}<div style="font-family:ST,PP,KR;font-weight:400;font-size:{size}px;line-height:1.08;color:{col};white-space:nowrap">{roll_html(text)}</div></div>', f"left:{x}px;top:{y}px;width:{w}px")
    b.js(f'tl.fromTo("#{i} .lb",{{opacity:0,y:12}},{{opacity:1,y:0,duration:.45}},{t:.3f});tl.to("#{i}",{{opacity:0,duration:.35}},{t + d - .37:.3f});')
    roll_js(b, f"#{i}", t + .25, .06, .8)

def centertext(b, t, d, y, lines, size=40, theme="dark"):
    """가운데 정렬 짧은 글줄(엔드 로고 아래 등): lines=[('글', None|'g'|'b'|'bp'), ...] 위에 짧은 그라데이션 선"""
    col = "#16171c" if theme == "dark" else "#fff"
    ln = "".join(f'<div class="e" style="font-weight:{900 if g in ("b","p","bp") else 700};font-size:{size * (1.6 if g in ("b","p","bp") else 1):.0f}px;color:{"var(--gry)" if g == "g" else col};margin-top:14px">{gtext(s, g) if g in ("b","p","bp","n") else E(s)}</div>' for s, g in lines)
    i = b.clip(t, d, f'<div style="text-align:center"><div class="e g-b" style="width:80px;height:7px;border-radius:4px;margin:0 auto 10px"></div>{ln}</div>', f"left:0;top:{y}px;width:1080px")
    b.js(f'tl.fromTo("#{i} .e",{{opacity:0,y:24}},{{opacity:1,y:0,duration:.6,stagger:.14,ease:"power3.out"}},{t:.3f});tl.to("#{i}",{{opacity:0,duration:.4}},{t + d - .42:.3f});')

PARTS = dict(centertext=centertext, rollstat=rollstat, rolltext=rolltext, header=header, logo=logo, bgword=bgword, caption=caption, kinetic=kinetic, titlecard=titlecard, strike=strike, checklist=checklist,
             hbars=hbars, xyline=xyline, counter=counter, ring=ring, seesaw=seesaw, steps=steps, versus=versus, photo=photo, spectrum=spectrum,
             waves=waves, timeline=timeline, typeline=typeline, receipt=receipt, slot=slot, compare=compare, endcard=endcard)

# ───────── 조립 · 폰트 · 렌더 ─────────
def build(spec, D, overlay=False):
    b = B()
    for it in spec["items"]:
        it = dict(it); fn = PARTS[it.pop("p")]; fn(b, **it)
    dur = spec["dur"]; bg = "transparent" if overlay else spec.get("bg", "#f5f6f9")
    html = f'''<!doctype html><html lang="ko"><head><meta charset="UTF-8"><meta name="viewport" content="width=1080, height=1920">
<script src="assets/gsap.min.js"></script><style>{CSS}:root{{--bg:{bg}}}</style></head><body>{SVG_DEFS}
<div id="root" data-composition-id="main" data-start="0" data-duration="{dur:.3f}" data-width="1080" data-height="1920">{"".join(b.h)}</div>
<script>const tl=gsap.timeline({{paused:true}});{"".join(b.j)}
window.__timelines["main"]=tl;tl.seek(0);</script></body></html>'''
    os.makedirs(os.path.join(D, "assets", "fonts"), exist_ok=True)
    for f in os.listdir(os.path.join(KIT, "assets")):
        if f != "fonts": shutil.copy(os.path.join(KIT, "assets", f), os.path.join(D, "assets", f))
    for f in spec.get("files", []): shutil.copy(f, os.path.join(D, "assets", os.path.basename(f)))
    for f in ("package.json", "hyperframes.json"): shutil.copy(os.path.join(KIT, f), os.path.join(D, f))
    open(os.path.join(D, "index.html"), "w", encoding="utf-8").write(html)
    fonts(html, D)
    return html

def fonts(html, D):
    from fontTools.ttLib import TTCollection, TTFont
    from fontTools import subset
    txt = H.unescape(re.sub(r"<[^>]+>", "", html.split("<body>")[1])); text = "".join(sorted(set(txt) | set("0123456789%/.,+-×=·~ ")))
    def sub(font_obj, dst):
        o = subset.Options(); o.flavor = "woff2"; tmp = f"/tmp/_hf_{os.path.basename(dst)}.otf"; font_obj.save(tmp)
        f = subset.load_font(tmp, o); s = subset.Subsetter(o); s.populate(text=text); s.subset(f); subset.save_font(f, dst, o)
    for src, dst in [("Regular", "kr-regular"), ("Bold", "kr-bold"), ("Black", "kr-black")]:
        out = os.path.join(D, "assets", "fonts", dst + ".woff2")
        f = [f for f in TTCollection(f"/usr/share/fonts/opentype/noto/NotoSansCJK-{src}.ttc").fonts if "KR" in f["name"].getDebugName(1)][0]; sub(f, out)
    sub(TTFont(os.path.join(KIT, "assets", "NanumMyeongjo-ExtraBold.ttf")), os.path.join(D, "assets", "fonts", "tw-ko.woff2"))
    sub(TTFont(os.path.join(KIT, "assets", "SpecialElite-Regular.ttf")), os.path.join(D, "assets", "fonts", "tw-en.woff2"))
    for src, dst in [("Poppins-Medium.ttf", "pp-medium"), ("Poppins-Bold.ttf", "pp-bold"), ("Stylish-Regular.ttf", "stylish")]: sub(TTFont(os.path.join(KIT, "assets", src)), os.path.join(D, "assets", "fonts", dst + ".woff2"))

def render(D, out, overlay=False, quality="high"):
    env = dict(os.environ, DO_NOT_TRACK="1")
    if overlay:
        fr = os.path.join(D, "frames"); shutil.rmtree(fr, ignore_errors=True)
        subprocess.run(["npx", "--yes", "hyperframes@0.9.65", "render", "--format", "png-sequence", "--fps", "30", "--output", fr], cwd=D, env=env, check=True)
        return fr
    subprocess.run(["npx", "--yes", "hyperframes@0.9.65", "render", "--quality", quality, "--fps", "30", "--output", os.path.abspath(out)], cwd=D, env=env, check=True)
    return out

if __name__ == "__main__":
    ns = {}; exec(open(sys.argv[1], encoding="utf-8").read(), ns); spec = ns["SPEC"]
    overlay = "--overlay" in sys.argv; D = os.path.abspath(spec.get("dir", "/tmp/hf/job"))
    build(spec, D, overlay)
    if "--build" in sys.argv: print("built", D); sys.exit()
    print(render(D, sys.argv[2], overlay, "draft" if "--draft" in sys.argv else "high"))
