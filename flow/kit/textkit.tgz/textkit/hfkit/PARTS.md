# MOTIF HyperFrames 부품 키트 (hfkit)

마틴 확정(2026-11-22): 제작할 때는 무조건 HyperFrames로 만든다("무조건 하이퍼 프레임스로 해야 돼"). textv · cityv 같은 파이썬(PIL) 렌더러로 화면을 만들지 않는다. 디자인 기준은 "밝은 틴팅으로 만나는 도시의 밤".
토큰 절약이 핵심: 새 HTML을 짜지 말고 아래 부품을 spec 목록으로만 조합한다. 확인은 축소 시트 1~2장만 본다.

## 흐름
1. 대본 승인 → 일레븐랩스 B 목소리 녹음 → 제미나이 검수(make_reel.py, 문장 시작 시각 확보)
2. spec.py 작성: SPEC = dict(dur=초, items=[...], dir="/tmp/hf/작업명", files=[사진 경로들])
3. `python3 hfkit.py spec.py video.mp4` (확인용 `--draft`, HTML만 `--build`, 영상 위 오버레이 `--overlay` → frames 폴더)
4. `python3 finish.py reel video.mp4 voice.wav out.mp4 calm` 또는 `python3 finish.py overlay 원본.mp4 /tmp/hf/작업명/frames out.mp4`

모든 항목 공통 인자: p=부품이름, t=시작(초), d=길이(초). 화면 1080×1920. 글자 안전 영역은 위 230 ~ 아래 1330(문장은 y≈1060).

## 부품 (p=)
| 부품 | 쓰임 | 주요 인자 |
|---|---|---|
| header | 맨 위 파란 세로선 + 한 줄 제목 + 작은 좌/우 라벨 | title, left="MOTIF", right="SOLAR GARD LX" |
| logo | 하단 로고 | name=motif/motif_w/lxsg/lxsg_w/thelx, w=150, y=1780 |
| bgword | 오른쪽 아래 큰 옅은 영문이 천천히 흐름(장면마다) | word |
| caption | 아래 문장 2~3줄, 핵심어 그라데이션+형광펜 | rows=[[("글","b"),("~붙는말",None)],...] 스타일 None/g/b/p/n/bp, y=1060, size=64 |
| kinetic | 후킹 단어가 하나씩 튀어 들어옴 | words=[("썬팅",None),("쭈글쭈글?","n")], y, size |
| titlecard | 태그 + 큰 그라데이션 글씨 카드(영상 오버레이에도) | box=(x,y,w,h), tag, lines=[("글","b")], size, paper=True면 종이색 |
| strike | 취소선이 그어지고 새 단어 카드 등장 | box, text, at=긋는시각, to="새 단어" |
| checklist | 체크가 하나씩 그려지는 목록 | box, title, items=[("품목",시각)] |
| hbars | 축 있는 가로 막대 + 숫자 카운트 | box, title, rows=[("라벨",값,시각)], vmax, unit, ticks |
| xyline | XY 꺾은선이 그려짐 + 기준 점선 + 초과 점 빨강 | box, title, pts=[("라벨",값)], vmax, at, dur, thr, thr_label, over_label, caption_ |
| counter | 큰 숫자 카운트 + 아래 막대 | box, label, v0, v1, unit, bar=최댓값, caption_ |
| ring | 원형 게이지 % | box, label, pct, sub |
| seesaw | 두 가치 시소(양자택일) | left, right, note |
| steps | 단계 카드 + 화살표 | items=[("글","b",시각)] |
| versus | 두 카드 비교 + VS | a=("라벨","값","부제","b"), bb=(...), at2 |
| photo | 실차 사진 카드(느린 확대) + 배지 + 라벨 | box, src(files에 넣은 파일명), badge, label |
| spectrum | 가시광선 통과 / 근적외선 차단 개념도 | pass_label, block_label |
| waves | 태양에너지 파동이 유리판을 지나감 | glass, passed, note_l, note_r |
| timeline | 세로 타임라인 | items=[("시점","내용",시각)] |
| typeline | (종이 타자기 느낌이 필요할 때만) 타자기 카드(한 글자씩 + 커서) | box, lines=[("글","ink"/"blue"/"red")], size, cps, tag |
| receipt | 타자기 영수증(품목 → 점선 → 가격) | box, title, rows=[("품목","가격")], cps |
| slot | 슬롯머신처럼 숫자가 굴러 멈춤 | box, label, value, unit |
| compare | 시공 전/후 사진 슬라이더 | box, left=("라벨","사진"), right=(...) |
| rollstat | ["타자기" 요청 때만] 참고 릴스(BMW 7 · LX 40) 수치 패널: "FRONT — SOLAR GARD LX 40" 자간 넓은 한 줄 + 가는 선 + 칸별 라벨/큰 숫자, 숫자가 글자마다 블러와 함께 굴러 내려와 왼쪽부터 맞춰짐. 영상 위 오버레이용 | x, y, w, title, cols=[("TSER","61"),("VLT","42"),("VLT/SHGC","1.08")], theme=dark(검정 글씨)/light(흰 글씨), size=150, at |
| rolltext | ["타자기" 요청 때만] 글자가 제자리에 하나씩 찍히는 타자 글씨(Stylish) + 위 작은 영문 라벨. 타자음은 type_clicks(items) → click_wav(...)로 만들어 섞는다 | x, y, text, size, theme, label, align, w, cps=14, mode="type"(기본)/"roll" |
| centertext | 가운데 정렬 짧은 글줄 + 그라데이션 선(엔드 로고 아래 등) | y, lines=[("글",None/"g"/"b"/"bp")], size, theme |
| endcard | 로고 + 특화샵 문구 + 그라데이션 전화번호 + 주소 | logo_=motif/lxsg, lines, phone(None이면 생략), big |

## 규칙
- 그래프 색은 파랑 계열(b). 넓은 색 면 금지. 강조 튀어나옴(kinetic)은 첫 장면 후킹에만.
- 테슬라 전라지역 신차 패키지처럼 다른 샵과 같이 쓰는 내용은 logo name=lxsg, endcard logo_="lxsg", phone=None.
- 다른 인스타 릴스에서 본 연출은 구도·움직임 아이디어만 가져와 부품으로 만든다(로고·문구·캐릭터·고유 디자인 복제 금지).
- 견본: examples/demo_spec.py (부품 전부를 3초씩 보여 줌)

- 마틴(2026-11-22): "타자기"라고 하면 rolltext(글자가 움직이지 않고 하나씩 찍힘 + Stylish 폰트 + 타자음)를 쓴다("무빙하지 말고 타자 치는 것처럼"). 블러 굴림(roll)은 따로 말할 때만. 타자기 얘기가 없으면 평소 부품(caption·titlecard·hbars 등)으로 만든다. 종이 타자기 카드(typeline·receipt)는 "종이 타자기"처럼 따로 말할 때만.
- 마틴(2026-11-22): 영상 끝은 로고·마지막 글줄 뒤 3~4초 더 머문 뒤 검정으로 2초 페이드아웃(fade=t=out:color=black), 음악도 마지막 4~5초에 걸쳐 줄인다. 흰색으로 사라지게 하면 페이드아웃으로 안 보인다.

## UI 패턴 부품 (2026-11-22 추가)
앱 화면에서 흔히 쓰는 UI 움직임을 모티프 톤(무채색 + 블루, 등장 power3.out · 튀는 이징 없음)으로 직접 설계한 부품이다. 다른 사이트의 그림·애니메이션을 옮긴 것이 아니다. 예약·견적·농도 선택처럼 고객 경험을 앱 화면처럼 보여줄 때 쓴다. 데모: examples/ui_demo_spec.py
- 알림·피드백: `toast(text, icon, y)` 위에서 내려오는 알약 · `snackbar(text, action, y, at)` 아래 알림 막대 · `banner(title, text, y)` 파란 선 안내 배너 · `modal(title, body, ok, cancel, at)` 대화상자 + 확인 눌림 · `bottomsheet(title, rows=[(라벨,값)])` 아래에서 올라오는 시트 · `inlineerror(label, value, error, fixed)` 빨간 오류 → 고친 값으로 통과 · `tooltip(x, y, text, side)` 맥동 점 + 말풍선 · `coachmark(cx, cy, r, title, text, step)` 스포트라이트 안내 · `badge(x, y, text|count)` 숫자 배지
- 로딩: `spinner(label, done)` 회전 → 체크 · `skeleton(box, title, lines)` 반짝이는 자리표시 → 내용 · `progress(box, label, pct, steps)` 진행 막대 + 단계
- 입력 폼: `inputfield(box, label, text)` 라벨이 떠오르며 타이핑 · `toggles(box, items=[(라벨,시각)], title)` 스위치 · `segmented(options, seq=[(번호,시각)])` 알약 선택 · `rangeslider(box, label, vmin, vmax, value, unit, start)` 슬라이더 + 카운트
- AI 화면: `chat(msgs=[("user"|"ai", 글, 시각)])` 말풍선, AI는 점 세 개 → 글자가 흘러나옴
- 빈 화면: `emptystate(title, sub, btn, icon)`
- 제스처: `tap(x, y, at, n)` 터치 물결 · `swipecards(cards=[(제목,설명)])` 카드 넘기기
- 이동 구조·메뉴: `tabbar(tabs, seq, icons)` 하단 탭 · `carousel(box, slides=[(제목,설명,사진|None)])` 가로 넘김 + 점 · `dropdown(box, label, options, pick)` 선택 상자
- 공통 인자 t(시작 초), d(길이 초). 어둡게 덮는 modal · bottomsheet · coachmark는 한 릴스에 한두 번만(넓은 색 면 주의).

## 프로 모션·타이포 부품 (2026-11-25 제미나이 제안 · Claude 시험 렌더 통과)
엔진 전체 변경: 자막 어절 단위 등장(블러 4px · 확대 없음), 카드 다중 그림자, 숫자 tabular-nums, 같은 박스 그래프 장면이 이어지면 흰 카드가 다음 장면 크기로 미끄러지며 변형(sharedcard 자동).
- splitline: 중앙 기준선이 그어지며 위/아래 문구가 교차 등장(대비·역설 후킹) | box, top, bottom, tag="CONTRAST", g="b", at
- morphcard: 알약 배지 → 중간 바 → 큰 카드로 한 덩어리가 커지며 내용이 바뀜 | stages=[["태그","문구",시각], ...], y=340
- bento: 비대칭 벤토 그리드 2~4칸(패키지 구성·강점 요약) | box, cells=[["태그","제목","설명","b"|"p"|"k",시각], ...]
- ladder: 등급·가격 사다리, 추천 등급 하나만 돌출 강조 | box, title, tiers=[["등급명","가격",시각], ...], pick=번호(0부터)
- focusword: 영문 자간이 넓어지며 핵심 명제가 초점 맞듯 안착(여운) | box, eyebrow, word, sub, g="bp", at
- crossscan: 십자선이 가로지르며 스펙·수치가 드러남 | box, tag, text, sub, g="b", at
- metricpair: 두 수치(TSER·IRER 등) 좌우 동시 카운트 + 막대 | box, title, left=["라벨",값,"단위","b"], right=["라벨",값,"단위","p"], at, caption_
- stacklist: 품목 알약이 쌓였다가 한 줄 결론 카드로 압축 | box, pills=["품목", ...], at, collapse_at, result, g="bp"

## 그림 부품 (2026-11-25 · 장면마다 다른 그림이 나오게)
부품만 고르면 장면이 비슷해진다는 지적("예전엔 보온병도 나오고 그래프도 화려했는데")으로 추가. 한 릴스에 그림 부품을 2~3개 이상 섞어 쓴다. 시간 인자는 reel.json에서 "+초" · "s2+초" 문자열로.
- thermos: 보온병 단면, 안쪽 금속 코팅이 열을 되돌림 | box, mode="winter"|"summer", title, inside, outside, note, at
- tempcurve: 시간에 따른 온도 XY 곡선 2개(회색 vs 파랑) + 끝값 · 배지 | box, title, series=[["맨유리",[값...]],["LX",[값...]]], xlabels, ymin, ymax, unit="℃", delta, caption_, at
- filmlayers: 필름 단면 층이 하나씩 쌓임(금속층은 파랑) | box, title, layers=[["이름","m"|"c"|"a"|"d"|"h"], ...], badge
- spectrumcurve: 파장별 투과율 곡선(가시광선 띠 · 적외선 구간) | box, title, pts=[[nm,%], ...], caption_="개념도", at
- cartop: 차량 평면도, 유리 위치가 농도만큼 어두워지며 이름표 | box, title, zones=[["front"|"side1"|"side2"|"roof"|"rear","LX 40",시각], ...]
- heatflow: 필름 단면에서 열이 반사되는 길(summer 바깥 열기 · winter 실내 난방열) | box, mode, title, outside, inside, film, passed=통과 점선 수, at
- colbars: 세로 막대 XY 그래프, 강조 막대만 파랑 | box, title, bars=[["라벨",값,시각], ...], vmax, unit, ticks, hi=강조 번호, caption_
- dial: 반원 계기판, 바늘과 수치가 함께 | box, label, value, vmax=100, unit="%", sub, at
- donut: 도넛 비율(반사 · 흡수 · 투과 등) + 범례 카운트 | box, title, parts=[["반사",45,"b"],["흡수",26,"p"],["투과",29,"g"]], center, caption_, at
- 원문에 없는 수치로 그린 곡선·비율은 caption_에 "개념도" 또는 "예시 수치"라고 적는다.

## 자막 · 전환 (2026-11-25 제미나이 제안 반영)
- caption: 어절이 아래 마스크에서 올라오며(블러 4px) 등장, 강조 단어는 양쪽 핸들이 지나가며 옅은 형광 띠가 칠해지고 핸들은 0.8초 뒤 사라짐.
- zoomcut: spec(또는 reel.json)에 "zoomcut": true를 넣을 때만 장면 전환 순간 화면이 살짝 확대·블러됨. 기본은 끔(마틴: 화려한 펀치 줌 전환은 어색하다).
- 첫 장면(후킹) 그래픽은 run_reel.py가 자동으로 0.4초에 시작시킨다.

## 에디토리얼 스타일 (2026-11-25 제미나이 제안 · style:"editorial")
reel.json에 "style": "editorial"을 넣으면 카드형 대신 화면 전체를 쓰는 잡지형 장면. 장면 번호(01 / HOOK)와 영문 메타가 위에, 자막은 장면 안 큰 글씨로 들어간다. header는 쓰지 않는다(메타 줄이 대신함). 글자·화면 블러는 4~5px로 조정.
- ed_split: 통념 카드가 흐려지고 아래 큰 카드에 고온/저온 숫자 + 법칙 문장 | no, q_tag, q_txt, a_tag, t_high, t_low, rule
- ed_temp: 큰 온도 곡선(점선 맨유리 vs 파랑 LX) + 끝값 라벨 | no, bare=[...], lx=[...], xlabels, badge
- ed_thermos: 가운데 금속 벽을 사이에 두고 양쪽 복사열이 반사 | no, in_label, out_label, wall
- ed_odometer: 큰 +수치 카운트 + 필름 층 목록(METAL 층은 파랑) | no, label, val, unit, layers=[...]
- ed_bento: 큰 카드(막대 8개 차오름) + 여름/겨울 두 카드 | no, main_tit, main_sub, summer=[태그,제목,설명], winter=[...]
- ed_night: 원이 열리며 어두운 야간 화면 + 레이저 스캔 + 수치 카운트다운 | no, model, val, sub
- ed_verdict: 결론 시소 | no, left, right, sub

## 2026 트렌드 모션·도식 부품 10종 (2026-11-25 제미나이 리서치 · Claude 시험 렌더 통과, 검정 면은 파랑으로 조정)
- sankey: 태양에너지 줄기가 반사·흡수·투과 리본으로 갈라지며 수치 카운트 | box, title, source="태양에너지 100%", branches=[["외부 반사",55,"b"],["원단 흡수",16,"p"],["실내 투과",29,"g"]], unit, caption_, at
- loupe: 원형 확대 루페(2.4배)가 도면 위를 지나며 쉐이빙·PPF 끝단·도장 검수 | box, title, mode="shaving"|"ppf_edge"|"paint", zoom, metric_label, value, unit="mm", caption_, at
- dotmatrix: 10×10 도트가 대각선으로 채워지며 비율 카운트 | box, title, count=71, second_count=0, unit="%", label, sub, g="b"|"p", caption_, at
- caliper: 눈금자와 캘리퍼스 조가 맞물리며 두께(mil) 계측 | box, title, target_label, v1, compare_v, unit="mil", caption_, at
- nodeflow: 주행 환경에서 조건별 회로선이 갈라져 추천 필름 노드 점등 | box, title, root, paths=[["조건","필름명",true|false], ...], caption_, at
- elasticmesh: 탄성 그리드가 스톤칩 충격을 흡수한 뒤 수평 복원(PPF) | box, title, impact_label, base_label, pct, caption_, at
- frostlens: 뿌연 잔상 도식 위로 선명한 창이 지나감 | box, title, haze_label, clear_label, metric_name, metric_val, unit, caption_, at
- drumwheel: 농도·등급 목록이 돌다가 가이드 레일에 멈춤 + VLT | box, title, options=[...], pick, spec_label, spec_val, unit, caption_, at
- vernier: 눈금자가 이동하며 농도 창과 VLT·TSER 동시 연동 | box, title, steps=[["LX 15",12,71],["LX 25",23,65],["LX 40",42,61],["LX 70",72,55]], target_idx, caption_, at
- ripplefield: 동심원 파동이 필름을 통과(rf_pass)하거나 반사 분산(heat_dispersion) | box, title, mode, src_label, dst_label, barrier, pct, unit, caption_, at

## VORTEX 30 (2026-11-25 제미나이 해외 스튜디오 리서치 · Claude 시험 렌더 통과)
조정: eyetrace 선 색 정의 오류 수정, flipboard 검정 타일을 밝은 타일+파랑 글자로, prismray 입사광 검정을 회색으로. E군(eyetrace · causticsweep · depthdust · blueprintgrid)은 reel.json 장면에 "fx": [{"p":"depthdust"}, ...]로 그래픽과 함께 겹쳐 쓴다(장면 길이 자동).

### A. 3D · 아이소메트릭 · 공간 카메라 리그 (평면 카드 탈피 6종)
1. isoexplode: SSR 30° 등각투영 3D 슬래브들이 공중으로 부양 분리되며 내부 블루 코어 광원과 우측 지시선 라벨이 연결됨 | box, title, slabs=[["하드코팅","g"],["다층 은·금속 스퍼터","b"],["광학 PET 원단","w"],["전면 점착층","p"]], metric_label, val, unit, at
2. zparallax: 흰 카드 틀 없이 원경 제도판 · 중경 메인 수치 · 근경 플로팅 칩 3겹이 실제 3D Z축 시차로 돌리 아웃 | box, eyebrow, big_val, unit, headline, chips=["키워드1","키워드2","키워드3"], at
3. rackfocus: 전경(통념·질문)에서 원경(핵심 수치·해답)으로 카메라 초점 거리(blur 4.8px ↔ 0px)가 이동하는 시네마틱 포커스 풀 | box, front_tag, front_text, back_tag, back_val, back_unit, back_sub, at
4. hudtilt: 3D 원근 각도(rotateX/Y)로 기울어진 정밀 광학 텔레메트리 데크와 회전 레티클 링 · 스펙 리드아웃 | box, title, code="OPTICAL TELEMETRY", main_val, unit, specs=[["TSER","65%"],["VLT","23%"],["보증","10년"]], at
5. irisshutter: 삼각함수 대칭 회전하는 4분할 기하학 조리개 셔터가 열리며 중앙 핵심 수치·명제를 노출 | box, tag, val, unit, label, sub, at
6. hingeportal: 기존 통념 패널이 3D 경첩 축으로 회전해 열리며 그 너머의 블루 솔루션 패널로 진입 | box, door_tag, door_title, inside_tag, inside_title, inside_val, inside_unit, at

### B. 광학 · 물리 · 소재 과학 시뮬레이터 (썬팅·PPF 원리 7종)
7. liquidglass: 애플 리퀴드 글래스 굴절 캡슐(배경 확대 변위 + 양방향 대각선 라이트 스윕 + 스페큘러 림)이 유영하며 수치 표시 | box, title, bg_word="SOLAR GARD", val, unit, sub, at
8. prismray: 백색 태양광이 광학 삼각 프리즘을 통과하며 가시광선(통과)과 적외선·자외선(전반사 차단)으로 정밀 분광 | box, title, pass_txt="가시광선 시야 확보", block_txt="적외선 복사열 반사", pct=65, unit="%", caption_, at
9. raindrop: 고속 낙하 빗줄기가 스피드램프로 감속해 코팅면에 맺히며 초발수 접촉각(°)과 튕겨 나가는 구형 물방울 계측 | box, title, angle=112, surface="야와라 · 유리막 발수층", sub, caption_, at
10. debrisshield: 날아드는 스톤칩·열 파편들이 중앙 포커스 배리어에 부딪혀 튕겨 나가고 배리어가 미세 탄성 리코일 후 복원 | box, title, shield_label="XPEL · PPF BARRIER", hits=4, pct=100, unit="%", at
11. polarizer: 난반사 눈부심 스파이크 광원 위로 편광 필터 링이 90° 회전하며 글레어를 수평 소거하고 야간 선명도 확보 | box, title, before_txt="난반사 눈부심", after_txt="잔상·글레어 억제", val=6, unit="%", at
12. heatcamera: 무채색·블루·바이올렛 등온선(Isotherm) 컨투어가 차량 유리창의 열 구배를 실시간 스캔하며 온도차 계측 | box, title, mode="winter"|"summer", delta=20, unit="%", label="단열 효율 상승", caption_, at
13. selfheal: 확대된 클리어코트 위 스월 스크래치 선들 위로 온열 복원 링이 스캔하며 상처가 스스로 아물어 소멸 | box, title, temp_label="열복원 활성화", pct=100, sub="우레탄 엘라스토머 자가복원", at

### C. 프로시저럴 · 제너레이티브 데이터 아트 (Cavalry 스타일 6종)
14. repelfield: 7×5 정밀 벡터 바늘 매트릭스 사이로 에너지 프로브가 지나가며 자기장처럼 바늘 각도와 색상을 실시간 밀어냄 | box, title, probe_label="열반사 금속 장벽", metric_val=71, unit="%", caption_, at
15. oscwave: 24개 수직 정밀 바가 사인파 위상차(Phase Stagger)로 물결치다 내레이션 타이밍에 목표 스펙 곡선으로 칼같이 정렬 | box, title, peak_label="적외선 차단 피크", val=94, unit="%", caption_="개념도", at
16. falloffstack: 겹쳐 있던 5장의 공정·품목 카드가 벨커브 폴오프 곡선으로 부채처럼 펼쳐졌다가 핵심 1장으로 수렴 | box, title, cards=["신차 검수","전처리 탈지","정밀 성형","쉐이빙 마감","QR 전자보증"], pick=2, at
17. radialsweep: 5~6개 성능 축 위로 일반 필름(회색)과 주인공 필름(블루 폴리곤)이 중심에서 회전 확장하며 면적 격차 비교 | box, title, axes=["열반사","야간시야","내구성","전비방어","보증기간"], base=[45,50,40,42,35], hero=[92,88,95,90,96], hero_name="THE LX", caption_="개념도", at
18. echostack: 초대형 핵심 수치·단어 뒤로 프레임 시차를 둔 4겹의 블루·보라 윤곽선 에코가 파동처럼 따라붙어 합체 | box, eyebrow, word="10 YEARS", sub="변색 없는 풀메탈 스퍼터링 보증", g="b", at
19. orbitduplicator: 원형 배열된 18개 정밀 기하 캡슐이 반경 확장과 자체 회전을 수식 연동해 시계 무브먼트처럼 개폐 | box, label, val=1665, unit="년", sub="생고뱅 광학 제조 헤리티지", at

### D. 에디토리얼 · 저널리즘 · 타이포 아키텍처 (Vox / WSJ / Rive 스타일 6종)
20. doczoom: 공식 성적서·보증서 도면 전체에서 핵심 문구로 줌인 매치컷하며 멀티플라이 블루 형광펜 드로잉 + 외곽 심도 블러 | box, doc_title="NFRC OFFICIAL SPEC", lines=["VLT 가시광선 투과율 : 42%","TSER 총태양에너지 차단 : 61%","WARRANTY 공식 보증 : 10년"], pick=1, at
21. pannabletrack: 광폭 건축 눈금 타임라인 위를 카메라가 가로 패닝하며 출고~10년 시점별 상태 마커와 스템을 순차 점등 | box, title, milestones=[["출고 첫날","새 필름 동일 외관"],["3년 경과","염색 필름 변색 시작"],["5년 경과","재시공 중복 지출"],["10년 보증","LX 초기 물성 유지"]], pick=3, at
22. cadbox: 8개 코너·미드 핸들이 달린 CAD 바운딩 박스가 스냅 확장되며 내부 핵심 문구의 폰트 웨이트(300→900)가 실시간 변화 | box, tag="PRECISION FIT", word="오차 없는 파이널핏", sub="도장 안쪽 마감 설계", val=0.1, unit="mm", at
23. flipboard: 기계식 스플릿 플랩 타일들이 차르륵 회전하며 농도·등급·수치 스펙을 크로노그래프 감성으로 맞춤 | box, title, rows=[["FRONT","LX 40"],["SIDE · REAR","LX 25"],["TSER","65 %"]], at
24. shuttertext: 7개의 수평 베네시안 슬랫 블라인드가 시차 회전하며 통념 문장에서 핵심 결론 문장으로 면도날 교차 전환 | box, tag, before="어두워야 시원하다는 통념", after="밝아도 뜨거운 열을 반사하는 기술", g="b", at
25. certseal: 원형 경로를 따라 공전하는 타이포그래피 인장 링과 중앙 공식 특화샵·전자보증 체크 마크 각인 | box, ring_text="SOLAR GARD THE LX · OFFICIAL SPECIALIZED STUDIO · ", center_top="WARRANTY", center_val="10YR", sub="QR 전자보증 정품 등록", at

### E. 전화면 시네마틱 이펙트 · 공간 오버레이 ("그외의 효과" 5종 — graphic 또는 fx 겸용)
26. eyetrace: 상단 그래픽 결론 지점에서 출발한 테이퍼드 블루 코멧 광선이 우아한 호를 그리며 하단 자막 핵심어로 시선을 유도 | x0=540, y0=860, x1=540, y1=1055, at
27. causticsweep: 쇼룸 천창을 통과한 듯한 은은한 사선 유리 굴절 채광(Studio Light Gobo)이 화면 배경을 가로지르며 공기감 부여 | angle=-24, intensity=0.55
28. depthdust: 서로 다른 Z속도와 초점 심도를 가진 클린 광학 마이크로 보케 입자들이 부유하며 정적인 화면에 공간 깊이감 추가 | count=16, g="b"
29. xrayblade: 화면 위를 레이저 스캔 블레이드가 가로지르며 일반 외관 도면을 내부 금속 와이어프레임·스펙 투시도로 변환 | box, title, outer_txt="외관상 비슷해 보이는 새 필름", inner_txt="내부 다층 풀메탈 스퍼터링 구조", val=10, unit="년", at
30. blueprintgrid: 장면 시작과 함께 화면 외곽·코너 십자 마크·각도 보조선이 실시간 제도되듯 그려지며 설계 도면 무드 형성 | code="MOTIF ARCHIVE · SPEC SHEET", margin=52
- pricedrop(box,tag,title,old,new,unit="만원",save,note,at_old,at_new): 정상가 막대가 차고 at_new-0.3에 취소선 → 큰 숫자가 old에서 new로 내려가며 막대도 줄어듦 → save 알약. 패키지 할인가 장면용.
