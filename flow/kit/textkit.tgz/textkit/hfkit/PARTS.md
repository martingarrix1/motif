# MOTIF HyperFrames 부품 키트 (hfkit)

마틴 확정(2026-11-22): 앞으로 릴스 화면은 전부 HyperFrames로 만든다. 디자인 기준은 "밝은 틴팅으로 만나는 도시의 밤".
토큰 절약이 핵심: 새 HTML을 짜지 말고 아래 부품을 spec 목록으로만 조합한다. 확인은 축소 시트 1~2장만 본다.

## 흐름
1. 대본 승인 → 일레븐랩스 B 목소리 녹음 → 제미나이 검수(make_reel.py, 문장 시작 시각 확보)
2. spec.py 작성: SPEC = dict(dur=초, items=[...], dir="/tmp/hf/작업명", files=[사진 경로들])
3. `python3 hfkit.py spec.py video.mp4` (확인용 `--draft`, HTML만 `--build`, 영상 위 오버레이 `--overlay` → frames 폴더)
4. `python3 finish.py reel video.mp4 voice.wav out.mp4 calm` 또는 `python3 finish.py overlay 원본.mp4 /tmp/hf/작업명/frames out.mp4`

모든 항목 공통 인자: p=부품이름, t=시작(초), d=길이(초). 화면 1080×1920. 글자 안전 영역은 위 230 ~ 아래 1330(문장은 y≈1060).

## 부품 (p=)
| 부품 | 쓰임 | 주요 인자 |
|---|---|---|
| header | 맨 위 파란 세로선 + 한 줄 제목 + 작은 좌/우 라벨 | title, left="MOTIF", right="SOLAR GARD LX" |
| logo | 하단 로고 | name=motif/motif_w/lxsg/lxsg_w/thelx, w=150, y=1780 |
| bgword | 오른쪽 아래 큰 옅은 영문이 천천히 흐름(장면마다) | word |
| caption | 아래 문장 2~3줄, 핵심어 그라데이션+형광펜 | rows=[[("글","b"),("~붙는말",None)],...] 스타일 None/g/b/p/n/bp, y=1060, size=64 |
| kinetic | 후킹 단어가 하나씩 튀어 들어옴 | words=[("썬팅",None),("쭈글쭈글?","n")], y, size |
| titlecard | 태그 + 큰 그라데이션 글씨 카드(영상 오버레이에도) | box=(x,y,w,h), tag, lines=[("글","b")], size, paper=True면 종이색 |
| strike | 취소선이 그어지고 새 단어 카드 등장 | box, text, at=긋는시각, to="새 단어" |
| checklist | 체크가 하나씩 그려지는 목록 | box, title, items=[("품목",시각)] |
| hbars | 축 있는 가로 막대 + 숫자 카운트 | box, title, rows=[("라벨",값,시각)], vmax, unit, ticks |
| xyline | XY 꺾은선이 그려짐 + 기준 점선 + 초과 점 빨강 | box, title, pts=[("라벨",값)], vmax, at, dur, thr, thr_label, over_label, caption_ |
| counter | 큰 숫자 카운트 + 아래 막대 | box, label, v0, v1, unit, bar=최댓값, caption_ |
| ring | 원형 게이지 % | box, label, pct, sub |
| seesaw | 두 가치 시소(양자택일) | left, right, note |
| steps | 단계 카드 + 화살표 | items=[("글","b",시각)] |
| versus | 두 카드 비교 + VS | a=("라벨","값","부제","b"), bb=(...), at2 |
| photo | 실차 사진 카드(느린 확대) + 배지 + 라벨 | box, src(files에 넣은 파일명), badge, label |
| spectrum | 가시광선 통과 / 근적외선 차단 개념도 | pass_label, block_label |
| waves | 태양에너지 파동이 유리판을 지나감 | glass, passed, note_l, note_r |
| timeline | 세로 타임라인 | items=[("시점","내용",시각)] |
| typeline | (종이 타자기 느낌이 필요할 때만) 타자기 카드(한 글자씩 + 커서) | box, lines=[("글","ink"/"blue"/"red")], size, cps, tag |
| receipt | 타자기 영수증(품목 → 점선 → 가격) | box, title, rows=[("품목","가격")], cps |
| slot | 슬롯머신처럼 숫자가 굴러 멈춤 | box, label, value, unit |
| compare | 시공 전/후 사진 슬라이더 | box, left=("라벨","사진"), right=(...) |
| rollstat | 참고 릴스(BMW 7 · LX 40) 수치 패널: "FRONT — SOLAR GARD LX 40" 자간 넓은 한 줄 + 가는 선 + 칸별 라벨/큰 숫자, 숫자가 글자마다 블러와 함께 굴러 내려와 왼쪽부터 맞춰짐. 영상 위 오버레이용 | x, y, w, title, cols=[("TSER","61"),("VLT","42"),("VLT/SHGC","1.08")], theme=dark(검정 글씨)/light(흰 글씨), size=150, at |
| rolltext | 같은 굴림 효과의 큰 글씨 + 위 작은 영문 라벨(한글은 같은 글자가 블러로 굴러 내려옴) | x, y, text, size, theme, label, align, w |
| endcard | 로고 + 특화샵 문구 + 그라데이션 전화번호 + 주소 | logo_=motif/lxsg, lines, phone(None이면 생략), big |

## 규칙
- 그래프 색은 파랑 계열(b). 넓은 색 면 금지. 강조 튀어나옴(kinetic)은 첫 장면 후킹에만.
- 테슬라 전라지역 신차 패키지처럼 다른 샵과 같이 쓰는 내용은 logo name=lxsg, endcard logo_="lxsg", phone=None.
- 다른 인스타 릴스에서 본 연출은 구도·움직임 아이디어만 가져와 부품으로 만든다(로고·문구·캐릭터·고유 디자인 복제 금지).
- 견본: examples/demo_spec.py (부품 전부를 3초씩 보여 줌)

- 마틴(2026-11-22): 수치·글자 등장은 rollstat/rolltext의 블러 굴림 효과 + 스타일리시(Stylish) 폰트가 기본(영문·숫자·한글 모두). 종이 타자기(typeline·receipt)는 따로 요청할 때만.
