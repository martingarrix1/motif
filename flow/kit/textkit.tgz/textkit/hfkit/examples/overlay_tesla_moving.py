IT=[
 dict(p="titlecard",t=0.4,d=5.3,box=(72,230,640,400),tag="TESLA",lines=[("전라지역","b"),("신차 패키지","p")],size=92),
 dict(p="titlecard",t=6.3,d=4.5,box=(72,230,560,240),tag="01 / 05",lines=[("신차 검수","b")],size=84),
 dict(p="titlecard",t=11.4,d=4.7,box=(72,230,700,330),tag="02 / 05",lines=[("썬팅","b"),("S라인 · 제니스 IR","p")],size=72),
 dict(p="titlecard",t=16.7,d=4.9,box=(72,230,640,240),tag="02 / 05 · TINTING",lines=[("전면 + 측후면","b")],size=72),
 dict(p="titlecard",t=22.2,d=4.6,box=(72,1230,700,240),tag="03 / 05",lines=[("생활 보호 PPF","b")],size=78),
 dict(p="checklist",t=27.4,d=4.8,box=(120,230,840,600),title="신차 패키지 구성",items=[("신차 검수",28.0),("썬팅",28.4),("생활 보호 PPF",28.8),("본넷 PPF",30.6),("디스플레이 보호 필름 · 하이패스",31.0)]),
 dict(p="titlecard",t=32.8,d=4.7,box=(72,230,560,240),tag="04 / 05",lines=[("본넷 PPF","b")],size=84),
 dict(p="titlecard",t=38.0,d=4.7,box=(72,230,620,330),tag="05 / 05",lines=[("디스플레이","b"),("보호 필름","p")],size=80),
 dict(p="titlecard",t=43.3,d=4.8,box=(270,760,540,240),tag="PLUS",lines=[("하이패스","b")],size=80),
 dict(p="hbars",t=48.6,d=6.8,box=(72,220,936,600),title="썬팅 선택 · 패키지 가격",rows=[("S라인",99,49.3),("전면 제니스 IR",129,49.9),("전체 제니스 IR",169,50.5)],vmax=200,unit="만 원",ticks=(50,100,150)),
 dict(p="centertext",t=56.8,d=2.7,y=1040,lines=[("테슬라 전라지역 신차 패키지",None),("한시 운영","bp")],size=38),
]
SPEC=dict(dur=59.9,items=IT,dir="/tmp/hf/v15495")
