import json
G=19.7
L=[]  # (t, d, x, y, text, size, label, align, w)
def ln(t,end,y,text,size=56,label=None,x=72,align="left",w=940): L.append((t,end-t,x,y,text,size,label,align,w))
ln(0.3,3.4,250,"출고하던 날의 설렘은",64)
ln(1.2,3.4,340,"오래 지켜져야 하니까",64)
ln(3.7,8.9,250,"햇볕은 차급을 가려 가며 비추지 않고",46)
ln(5.6,8.9,330,"그 뜨거움은 결국 안에 탄 사람이 받아냅니다",46)
ln(9.3,14.1,1250,"그래서 처음부터",60)
ln(10.6,14.1,1340,"필요한 것만 제대로",60)
ln(14.5,19.5,250,"매일 손이 닿는 곳엔 PPF를",52)
ln(16.4,19.5,335,"매일 바라보는 화면엔 보호 필름을",52)
ln(G+0.3,26.2,215,"S라인 99만 원 패키지",66,"TESLA MODEL Y — WORK LIST")
for k,s in enumerate(["신차 검수 · 썬팅 S라인","본넷 PPF · 생활 보호 PPF","디스플레이 보호 필름 · 하이패스"]): ln(G+1.5+k*1.0,26.2,340+k*72,s,44)
ln(27.4,30.25,1040,"테슬라 전라지역 신차 패키지",40,None,0,"center",1080)
ln(28.3,30.25,1100,"S라인 99만 원 · 한시 운영",56,None,0,"center",1080)
IT=[dict(p="rolltext",t=t,d=d,x=x,y=y,text=s,size=z,label=lb,align=al,w=w) for (t,d,x,y,s,z,lb,al,w) in L]
CL=[]
for (t,d,x,y,s,z,lb,al,w) in L:
    k=0
    for ch in s:
        if ch.strip(): CL.append([round(t+.25+k*.06+.35,3),0.11]); k+=1
    CL.append([round(t+.25+k*.06+.5,3),0.18])
json.dump(CL,open("/tmp/hf/s30t_clicks.json","w"))
SPEC=dict(dur=30.3,items=IT,dir="/tmp/hf/s30t")
