A="/tmp/hf/demo_assets/"
T=0; IT=[]
def add(d,*parts):
    global T
    for p in parts: p.setdefault("t",T); p.setdefault("d",d); IT.append(p)
    T+=d
add(3.0,dict(p="kinetic",words=[("썬팅",None),("3년이면",None),("쭈글쭈글?","n")],y=700),dict(p="caption",rows=[[("kinetic · 후킹 단어 튀어나옴","g")]],y=1150,size=44))
add(3.0,dict(p="titlecard",box=(72,300,640,380),tag="01 / 05",lines=[("전라지역","b"),("신차 패키지","p")]),dict(p="caption",rows=[[("titlecard","g")],[("핵심 단어","b"),("~ 강조 문장",None)]]))
add(3.2,dict(p="strike",box=(170,380,740,140),text="어두운 필름",at=T+1.0,to="Window Film"),dict(p="caption",rows=[[("strike → 새 단어","g")]]))
add(3.5,dict(p="checklist",box=(130,300,820,600),title="신차 패키지 구성",items=[(s,T+0.6+k*0.45) for k,s in enumerate(["신차 검수","본넷 PPF","생활 보호 PPF","디스플레이 필름","하이패스"])]))
add(3.5,dict(p="hbars",box=(96,300,888,620),title="썬팅 선택 · 패키지 가격",rows=[("S라인",99,T+.4),("전면 제니스 IR",129,T+.8),("전체 제니스 IR",169,T+1.2)],vmax=200,unit="만 원",ticks=(50,100,150)))
add(4.0,dict(p="xyline",box=(96,300,888,640),title="품목별 정상가 누적",pts=[("전면",35),("측후면",80),("본넷",130),("생활 보호",145),("디스플레이",150),("하이패스",155)],vmax=170,at=T+.6,thr=110,thr_label="예상 예산",over_label="예산 초과",caption_="모델 Y 기준(만 원)"))
add(3.0,dict(p="counter",box=(190,330,700,520),label="TSER",v0=0,v1=61,unit="%",bar=100,caption_="총태양에너지 차단율"))
add(3.0,dict(p="ring",box=(240,300,600,640),label="가시광선 투과율",pct=55,sub="VLT"))
add(3.0,dict(p="seesaw",left="시인성",right="열차단",note="양자택일?"))
add(3.5,dict(p="steps",items=[("주행 환경","b",T+.2),("성능 · 농도","p",T+.9),("예산","b",T+1.6)]))
add(3.0,dict(p="versus",a=("제니스 IR 30","61%","TSER",("b")),bb=("S라인 30","55%","TSER","p")))
add(3.0,dict(p="photo",box=(110,330,860,560),src="car.jpg",badge="VLT 55%",label="모델 Y 주니퍼"))
add(3.2,dict(p="spectrum"))
add(3.2,dict(p="waves"))
add(3.5,dict(p="timeline",items=[("출고 전","신차 검수",T+.3),("출고 당일","썬팅 · PPF",T+.8),("1년 뒤","점검",T+1.3)]))
add(3.5,dict(p="typeline",box=(72,300,700,330),lines=[("썬팅","ink"),("S라인 · 제니스 IR","blue")],tag="02 / 05"))
add(3.5,dict(p="receipt",box=(70,300,940,470),title="PACKAGE PRICE",rows=[("S라인","99만 원"),("전면 제니스 IR","129만 원"),("전체 제니스 IR","169만 원")]))
add(3.0,dict(p="slot",box=(190,330,700,420),label="패키지",value=99,unit="만 원"))
add(3.0,dict(p="compare",box=(110,330,860,560),left=("시공 전","car_dark.jpg"),right=("LX 시공 후","car.jpg")))
add(3.5,dict(p="endcard",logo_="motif"))
DUR=T
for w,(a,b) in [("HOOK",(0,3)),("PACKAGE",(3,40)),("DATA",(40,DUR-3.5))]: IT.insert(0,dict(p="bgword",t=a,d=b-a,word=w))
IT.insert(0,dict(p="header",t=0,d=DUR-3.5,title="HyperFrames 부품 견본")); IT.append(dict(p="logo",t=0,d=DUR-3.5,name="motif"))
SPEC=dict(dur=DUR,items=IT,dir="/tmp/hf/demo",files=[A+"car.jpg",A+"car_dark.jpg"])
