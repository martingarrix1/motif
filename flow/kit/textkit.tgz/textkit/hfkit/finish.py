"""마무리: 소리 입히기 · 영상 위 오버레이 합성
reel   : python3 finish.py reel <hf영상.mp4> <voice.wav> <out.mp4> [calm|grand]
         목소리 + 클래식 피아노(목소리 뒤 2~3초 여운, -16 LUFS)
overlay: python3 finish.py overlay <원본영상.mp4> <frames폴더> <out.mp4>
         투명 PNG 시퀀스를 원본 위에 겹치고 원본 소리 유지
"""
import sys, subprocess, os, glob
def dur(f): return float(subprocess.check_output(["ffprobe","-v","error","-show_entries","format=duration","-of","csv=p=0",f]))
m = sys.argv[1]
if m == "reel":
    v, vo, out = sys.argv[2:5]; kind = sys.argv[5] if len(sys.argv) > 5 else "calm"; T = dur(v)
    sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
    import make_reel as MR; MR.pick_piano(kind, T + 0.5, "/tmp/_pia.wav")
    subprocess.run(["ffmpeg","-loglevel","error","-y","-i",v,"-i",vo,"-i","/tmp/_pia.wav","-filter_complex",
        f"[1:a]apad[a1];[2:a]volume=0.32,afade=t=out:st={T-3:.2f}:d=3[p];[a1][p]amix=inputs=2:normalize=0:duration=longest,loudnorm=I=-16:TP=-1.5[a]",
        "-map","0:v","-map","[a]","-c:v","copy","-c:a","aac","-b:a","256k","-ar","48000","-shortest","-movflags","+faststart",out], check=True)
elif m == "overlay":
    base, fr, out = sys.argv[2:5]; first = sorted(glob.glob(os.path.join(fr, "*.png")))[0]
    pat = os.path.join(fr, os.path.basename(first).rsplit("_", 1)[0] + "_%0" + str(len(first.rsplit("_", 1)[1]) - 4) + "d.png") if "_" in os.path.basename(first) else os.path.join(fr, "%0" + str(len(os.path.basename(first)) - 4) + "d.png")
    subprocess.run(["ffmpeg","-loglevel","error","-y","-i",base,"-framerate","30","-start_number","0" if first.endswith("0.png") else "1","-i",pat,"-filter_complex","[1:v]format=rgba[o];[0:v][o]overlay=0:0:shortest=1[v]",
        "-map","[v]","-map","0:a?","-c:v","libx264","-crf","16","-pix_fmt","yuv420p","-c:a","copy","-movflags","+faststart",out], check=True)
print(out)
