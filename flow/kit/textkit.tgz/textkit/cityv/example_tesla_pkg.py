import sys, json, math, subprocess, os
sys.path.insert(0, "/home/claude/tkl/textkit/cityv")
from citylib import *

TM = json.load(open("/home/claude/rs/tesla_pkg/timing.json"))
ST = TM["sent_starts"]; SD = TM["sent_durs"]; SC = TM["scene_starts"]; VL = TM["voice_len"]
END0 = VL + 0.5; TOTAL = END0 + 4.2
LG = "/home/claude/motif_reel_kit/brand/lxsg_ink_dark.png"
TITLE = "테슬라 전라지역 신차 패키지"
BGW = ["OPTIONS", "BUDGET", "SCOPE", "PACKAGE", "PRICE", "BALANCE", "TESLA"]

def sent_win(j):
    t0 = ST[j] - 0.15; t1 = (ST[j + 1] - 0.12) if j + 1 < len(ST) else END0 - 0.1
    return t0, t1
def scene_win(i):
    return SC[i] - 0.25, (SC[i + 1] - 0.1) if i + 1 < len(SC) else END0 - 0.1
def vis(t, t0, t1): return eo((t - t0) / 0.45) * cl((t1 - t) / 0.35)

CAP = [
 [[("테슬라 출고를 앞두고", "g")], [("견적", "b"), ("~을 받아보면", None)], [("추가할 품목", "p"), ("~이 제법 많습니다", None)]],
 [[("차 살 때", "g"), ("옵션 고민", None), ("~을 끝냈는데", None)], [("또", None), ("시작", "b"), ("~인 셈이죠", None)]],
 [[("본넷 PPF", "b"), ("~에", None)], [("생활 보호 PPF", "b"), ("~와", None)], [("하이패스", "b"), ("~까지", None)]],
 [[("하나씩 알아보려니 번거롭고", "g")], [("전부 하자니", None)], [("예산", "n"), ("~을 넘기기 쉽습니다", None)]],
 [[("그렇다고 품목이 많다는", "g")], [("이유만으로", None), ("패키지", "b"), ("~를", None)], [("고르는 것도 아쉽죠", None)]],
 [[("내게 필요한", "g")], [("보호 범위", "b"), ("~와", None), ("썬팅 성능", "p"), ("~이", None)], [("그 구성에 들어 있는지가 중요합니다", None)]],
 [[("테슬라 전라지역 신차 패키지는", "g")], [("신차 검수", "b"), ("~와", None), ("본넷 · 생활 보호 PPF", "b")], [("디스플레이 필름", "p"), ("~과", None), ("하이패스", "p"), ("~까지", None)]],
 [[("이 품목들을 함께", "g")], [("준비하려던 분께", None)], [("맞는 구성", "b"), ("~입니다", None)]],
 [[("썬팅은", "g")], [("예산", "b"), ("~에 맞춰", None)], [("선택하시면 됩니다", None)]],
 [[("S라인 구성", "g")], [("99만 원", "b")]],
 [[("전면 제니스 IR 구성", "g")], [("129만 원", "b")]],
 [[("전체 제니스 IR 구성", "g")], [("169만 원", "bp"), ("~입니다", None)]],
 [[("무조건", "g")], [("가장 비싼 구성", "n"), ("~이", None)], [("정답은 아닙니다", None)]],
 [[("주행 환경", "b"), ("~에 필요한", None)], [("성능", "p"), ("~과", None), ("농도", "p"), ("~를 정하고", None)], [("그 안에서", None), ("예산", "b"), ("~을 맞추는 게 합리적이죠", None)]],
 [[("한시적으로 운영하는", "g")], [("테슬라 전라지역", None)], [("신차 패키지", "bp")]],
 [[("차종", "b"), ("~과", None), ("출고 예정일", "b"), ("~을 알려주시면", None)], [("필요한 품목과 예산부터", None)], [("함께 살펴드리겠습니다", None)]],
]
SIZE = {13: 58, 6: 58, 15: 58, 5: 58}

# ── 장면 그림 ──
ITEMS0 = ["썬팅", "본넷 PPF", "생활 보호 PPF", "디스플레이 필름", "하이패스"]
def g0(c, t):
    a0, b0 = scene_win(0); a = vis(t, a0, b0)
    if a <= 0.01: return
    s1 = ST[1] - 0.1
    # 견적서 카드: 품목이 하나씩 쌓인다
    q, dy = pop(t, a0 + 0.1); y = 300 + dy + float_(t)
    box = [150, y, 930, y + 540]; card(c, box, 44, a * cl(q * 2))
    label(c, 540, y + 62, "출고 견적", a * cl(q * 2), GRY, 28)
    for k, nm in enumerate(ITEMS0):
        z = eo((t - a0 - 0.6 - k * 0.55) / 0.4) * a
        if z <= 0.01: continue
        yy = y + 112 + k * 80; xo = (1 - z) * 40
        c.rr([210 + xo, yy, 870 + xo, yy + 62], 18, fill=A((244, 246, 251), z))
        c.tx(240 + xo, yy + 31, nm, F("Bold", 32), A(INK, z), "lm"); c.tx(840 + xo, yy + 31, "+", F("Black", 40), A(G1, z), "rm")
    # 옵션 고민 끝 → 또 시작
    if t > s1:
        k = eo((t - s1) / 0.5);
        c.im.alpha_composite(Image.new("RGBA", (W, H), BG + (int(200 * k),)), (0, 0)) if False else None
        z = eo((t - s1 - 0.1) / 0.5) * a
        strike(c, [220, 900 + 30 * (1 - z), 860, 990 + 30 * (1 - z)], "옵션 고민 끝", t, s1 + 0.6, z, 44)

def g1(c, t):
    a0, b0 = scene_win(1); a = vis(t, a0, b0)
    if a <= 0.01: return
    s3 = ST[3] - 0.1; out = 1 - eo((t - s3) / 0.4)
    for k, nm in enumerate(["본넷 PPF", "생활 보호 PPF", "하이패스"]):
        q, dy = pop(t, a0 + 0.3 + k * 0.7)
        if q <= 0.01 or out <= 0.01: continue
        y = 360 + k * 170 + dy + float_(t, k); card(c, [180, y, 900, y + 130], 36, a * out * cl(q * 2), sh=0.24)
        c.gtx(540, y + 65, nm, F("Black", 54), a * out * cl(q * 2), (G1, G2), "mm")
    if t > s3:   # 누적 비용이 예산선을 넘는 XY 그래프
        z = eo((t - s3) / 0.5) * a; y0 = 300; card(c, [96, y0, 984, y0 + 640], 40, z, sh=0.24)
        X0, X1, Y0, Y1 = 190, 930, y0 + 540, y0 + 110
        c.ln([(X0, Y1 - 20), (X0, Y0), (X1, Y0)], A(LGT, z), 3)
        pts = [("전면", 35), ("측후면", 80), ("본넷", 130), ("생활 보호", 145), ("디스플레이", 150), ("하이패스", 155)]
        yv = lambda v: Y0 - (Y0 - Y1) * v / 170
        bud = yv(110)
        dash = eo((t - s3 - 0.3) / 0.6)
        for xx in range(X0, int(X0 + (X1 - X0) * dash), 26): c.ln([(xx, bud), (xx + 14, bud)], A(GRY, z), 3)
        label(c, X1, bud - 24, "예상 예산", z * dash, GRY, 24, "rm")
        g = eo((t - s3 - 0.5) / 2.6); n = len(pts); P = []
        for k, (nm, v) in enumerate(pts):
            x = X0 + 30 + (X1 - X0 - 60) * k / (n - 1); P.append((x, yv(v)))
            c.tx(x, Y0 + 30, nm, F("Medium", 20), A(GRY, z), "mm")
        seg = g * (n - 1); i = int(min(seg, n - 2)); f = seg - i
        line = [(X0, Y0)] + P[:i + 1] + [(P[i][0] + (P[i + 1][0] - P[i][0]) * f, P[i][1] + (P[i + 1][1] - P[i][1]) * f)]
        c.ln(line, A(G1, z), 7)
        for k, p in enumerate(P[:i + 1]):
            over = pts[k][1] > 110; c.el(p[0], p[1], 9, fill=A(NIR if over else G1, z))
        hx, hy = line[-1];
        if pts[min(i + 1, n - 1)][1] > 110 and g > 0.4: label(c, hx, hy - 40, "예산 초과", z * eo((g - 0.4) / 0.2), NIR, 26)
        label(c, 540, y0 + 60, "품목별 정상가 누적 · 모델 Y 기준(만 원)", z, GRY, 24)

def g2(c, t):
    a0, b0 = scene_win(2); a = vis(t, a0, b0)
    if a <= 0.01: return
    s5 = ST[5] - 0.1
    q, dy = pop(t, a0 + 0.2); y = 380 + dy
    strike(c, [200, y, 880, y + 140], "품목 수", t, a0 + 1.4, a * cl(q * 2), 56)
    if t > s5:
        for k, (nm, sub, cols) in enumerate([("보호 범위", "PPF", (G1, G2)), ("썬팅 성능", "FILM", (G2, G3))]):
            q2, d2 = pop(t, s5 + 0.2 + k * 0.6); x = 110 + k * 450; yy = 590 + d2 + float_(t, k)
            if q2 <= 0.01: continue
            card(c, [x, yy, x + 410, yy + 300], 44, a * cl(q2 * 2))
            label(c, x + 205, yy + 72, sub, a * cl(q2 * 2), GRY, 26); c.gtx(x + 205, yy + 180, nm, F("Black", 64), a * cl(q2 * 2), cols, "mm")

PK = ["신차 검수", "본넷 PPF", "생활 보호 PPF", "디스플레이 보호 필름", "하이패스"]
PKT = [0.25, 0.30, 0.42, 0.62, 0.84]   # 6번 문장 안에서 품목이 불리는 지점(비율)
def g3(c, t):
    a0, b0 = scene_win(3); a = vis(t, a0, b0)
    if a <= 0.01: return
    q, dy = pop(t, a0 + 0.1); y = 300 + dy + float_(t)
    card(c, [130, y, 950, y + 620], 44, a * cl(q * 2))
    c.tx(190, y + 62, "PACKAGE", F("Bold", 24), A(G1, a * cl(q * 2)), "lm")
    c.gtx(190, y + 112, "신차 패키지 구성", F("Black", 44), a * cl(q * 2), (G1, G2), "lm")
    for k, nm in enumerate(PK):
        tk = ST[6] + SD[6] * PKT[k] - 0.3; z = eo((t - tk) / 0.4) * a
        yy = y + 190 + k * 82
        c.tx(260, yy + 30, nm, F("Bold", 34), A(INK if z > 0.01 else LGT, max(z, 0.5 * a * cl(q * 2))), "lm")
        c.el(212, yy + 30, 22, outline=A(LGT, a * cl(q * 2)), width=3)
        check(c, 212, yy + 30, 22, (t - tk) / 0.6, a)
    s7 = ST[7] - 0.1
    if t > s7:
        z = eo((t - s7) / 0.5) * a; yy = y + 560
        c.rr([620, yy - 4, 900, yy + 52], 26, fill=A(G1, z)); c.tx(760, yy + 24, "기본 구성", F("Bold", 28), A((255, 255, 255), z), "mm")

PR = [("S라인", 99), ("전면 제니스 IR", 129), ("전체 제니스 IR", 169)]
def g4(c, t):
    a0, b0 = scene_win(4); a = vis(t, a0, b0)
    if a <= 0.01: return
    q, dy = pop(t, a0 + 0.15); y = 300 + dy + float_(t) * 0.5
    card(c, [96, y, 984, y + 620], 44, a * cl(q * 2))
    c.tx(150, y + 70, "썬팅 선택 · 패키지 가격", F("Bold", 28), A(GRY, a * cl(q * 2)), "lm")
    X0, X1 = 150, 930; yb = y + 520
    c.ln([(X0, y + 130), (X0, yb)], A(LGT, a), 3); c.ln([(X0, yb), (X1, yb)], A(LGT, a), 3)
    for v in (50, 100, 150):
        gx = X0 + (X1 - X0 - 120) * v / 200; c.ln([(gx, yb), (gx, yb + 12)], A(LGT, a), 3); label(c, gx, yb + 34, str(v), a, (160, 164, 172), 22)
    for k, (nm, v) in enumerate(PR):
        tk = ST[9 + k] - 0.1
        if t < tk: continue
        u = eo((t - tk) / 1.0); z = eo((t - tk) / 0.3) * a; yy = y + 160 + k * 122
        c.tx(X0 + 20, yy, nm, F("Bold", 32), A(INK, z), "lm")
        bw = (X1 - X0 - 120) * v / 200 * u
        gbar(c, X0, yy + 30, bw, 40, (G1, (90, 140, 255)) if k < 2 else (G1, G2), z)
        c.tx(X0 + bw + 18, yy + 50, f"{int(round(v * u))}만 원", F("Black", 40), A(G1 if k < 2 else G2, z), "lm")
    if t < ST[9]:   # 8번 문장: 예산 다이얼 대신 '선택' 세 칸이 먼저 깜빡인다
        for k in range(3):
            z = eo((t - ST[8] - k * 0.25) / 0.4) * a * cl((ST[9] - 0.1 - t) / 0.3)
            c.rr([X0 + 20 + k * 250, y + 260, X0 + 230 + k * 250, y + 360], 24, outline=A(G1, z), width=3)
            label(c, X0 + 125 + k * 250, y + 310, ["S라인", "전면 IR", "전체 IR"][k], z, G1, 30)

def g5(c, t):
    a0, b0 = scene_win(5); a = vis(t, a0, b0)
    if a <= 0.01: return
    s13 = ST[13] - 0.1; out = 1 - eo((t - s13) / 0.4)
    q, dy = pop(t, a0 + 0.1)
    if out > 0.01:
        strike(c, [170, 420 + dy, 910, 560 + dy], "가장 비싼 구성 = 정답", t, a0 + 1.3, a * out * cl(q * 2), 50)
    if t > s13:
        steps = [("주행 환경", (G1, G2)), ("성능 · 농도", (G2, G3)), ("예산", (G1, G2))]
        tks = [s13 + 0.1, ST[13] + SD[13] * 0.35, ST[13] + SD[13] * 0.62]
        for k, (nm, cols) in enumerate(steps):
            q2, d2 = pop(t, tks[k]); y = 340 + k * 210 + d2 + float_(t, k)
            if q2 <= 0.01: continue
            card(c, [230, y, 850, y + 140], 40, a * cl(q2 * 2)); c.gtx(540, y + 70, nm, F("Black", 56), a * cl(q2 * 2), cols, "mm")
            label(c, 290, y + 70, f"0{k + 1}", a * cl(q2 * 2), LGT, 28)
            if k: arrow(c, (540, y - 66), (540, y - 14), a * cl(q2 * 2), G1)

def g6(c, t):
    a0, b0 = scene_win(6); a = vis(t, a0, b0)
    if a <= 0.01: return
    s15 = ST[15] - 0.1; out = 1 - eo((t - s15) / 0.4)
    q, dy = pop(t, a0 + 0.1)
    if out > 0.01:
        y = 360 + dy + float_(t); card(c, [130, y, 950, y + 440], 48, a * out * cl(q * 2))
        label(c, 540, y + 80, "TESLA", a * out * cl(q * 2), GRY, 30)
        c.gtx(540, y + 190, "전라지역", F("Black", 92), a * out * cl(q * 2), (G1, G2), "mm")
        c.gtx(540, y + 300, "신차 패키지", F("Black", 92), a * out * cl(q * 2), (G2, G3), "mm")
        z = eo((t - a0 - 1.6) / 0.5) * a * out
        c.rr([430, y + 410, 650, y + 470], 30, fill=A(INK, z)); c.tx(540, y + 440, "한시 운영", F("Bold", 30), A((255, 255, 255), z), "mm")
    if t > s15:
        for k, nm in enumerate(["차종", "출고 예정일"]):
            q2, d2 = pop(t, s15 + 0.1 + k * 0.5); x = 120 + k * 430; y = 380 + d2 + float_(t, k)
            if q2 > 0.01:
                card(c, [x, y, x + 400, y + 170], 40, a * cl(q2 * 2)); label(c, x + 200, y + 85, nm, a * cl(q2 * 2), INK, 46, w="Black")
        q3, d3 = pop(t, ST[15] + SD[15] * 0.45)
        if q3 > 0.01:
            arrow(c, (540, 600), (540, 680), a * cl(q3 * 2)); y = 720 + d3
            card(c, [230, y, 850, y + 170], 44, a * cl(q3 * 2)); c.gtx(540, y + 85, "품목 · 예산", F("Black", 60), a * cl(q3 * 2), (G1, G2, G3), "mm")

G = [g0, g1, g2, g3, g4, g5, g6]

def endcard(c, t):
    u = t - END0; a = eo(u / 0.7) * cl((TOTAL - t) / 1.2)
    logo(c, LG, 540, 760, 380, a)
    c.tx(540, 1000, TITLE, F("Bold", 40), A(INK, a), "mm")
    g = grad(90, 8, (G1, G2)).convert("RGBA"); g.putalpha(int(255 * a)); c.im.alpha_composite(g, (495, 1060))
    c.gtx(540, 1150, "한시 운영", F("Black", 72), a, (G1, G2, G3), "mm")

def frame(t):
    c = C()
    if t >= END0 - 0.05:
        endcard(c, t); return c.im.convert("RGB")
    i = max(k for k in range(len(SC)) if SC[k] - 0.25 <= t) if t >= SC[0] - 0.25 else 0
    bgword(c, t, BGW[i], SC[i])
    header(c, TITLE, "TESLA", "SOLAR GARD LX")
    G[i](c, t)
    if i + 1 < len(G) and t > SC[i + 1] - 0.3: G[i + 1](c, t)
    for j in range(len(ST)):
        t0, t1 = sent_win(j)
        if t0 - 0.1 <= t <= t1 + 0.1: caption(c, t, t0, t1, CAP[j], 1060, SIZE.get(j, 64))
    logo(c, LG, 540, 1780, 150, 1.0)
    return c.im.convert("RGB")

if __name__ == "__main__":
    mode = sys.argv[1]
    if mode == "stills":
        ts = [float(x) for x in sys.argv[2].split(",")]
        ims = [frame(t).resize((270, 480)) for t in ts]
        sh = Image.new("RGB", (270 * len(ims), 480)); [sh.paste(im, (k * 270, 0)) for k, im in enumerate(ims)]; sh.save(sys.argv[3])
    else:   # render a b out
        a, b, out = int(sys.argv[2]), int(sys.argv[3]), sys.argv[4]
        p = subprocess.Popen(["ffmpeg", "-loglevel", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                              "-c:v", "libx264", "-crf", "17", "-preset", "medium", "-pix_fmt", "yuv420p", out], stdin=subprocess.PIPE)
        for n in range(a, b): p.stdin.write(frame(n / FPS).tobytes())
        p.stdin.close(); p.wait()
