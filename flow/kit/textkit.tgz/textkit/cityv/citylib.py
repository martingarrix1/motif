# MOTIF "도시의 밤" 스타일 렌더 엔진 (2026-11-22 마틴이 "제일 내 스타일"이라고 확정한 기준작을 재구성)
# 오프화이트 배경 · 상단 파란 세로선 + 한 줄 제목 · 위쪽 개념 그림 카드 · 아래 문장 2~3줄(핵심어 그라데이션 + 형광펜 띠)
# · 오른쪽 아래 흐르는 큰 배경 글자 · 하단 로고 · 엔드카드
import math, os
from PIL import Image, ImageDraw, ImageFont, ImageFilter

W, H, FPS = 1080, 1920, 30
BG = (245, 246, 249); INK = (22, 23, 28); GRY = (118, 122, 132); LGT = (198, 202, 212)
G1 = (36, 92, 255); G2 = (128, 82, 242); G3 = (236, 78, 148)
NIR = (236, 92, 66); NIR2 = (250, 150, 60)
GR = {"b": (G1, G2), "p": (G2, G3), "n": (NIR, NIR2), "bp": (G1, G2, G3)}
BAND = {"b": (214, 224, 255), "p": (240, 220, 246), "n": (255, 226, 214), "bp": (226, 222, 252)}
FD = "/usr/share/fonts/opentype/noto/"
_FC = {}
def F(w, s):
    k = (w, s)
    if k not in _FC: _FC[k] = ImageFont.truetype(FD + f"NotoSansCJK-{w}.ttc", s, index=1)
    return _FC[k]

def cl(x): return max(0.0, min(1.0, x))
def eo(x): x = cl(x); return 1 - (1 - x) ** 4
def bo(x):  # 살짝 튀어 오르는 등장
    x = cl(x); c = 1.6; return 1 + (c + 1) * (x - 1) ** 3 + c * (x - 1) ** 2
def A(c, a): return tuple(c[:3]) + (int(255 * cl(a)),)

_GC = {}
def grad(w, h, cols):
    k = (w, h, cols)
    if k not in _GC:
        g = Image.new("RGB", (max(w, 1), 1)); n = len(cols) - 1
        for x in range(max(w, 1)):
            u = x / max(w - 1, 1) * n; i = min(int(u), n - 1); f = u - i
            g.putpixel((x, 0), tuple(int(cols[i][k_] + (cols[i + 1][k_] - cols[i][k_]) * f) for k_ in range(3)))
        _GC[k] = g.resize((max(w, 1), max(h, 1)))
    return _GC[k]

class C:
    def __init__(s):
        s.im = Image.new("RGBA", (W, H), BG + (255,)); s.d = ImageDraw.Draw(s.im)
    def tw(s, t, f): b = s.d.textbbox((0, 0), t, font=f); return b[2] - b[0]
    def tx(s, x, y, t, f, fill, anc="la"): s.d.text((x, y), t, font=f, fill=fill, anchor=anc)
    def gtx(s, x, y, t, f, a, cols, anc="la"):
        if a <= 0.01: return
        x, y = int(x), int(y); b = [int(v) for v in s.d.textbbox((x, y), t, font=f, anchor=anc)]; w, h = b[2] - b[0] + 4, b[3] - b[1] + 4
        m = Image.new("L", (w, h), 0); ImageDraw.Draw(m).text((x - b[0] + 2, y - b[1] + 2), t, font=f, fill=int(255 * cl(a)), anchor=anc)
        g = grad(w, h, cols).convert("RGBA"); g.putalpha(m); s.im.alpha_composite(g, (b[0] - 2, b[1] - 2))
    def rr(s, box, r, **k): s.d.rounded_rectangle([int(v) for v in box], radius=int(r), **k)
    def ln(s, pts, fill, w): s.d.line(pts, fill=fill, width=int(w))
    def el(s, cx, cy, r, **k): s.d.ellipse([cx - r, cy - r, cx + r, cy + r], **k)
    def poly(s, pts, fill): s.d.polygon(pts, fill=fill)

_CC = {}
def _cardspr(w, h, r, fill, sh):
    k = (w, h, r, fill, sh)
    if k not in _CC:
        pad = 70; im = Image.new("RGBA", (w + pad * 2, h + pad * 2), (0, 0, 0, 0))
        m = Image.new("L", im.size, 0); ImageDraw.Draw(m).rounded_rectangle([pad + 10, pad + 26, pad + w - 10, pad + h + 18], radius=r, fill=int(255 * sh))
        m = m.filter(ImageFilter.GaussianBlur(26)); shd = Image.new("RGBA", im.size, (60, 70, 100, 0)); shd.putalpha(m)
        im.alpha_composite(shd); ImageDraw.Draw(im).rounded_rectangle([pad, pad, pad + w, pad + h], radius=r, fill=fill + (255,))
        _CC[k] = im
    return _CC[k]

def card(c, box, r=40, a=1.0, fill=(255, 255, 255), sh=0.30):
    """그림자 있는 둥근 카드"""
    if a <= 0.01: return
    x0, y0, x1, y1 = [int(v) for v in box]; spr = _cardspr(x1 - x0, y1 - y0, r, fill, sh)
    if a < 0.995:
        spr = spr.copy(); al = spr.getchannel("A").point(lambda v: int(v * a)); spr.putalpha(al)
    c.im.alpha_composite(spr, (x0 - 70, y0 - 70))

def pop(t, t0, d=0.6):
    """등장 진행(0~1.05), 떠오르는 오프셋"""
    q = min(bo((t - t0) / d), 1.06) if t >= t0 else 0.0
    return q, (1 - min(q, 1)) * 70

def float_(t, k=0): return 7 * math.sin(t * 1.15 + k)

def label(c, x, y, t, a, col=GRY, size=28, anc="mm", w="Bold"):
    if a > 0.01: c.tx(x, y, t, F(w, size), A(col, a), anc)

def strike(c, box, text, t, t0, a, size=46):
    """카드 안 글자에 취소선이 그어진다"""
    x0, y0, x1, y1 = box; card(c, box, 34, a, sh=0.22); f = F("Black", size)
    cy = (y0 + y1) / 2; c.tx((x0 + x1) / 2, cy, text, f, A(GRY, a), "mm")
    s_ = eo((t - t0) / 0.5); tw = c.tw(text, f) + 40
    if s_ > 0.01: c.ln([((x0 + x1) / 2 - tw / 2, cy + 2), ((x0 + x1) / 2 - tw / 2 + tw * s_, cy + 2)], A(G3, a), 7)

def gbar(c, x, y, w, h, cols, a, r=None):
    if w < 4 or a <= 0.01: return
    r = h / 2 if r is None else r
    g = grad(int(w), int(h), cols).convert("RGBA"); m = Image.new("L", g.size, 0)
    ImageDraw.Draw(m).rounded_rectangle([0, 0, g.width - 1, g.height - 1], radius=int(min(r, w / 2)), fill=int(255 * cl(a))); g.putalpha(m)
    c.im.alpha_composite(g, (int(x), int(y)))

def check(c, cx, cy, r, p, a):
    """파란 원 + 체크가 그려진다"""
    if a <= 0.01: return
    c.el(cx, cy, r, fill=A(G1, a * eo(p / 0.4)))
    k = eo((p - 0.2) / 0.5)
    if k > 0:
        p0, p1, p2 = (cx - r * 0.45, cy), (cx - r * 0.1, cy + r * 0.38), (cx + r * 0.5, cy - r * 0.35)
        if k < 0.5: c.ln([p0, (p0[0] + (p1[0] - p0[0]) * k * 2, p0[1] + (p1[1] - p0[1]) * k * 2)], A((255, 255, 255), a), 6)
        else:
            u = (k - 0.5) * 2; c.ln([p0, p1, (p1[0] + (p2[0] - p1[0]) * u, p1[1] + (p2[1] - p1[1]) * u)], A((255, 255, 255), a), 6)

def arrow(c, p0, p1, a, col=G1, w=5, hd=16):
    if a <= 0.01: return
    c.ln([p0, p1], A(col, a), w); ang = math.atan2(p1[1] - p0[1], p1[0] - p0[0])
    c.poly([p1, (p1[0] - hd * math.cos(ang - 0.45), p1[1] - hd * math.sin(ang - 0.45)), (p1[0] - hd * math.cos(ang + 0.45), p1[1] - hd * math.sin(ang + 0.45))], A(col, a))

# ── 상단 머리말 · 배경 글자 · 하단 로고 ──
def header(c, title, left="MOTIF", right="SOLAR GARD LX"):
    c.rr([44, 92, 52, 140], 3, fill=G1 + (255,)); c.tx(68, 116, title, F("Bold", 40), INK + (255,), "lm")
    sp = lambda s: " ".join(s)
    c.tx(48, 178, sp(left), F("Bold", 20), (60, 62, 70, 255), "lm"); c.tx(W - 48, 178, sp(right), F("Medium", 20), (120, 124, 134, 255), "rm")

def bgword(c, t, word, t0):
    a = eo((t - t0 + 0.2) / 0.9); f = F("Black", 330); x = W - 140 - (t - t0) * 44
    c.tx(x, 1480, word, f, A((226, 231, 243), a * 0.9), "lm")

_LOGO = {}
def logo(c, path, cx, cy, w, a=1.0):
    if a <= 0.01: return
    if (path, w) not in _LOGO:
        im = Image.open(path).convert("RGBA"); im = im.crop(im.getbbox()); _LOGO[(path, w)] = im.resize((w, int(w * im.height / im.width)), Image.LANCZOS)
    im = _LOGO[(path, w)]
    if a < 0.995: im = im.copy(); im.putalpha(im.getchannel("A").point(lambda v: int(v * a)))
    c.im.alpha_composite(im, (int(cx - im.width / 2), int(cy - im.height / 2)))

# ── 아래 문장 (핵심어 그라데이션 + 형광펜 띠) ──
def kline(c, t, t0, t1, y, segs, size=64, x0=72):
    """segs=[(글, 스타일)] 스타일 None=검정, 'g'=회색, 'b'/'p'/'n'/'bp'=그라데이션. '~'로 시작하면 앞말에 붙인다"""
    a = eo((t - t0) / 0.45) * cl((t1 - t) / 0.25)
    if a <= 0.01: return
    dy = (1 - eo((t - t0) / 0.5)) * 34; f = F("Black", size); x = x0; yy = y + dy
    for k, (tx_, st) in enumerate(segs):
        glue = tx_.startswith("~"); tx_ = tx_.lstrip("~")
        if k and not glue: x += size * 0.28
        w = c.tw(tx_, f)
        if st in GR:
            hb = eo((t - t0 - 0.3) / 0.5)
            if hb > 0.01: c.rr([x - 6, yy + size * 0.52, x - 6 + (w + 12) * hb, yy + size * 0.98], 8, fill=A(BAND[st], a * 0.95))
            c.gtx(x, yy, tx_, f, a, GR[st])
        else:
            c.tx(x, yy, tx_, f, A(GRY if st == "g" else INK, a))
        x += w

def caption(c, t, t0, t1, rows, y=1030, size=64, gap=None):
    gap = gap or size * 1.40
    for k, ws in enumerate(rows): kline(c, t, t0 + k * 0.14, t1, y + k * gap, ws, size)
