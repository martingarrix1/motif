# 릴스 목소리 (일레븐랩스)
- B (기본, 남성): voice_id 5WQiuyr3CgBT8RI5vL9r "MOTIF B2 (원본)" · v2 · 속도 0.9
- 여성 버전 (2026-11-22): voice_id m7Ra9MY2nOIpz2AQPg0z "MOTIF 여성 (친구)" — 마틴과 릴스를 함께 공부하는 친구 목소리를 복제. "여성 버전으로" 요청 시 MOTIF_VOICE_ID=m7Ra9MY2nOIpz2AQPg0z 로 make_text.py 실행. 설정 stability 0.6 · similarity 1.0 · speed 1.08 (마틴이 시험 녹음 중 test2(1.08)를 고름, 2026-11-22) — MOTIF_VOICE_SETTINGS로 넘김
- 험비(치즈냥이): voice_id WWaMzLGNibuiLVQIGfIc — 피치가 높아 귀가 아프다는 평, 지금은 안 씀
