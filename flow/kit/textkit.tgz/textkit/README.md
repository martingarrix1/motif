# MOTIF 릴스 키트 v3 (2026-11-21)

명령 한 번으로 "텍스트 버전" 릴스를 만든다. Claude는 대사 쓰기·승인·점검만 하고 나머지는 이 프로그램이 한다.

## 준비 (새 작업 공간에서 1회)
    pip install playwright --break-system-packages   # 없을 때만
    # 크롬: google-chrome 이 있으면 그대로 사용, 없으면  python3 -m playwright install chromium
    # 폰트: Noto Sans CJK KR (없으면 apt-get install -y fonts-noto-cjk)
    # 키: motif-api-keys 스킬 → ~/.eleven/key, ~/.gemini/key

## 가장 빠른 방법 (v3)
    python3 make_reel.py all <폴더>
  script.txt만 있으면 계획(제미나이) → 읽기 변환 → 녹음 → 제미나이 검수·자동 재녹음(최대 2번) → 자동 점검·자동 수정 → sheet.jpg → mp4 까지 한 번에.
  Claude는 대사 승인과 출력 몇 줄, 문제가 남았을 때만 sheet.jpg 확인.

## v3에서 바뀐 것
- script.txt는 화면용 글자 그대로(3년, 10만 원, S라인). 읽기용 문장은 제미나이가 vo/say.json에 만든다(손으로 고쳐도 됨).
- 대사에 "전주 모티프였습니다"가 있으면 자동으로 모티프 버전: 하단 MOTIF 로고, 그 멘트에 엔드카드(MOTIF 로고·제품명·주소), 뒤로 5.5초 여운. 없으면 THE LX 하단 로고 + 엔드카드(마지막 질문·묶음 로고·제품명).
- 자동 점검(check): 제목 넘침·줄바꿈, ~요 제목, 부품 오류, 작은 글씨(24px 미만), 제목·자막과 겹침, 짧은 글자 줄바꿈, 배경과 같은 글자색 → 걸린 장면만 제미나이가 다시 짬(최대 2번).
- 제목 자동 축소(한 줄 920px), 파란 배경 위 강조 글자는 자동으로 흰색, 부품 글자 단어 단위 줄바꿈.
- 마틴 스타일 가이드 scene/STYLE.md를 계획 단계에 항상 넣는다. 피드백이 생기면 이 파일에 한 줄씩 더한다.
- 생성 파일(sheet·_로 시작)은 사진 목록에서 뺀다. badge 로고 solargard 지원.

## 작업 순서 (단계별로 할 때)
1. 작업 폴더를 만들고 script.txt(마틴 승인 대사)와 사진을 넣는다. 장면 사이 빈 줄, 한 줄 = 한 문장, 보통 7장면.
2. python3 make_reel.py plan   <폴더>   → 제미나이가 장면마다 부품·제목을 골라 job.json 생성 (최근 3편 부품은 피함)
   - job.json의 제목·params는 Claude가 마틴 어조로 다듬는다. "logo": thelx | lxsg | motif | solargard | none, "piano": calm | grand | auto
3. python3 make_reel.py stills  <폴더>  → sheet.jpg 한 장으로 7장면 점검 (녹음 전에도 가능)
4. python3 make_reel.py voice   <폴더>  → 일레븐랩스 B 목소리로 문장별 녹음 + 제미나이 검수(짧은 결과)
   - 걸린 문장만:  python3 make_reel.py voice <폴더> --redo 3,7
5. python3 make_reel.py render  <폴더>  → 피아노 자동 선택(가장 오래 안 쓴 곡)·믹싱(-16 LUFS)·mp4
   (4+5 한 번에: all)  — 60초 릴스 기준 약 2분 30초

## 폴더 구성
- make_reel.py — 전체 제작 프로그램
- scene/engine.js — 화면 엔진(진행 바·페이지 번호·태그·헤드라인·자막·하단 로고·전환, 부품 자동 크기 맞춤)
- scene/parts/*.js — 화면 부품 30종 (숫자·그래프·글자·사진·구조·도식). 명세: scene/PARTS_SPEC.md
  - 부품마다 variant {layout, motion, accent} 0~2 로 모습이 달라진다
  - 문자열 강조 문법: [[파랑 강조]] ((회색)) ~~빨간 취소선~~
- piano/ — 클래식 피아노 20곡 (calm_01~10 잔잔, grand_01~10 웅장), rotation.json 으로 돌려 씀
- brand/ — 투명 PNG 로고(흰 판 없이 얹는다)
  - motif_logo_dark/light, thelx_ink_dark/light(THE LX), lxsg_ink_dark/light(THE LX + Solar Gard PREMIUM 묶음),
    solargard_premium_ink_dark/light(Solar Gard PREMIUM 단독, 묶음 로고에서 잘라낸 것), thelx_logo_v2(원본)
- voice/ref_full.wav, refD.wav — B 목소리 원본 녹음 (일레븐랩스 목소리 "MOTIF B2 (원본)" voice_id 5WQiuyr3CgBT8RI5vL9r 를 만든 파일)
- photos/ — 자주 쓰는 시공 사진
- history.json — 최근 릴스에 쓴 부품·피아노 (반복 방지용, 자동 기록)
- tools/, render/, examples/ — 예전 OmniVoice 방식 (일레븐랩스가 안 될 때만)

## 알려진 보완점
- sun_reflect(햇빛 도식)·glass_layers(유리 층) 라벨이 가끔 겹친다, night_view(밤 시야) 대비가 약하다 → 쓸 때 sheet.jpg로 확인
- 부품 수정·추가는 scene/parts/ 에 PARTS.이름={build,update} 형식으로 파일을 더하면 된다 (제미나이에게 PARTS_SPEC.md + engine.js API를 주고 맡기면 토큰 절약)

목소리 사용 권한: 마틴이 원본 화자에게 허락을 받았다고 밝힌 목소리. 모티프 콘텐츠에만 사용.

## 험비 캐릭터 (요청할 때만)
    python3 humbi/humbi.py <릴스 폴더>   → 오른쪽 아래 치즈냥이 험비가 표정을 바꾸며 말하는 *_humbi.mp4. 자세한 건 humbi/README.md
