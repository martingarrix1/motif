# 깜비 (치즈냥이 캐릭터) — 마틴이 "깜비 넣어줘"라고 할 때만
- 마틴의 고양이 깜비를 본뜬 캐릭터(샌디 캐러멜 털 · 이마 M자 줄무늬 · 올리브 그린 눈). 2026-11-21 LX 블랙 릴스에서 처음 씀.
- 텍스트 버전 릴스를 만든 뒤: python3 ~/mk/textkit/kkambi/kkambi.py <릴스 폴더>  → *_kkambi.mp4 (약 40초)
- 표정 자동 선택(첫 문장 놀람 · 질문 궁금 · ~셈이죠 확신 · 원리 생각 · 마무리 뿌듯). 바꾸려면 폴더에 kkambi.json.
- 그림을 고칠 때만 kkambi.js 수정 후 python3 sprites.py (playwright + google-chrome 필요) → sp/ PNG 24장 갱신.
