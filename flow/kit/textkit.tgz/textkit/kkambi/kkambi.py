"""깜비(치즈냥이) 캐릭터 얹기 — 마틴이 요청할 때만 쓴다.
사용: python3 kkambi.py <릴스 폴더> [원본.mp4]
- 폴더의 timing.json(make_text.py가 만든 것)으로 문장별 표정을 자동으로 고른다.
- 표정을 직접 정하려면 폴더에 kkambi.json = ["surprise","curious",...] (문장 수만큼) 을 둔다.
- 표정: base 기본 · curious 궁금(?) · surprise 놀람(!) · think 생각(…) · sure 확신(✓) · proud 뿌듯(✦)
- 결과: <원본 이름>_kkambi.mp4 (오른쪽 아래 · 입은 목소리에 맞춰 · 3.4초마다 깜빡 · 표정 바뀔 때 통통)
"""
import json,subprocess,numpy as np,math,sys,os,glob,re
from PIL import Image
HERE=os.path.dirname(os.path.abspath(__file__))
D=os.path.abspath(sys.argv[1])
if len(sys.argv)>2: SRC=sys.argv[2]
else:
  c=[f for f in sorted(glob.glob(D+'/*.mp4')) if '_kkambi' not in f]
  c.sort(key=lambda f:(not os.path.basename(f).startswith('reel_'),f)); SRC=c[0]
OUT=SRC[:-4]+'_kkambi.mp4'
W,H,FPS=1080,1920,30; LEAD=0.3
TM=json.load(open(D+'/timing.json')); SS=TM['sent_starts']; SEN=TM['sentences']; G=TM['groups']
def auto():
  E=[]
  last_scene_2nd=G[-2][-1] if len(G)>1 else -1
  for i,s in enumerate(SEN):
    t=s.strip()
    if i==0: e='surprise'
    elif '모티프였습니다' in t: e='proud'
    elif t.endswith('?') or t.endswith('까') or '같은데' in t: e='curious'
    elif i==last_scene_2nd: e='proud'
    elif i==G[-1][0]: e='think'
    elif re.search(r'(셈이죠|거죠|수밖에 없습니다|분명|결국)',t) and not t.startswith('그런데'): e='sure'
    elif re.search(r'(때문|원리|간섭|파장|에 따라|구조|설계)',t): e='think'
    else: e='base'
    E.append(e)
  return E
EXP=json.load(open(D+'/kkambi.json')) if os.path.exists(D+'/kkambi.json') else auto()
print('표정:',' / '.join(f'{i+1}{e}' for i,e in enumerate(EXP)))
DUR=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',SRC]))
SC=0.55; CW,CH=int(600*SC),int(680*SC); X0,Y0=W-CW-24,H-CH-28
SP={}
for n in set(EXP):
  for k in ['00','01','10','11']:
    SP[n+k]=Image.open(f'{HERE}/sp/{n}_{k}.png').convert('RGBA').resize((CW,CH),Image.LANCZOS)
VO=D+'/voice_mix.wav' if os.path.exists(D+'/voice_mix.wav') else SRC
sr=16000
a=np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',VO,'-ac','1','-ar',str(sr),'-f','s16le','-']),np.int16).astype(np.float32)/32768
N=int(DUR*FPS); rms=np.zeros(N)
for f in range(N):
  s=a[int(f/FPS*sr):int((f+1)/FPS*sr)]; rms[f]=np.sqrt((s**2).mean()) if len(s) else 0
thr=max(0.02,np.percentile(rms[rms>0.005],35)*0.9) if (rms>0.005).any() else 0.03
talk=np.zeros(N,int); st=0;hold=0
for f in range(N):
  want=1 if rms[f]>thr else 0
  if f%3==0 and want: want=1-st if st else 1
  if hold>0: hold-=1
  elif want!=st: st=want; hold=1
  talk[f]=st
def idx(t):
  i=0
  for j,s in enumerate(SS):
    if t>=LEAD+s-0.05: i=j
  return min(i,len(EXP)-1)
p_in=subprocess.Popen(['ffmpeg','-v','error','-i',SRC,'-f','rawvideo','-pix_fmt','rgb24','-'],stdout=subprocess.PIPE)
p_out=subprocess.Popen(['ffmpeg','-y','-v','error','-thread_queue_size','64','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(FPS),'-i','-','-i',SRC,'-map','0:v','-map','1:a','-c:v','libx264','-preset','veryfast','-crf','19','-pix_fmt','yuv420p','-c:a','copy','-t',f'{DUR:.2f}',OUT],stdin=subprocess.PIPE)
prev=None;chg=-9
for f in range(N):
  raw=p_in.stdout.read(W*H*3)
  if len(raw)<W*H*3: break
  t=f/FPS; fr=Image.frombytes('RGB',(W,H),raw).convert('RGBA')
  i=idx(t); n=EXP[i]
  if i!=prev: chg=t; prev=i
  blink=n!='proud' and (t%3.4)<0.12
  sp=SP[f"{n}{talk[f]}{int(blink)}"]
  ap=min(1,max(0,(t-0.15)/0.45)); ease=1-(1-ap)**3
  dp=min(1,(t-chg)/0.28); pop=1+0.08*math.sin(math.pi*dp)*(1-dp*0.3) if t-chg<0.28 else 1
  s=pop*(1+0.012*math.sin(t*2*math.pi/2.6)); w2,h2=int(CW*s),int(CH*s)
  im=sp.resize((w2,h2),Image.BILINEAR)
  x=X0+(CW-w2)//2; y=Y0+(CH-h2)+int((1-ease)*80)
  k=ease*(max(0,1-(t-(DUR-0.5))/0.5) if t>DUR-0.5 else 1)
  if k<1: im=im.copy(); im.putalpha(im.getchannel('A').point(lambda v:int(v*k)))
  fr.alpha_composite(im,(x,y)); p_out.stdin.write(fr.convert('RGB').tobytes())
p_out.stdin.close(); p_out.wait(); print('완성:',OUT)
