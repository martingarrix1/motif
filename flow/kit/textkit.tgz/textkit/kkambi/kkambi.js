// 깜비(치즈냥이) 캐릭터 SVG — 표정 · 입 · 눈 깜빡임
const OR='#D9A872',ST='#A8713E',CR='#F6EBDC',INK='#2B2320',PK='#E3A3A0',NS='#C98B7E',IR='#A9A45C',BL='#2563EB';
function eyes(t,blink){
 const L=118,R=182,Y=150;
 const shut=(x)=>`<path d="M${x-14} ${Y+2} Q${x} ${Y+10} ${x+14} ${Y+2}" stroke="${INK}" stroke-width="5.5" fill="none" stroke-linecap="round"/>`;
 if(blink&&t!=='happy')return t==='wink'?shut(L)+shut(R):shut(L)+shut(R);
 const cat=(x,dx,dy,r)=>`<ellipse cx="${x}" cy="${Y}" rx="${r}" ry="${r+3}" fill="${IR}" stroke="${INK}" stroke-width="3.5"/><ellipse cx="${x+dx}" cy="${Y+dy}" rx="${r*0.32}" ry="${r*0.95}" fill="${INK}"/><circle cx="${x+dx+r*0.38}" cy="${Y+dy-r*0.45}" r="${r*0.27}" fill="#fff"/>`;
 if(t==='open')return cat(L,0,0,13)+cat(R,0,0,13);
 if(t==='big')return `<ellipse cx="${L}" cy="${Y}" rx="18" ry="20" fill="${IR}" stroke="${INK}" stroke-width="4"/><ellipse cx="${R}" cy="${Y}" rx="18" ry="20" fill="${IR}" stroke="${INK}" stroke-width="4"/><circle cx="${L}" cy="${Y+1}" r="11" fill="${INK}"/><circle cx="${R}" cy="${Y+1}" r="11" fill="${INK}"/><circle cx="${L+5}" cy="${Y-5}" r="4.5" fill="#fff"/><circle cx="${R+5}" cy="${Y-5}" r="4.5" fill="#fff"/>`;
 if(t==='happy')return `<path d="M${L-14} ${Y+5} Q${L} ${Y-12} ${L+14} ${Y+5}" stroke="${INK}" stroke-width="6" fill="none" stroke-linecap="round"/><path d="M${R-14} ${Y+5} Q${R} ${Y-12} ${R+14} ${Y+5}" stroke="${INK}" stroke-width="6" fill="none" stroke-linecap="round"/>`;
 if(t==='up')return cat(L,3,-5,13)+cat(R,3,-5,13);
 if(t==='wink')return cat(L,0,0,13)+`<path d="M${R-14} ${Y} Q${R} ${Y+10} ${R+14} ${Y}" stroke="${INK}" stroke-width="6" fill="none" stroke-linecap="round"/>`;
 if(t==='side')return cat(L,5,0,12)+cat(R,5,0,12)+`<path d="M${L-15} ${Y-9} L${L+14} ${Y-6}" stroke="${OR}" stroke-width="7"/><path d="M${R-15} ${Y-6} L${R+14} ${Y-9}" stroke="${OR}" stroke-width="7"/>`;
}
function brows(t){
 if(t==='q')return `<path d="M102 122 L130 128" stroke="${INK}" stroke-width="5" stroke-linecap="round"/><path d="M170 118 Q184 106 200 114" stroke="${INK}" stroke-width="5" fill="none" stroke-linecap="round"/>`;
 if(t==='up')return `<path d="M102 116 Q118 104 134 113" stroke="${INK}" stroke-width="5" fill="none" stroke-linecap="round"/><path d="M166 113 Q182 104 198 116" stroke="${INK}" stroke-width="5" fill="none" stroke-linecap="round"/>`;
 if(t==='sure')return `<path d="M102 124 L132 119" stroke="${INK}" stroke-width="5" stroke-linecap="round"/><path d="M168 119 L198 124" stroke="${INK}" stroke-width="5" stroke-linecap="round"/>`;
 return '';
}
function mouth(t,talk){
 const m=`<path d="M150 180 L150 187" stroke="${INK}" stroke-width="4" stroke-linecap="round"/>`;
 if(t==='o')return m+(talk?`<ellipse cx="150" cy="200" rx="10" ry="14" fill="${INK}"/><ellipse cx="150" cy="206" rx="6" ry="6" fill="${PK}"/>`:`<ellipse cx="150" cy="197" rx="8" ry="9" fill="${INK}"/>`);
 if(talk)return m+`<path d="M135 187 Q150 214 165 187 Q150 193 135 187 Z" fill="${INK}"/><path d="M142 199 Q150 208 158 199 Z" fill="${PK}"/>`;
 if(t==='w')return m+`<path d="M134 187 Q142 197 150 187 Q158 197 166 187" stroke="${INK}" stroke-width="4" fill="none" stroke-linecap="round"/>`;
 if(t==='open')return m+`<path d="M134 187 Q150 214 166 187 Z" fill="${INK}"/><path d="M142 199 Q150 208 158 199 Z" fill="${PK}"/>`;
 if(t==='hm')return m+`<path d="M138 193 Q150 186 162 195" stroke="${INK}" stroke-width="4" fill="none" stroke-linecap="round"/>`;
 return m+`<path d="M140 190 Q150 194 160 190" stroke="${INK}" stroke-width="4" fill="none" stroke-linecap="round"/>`;
}
const BADGE=(t,c)=>`<g><circle cx="262" cy="46" r="27" fill="${c}"/><text x="262" y="59" font-size="36" font-weight="900" fill="#fff" text-anchor="middle" font-family="Noto Sans CJK KR">${t}</text></g>`;
const EX={
 base:{eye:'open',mouth:'w',brow:''},
 curious:{eye:'side',mouth:'hm',brow:'q',tilt:-12,fx:BADGE('?',BL)},
 surprise:{eye:'big',mouth:'o',brow:'up',fx:BADGE('!','#141416')},
 think:{eye:'up',mouth:'',brow:'',tilt:6,fx:`<g fill="#9AA0AA"><circle cx="236" cy="66" r="7"/><circle cx="258" cy="48" r="9"/><circle cx="282" cy="26" r="11"/></g>`},
 sure:{eye:'wink',mouth:'open',brow:'sure',paw:1,fx:BADGE('✓',BL)},
 proud:{eye:'happy',mouth:'w',brow:'',blush:1,fx:`<path d="M258 22 l6 14 l14 6 l-14 6 l-6 14 l-6 -14 l-14 -6 l14 -6 Z" fill="${BL}"/><path d="M232 80 l3 7 l7 3 l-7 3 l-3 7 l-3 -7 l-7 -3 l7 -3 Z" fill="#9646EB"/>`},
};
function cat(name,talk,blink){
 const o=EX[name],tilt=o.tilt||0;
 return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 340" width="300" height="340">
 <path d="M220 300 Q290 290 272 220 Q262 190 248 205" stroke="${OR}" stroke-width="22" fill="none" stroke-linecap="round"/>
 <path d="M266 252 l14 -4 M261 226 l14 2 M250 288 l10 10" stroke="${ST}" stroke-width="6" stroke-linecap="round"/>
 <ellipse cx="150" cy="282" rx="82" ry="52" fill="${OR}"/>
 <path d="M86 262 l18 8 M84 286 l18 4 M214 262 l-18 8 M216 286 l-18 4" stroke="${ST}" stroke-width="6" stroke-linecap="round"/>
 <ellipse cx="150" cy="292" rx="44" ry="38" fill="${CR}"/>
 <ellipse cx="112" cy="326" rx="22" ry="12" fill="${CR}"/><ellipse cx="188" cy="326" rx="22" ry="12" fill="${CR}"/>
 ${o.paw?`<ellipse cx="228" cy="236" rx="20" ry="17" fill="${CR}" stroke="${OR}" stroke-width="6"/>`:''}
 <g transform="rotate(${tilt} 150 160)">
  <path d="M74 122 L84 44 L138 92 Z" fill="${OR}"/><path d="M88 104 L94 64 L122 92 Z" fill="${PK}" opacity=".8"/>
  <path d="M226 122 L216 44 L162 92 Z" fill="${OR}"/><path d="M212 104 L206 64 L178 92 Z" fill="${PK}" opacity=".8"/>
  <ellipse cx="150" cy="158" rx="96" ry="80" fill="${OR}"/>
  <path d="M130 112 L138 86 L150 104 L162 86 L170 112" stroke="${ST}" stroke-width="7" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M112 92 L120 112 M188 92 L180 112" stroke="${ST}" stroke-width="6" stroke-linecap="round"/>
  <path d="M56 150 L82 153 M58 172 L84 168 M244 150 L218 153 M242 172 L216 168" stroke="${ST}" stroke-width="7" stroke-linecap="round"/>
  <path d="M94 136 Q84 130 78 136 M206 136 Q216 130 222 136" stroke="${ST}" stroke-width="5" fill="none" stroke-linecap="round"/>
  <ellipse cx="150" cy="192" rx="50" ry="36" fill="${CR}"/>
  ${o.blush?`<ellipse cx="96" cy="182" rx="14" ry="8" fill="${PK}" opacity=".6"/><ellipse cx="204" cy="182" rx="14" ry="8" fill="${PK}" opacity=".6"/>`:''}
  ${brows(o.brow)}${eyes(o.eye,blink)}
  <path d="M141 170 Q150 165 159 170 Q150 183 141 170 Z" fill="${NS}"/>
  ${mouth(o.mouth,talk)}
  <path d="M104 188 L68 182 M104 196 L70 200 M196 188 L232 182 M196 196 L230 200" stroke="#fff" stroke-width="3" stroke-linecap="round" opacity=".9"/>
 </g>
 ${o.fx||''}
 </svg>`;
}
