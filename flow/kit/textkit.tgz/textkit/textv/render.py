import numpy as np, math, random, subprocess, sys, wave, json, re, os
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageChops
W,H,FPS=1080,1920,30
D=sys.argv[1].rstrip("/"); MODE=sys.argv[2]; OUTN=sys.argv[3] if len(sys.argv)>3 else D+"/out.mp4"
KIT=os.path.dirname(os.path.abspath(__file__)); JOB=json.load(open(D+"/job.json")); VO=D+"/vo"; LOGO=JOB.get("mode","thelx")
LEAD=0.3; T=[]
if os.path.exists(D+"/timing.json"):
    TM=json.load(open(D+"/timing.json")); SS=TM["sent_starts"]; SD=TM["sent_durs"]; INFO=[]
    for g in TM["groups"]:
        s0=SS[g[0]]; T.append(LEAD+s0); INFO.append({"d":SS[g[-1]]+SD[g[-1]]-s0,"ph":[[SS[j]-s0,SD[j]] for j in g]})
    N=len(INFO)
else:
    TM=None; INFO=json.load(open(VO+"/info.json")); N=len(INFO); GAP=0.28; t=LEAD
    for i in range(N): T.append(t); t+=INFO[i]["d"]+GAP
TEND=T[-1]+INFO[-1]["d"]; DUR=TEND+(5.5 if LOGO=="motif" else 4.0)
FD="/usr/share/fonts/opentype/noto/NotoSansCJK-%s.ttc"; _fc={}
def F(w,s):
    if (w,s) not in _fc: _fc[(w,s)]=ImageFont.truetype(FD%w,s)
    return _fc[(w,s)]
Bk,Bd,Md="Black","Bold","Medium"
INK=(24,26,34); SUB=(120,124,138); G0,G1=(36,108,255),(150,70,235)
WM={"Bk":"Black","Bd":"Bold","Md":"Medium"}; TX={}; ECP=None
for i,sc in enumerate(JOB["scenes"]):
    for j,p in enumerate(sc["phrases"]):
        if p.get("endcard") and ECP is None: ECP=(i,j)
        if p.get("show"):
            g=(p.get("gfx") or {}).get("name"); TX[(i,j)]=(sc["tag"],p["show"]["mode"],[(l[0],WM.get(l[1],l[1]),int(l[2])) for l in p["show"]["lines"]],g,-500 if g else 0)
SL=[]
for i in range(N):
    for j,(st,du) in enumerate(INFO[i]["ph"]):
        if (i,j) in TX:
            tag,mode,lines,g,yo=TX[(i,j)]; pops=[]
            sent=re.sub(r"\s","",(TM["sentences"][TM["groups"][i][j]] if TM else ""))
            for k,l in enumerate(lines):
                m_=re.search(r"\[(.+?)\]",l[0]); tp=None
                if m_:
                    w_=re.sub(r"\s","",m_.group(1)); w0=re.sub(r"[^0-9가-힣A-Za-z]","",w_)[:3]; pos=sent.find(w0) if (sent and w0) else -1
                    tp=(0.12+du*pos/max(1,len(sent))) if pos>=0 else 0.75+0.11*k
                    tp=max(tp,0.55+0.11*k)
                pops.append(tp if i==0 else None)
            SL.append(dict(t=T[i]+st-0.12,tag=tag,mode=mode,lines=lines,sc=i,g=g,yo=yo,pops=pops))
EC=(T[ECP[0]]+INFO[ECP[0]]["ph"][ECP[1]][0]-0.25) if ECP else TEND+0.5
for k,s in enumerate(SL): s["e"]=SL[k+1]["t"] if k+1<len(SL) else EC
SL[0]["t"]=0.0
def expo(p): p=max(0.0,min(1.0,p)); return 1-2**(-10*p) if p<1 else 1.0
def eo(p): p=max(0,min(1,p)); return 1-(1-p)**3
_d0=ImageDraw.Draw(Image.new("RGBA",(4,4)))
def lineimg(txt,w,s,maxw=960,col=INK):
    segs=[(x,i%2==1) for i,x in enumerate(re.split(r"[\[\]]",txt)) if x]
    plain="".join(x for x,_ in segs); tw=_d0.textlength(plain,font=F(w,s))
    if tw>maxw: s=int(s*maxw/tw)
    f=F(w,s); tw=int(_d0.textlength(plain,font=f))+2; h=int(s*1.22)
    im=Image.new("RGBA",(tw+40,h+40),(0,0,0,0)); x=20.0
    for t_,g in segs:
        sw=_d0.textlength(t_,font=f); ln=Image.new("RGBA",im.size,(0,0,0,0)); ImageDraw.Draw(ln).text((x,20-s*0.12),t_,font=f,fill=col+(255,))
        if g:
            a=np.array(ln); gx=np.clip((np.arange(im.width)-x)/max(1,sw),0,1)[None,:,None]
            a[...,:3]=(np.array(G0)[None,None,:]*(1-gx)+np.array(G1)[None,None,:]*gx).astype(np.uint8)*np.ones((a.shape[0],1,1),np.uint8); ln=Image.fromarray(a)
        if g: im.info.setdefault("hl",[]).append((int(x),int(x+sw)+2))
        im.alpha_composite(ln); x+=sw
    return im
# ---------- background ----------
yy,xx=np.mgrid[0:H,0:W].astype(np.float32); u=xx/W; v=yy/H
def grad(c0,c1,c2,ang):
    d=np.clip(u*math.cos(ang)+v*math.sin(ang),0,1.4)/1.4; r=np.sqrt((u-0.3)**2+(v-0.25)**2)
    a=np.array(c0)[None,None,:]*(1-d[...,None])+np.array(c1)[None,None,:]*d[...,None]
    k=np.clip(1-r*1.3,0,1)[...,None]**2; a=a*(1-0.9*k)+np.array(c2)[None,None,:]*0.9*k
    return Image.fromarray(np.clip(a,0,255).astype(np.uint8))
BGA=grad((255,255,255),(244,246,251),(255,255,255),1.0); BGB=grad((255,255,255),(247,245,251),(255,255,255),1.25)
rd=random.Random(5); DUST=[]
def sprite(r,bl,col,al):
    s=int(r*2+bl*6+6); im=Image.new("RGBA",(s,s),(0,0,0,0)); ImageDraw.Draw(im).ellipse([s/2-r,s/2-r,s/2+r,s/2+r],fill=col+(al,))
    return im.filter(ImageFilter.GaussianBlur(bl)) if bl>0 else im
for k in range(95):
    z=rd.random()
    if z<0.18: r=14+rd.random()*22; bl=9+rd.random()*6; al=int(40+rd.random()*30); sp=10+rd.random()*10
    elif z<0.6: r=4+rd.random()*5; bl=2+rd.random()*2; al=int(90+rd.random()*60); sp=18+rd.random()*18
    else: r=1.5+rd.random()*2.2; bl=0.6; al=int(150+rd.random()*80); sp=26+rd.random()*30
    col=rd.choice([(176,170,160),(150,160,186),(196,182,150),(168,168,176)])
    DUST.append((rd.random()*W,rd.random()*H,sprite(r,bl,col,al),sp,rd.random()*6.28,0.3+rd.random()*0.9,20+rd.random()*50,rd.random()*6.28,0.8+rd.random()*2))
bm=np.clip(1-np.abs((u-0.15)-(v-0.0)*0.55)*3.2,0,1)**2*np.clip(1-v*0.9,0,1)
BEAM=Image.fromarray((bm*0).astype(np.uint8))
DUST=[]
def bg(t):
    out=Image.blend(BGA,BGB,0.5+0.5*math.sin(t*0.22)).convert("RGBA")
    wl=Image.new("RGBA",(W,H),(255,255,255,0)); wl.putalpha(BEAM.point(lambda x:int(x*(0.75+0.25*math.sin(t*0.5))))); out.alpha_composite(wl)
    for x0,y0,sp_,v_,ph,fw,amp,tp,tf in DUST:
        x=(x0+amp*math.sin(t*fw+ph)+v_*0.35*t)%(W+80)-40; y=(y0-v_*t)%(H+80)-40
        tw=0.6+0.4*math.sin(t*tf+tp)
        s=sp_ if tw>0.97 else Image.merge("RGBA",(*sp_.split()[:3],sp_.split()[3].point(lambda a:int(a*tw))))
        out.alpha_composite(s,(int(x-s.width/2),int(y-s.height/2))) if -s.width<x-s.width/2<W and -s.height<y-s.height/2<H and x-s.width/2>=0 and y-s.height/2>=0 else None
    return out
BR=os.path.join(KIT,"..","brand")+"/"; ML=Image.open(BR+"motif_logo_dark.png").convert("RGBA")
def mlogo(wd): return ML.resize((wd,int(wd*ML.height/ML.width)),Image.LANCZOS)
cache={}
def put(out,img,x0,y0,al=1.0):
    if al<=0: return
    if al<1: img=img.copy(); img.putalpha(img.split()[3].point(lambda v:int(v*al)))
    x0=int(x0); y0=int(y0); cx=max(0,-x0); cy_=max(0,-y0)
    if cx or cy_: img=img.crop((cx,cy_,img.width,img.height)); x0+=cx; y0+=cy_
    if img.width>0 and img.height>0 and x0<W and y0<H: out.alpha_composite(img,(x0,y0))
def L_of(si):
    if si not in cache: cache[si]=[lineimg(*l) for l in SL[si]["lines"]]
    return cache[si]
def draw_text(out,si,ts,yoff=0,amul=1.0,final=False):
    s=SL[si]; ims=L_of(si); mode=s["mode"]; cy=930+s["yo"]; tot=sum(i.height-40 for i in ims)+12*(len(ims)-1)
    drift=0 if final else -14*min(1,ts/4.0); y=cy-tot/2+yoff+drift-20; N_=len(ims)
    calm=(not final) and (not s.get("g"))   # 그래프 없는 글자 장면: 천천히 다가오기 + 강조 단어 밑줄
    zf=1+0.035*min(1,max(0,ts)/3.0) if calm else 1.0
    for k,im in enumerate(ims):
        if zf>1.001:
            hl0=im.info.get("hl"); im=im.resize((int(im.width*zf),int(im.height*zf)),Image.BILINEAR)
            if hl0: im.info["hl"]=[(int(a*zf),int(b*zf)) for a,b in hl0]
        tk=ts-0.11*k; e=1.0 if final else expo(tk/0.5); h=im.height; x=W/2-im.width/2; al=amul
        tp=s.get("pops",[None]*N_)[k] if not final else None; pp=(ts-tp)/0.55 if (tp is not None and im.info.get("hl")) else -1
        hl=im.info.get("hl")
        if 0<pp<1:
            im=im.copy(); a_=np.array(im)
            for (hx0,hx1) in hl: a_[:,max(0,hx0-2):hx1+2,3]=0
            im=Image.fromarray(a_)
        if not final and mode!="rise": al*=max(0,min(1,tk/0.14))
        if mode=="rise":
            off=int(h*(1-e))
            if off<h-2: put(out,im.crop((0,0,im.width,h-off)),x,y+off,al)
        else:
            dx=dy=0
            if mode=="drop": dy=-200*(1-e)
            elif mode=="split": dy=(-260 if k<N_/2 else 260)*(1-e)
            elif mode=="alt": dx=(-460 if k%2==0 else 460)*(1-e)
            tr=im; br=0 if final else 9*(1-min(1,max(0,tk)/0.2))
            if br>0.8: tr=im.filter(ImageFilter.GaussianBlur(br))
            put(out,tr,x+dx,y+dy,al)
        if 0<pp<1:
            src=L_of(si)[k]; fz=1+0.22*math.sin(math.pi*pp)*(1-0.35*pp); lift=-14*math.sin(math.pi*pp)
            for (hx0,hx1) in hl:
                seg=src.crop((hx0,0,hx1,h)); nw=int(seg.width*fz); nh=int(seg.height*fz)
                put(out,seg.resize((nw,nh),Image.LANCZOS),x+(hx0+hx1)/2-nw/2,y+h/2-nh/2+lift,amul)
        y+=h-40+12
    lw=int(120*(1.0 if final else expo((ts-0.3)/0.6)))
    if lw>3:
        d=ImageDraw.Draw(out); yb=int(cy+tot/2+yoff+drift+46); a=int(255*amul)
        for q in range(-lw,lw,4):
            p=(q+lw)/(2*lw); c=tuple(int(G0[i]+(G1[i]-G0[i])*p) for i in range(3)); d.rectangle([W/2+q,yb,W/2+q+4,yb+6],fill=c+(a,))
def endcard(out,te):
    if "ec" not in cache:
        it=[]; P=JOB.get("product","")
        if LOGO=="motif":
            LS=Image.open(BR+"motif_logo_dark.png").convert("RGBA"); it.append((LS.resize((420,int(420*LS.height/LS.width)),Image.LANCZOS),800))
            if P: it.append((lineimg(P,Bd,46),1010))
            it.append((lineimg("전주 덕진구 정여립로 1104 · 010-4814-4506",Md,32,col=SUB),1110))
        else:
            if LOGO=="thelx":
                LS=Image.open(BR+"lxsg_ink_dark.png").convert("RGBA"); it.append((LS.resize((300,int(300*LS.height/LS.width)),Image.LANCZOS),760))
            if LOGO=="sgp":
                LS=Image.open(BR+"solargard_premium_ink_dark.png").convert("RGBA"); it.append((LS.resize((420,int(420*LS.height/LS.width)),Image.LANCZOS),800))
            if P: it.append((lineimg(P,Bd,40,col=SUB),1120 if LOGO in ("thelx","sgp") else 900))
        cache["ec"]=it
    for k,(im,y) in enumerate(cache["ec"]):
        ek=expo((te-0.18*k)/0.7); put(out,im,W/2-im.width/2,y+60*(1-ek),min(1,max(0,(te-0.18*k)/0.45)))
def tagimg(txt):
    k=("tag",txt)
    if k not in cache:
        ti=lineimg(txt,Bd,40,col=(60,90,200)); im=Image.new("RGBA",(ti.width+30,ti.height-4),(0,0,0,0)); ImageDraw.Draw(im).rounded_rectangle([0,12,im.width-1,im.height-12],radius=30,fill=(60,110,255,26),outline=(60,110,255,90),width=2); im.alpha_composite(ti,(15,-2)); cache[k]=im
    return cache[k]
# ---- premium gfx: 2x supersampled, hairlines, soft shadows ----
ACC=(36,108,255); HAIR=(216,220,230); SOFT=(150,155,168); MET0=(176,184,200); MET1=(232,235,242); CHAMP=(198,170,118); Rg="Regular"; Lt="Light"
Y0=760; HH=900
def rgba(c,a=1.0): return (c[0],c[1],c[2],int(255*max(0,min(1,a))))
def mixc(a,b,p): p=max(0,min(1,p)); return tuple(int(a[i]+(b[i]-a[i])*p) for i in range(3))
class Ly:
    def __init__(s): s.im=Image.new("RGBA",(W*2,HH*2),(0,0,0,0)); s.d=ImageDraw.Draw(s.im)
    def P(s,x,y): return (x*2,(y-Y0)*2)
    def line(s,pts,col,w=2,a=1.0):
        if a<=0.01: return
        s.d.line([s.P(*p) for p in pts],fill=rgba(col,a),width=max(1,int(w*2)),joint="curve")
    def rrect(s,b,r,fill=None,outline=None,w=1.5,a=1.0):
        x0,y0=s.P(b[0],b[1]); x1,y1=s.P(b[2],b[3])
        if x1-x0<2 or y1-y0<2: return
        r=min(r*2,(x1-x0)/2,(y1-y0)/2); s.d.rounded_rectangle([x0,y0,x1,y1],radius=r,fill=rgba(fill,a) if fill else None,outline=rgba(outline,a) if outline else None,width=int(w*2))
    def circ(s,x,y,r,fill=None,outline=None,w=1.5,a=1.0):
        if a<=0.01: return
        X,Y=s.P(x,y); s.d.ellipse([X-r*2,Y-r*2,X+r*2,Y+r*2],fill=rgba(fill,a) if fill else None,outline=rgba(outline,a) if outline else None,width=int(w*2))
    def text(s,t_,wt,sz,x,y,col=INK,anc="lm",a=1.0,sp=0):
        if a<=0: return
        f=F(wt,int(sz*2)); X,Y=s.P(x,y)
        if sp==0: s.d.text((X,Y),t_,font=f,fill=rgba(col,a),anchor=anc); return
        tw=sum(s.d.textlength(ch,font=f)+sp*2 for ch in t_)-sp*2
        if anc[0]=="m": X-=tw/2
        elif anc[0]=="r": X-=tw
        for ch in t_: s.d.text((X,Y),ch,font=f,fill=rgba(col,a),anchor="l"+anc[1]); X+=s.d.textlength(ch,font=f)+sp*2
    def tw(s,t_,wt,sz): return s.d.textlength(t_,font=F(wt,int(sz*2)))/2
    def gbar(s,b,c0,c1,r,a=1.0,vert=False):
        x0,y0=s.P(b[0],b[1]); x1,y1=s.P(b[2],b[3]); w=int(x1-x0); h=int(y1-y0)
        if w<2 or h<2: return
        g=np.linspace(0,1,h if vert else w)[:,None]; c=(np.array(c0)[None,:]*(1-g)+np.array(c1)[None,:]*g).astype(np.uint8)
        arr=np.repeat(c[:,None,:],w,1) if vert else np.repeat(c[None,:,:],h,0); im=Image.fromarray(arr,"RGB").convert("RGBA")
        m=Image.new("L",(w,h),0); ImageDraw.Draw(m).rounded_rectangle([0,0,w-1,h-1],radius=min(r*2,w/2,h/2),fill=int(255*a)); im.putalpha(m); s.im.alpha_composite(im,(int(x0),int(y0)))
    def fin(s,out,a=1.0): put(out,s.im.resize((W,HH),Image.LANCZOS),0,Y0,a)
_shc={}
def card(out,ly,b,a=1.0,r=44):
    w=int(b[2]-b[0]); h=int(b[3]-b[1]); k=(w,h)
    if k not in _shc:
        im=Image.new("RGBA",(w+240,h+240),(0,0,0,0)); ImageDraw.Draw(im).rounded_rectangle([120,120,120+w,120+h],radius=r,fill=(40,56,110,46)); _shc[k]=im.filter(ImageFilter.GaussianBlur(44))
    put(out,_shc[k],b[0]-120,b[1]-120+30,a); ly.rrect(b,r,fill=(255,255,255),outline=(234,237,244),w=1.5,a=a)
def st(t,t0,d=0.7): return expo((t-t0)/d)
def fa(t,t0,d=0.3): return max(0,min(1,(t-t0)/d))
def num(v): return f"{int(round(v)):,}"

RED=(222,66,48)
exec(open(D+'/gfx.py').read()) if os.path.exists(D+'/gfx.py') else None
def frame(t):
    out=bg(t)
    if t>=EC:
        te=t-EC
        if te<0.22: p=te/0.22; draw_text(out,len(SL)-1,9,yoff=-300*p*p,amul=(1-p)**2,final=True)
        endcard(out,te)
    else:
        si=0
        for k,s in enumerate(SL):
            if t>=s["t"]: si=k
        s=SL[si]; ts=t-s["t"]; XT=0.22
        if si>0 and ts<XT:
            p=ts/XT; dr=-1 if si%2==0 else 1; draw_text(out,si-1,9,yoff=dr*-300*p*p,amul=(1-p)**2,final=True)
        draw_text(out,si,ts)
        if s["g"] and s["g"] in globals():
            try: globals()[s["g"]](out,ts,max(0,min(1,(s["e"]-t)/0.2)))
            except Exception as ex: pass
        if JOB.get("headline"):
            if "hd" not in cache:
                hl=JOB["headline"].split("\n")
                cache["hd"]=[lineimg(hl[0],Bd,40,maxw=900,col=SUB)] if len(hl)==1 else [lineimg(x,Bk,60 if k==0 else 52,maxw=940,col=INK if k==0 else SUB) for k,x in enumerate(hl)]
            e=expo(t/0.6); yy=58 if len(cache["hd"])==1 else 96
            for hd in cache["hd"]: put(out,hd,W/2-hd.width/2,yy-30*(1-e),e); yy+=hd.height-30
        else:
            tg=tagimg(s["tag"]); first=si==0 or SL[si-1]["tag"]!=s["tag"]; e=expo(ts/0.5) if first else 1.0
            put(out,tg,W/2-tg.width/2,205-30*(1-e),e)
        if LOGO!="none":
            if "ml" not in cache:
                fn,wd={"motif":("motif_logo_dark.png",170),"sgp":("solargard_premium_ink_dark.png",230)}.get(LOGO,("thelx_ink_dark.png",190))
                _L=Image.open(BR+fn).convert("RGBA"); cache["ml"]=_L.resize((wd,int(wd*_L.height/_L.width)),Image.LANCZOS)
            ml=cache["ml"]; put(out,ml,W/2-ml.width/2,1690,0.85*min(1,t/0.6))
    o=out.convert("RGB")
    if t>DUR-0.5: o=Image.blend(o,Image.new("RGB",(W,H),(255,255,255)),min(1,(t-(DUR-0.5))/0.5))
    return o
if MODE=="check":
    res={}
    for k,s in enumerate(SL):
        tv=Image.new("RGBA",(W,H),(0,0,0,0)); draw_text(tv,k,9,final=True); ta=np.array(tv)[...,3]>60
        if ta.any():
            xs=np.where(ta.any(0))[0]
            if xs.min()<30 or xs.max()>1050: res.setdefault("제목",[]).append(f"{k+1}번 제목이 화면 밖")
        if re.sub(r"[\[\]\s.]","",s["lines"][-1][0]).endswith("요"): res.setdefault("제목",[]).append(f"{k+1}번 제목 ~요 종결")
        if not s["g"]: continue
        fn=globals().get(s["g"]); iss=[]
        if fn is None: res[s["g"]]=["함수가 없음"]; continue
        dur=s["e"]-s["t"]
        for ts in (0.6,max(1.2,dur-0.3)):
            cv=Image.new("RGBA",(W,H),(0,0,0,0))
            try: fn(cv,ts,1.0)
            except Exception as ex: iss.append(f"실행 오류 {type(ex).__name__}: {ex}"); break
            a=np.array(cv); al=a[...,3]>60
            if not al.any(): iss.append(f"{ts:.1f}초에 아무것도 안 그려짐"); continue
            ys,xs=np.where(al)
            if xs.min()<50 or xs.max()>1030 or ys.min()<840 or ys.max()>1580: iss.append(f"카드 영역(90,880)-(1000,1520) 밖으로 나감: x {xs.min()}~{xs.max()}, y {ys.min()}~{ys.max()}")
            ink=al&(a[...,:3].astype(int).sum(-1)<690)
            if ink.any() and ts>1:
                ys,xs=np.where(ink); ar=(xs.max()-xs.min())*(ys.max()-ys.min())/(900*640)
                if ar<0.45: iss.append(f"그래픽이 카드에 비해 작음(카드의 {ar:.0%}만 사용, 75% 이상 채울 것)")
            if (ta&ink).sum()>150: iss.append("위쪽 제목 글자와 겹침")
        if iss: res[s["g"]]=sorted(set(iss))
    print(json.dumps(res,ensure_ascii=False)); sys.exit()
if MODE=="stills":
    ts=[s["t"]+0.25 for s in SL[:4]]+[s["e"]-0.1 for s in SL]+[EC+0.3,EC+2.2]; cols=11; rows=math.ceil(len(ts)/cols)
    sh=Image.new("RGB",(216*cols,384*rows))
    for k,t_ in enumerate(ts): sh.paste(frame(t_).resize((216,384)),((k%cols)*216,(k//cols)*384))
    sh.save(D+"/sheet.jpg",quality=82); print(f"{DUR:.1f}"); sys.exit()
SR=44100; n=int(DUR*SR); vo=np.zeros(n)
for i in (range(0) if TM else range(N)):
    w=wave.open(f"{VO}/scene{i+1}.wav","rb"); sr=w.getframerate(); x=np.frombuffer(w.readframes(w.getnframes()),dtype=np.int16).astype(np.float32)/32768
    if w.getnchannels()==2: x=x.reshape(-1,2).mean(axis=1)
    if sr!=SR: x=np.interp(np.arange(int(len(x)*SR/sr))*sr/SR,np.arange(len(x)),x)
    a=int(T[i]*SR); b=min(n,a+len(x)); vo[a:b]+=x[:b-a]
if TM:
    w=wave.open(D+"/voice.wav","rb"); sr=w.getframerate(); x=np.frombuffer(w.readframes(w.getnframes()),dtype=np.int16).astype(np.float32)/32768
    if w.getnchannels()==2: x=x.reshape(-1,2).mean(axis=1)
    if sr!=SR: x=np.interp(np.arange(int(len(x)*SR/sr))*sr/SR,np.arange(len(x)),x)
    a=int(LEAD*SR); b=min(n,a+len(x)); vo[a:b]+=x[:b-a]
w=wave.open(D+"/voice_mix.wav","wb"); w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((np.clip(vo,-1,1)*32000).astype(np.int16).tobytes()); w.close()
if not os.path.exists(D+"/piano.wav"): subprocess.run(["python3",KIT+"/piano_real.py",f"{DUR:.2f}",D+"/piano.wav",JOB.get("name","reel")],check=True)
p=subprocess.Popen(["ffmpeg","-y","-loglevel","error","-f","rawvideo","-pix_fmt","rgb24","-s",f"{W}x{H}","-r",str(FPS),"-i","-","-i",D+"/voice_mix.wav","-i",D+"/piano.wav","-filter_complex","[1:a]loudnorm=I=-16:TP=-1.5:LRA=11,asplit=2[v1][v2];[2:a]loudnorm=I=-18:TP=-2:LRA=11,volume=-10dB[p];[p][v1]sidechaincompress=threshold=0.02:ratio=6:attack=20:release=500[pd];[v2][pd]amix=inputs=2:normalize=0,loudnorm=I=-16:TP=-1.5:LRA=11[a]","-map","0:v","-map","[a]","-c:v","libx264","-preset","veryfast","-crf","19","-pix_fmt","yuv420p","-c:a","aac","-b:a","192k","-t",f"{DUR:.2f}",OUTN],stdin=subprocess.PIPE)
for f in range(int(DUR*FPS)): p.stdin.write(frame(f/FPS).tobytes())
p.stdin.close(); p.wait(); print("done",DUR)
