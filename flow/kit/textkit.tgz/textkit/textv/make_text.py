#!/usr/bin/env python3
"""MOTIF 텍스트 버전 릴스 (Claude 스타일 렌더러 + 제미나이 그래픽) — 명령 한 번
  python3 textv/make_text.py all <폴더>      # plan → voice → gfx(제미나이 코드) → 자동점검·재작성 → sheet.jpg → mp4
  단계별: plan | voice | gfx | check | stills | render
폴더: script.txt (화면용 대사, 장면 사이 빈 줄, 한 줄=한 문장)
"""
import sys, os, json, re, subprocess, ast
TX = os.path.dirname(os.path.abspath(__file__)); KIT = os.path.dirname(TX); sys.path.insert(0, KIT)
import make_reel as MR

def R(*a, cap=False):
    r = subprocess.run(["python3", os.path.join(TX, "render.py"), *a], capture_output=cap, text=True)
    if r.returncode: sys.exit(f"[render 오류]\n{(r.stderr or '')[-1500:]}")
    return r.stdout

def style(): return open(os.path.join(TX, "style.txt"), encoding="utf-8").read()
def code_only(t):
    t = re.sub(r"^```\w*\n|```\s*$", "", t.strip(), flags=re.M); return t

def cmd_plan(d):
    sents, groups = MR.read_script(d)
    ex = open(os.path.join(TX, "plan_example.json"), encoding="utf-8").read()
    sc = "\n".join(f"장면{i+1}:\n" + "\n".join(f"  문장{j+1}: {sents[k]}" for j, k in enumerate(g)) for i, g in enumerate(groups))
    q = f"""너는 MOTIF(전주 썬팅 전문점) 릴스 '텍스트 버전' 연출가다. 화이트 배경에 문장마다 큰 키네틱 타이포가 바뀌고, 그 중 절반 이상은 아래에 고급 모션그래픽 카드가 붙는다.
[마틴 스타일]\n{style()}
[대사]\n{sc}
규칙:
- 문장마다 하나의 phrase. show = {{"mode":"rise"|"split"|"drop","lines":[[글자,"Bk"|"Bd"|"Md",크기],...]}}.
  · rise: 2줄, 아래에 그래픽 카드가 붙는 문장(gfx 필수). 크기 70~110.
  · split/drop: 그래픽 없이 큰 글자만 2~3줄, 크기 76~130. 핵심 단어 줄은 Bk로 크게.
  · 줄당 최대 13자. [단어]는 블루 그라데이션 강조(줄마다 0~1개). 숫자는 아라비아 숫자로(3년, 10만 원).
  · 글자는 대사의 핵심을 마틴 어조 그대로 줄인 것. ~요 종결 금지, 대사에 없는 주장 금지.
- gfx: rise 문장에만 {{"name":"g_영문소문자","spec":"한국어로 자세한 그래픽 명세"}}. 릴스 전체에서 7~9개, 장면마다 최소 1개. 같은 종류 반복 금지.
  · spec에는 카드 안 구성·등장 순서·카운트업 숫자·강조 색·소제목(영문)·우상단 한글 라벨까지 구체적으로. 대사의 수치만 쓰고, 대사에 수치가 없으면 숫자 그래프 대신 도식(창·구조·비교·흐름)으로 표현하고 숫자를 지어내지 않는다.
  · 그래픽은 역동적으로: 한 그래픽 안에 등장 → 변형·이동·카운트 → 결론 강조의 3단계 이상, 멈춰 있는 시간 없이 계속 움직이게.
  · 대사의 의태어·동작어(쭈글쭈글, 반사, 쌓인다, 떨어진다, 사라진다 등)는 그래픽이 그 모양대로 직접 움직이게 명세한다.
  · 종류 예: 카운트업 큰 숫자, 막대·곡선 그래프, 타임라인, 비교 카드 2개, 체크리스트, 저울, 계단 라인업, 단면 구조, 시야 비교 창, 쌓이는 블록.
- tag: 장면마다 한글 2~5자.
- "전주 모티프였습니다" 문장은 show 없이 {{"endcard":true}}.
- product: 엔드카드 제품명(예: "솔라가드 프리미엄 [S라인]").
출력은 JSON만. 형식 예시(다른 릴스):\n{ex}"""
    t = MR.gemini([{"text": q}], model="gemini-3.1-pro-preview", timeout=900)
    job = json.loads(t[t.find("{"): t.rfind("}") + 1])
    for i, g in enumerate(groups):
        assert len(job["scenes"][i]["phrases"]) == len(g), f"장면{i+1} 문장 수 불일치"
    job["name"] = os.path.basename(os.path.abspath(d))
    job["mode"] = "motif" if any("모티프였습니다" in x for x in sents) else "thelx"
    json.dump(job, open(os.path.join(d, "job.json"), "w"), ensure_ascii=False, indent=1)
    for i, s_ in enumerate(job["scenes"]):
        for p in s_["phrases"]:
            if p.get("show"): print(f"{i+1}[{s_['tag']}] {' / '.join(l[0] for l in p['show']['lines'])}" + (f"  ← {p['gfx']['name']}" if p.get("gfx") else ""))

def specs(job):
    return [(p["gfx"]["name"], p["gfx"]["spec"]) for s_ in job["scenes"] for p in s_["phrases"] if p.get("gfx")]

def ask_gfx(items, extra=""):
    api = open(os.path.join(TX, "gfx_api.txt"), encoding="utf-8").read()
    q = (style() + "\n\n너는 파이썬 PIL 모션그래픽 개발자다. 아래 헬퍼(이미 정의됨)만 써서 함수를 작성해라. 출력은 파이썬 코드만(펜스 없이). import 금지(np, math, Image, ImageDraw 사용 가능). 다른 전역 정의 금지.\n"
         "공통: 시그니처 g_이름(out,t,a) — t=그 문장 시작 후 초(0~5), a=투명도 배수(모든 알파에 곱함). 시작은 al=a*fa(t,0,0.3); ly=Ly(); card(out,ly,(90,880,1000,1520),al), 끝은 ly.fin(out). "
         "좌표는 화면 픽셀(가로 1080), 그래픽은 카드 (90,880)-(1000,1520) 안, 카드 면적 75% 이상을 채운다. 카드 왼쪽 위 영문 소제목(Md,22,SOFT,sp=5), 오른쪽 위 한글 작은 라벨(Rg,22,SOFT,'rm'). "
         "숫자는 st()로 0부터 카운트업. 글씨 22~220px, 카드 폭을 넘거나 겹치지 않게.\n" + extra +
         "\n[함수 명세]\n" + "\n".join(f"- {n}: {s}" for n, s in items) + "\n\n[헬퍼 코드]\n" + api)
    return code_only(MR.gemini([{"text": q}], model="gemini-3.1-pro-preview", timeout=900))

def merge(old, new):
    try: nt = ast.parse(new)
    except SyntaxError: return old
    fns = {n.name: ast.get_source_segment(new, n) for n in nt.body if isinstance(n, ast.FunctionDef)}
    if not old: return "\n\n".join(fns.values())
    ot = ast.parse(old); keep = [ast.get_source_segment(old, n) for n in ot.body if isinstance(n, ast.FunctionDef) and n.name not in fns]
    return "\n\n".join(keep + list(fns.values()))

def cmd_gfx(d):
    job = json.load(open(os.path.join(d, "job.json")))
    g = os.path.join(d, "gfx.py")
    if os.path.exists(g): os.replace(g, g + ".bak")
    open(os.path.join(d, "gfx.py"), "w").write(merge("", ask_gfx(specs(job)))); print("[그래픽] 제미나이 작성 완료")

def cmd_check(d, rounds=2):
    job = json.load(open(os.path.join(d, "job.json"))); sp = dict(specs(job))
    for r in range(rounds + 1):
        res = json.loads(R(d, "check", cap=True).strip().splitlines()[-1])
        bad = {k: v for k, v in res.items() if k in sp}
        if not res: print("[자동 점검] 문제 없음"); return {}
        print(f"[자동 점검 {r+1}] " + " | ".join(f"{k}: {', '.join(v)}" for k, v in res.items()))
        if not bad or r == rounds: return res
        new = ask_gfx([(k, sp[k] + "  ※ 지난 버전 문제: " + "; ".join(v)) for k, v in bad.items()])
        g = os.path.join(d, "gfx.py"); old = open(g).read(); m = merge(old, new); open(g, "w").write(m)
    return res

def cmd_render(d):
    job = json.load(open(os.path.join(d, "job.json"))); tm = json.load(open(os.path.join(d, "timing.json")))
    dur_ = float(R(d, "stills", cap=True).strip().splitlines()[-1])
    pf = os.path.join(d, "piano.wav")
    if os.path.exists(pf): os.remove(pf)
    pn = MR.pick_piano(job.get("piano", "auto"), dur_, pf)
    out = os.path.join(d, f"reel_{job['name']}.mp4"); R(d, "render", out)
    print(f"완성: {out} ({dur_:.1f}초, 피아노 {pn})")

if __name__ == "__main__":
    a = sys.argv[1:]
    if len(a) < 2: sys.exit(__doc__)
    c, d = a
    if c == "plan": cmd_plan(d)
    elif c == "voice": MR.cmd_voice(d)
    elif c == "gfx": cmd_gfx(d)
    elif c == "check": cmd_check(d)
    elif c == "stills": print(R(d, "stills", cap=True))
    elif c == "render": cmd_render(d)
    elif c == "all":
        if not os.path.exists(os.path.join(d, "job.json")): cmd_plan(d)
        MR.cmd_voice(d)
        if not os.path.exists(os.path.join(d, "gfx.py")): cmd_gfx(d)
        cmd_check(d); cmd_render(d); print("→ sheet.jpg")
