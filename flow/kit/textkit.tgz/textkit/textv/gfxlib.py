# MOTIF 그래프 라이브러리 — Claude가 직접 다듬은 고급 모션그래픽 부품 (2026-11-22)
# render.py가 gfx.py보다 먼저 불러온다. 릴스마다 gfx.py에는 "g_이름 = L_부품(설정...)" 몇 줄만 쓴다.
#
# 마틴 기준(요약): 애플 키노트·프리미엄 자동차 브로슈어 톤 / 무채색(INK·SOFT·HAIR) 계층 + ACC는 포인트 한 곳 /
# 넓은 면을 색·그라데이션으로 채우지 않기 / 클립아트(저울·체크박스) 금지 → 큰 타이포·가는 선·점 /
# 카드가 뜬 뒤 멈춰 있지 않게: 등장 → 변형·카운트 → 결론, 그 뒤에도 미세한 흐름 하나 /
# 대사의 동작어(쭈글쭈글·반사·쌓인다·사라진다)는 그래픽이 그대로 움직인다 / 수치는 0부터 카운트업 + 세로 막대 동행 /
# 색감·외관처럼 도식이 안 되는 건 실차 사진 카드.
#
# 공통 인자: en=카드 왼쪽 위 영문 소제목, ko=오른쪽 위 한글 라벨. 시간 t는 문장 시작 후 초.

CB = (90, 880, 1000, 1520)            # 카드 영역
CX0, CX1, CY0, CY1 = 150, 940, 975, 1470   # 내용 영역


def _base(out, t, a, en, ko):
    al = a * fa(t, 0, 0.3); ly = Ly(); card(out, ly, CB, al)
    if en: ly.text(en, Md, 22, CX0, 925, SOFT, "lm", al, sp=5)
    if ko: ly.text(ko, Rg, 22, CX1, 925, SOFT, "rm", al)
    return ly, al


def _fmt(v, dec):
    return f"{v:.{dec}f}" if dec else f"{int(round(v)):,}"


def _pill(ly, x, y, txt, al, col=INK, sz=24, anc="l"):
    w = ly.tw(txt, Bd, sz) + 36; h = sz + 22
    x0 = x if anc == "l" else (x - w / 2 if anc == "m" else x - w)
    ly.rrect((x0, y - h / 2, x0 + w, y + h / 2), h / 2, fill=col, a=al)
    ly.text(txt, Bd, sz, x0 + w / 2, y, (255, 255, 255), "mm", al)


def _vbar(ly, x, y0, y1, p, al, maxv, val, w=56, col=ACC, ticks=True, t=0):
    """세로 막대: 0~maxv 눈금 트랙 + 단색 채움 + 끝 값 가는 선."""
    ly.rrect((x - w / 2, y0, x + w / 2, y1), w / 2, fill=(244, 246, 250), a=al)
    if ticks:
        for k in range(0, 5):
            yy = y1 - (y1 - y0) * k / 4
            ly.line([(x + w / 2 + 10, yy), (x + w / 2 + 22, yy)], HAIR, 1.5, al)
            ly.text(_fmt(maxv * k / 4, 0), Rg, 18, x + w / 2 + 30, yy, SOFT, "lm", al)
    h = (y1 - y0) * min(1, val / maxv) * p
    if h > 2: ly.rrect((x - w / 2, y1 - h, x + w / 2, y1), min(w / 2, h / 2), fill=col, a=al)
    if p > 0.98:   # 끝 값 표시선 + 미세한 맥동
        yy = y1 - h; q = (t * 0.7) % 1
        ly.line([(x - w / 2 - 16, yy), (x + w / 2 + 6, yy)], INK, 1.5, al)
        ly.rrect((x - w / 2 - 4 * q, yy - 3 - 6 * q, x + w / 2 + 4 * q, yy + 3 + 6 * q), 8, outline=col, w=1.5, a=al * (1 - q) * 0.7)


# 1) 수치 하나: 큰 카운트업 숫자 + 같은 속도로 차오르는 세로 막대 (TSER·VLT·차단율)
def L_stat(value, unit="%", label="", note="", en="PERFORMANCE", ko="", dec=0, maxv=100, col=None):
    col = col or ACC
    def g(out, t, a):
        ly, al = _base(out, t, a, en, ko)
        p = st(t, 0.35, 1.8)
        v = value * p
        tx = _fmt(v, dec)
        ly.text(tx, Bk, 190, CX0, 1150, INK, "ls", al)
        ly.text(unit, Bd, 70, CX0 + ly.tw(tx, Bk, 190) + 14, 1150, col, "ls", al)
        if label: ly.text(label, Bd, 40, CX0, 1240, INK, "lm", al * fa(t, 0.6, 0.4))
        if note:
            ly.line([(CX0, 1300), (CX0 + 470 * st(t, 1.4, 0.8), 1300)], HAIR, 1.5, al)
            ly.text(note, Rg, 27, CX0, 1350, SOFT, "lm", al * fa(t, 1.7, 0.4))
        _vbar(ly, 790, 1000, 1440, p, al, maxv, value, col=col, t=t)
        ly.fin(out)
    return g


# 2) 두 대상 비교 수치: 두 개의 숫자 카운트업 + 두 막대 (우세한 쪽만 ACC, 다른 쪽은 무채색)
def L_stat_pair(items, unit="%", en="COMPARISON", ko="", maxv=100, win=1, dec=0, diff=None):
    def g(out, t, a):
        ly, al = _base(out, t, a, en, ko)
        y0, y1 = 1060, 1400
        for i, (nm, val) in enumerate(items):
            x = 330 + i * 330; d0 = 0.3 + 0.45 * i; p = st(t, d0, 1.6)
            c = ACC if i == win else (205, 209, 218)
            w = 150
            ly.rrect((x - w / 2, y0, x + w / 2, y1), 26, fill=(245, 247, 250), a=al)
            h = (y1 - y0) * min(1, val / maxv) * p
            if h > 2: ly.rrect((x - w / 2, y1 - h, x + w / 2, y1), min(26, h / 2), fill=c, a=al)
            tx = _fmt(val * p, dec) + unit
            ly.text(tx, Bk, 64, x, y1 - h - 46, INK if i == win else SOFT, "mm", al * fa(t, d0, 0.3))
            ly.text(nm, Bd, 32, x, y1 + 42, INK if i == win else SOFT, "mm", al)
        if diff:   # 결론: 두 막대 끝을 잇는 가는 괄호선 + 차이 라벨
            q = st(t, 2.3, 0.7)
            xa, xb = 330, 660; ya = y1 - (y1 - y0) * min(1, items[0][1] / maxv); yb = y1 - (y1 - y0) * min(1, items[1][1] / maxv)
            ly.line([(xb + 70, yb), (xb + 70 + (790 - xb - 70) * q, yb)], HAIR, 1.5, al)
            ly.line([(780 - 20 * q, ya), (800, ya)], HAIR, 1.5, al)
            if q > 0.5:
                ly.line([(800, ya), (800, ya + (yb - ya) * st(t, 2.6, 0.5))], INK, 2, al)
                ly.text(diff, Bk, 46, 830, (ya + yb) / 2, ACC, "lm", al * fa(t, 2.8, 0.4))
        ly.fin(out)
    return g


# 3) 투과율 스펙트럼: 곡선이 그어지고 세로 스캔선이 계속 흐르며 값을 짚는다
def L_spectrum(curves, en="SPECTRUM", ko="파장별 투과율", hi=(780, 2500, "근적외선"), xr=(300, 2500)):
    X0, X1, YT, YB = 190, 920, 1000, 1400
    def px(nm): return X0 + (X1 - X0) * (nm - xr[0]) / (xr[1] - xr[0])
    def py(v): return YB - (YB - YT) * v / 100
    def val(pts, nm):
        for (a0, v0), (a1, v1) in zip(pts, pts[1:]):
            if a0 <= nm <= a1: return v0 + (v1 - v0) * (nm - a0) / max(1, a1 - a0)
        return pts[-1][1]
    def g(out, t, a):
        ly, al = _base(out, t, a, en, ko)
        ax = st(t, 0.1, 0.6)
        ly.line([(X0, YB), (X0 + (X1 - X0) * ax, YB)], INK, 1.5, al); ly.line([(X0, YB), (X0, YB - (YB - YT) * ax)], HAIR, 1.5, al)
        for v in (0, 50, 100): ly.text(f"{v}", Rg, 18, X0 - 14, py(v), SOFT, "rm", al)
        if hi:   # 강조 구간: 면 채움 대신 가는 사선 해칭
            hx0, hx1 = px(hi[0]), px(hi[1]); q = fa(t, 0.4, 0.5)
            for k in range(int(hx0), int(hx1), 22):
                ly.line([(k, YB), (min(hx1, k + 40), YT)], (232, 236, 246), 1.2, al * q)
            ly.text(hi[2], Md, 22, (hx0 + hx1) / 2, YT - 22, SOFT, "mm", al * q)
        for nm, lb in ((380, "UV"), (580, "가시광선")):
            ly.text(lb, Rg, 18, px(nm), YB + 26, SOFT, "mm", al)
        for ci, c in enumerate(curves):
            col = {"acc": ACC, "soft": (180, 184, 196), "red": RED, "ink": INK}[c.get("col", "acc")]
            p = st(t, 0.5 + 0.35 * ci, 1.6); end = xr[0] + (xr[1] - xr[0]) * p
            pts = [(px(nm), py(val(c["pts"], nm))) for nm in range(xr[0], int(end) + 1, 20)]
            if len(pts) > 1: ly.line(pts, col, 3 if ci == 0 else 2.4, al)
            if p > 0.97: ly.text(c["name"], Bd, 26, X1 - 4, py(c["pts"][-1][1]) - 24, col, "rm", al * fa(t, 2.2 + 0.2 * ci, 0.4))
        if t > 2.3:   # 계속 흐르는 스캔선
            nm = xr[0] + (xr[1] - xr[0]) * ((t - 2.3) * 0.22 % 1)
            ly.line([(px(nm), YT), (px(nm), YB)], HAIR, 1.2, al)
            for ci, c in enumerate(curves):
                col = {"acc": ACC, "soft": (180, 184, 196), "red": RED, "ink": INK}[c.get("col", "acc")]
                ly.circ(px(nm), py(val(c["pts"], nm)), 6, fill=col, a=al)
        ly.fin(out)
    return g


# 4) 빛의 흐름: 태양열이 필름에 닿아 반사(reflect) / 흡수 후 재방출(absorb) / 좌우 비교(compare)
def L_rays(mode="reflect", en="HEAT CONTROL", ko="", film="THE LX", other="흡수형 필름"):
    FY = 1270; SUN = (214, 176, 108)
    def stream(ly, al, t, x0, x1, kind, lab):
        cx = (x0 + x1) / 2; wid = x1 - x0
        # 필름 단면: 유리(가는 이중선) + 필름 층(굵은 선)
        ly.rrect((x0, FY - 10, x1, FY + 10), 6, fill=(248, 249, 252), outline=(206, 210, 220), w=1.5, a=al)
        ly.line([(x0 + 4, FY - 10), (x1 - 4, FY - 10)], ACC if kind == "reflect" else (120, 124, 138), 3, al)
        ly.text("실외", Rg, 22, x0 + 4, FY - 40, SOFT, "lm", al); ly.text("실내", Rg, 22, x0 + 4, FY + 44, SOFT, "lm", al)
        for k in range(9):
            ph = (t * 0.5 + k / 9) % 1
            sx, sy = x0 + wid * 0.05 + k * wid * 0.03, 990
            hx, hy = cx - wid * 0.12 + k * wid * 0.035, FY - 12
            if ph < 0.45:   # 들어오는 태양열
                q = ph / 0.45; x = sx + (hx - sx) * q; y = sy + (hy - sy) * q
                dx, dy = (hx - sx), (hy - sy); ln = math.hypot(dx, dy)
                ly.line([(x - 60 * dx / ln, y - 60 * dy / ln), (x, y)], SUN, 4, al * min(1, q * 4))
            else:
                q = (ph - 0.45) / 0.55
                if kind == "reflect":   # 반사: 같은 각도로 되돌아 나간다
                    x = hx + (hx - sx) * q * 0.9; y = hy - (hy - sy) * q * 0.9
                    dx, dy = (hx - sx), -(hy - sy); ln = math.hypot(dx, dy)
                    ly.line([(x - 60 * dx / ln, y - 60 * dy / ln), (x, y)], ACC, 4, al * (1 - q * 0.7))
                else:                   # 흡수: 필름이 달궈지고 실내로 열이 번진다
                    y = FY + 24 + 150 * q; x = hx + 18 * math.sin(q * 8 + k)
                    ly.circ(x, y, 4 + 6 * q, outline=RED, w=2, a=al * (1 - q) * 0.9)
        if kind == "absorb":
            glow = 0.45 + 0.35 * math.sin(t * 3.2)
            ly.line([(x0 + 6, FY), (x1 - 6, FY)], RED, 5, al * glow)
        ly.text(lab, Bd, 36, cx, 1470, ACC if kind == "reflect" else RED, "mm", al * fa(t, 0.9, 0.4))
    def g(out, t, a):
        ly, al = _base(out, t, a, en, ko)
        if mode == "compare":
            stream(ly, al * fa(t, 0.2, 0.4), t, CX0, 525, "absorb", other)
            ly.line([(545, 990), (545, 1490)], HAIR, 1.5, al)
            stream(ly, al * fa(t, 0.9, 0.4), t - 0.7, 565, CX1, "reflect", film)
        else:
            stream(ly, al, t, CX0 + 40, CX1 - 40, mode, (film + " · 반사") if mode == "reflect" else (other + " · 흡수"))
        ly.fin(out)
    return g


# 5) 필름 구조 단면: 층이 하나씩 밀려 들어와 쌓였다가 하나의 얇은 필름으로 합쳐진다
def L_layers(layers, en="STRUCTURE", ko="필름 구조", hi=None, note=""):
    n = len(layers)
    def g(out, t, a):
        ly, al = _base(out, t, a, en, ko)
        comp = st(t, 0.8 + 0.28 * n + 0.6, 0.9)       # 합쳐지는 정도
        gap0, gap1 = min(62, 380 / max(1, n)), 9
        gap = gap0 + (gap1 - gap0) * comp
        ybase = 1250 - (n - 1) * gap / 2
        for i, nm in enumerate(layers):
            d0 = 0.3 + 0.28 * i; p = st(t, d0, 0.7)
            y = ybase + i * gap; xs = 200 + 260 * (1 - p)
            col = ACC if (hi is not None and i == hi) else INK
            xs = xs * (1 - comp) + 330 * comp
            ly.rrect((xs, y - 8, xs + 430, y + 8), 8, fill=(250, 251, 253), outline=col if i == hi else (196, 202, 214), w=1.5, a=al * p)
            la = al * p * max(0, 1 - comp * 4)
            ly.line([(xs + 440, y), (700, y)], HAIR, 1.2, la)
            ly.text(nm, Bd if i == hi else Md, 28, 712, y, col, "lm", la)
        if comp > 0.05:
            ly.text(note or f"{n}개 층 · 하나의 필름", Bd, 40, 545, ybase + n * gap + 80, INK, "mm", al * comp)
            ly.line([(330, ybase - 34), (330 + 430 * comp, ybase - 34)], ACC, 2, al * comp)
        ly.fin(out)
    return g


# 6) 쭈글쭈글: 매끈한 필름 시트가 천천히 구겨지고 기포가 생긴다 (무채색, 결론 글자만 RED)
def L_crumple(start="출고", end="3년", label="필름 변질 · 시야 저하", en="DURABILITY", ko=""):
    def g(out, t, a):
        ly, al = _base(out, t, a, en, ko)
        x0, x1, ym, hh = 170, 920, 1130, 120
        amp = 26 * st(t, 0.8, 2.4)
        def wv(x, k): return amp * (0.6 * math.sin(x * 0.021 + t * 0.9 + k) + 0.4 * math.sin(x * 0.047 - t * 0.6 + 2 * k))
        for r in range(7):
            yy = ym - hh + r * hh * 2 / 6
            pts = [(x, yy + wv(x, r * 0.7)) for x in range(x0, x1 + 1, 10)]
            ly.line(pts, INK if r in (0, 6) else (206, 210, 220), 2 if r in (0, 6) else 1.2, al)
        rng = [(260, 0.2), (420, -0.5), (560, 0.4), (700, -0.2), (820, 0.6), (350, 0.7), (640, -0.7)]
        for k, (bx, by) in enumerate(rng):
            q = st(t, 1.5 + 0.22 * k, 0.6)
            if q > 0.02: ly.circ(bx, ym + by * hh + wv(bx, 3), 4 + 9 * q, outline=(150, 155, 168), w=1.5, a=al * q)
        # 타임라인
        q = st(t, 0.4, 2.0)
        ly.line([(x0, 1340), (x0 + (x1 - x0) * q, 1340)], INK, 2, al)
        ly.circ(x0, 1340, 7, fill=INK, a=al); ly.text(start, Md, 24, x0, 1378, SOFT, "lm", al)
        if q > 0.97:
            ly.circ(x1, 1340, 7, fill=RED, a=al); ly.text(end, Bd, 30, x1, 1380, RED, "rm", al)
        ly.text(label, Bd, 38, (x0 + x1) / 2, 1445, RED, "mm", al * fa(t, 2.3, 0.5))
        ly.fin(out)
    return g


# 7) 쌓이는 비용: 장부처럼 한 줄씩 쌓이고, 옆 세로 기둥이 같이 높아진 뒤 합계 한 줄
def L_ledger(rows, total="다 비용입니다", en="COST", ko="", total_col=None):
    def g(out, t, a):
        ly, al = _base(out, t, a, en, ko)
        y = 1010; colh = 0
        stp = 0.55 if len(rows) <= 4 else 0.38
        gap_ = 96 if len(rows) <= 4 else 72
        for i, (txt, kind) in enumerate(rows):
            d0 = 0.3 + stp * i; p = st(t, d0, 0.6)
            if p <= 0.01: continue
            c = RED if kind == "extra" else INK
            sx = 120 * (1 - p)
            ly.circ(CX0 + 12 + sx, y, 7, fill=ACC if kind == "base" else RED, a=al * p)
            ly.text(txt, Bd, 40, CX0 + 44 + sx, y, c, "lm", al * p)
            ly.line([(CX0, y + 44), (CX0 + 520 * p, y + 44)], HAIR, 1.2, al)
            colh += 90 * p * 4 / max(4, len(rows)); y += gap_
        # 오른쪽 기둥: 줄이 늘수록 높아짐 (무채색 + 추가분만 RED 윤곽)
        bx, by1 = 820, 1400
        ly.rrect((bx - 50, by1 - colh * 1.2, bx + 50, by1), 16, fill=(240, 242, 246), a=al)
        acc_h = 0
        for i, (txt, kind) in enumerate(rows):
            p = st(t, 0.3 + stp * i, 0.6); h = 90 * 1.2 * p * 4 / max(4, len(rows))
            if kind == "extra" and h > 3:
                ly.rrect((bx - 50, by1 - acc_h - h, bx + 50, by1 - acc_h), 14, outline=RED, w=2, a=al)
            acc_h += h
        q = st(t, 0.4 + stp * len(rows), 0.6)
        if q > 0.01:
            ly.line([(CX0, y + 10), (CX0 + 520 * q, y + 10)], INK, 2.5, al)
            zz = 54 + 14 * math.sin(math.pi * min(1, q * 1.3)) * (1 - q)
            ly.text(total, Bk, int(zz), CX0, y + 80, total_col or RED, "lm", al * q)
        ly.fin(out)
    return g


# 8) 두 선택지 대비: 좌우 칼럼이 번갈아 채워지고, 끝에 지는 쪽은 흐려지고 이기는 쪽에 점 하나
def L_versus(left, right, en="DIFFERENCE", ko="", win=1, mid="vs"):
    def g(out, t, a):
        ly, al = _base(out, t, a, en, ko)
        cols = [(CX0 + 10, left), (560, right)]
        end = 0.6 + 0.45 * max(len(left[1]), len(right[1])) * 2
        dim = st(t, end, 0.8)
        for ci, (x, (title, items)) in enumerate(cols):
            lose = ci != win
            cA = mixc(INK, (190, 194, 204), dim) if lose else INK
            ly.text(title, Bk, 46, x, 1010, cA, "lm", al * fa(t, 0.2 + 0.2 * ci, 0.3))
            if not lose and dim > 0.05: ly.circ(x + ly.tw(title, Bk, 46) + 22, 1004, 8, fill=ACC, a=al * dim)
            ly.line([(x, 1052), (x + 330 * st(t, 0.3 + 0.2 * ci, 0.6), 1052)], INK if not lose else HAIR, 2 if not lose else 1.5, al)
            for k, it in enumerate(items):
                d0 = 0.6 + 0.45 * (k * 2 + ci); p = st(t, d0, 0.5)
                ly.text(it, Md, 32, x, 1120 + k * 78 + 20 * (1 - p), cA if lose else INK, "lm", al * p)
        rp = st(t, 0.3, 1.0); ring = [(530 + 42 * math.cos(t * 0.8 + 2 * math.pi * k / 60), 1260 + 42 * math.sin(t * 0.8 + 2 * math.pi * k / 60)) for k in range(int(60 * rp) + 1)]
        if len(ring) > 1: ly.line(ring, (214, 218, 226), 2, al)
        ly.text(mid, Bd, 30, 530, 1260, SOFT, "mm", al * fa(t, 0.4, 0.3))
        if dim > 0.05:
            wx = cols[win][0]; ly.line([(wx, 1052), (wx + 330 * dim, 1052)], ACC, 4, al)
        ly.line([(530, 1010), (530, 1220)], HAIR, 1.2, al); ly.line([(530, 1300), (530, 1450)], HAIR, 1.2, al)
        ly.fin(out)
    return g


# 9) 라인업 계단: 가는 계단선 위에 등급 이름, 강조 등급에 점과 알약 배지 (색 블록 없음)
def L_ladder(steps, hi=0, badge="ENTRY", en="LINEUP", ko="", subs=None, quick=False):
    n = len(steps)
    def g(out, t, a):
        ly, al = _base(out, t, a, en, ko)
        sw = (CX1 - CX0 - 20) / n; base = 1420; rise = 300 / max(1, n - 1)
        pts = [(CX0, base)]
        for i in range(n):
            y = base - rise * i; pts += [(CX0 + sw * i, y), (CX0 + sw * (i + 1), y)]
            if i < n - 1: pts.append((CX0 + sw * (i + 1), y - rise))
        tq = t + (5 if quick else 0)
        q = st(tq, 0.2, 1.6); m = max(2, int(len(pts) * q))
        ly.line(pts[:m], (196, 202, 214), 2, al)
        for i, nm in enumerate(steps):
            p = st(tq, 0.4 + 0.3 * i, 0.5); y = base - rise * i; x = CX0 + sw * i + sw / 2
            hp = st(t, 0.2, 0.6) if quick else 1.0
            c = mixc(INK, ACC, hp) if i == hi else ((150, 155, 168) if (quick and i != hi) else INK)
            off = 40 + (40 if subs else 0)
            ly.text(nm, Bk if i == hi else Bd, 40 if i == hi else 32, x, y - off - 16 * (1 - p), c, "mm", al * p)
            if subs: ly.text(subs[i], Bk if i == hi else Md, 34 if i == hi else 28, x, y - 36 - 16 * (1 - p), c, "mm", al * p)
            if i == hi and p > 0.9:
                pu = (t * 0.8) % 1
                ly.circ(x, y, 7, fill=ACC, a=al); ly.circ(x, y, 7 + 14 * pu, outline=ACC, w=1.5, a=al * (1 - pu))
                if badge: _pill(ly, x, y - off - 70, badge, al * fa(t, 0.6 if quick else 1.6, 0.4), INK, 22, "m")
        ly.fin(out)
    return g


# 10) 타임라인: 선이 그어지고 시점마다 원이 튀며 찍힌 뒤, 파란 진행선이 단계를 따라 계속 흐른다
def L_timeline(points, en="TIMELINE", ko="", hi=-1):
    n = len(points)
    def g(out, t, a):
        ly, al = _base(out, t, a, en, ko)
        y = 1225; q = st(t, 0.2, 1.4)
        ly.line([(CX0, y), (CX0 + (CX1 - CX0) * q, y)], (214, 218, 226), 3, al)
        f = st(t, 1.6, 1.8)   # 파란 진행선
        if f > 0.01: ly.line([(CX0, y), (CX0 + (CX1 - CX0) * f, y)], ACC, 4, al)
        for i, (lb, sub) in enumerate(points):
            x = CX0 + (CX1 - CX0) * i / max(1, n - 1); d0 = 0.3 + 1.1 * i / max(1, n - 1); p = st(t, d0, 0.45)
            reached = f >= i / max(1, n - 1) - 0.001
            ish = i == (hi % n)
            r = (12 if ish else 10) * (0.4 + 0.6 * p)
            ly.circ(x, y, r + 4, fill=(255, 255, 255), a=al * p)
            ly.circ(x, y, r, fill=ACC if reached else INK, a=al * p)
            if reached and f < 1:
                pu = min(1, (f - i / max(1, n - 1)) * 4)
                ly.circ(x, y, r + 30 * pu, outline=ACC, w=2, a=al * (1 - pu))
            up = i % 2 == 0
            ly.text(lb, Bk if ish else Bd, 48 if ish else 40, x, y + (-80 if up else 80) + 18 * (1 - p), ACC if (ish and reached) else INK, "mm", al * p)
            if sub: ly.text(sub, Md, 28, x, y + (-136 if up else 134), SOFT, "mm", al * p)
        if f > 0.99:
            k = (t * 0.35) % 1; ly.circ(CX0 + (CX1 - CX0) * k, y, 7, fill=(255, 255, 255), outline=ACC, w=2, a=al)
        ly.fin(out)
    return g


# 11) 선택 기준 목록: 체크박스 대신 01·02 번호와 가늘게 뻗는 선, 끝에 ACC 점
def L_criteria(items, en="CHECK POINT", ko=""):
    def g(out, t, a):
        ly, al = _base(out, t, a, en, ko)
        gap = min(210, 440 / max(1, len(items)))
        for i, (ttl, sub) in enumerate(items):
            y = 1225 - (len(items) - 1) * gap / 2 - 30 + i * gap; d0 = 0.3 + 0.7 * i; p = st(t, d0, 0.6)
            ly.text(f"{i + 1:02d}", Bk, 36, CX0 + 26, y, ACC if p > 0.99 else (200, 204, 214), "mm", al * p)
            ly.text(ttl, Bd, 50, CX0 + 100, y, INK, "lm", al * p)
            if sub: ly.text(sub, Rg, 30, CX0 + 100, y + 56, SOFT, "lm", al * fa(t, d0 + 0.3, 0.4))
            lp = st(t, d0 + 0.2, 0.8)
            ly.line([(CX0 + 100, y + 86), (CX0 + 100 + 640 * lp, y + 86)], HAIR, 1.5, al)
            if lp > 0.02: ly.line([(CX0 + 100, y + 86), (CX0 + 100 + 640 * lp * st(t, d0 + 0.9, 0.9), y + 86)], ACC, 3, al)
            if p > 0.99:
                rr = st(t, d0 + 0.3, 0.6); pts = [(CX0 + 26 + 40 * math.cos(-math.pi / 2 + 2 * math.pi * k / 48), y + 40 * math.sin(-math.pi / 2 + 2 * math.pi * k / 48)) for k in range(int(48 * rr) + 1)]
                if len(pts) > 1: ly.line(pts, ACC, 2, al)
        ly.fin(out)
    return g


# 12) 실차 사진 카드: 카드를 꽉 채운 사진이 천천히 다가가고 두 번째 컷으로 교차, 작은 검정 라벨
_phc = {}
def _photo(path, w, h):
    k = (path, w, h)
    if k not in _phc:
        im = Image.open(path if os.path.isabs(path) else os.path.join(D, path)).convert("RGB")
        s = max(w / im.width, h / im.height) * 1.12; im = im.resize((int(im.width * s), int(im.height * s)), Image.LANCZOS)
        _phc[k] = im
    return _phc[k]
def _mask(w, h, r=44):
    k = ("m", w, h)
    if k not in _phc:
        m = Image.new("L", (w, h), 0); ImageDraw.Draw(m).rounded_rectangle([0, 0, w - 1, h - 1], radius=r, fill=255); _phc[k] = m
    return _phc[k]
def _shot(path, w, h, z, fx=0.5, fy=0.5):
    im = _photo(path, w, h); cw, ch = w / z * 1.0, h / z * 1.0
    cw = min(cw, im.width); ch = min(ch, im.height)
    x0 = (im.width - cw) * fx; y0 = (im.height - ch) * fy
    return im.crop((int(x0), int(y0), int(x0 + cw), int(y0 + ch))).resize((w, h), Image.LANCZOS)
def L_photo(paths, label="", en=None, focus=None):
    focus = focus or [(0.5, 0.5)] * len(paths)
    def g(out, t, a):
        al = a * fa(t, 0, 0.35); ly = Ly(); card(out, ly, CB, al); ly.fin(out)
        w, h = CB[2] - CB[0], CB[3] - CB[1]
        n = len(paths); seg = 2.6
        i = min(n - 1, int(t / seg)); lt = t - i * seg
        z = 1.0 + 0.06 * (lt / seg) + 0.02 * i
        im = _shot(paths[i], w, h, z, *focus[i])
        if i + 1 < n and lt > seg - 0.5:   # 다음 컷과 교차
            k = (lt - (seg - 0.5)) / 0.5; im2 = _shot(paths[i + 1], w, h, 1.0, *focus[i + 1]); im = Image.blend(im, im2, k)
        sw_ = (t - 0.8) / 1.1
        if 0 < sw_ < 1:   # 한 번 지나가는 빛 반사
            arr = np.asarray(im).astype(np.float32); xx = np.arange(w)[None, :] + np.arange(h)[:, None] * 0.45
            c0 = -h * 0.45 + (w + h * 0.9) * sw_; band = np.exp(-((xx - c0) / 60) ** 2) * 70
            im = Image.fromarray(np.clip(arr + band[..., None], 0, 255).astype(np.uint8))
        im = im.convert("RGBA"); im.putalpha(_mask(w, h)); put(out, im, CB[0], CB[1], al)
        if label:
            l2 = Ly(); _pill(l2, CB[0] + 36, CB[3] - 52, label, al * fa(t, 0.4, 0.4), INK, 24); l2.fin(out)
        if en:
            l3 = Ly(); l3.text(en, Md, 22, CB[0] + 40, CB[1] + 46, (255, 255, 255), "lm", al * 0.9, sp=5); l3.fin(out)
    return g


# 13) 사진 비교 와이프: 한쪽은 눈부심·뿌연 시야(효과), 세로 구분선이 지나가며 선명한 화면이 드러난다
def L_wipe(path, before="일반 필름", after="THE LX", effect="glare", focus=(0.5, 0.5)):
    def g(out, t, a):
        al = a * fa(t, 0, 0.35); ly = Ly(); card(out, ly, CB, al); ly.fin(out)
        w, h = CB[2] - CB[0], CB[3] - CB[1]
        z = 1.02 + 0.04 * min(1, t / 4.5)
        clear = _shot(path, w, h, z, *focus)
        arr = np.asarray(clear).astype(np.float32)
        if effect == "glare":
            yy, xx = np.mgrid[0:h, 0:w]; bloom = np.exp(-(((xx - w * 0.62) / (w * 0.35)) ** 2 + ((yy - h * 0.3) / (h * 0.35)) ** 2))
            bad = arr * 0.75 + 255 * (0.55 * bloom[..., None] + 0.15)
            for k in range(4):   # 내부 반사 고스트 줄
                yk = int(h * (0.25 + 0.15 * k + 0.03 * math.sin(t + k))); bad[max(0, yk - 2):yk + 2] += 40
        elif effect == "haze":
            bad = arr * 0.55 + 255 * 0.38
        else:   # dark
            bad = arr * 0.35
        bad = Image.fromarray(np.clip(bad, 0, 255).astype(np.uint8))
        pos = w * (1 - st(t, 0.9, 1.6))     # 구분선이 오른쪽에서 왼쪽으로
        im = clear.copy(); im.paste(bad.crop((0, 0, max(1, int(pos)), h)), (0, 0))
        im = im.convert("RGBA"); im.putalpha(_mask(w, h)); put(out, im, CB[0], CB[1], al)
        l2 = Ly()
        if 4 < pos < w - 4: l2.line([(CB[0] + pos, CB[1] + 8), (CB[0] + pos, CB[3] - 8)], (255, 255, 255), 3, al)
        _pill(l2, CB[0] + 36, CB[1] + 52, before, al * (1 - st(t, 2.2, 0.4)), (60, 64, 76), 22)
        _pill(l2, CB[2] - 36, CB[1] + 52, after, al * fa(t, 1.2, 0.4), INK, 22, "r")
        l2.fin(out)
    return g


# 14) 링 게이지: 얇은 원호가 차오르며 가운데 숫자 카운트업 (기간·횟수·비율 강조)
def L_ring(value, unit="", label="", en="", ko="", maxv=100, dec=0, sub=""):
    def g(out, t, a):
        ly, al = _base(out, t, a, en, ko)
        cx, cy, r = 360, 1220, 190; p = st(t, 0.3, 1.8)
        steps = 120
        ring = [(cx + r * math.cos(-math.pi / 2 + 2 * math.pi * k / steps), cy + r * math.sin(-math.pi / 2 + 2 * math.pi * k / steps)) for k in range(steps + 1)]
        ly.line(ring, (236, 239, 245), 14, al)
        m = int(steps * min(1, value / maxv) * p)
        if m > 1: ly.line(ring[:m + 1], ACC, 14, al)
        tx = _fmt(value * p, dec)
        ly.text(tx, Bk, 120, cx, cy - 4, INK, "mm", al)
        if unit: ly.text(unit, Bd, 40, cx, cy + 82, SOFT, "mm", al)
        if label: ly.text(label, Bd, 44, 610, 1170, INK, "lm", al * fa(t, 1.0, 0.4))
        if sub: ly.text(sub, Rg, 27, 610, 1240, SOFT, "lm", al * fa(t, 1.4, 0.4))
        if p > 0.98:
            pu = (t * 0.6) % 1; ly.circ(cx, cy, r + 12 + 30 * pu, outline=ACC, w=1.2, a=al * (1 - pu) * 0.5)
        ly.fin(out)
    return g


# 15) 세로 막대 여러 개: 막대가 차례로 솟고 값이 카운트업, 강조 막대만 ACC + 끝 값 맥동 (가격·수치 비교)
def L_bars(items, hi=0, unit="", en="", ko="", maxv=None, quick=False, dec=0):
    n = len(items); maxv = maxv or max(v for _, v in items) * 1.08
    def g(out, t, a):
        ly, al = _base(out, t, a, en, ko)
        tq = t + (6 if quick else 0)
        y0, y1 = 1010, 1395; bw = min(170, (CX1 - CX0) / n * 0.55)
        for k in range(1, 4):   # 가는 눈금선
            yy = y1 - (y1 - y0) * k / 4
            ly.line([(CX0, yy), (CX0 + (CX1 - CX0) * st(t, 0.1, 0.8), yy)], (238, 240, 245), 1.2, al)
        ly.line([(CX0, y1), (CX1, y1)], INK, 2, al)
        for i, (nm, v) in enumerate(items):
            x = CX0 + (CX1 - CX0) * (i + 0.5) / n
            p = st(tq, 0.3 + 0.35 * i, 1.3)
            h = (y1 - y0) * v / maxv * p
            on = i == hi; hp = st(t, 0.15, 0.6) if quick else st(t, 0.3 + 0.35 * i + 0.6, 0.5)
            col = mixc((214, 218, 226), ACC, hp) if on else (214, 218, 226)
            if h > 2: ly.rrect((x - bw / 2, y1 - h, x + bw / 2, y1), min(18, h / 2), fill=col, a=al)
            if on and p > 0.95:   # 강조 막대: 위로 흐르는 빛줄기 + 끝 맥동
                q = (t * 0.6) % 1; yy = y1 - h * q
                ly.line([(x - bw / 2 + 10, yy), (x + bw / 2 - 10, yy)], (255, 255, 255), 3, al * (1 - q) * 0.8)
                pu = (t * 0.8) % 1
                ly.rrect((x - bw / 2 - 8 * pu, y1 - h - 8 * pu, x + bw / 2 + 8 * pu, y1 - h + 10), 20, outline=ACC, w=1.5, a=al * (1 - pu) * 0.6)
            tx = _fmt(v * p, dec) + unit
            ly.text(tx, Bk if on else Bd, 50 if on else 36, x, y1 - h - 42, INK if on else SOFT, "mm", al * fa(tq, 0.4 + 0.35 * i, 0.3))
            ly.text(nm, Bd if on else Md, 30 if on else 27, x, y1 + 40, INK if on else SOFT, "mm", al)
        ly.fin(out)
    return g


# ===================== XY 그래프 계열 (2026-11-22 마틴: "XY축 있는 그래프 좋아해") =====================
_CK = {"acc": ACC, "soft": (178, 183, 196), "red": RED, "ink": INK, "gold": (214, 160, 70)}
def _interp(pts, x):
    xs = [p[0] for p in pts]; ys = [p[1] for p in pts]; return float(np.interp(x, xs, ys))


# 16) 범용 XY 그래프: 축·눈금·격자가 그어지고, 선이 빛나는 점을 앞세워 그려지며, 표시점(마커)이 차례로 튄다
#   series=[{"name":..,"pts":[(x,y)..],"col":"acc"|"red"|"soft"|"ink","fill":True,"step":False,"label_at":x}]
#   bands=[(x0,x1,"라벨","acc"|"red")] 배경 구간(아주 옅게) · marks=[(x,"라벨","acc"|"red"|"ink", 시리즈번호)] 값 짚기
def L_xy(series, xr, yr, xlab="", ylab="", xt=None, yt=None, bands=(), marks=(), en="", ko="", xfmt=None, scan=False, dur=2.2):
    X0, X1, YT, YB = 210, 925, 1010, 1395
    def px(x): return X0 + (X1 - X0) * (x - xr[0]) / (xr[1] - xr[0])
    def py(y): return YB - (YB - YT) * (y - yr[0]) / (yr[1] - yr[0])
    xt_ = xt or [xr[0] + (xr[1] - xr[0]) * k / 4 for k in range(5)]
    yt_ = yt or [yr[0] + (yr[1] - yr[0]) * k / 4 for k in range(5)]
    def g(out, t, a):
        ly, al = _base(out, t, a, en, ko)
        ax = st(t, 0.05, 0.7)
        for x0, x1, lb, c in bands:   # 배경 구간: 옅은 면 + 위쪽 라벨
            q = fa(t, 0.3, 0.5); col = _CK.get(c, c)
            ly.rrect((px(x0), YT, px(x1), YB), 0, fill=mixc(col, (255, 255, 255), 0.95), a=al * q)
            ly.text(lb, Md, 22, (px(x0) + px(x1)) / 2, YT + 20, col, "mm", al * q)
        for v in yt_:
            ly.line([(X0, py(v)), (X0 + (X1 - X0) * ax, py(v))], (238, 240, 245), 1.2, al)
            ly.text(f"{v:g}", Rg, 20, X0 - 14, py(v), SOFT, "rm", al * ax)
        ly.line([(X0, YB), (X0 + (X1 - X0) * ax, YB)], INK, 2, al); ly.line([(X0, YB), (X0, YB - (YB - YT) * ax)], INK, 2, al)
        for v in xt_: ly.text(xfmt(v) if xfmt else f"{v:g}", Rg, 20, px(v), YB + 26, SOFT, "mm", al * ax)
        if xlab: ly.text(xlab, Md, 20, X1, YB + 56, SOFT, "rm", al)
        if ylab: ly.text(ylab, Md, 20, X0, YT - 26, SOFT, "lm", al)
        ends = []
        for si, s_ in enumerate(series):
            col = _CK.get(s_.get("col", "acc"), s_.get("col")); p = st(t, 0.4 + 0.55 * si, dur)
            xe = xr[0] + (xr[1] - xr[0]) * p; n = 140
            if s_.get("step"):
                pts = []; prev = None
                for (x, y) in s_["pts"]:
                    if x > xe: break
                    if prev is not None: pts.append((px(x), py(prev)))
                    pts.append((px(x), py(y))); prev = y
                if prev is not None: pts.append((px(xe), py(prev)))
            else:
                xs = np.linspace(xr[0], xe, max(2, int(n * p)))
                pts = [(px(x), py(_interp(s_["pts"], x))) for x in xs]
            if len(pts) < 2: continue
            if s_.get("fill"):
                lay = Image.new("RGBA", ly.im.size, (0, 0, 0, 0))
                ImageDraw.Draw(lay).polygon([ly.P(*q) for q in pts + [(pts[-1][0], YB), (pts[0][0], YB)]], fill=rgba(col, al * 0.13)); ly.im.alpha_composite(lay)
            ly.line(pts, col, 6 if si == 0 else 4.5, al)
            hx, hy = pts[-1]
            if p < 0.995:   # 선 끝의 빛나는 점
                ly.circ(hx, hy, 16, fill=col, a=al * 0.18); ly.circ(hx, hy, 8, fill=col, a=al)
            ends.append((hx, hy, col, s_, p))
        for hx, hy, col, s_, p in ends:
            if p > 0.97 and s_.get("name"):
                lx = s_.get("label_at"); yy = py(_interp(s_["pts"], lx)) if lx is not None else hy
                xx = px(lx) if lx is not None else hx
                ly.text(s_["name"], Bd, 30, xx - 6, yy - 34, col, "rm" if lx is None else "mm", al * fa(t, 0.4 + 0.55 * series.index(s_) + dur, 0.4))
        tm = 0.6 + 0.55 * len(series) + dur * 0.8
        for k, mk in enumerate(marks):   # 값 짚기: 세로 점선 + 점 + 알약 라벨이 튀며 등장
            x, lb, c = mk[0], mk[1], _CK.get(mk[2], mk[2]); si = mk[3] if len(mk) > 3 else 0
            q = st(t, tm + 0.45 * k, 0.5)
            if q <= 0.01: continue
            y = py(_interp(series[si]["pts"], x)); xx = px(x)
            for yy in range(int(y), int(YB), 14): ly.line([(xx, yy), (xx, min(YB, yy + 7))], c, 1.5, al * q)
            ly.circ(xx, y, 10 * q + 4, fill=(255, 255, 255), a=al * q); ly.circ(xx, y, 7 * q, fill=c, a=al * q)
            sc = 1 + 0.25 * (1 - st(t, tm + 0.45 * k, 0.35))
            w = ly.tw(lb, Bd, 26 * sc) + 34; xm = min(max(xx, X0 + w / 2), X1 - w / 2)
            ly.rrect((xm - w / 2, y - 76 * sc, xm + w / 2, y - 30), 22, fill=c, a=al * q)
            ly.text(lb, Bd, int(26 * sc), xm, y - 53 * sc + 8, (255, 255, 255), "mm", al * q)
        if scan and t > tm:   # 계속 흐르는 스캔선
            f_ = ((t - tm) * 0.2) % 1; xs_ = xr[0] + (xr[1] - xr[0]) * f_
            ly.line([(px(xs_), YT), (px(xs_), YB)], HAIR, 1.5, al)
            for s_ in series:
                if not s_.get("step"): ly.circ(px(xs_), py(_interp(s_["pts"], xs_)), 6, fill=_CK.get(s_.get("col", "acc")), a=al)
        ly.fin(out)
    return g


# 17) 태양 스펙트럼(면 채움) + 측정 방식 강조: mode="point"(한 지점) / "band"(구간) / "scan"(전 파장 스캔)
SUN_PTS = [(250,0),(300,0.05),(380,0.9),(450,1.45),(520,1.55),(600,1.42),(700,1.25),(800,1.05),(900,0.85),(940,0.5),(980,0.72),(1080,0.62),(1130,0.3),(1200,0.55),(1300,0.45),(1360,0.06),(1450,0.05),(1520,0.3),(1650,0.27),(1780,0.15),(1850,0.02),(1950,0.03),(2050,0.12),(2200,0.1),(2350,0.07),(2500,0.03)]
def L_solar(mode="scan", label=None, at=950, band=(1000, 2500), en="SOLAR SPECTRUM", ko="개념도"):
    X0, X1, YT, YB = 160, 950, 1000, 1400
    def px(nm): return X0 + (X1 - X0) * (nm - 250) / 2250
    def py(v): return YB - (YB - YT) * v / 1.7
    def g(out, t, a):
        ly, al = _base(out, t, a, en, ko)
        ly.rrect((px(380), YT, px(780), YB), 0, fill=(240, 245, 255), a=al * 0.9); ly.text("가시광선", Md, 22, (px(380) + px(780)) / 2, YT + 22, ACC, "mm", al)
        ly.text("적외선", Md, 22, (px(780) + X1) / 2, YT + 22, SOFT, "mm", al)
        ly.line([(X0, YB), (X1, YB)], INK, 2, al)
        for v in (500, 1000, 1500, 2000, 2500): ly.text(f"{v}", Rg, 20, px(v), YB + 24, SOFT, "mm", al)
        ly.text("nm", Rg, 20, X1, YB + 52, SOFT, "rm", al)
        xs = np.linspace(250, 2500, 220); P = [(px(x), py(_interp(SUN_PTS, x))) for x in xs]
        pr = st(t, 0.1, 1.2) if mode != "scan" else 1.0; k = max(2, int(len(P) * pr))
        lay = Image.new("RGBA", ly.im.size, (0, 0, 0, 0)); ImageDraw.Draw(lay).polygon([ly.P(*q) for q in P[:k] + [(P[k - 1][0], YB), (P[0][0], YB)]], fill=rgba((150, 160, 190), al * 0.3)); ly.im.alpha_composite(lay)
        ly.line(P[:k], (90, 98, 120), 3, al)
        if mode == "point":
            q = fa(t, 1.0, 0.3); x = px(at); pul = 0.5 + 0.5 * math.sin(t * 6)
            ly.line([(x, YT + 40), (x, YB)], RED, 4, al * q); ly.circ(x, py(_interp(SUN_PTS, at)), 12 + 6 * pul, fill=RED, a=al * q)
            _pill(ly, x, YT + 72, label or f"{at}nm 한 지점", al * q, RED, 28, "m")
        elif mode == "band":
            e = st(t, 0.3, 1.2); x0 = px(band[0]); x1 = x0 + (px(band[1]) - x0) * e
            ly.rrect((x0, YT + 40, x1, YB), 0, fill=RED, a=al * 0.16); ly.line([(x0, YT + 40), (x0, YB)], RED, 3, al)
            _pill(ly, (x0 + px(band[1])) / 2, YT + 76, label or f"{band[0]} ~ {band[1]}nm", al * fa(t, 0.9, 0.3), RED, 28, "m")
        else:
            p = st(t, 0.2, 2.2); x = X0 + (X1 - X0) * p
            ly.rrect((X0, YT + 40, x, YB), 0, fill=ACC, a=al * 0.12); ly.line([(x, YT + 40), (x, YB)], ACC, 4, al * (1 if p < 1 else 0.4))
            _pill(ly, 555, YT + 72, label or "전 파장 측정", al * fa(t, 0.4, 0.3), ACC, 28, "m")
        ly.fin(out)
    return g


# 18) 분광 선택성: 가시광선 무지개 줄기는 필름을 통과, 적외선은 V자로 반사 (빛 입자가 계속 흐름)
def L_spectral(film="THE LX 금속 박막", en="SPECTRAL SELECTIVITY", ko="개념도"):
    def g(out, t, a):
        ly, al = _base(out, t, a, en, ko)
        fy = 1215; ly.gbar((150, fy, 930, fy + 16), (150, 158, 178), (226, 206, 160), 4, al); ly.text(film, Md, 26, 930, fy + 48, SOFT, "rm", al)
        ly.text("실외", Md, 26, 150, 990, SOFT, "lm", al); ly.text("실내", Md, 26, 150, 1440, SOFT, "lm", al)
        VIS = [(124, 92, 246), (37, 99, 235), (22, 163, 74), (234, 179, 8), (240, 112, 44), (220, 50, 47)]
        q1 = fa(t, 0.3, 0.5); q2 = fa(t, 1.1, 0.5)
        for k in range(6):
            x = 260 + k * 50; c = VIS[k]
            for j in range(3):
                ph = (t * 0.42 + k * 0.13 + j / 3) % 1.0; y = 1000 + 430 * ph; aa = al * q1 * min(1, ph * 6) * min(1, (1 - ph) * 6)
                ly.line([(x, y - 34), (x, y)], c, 5, aa)
        ly.text("가시광선", Bd, 38, 400, 1465, INK, "mm", al * q1); _pill(ly, 470, 1466, "통과", al * q1, ACC, 26)
        for k in range(5):
            x0 = 630 + k * 58; P = [(x0, 1040), (x0 + 50, fy), (x0 + 100, 1040)]
            ly.line(P[:2], RED, 2, al * q2 * 0.25); ly.line(P[1:], RED, 2, al * q2 * 0.25)
            ph = (t * 0.45 + k * 0.2) % 1.0
            def pt(u, P=P):
                if u < 0.5: v = u / 0.5; return (P[0][0] + (P[1][0] - P[0][0]) * v, P[0][1] + (P[1][1] - P[0][1]) * v)
                v = (u - 0.5) / 0.5; return (P[1][0] + (P[2][0] - P[1][0]) * v, P[1][1] + (P[2][1] - P[1][1]) * v)
            for jj in range(12):
                u = ph - jj * 0.014; u2 = ph - (jj + 1) * 0.014
                if 0 < u2 and u < 1 and ((u < 0.5) == (u2 < 0.5)): ly.line([pt(u), pt(u2)], RED, 6, al * q2 * (1 - jj / 12))
            if 0 < ph < 1: ly.circ(*pt(ph), 7, fill=RED, a=al * q2)
        ly.text("적외선", Bd, 38, 760, 995, RED, "mm", al * q2); _pill(ly, 830, 996, "반사", al * q2, RED, 26)
        ly.fin(out)
    return g


# 19) 큰 금액·수치 한 방: 거대한 숫자가 카운트업, 옆에 + 배지가 튀어나오고 아래 한 줄
def L_bignum(value, unit="원", caption="", top="", plus=True, en="", ko=""):
    def g(out, t, a):
        ly, al = _base(out, t, a, en, ko)
        if top: ly.text(top, Md, 28, CX0, 1000, SOFT, "lm", al)
        ly.line([(CX0, 1040), (CX0 + 780 * st(t, 0.2, 0.9), 1040)], HAIR, 1.5, al)
        v = value * st(t, 0.2, 1.3); tx = num(v); sz = 150 if len(num(value)) <= 7 else 120
        ly.text(tx, Bk, sz, CX0 - 6, 1210, INK, "lm", al); x = CX0 + ly.tw(num(value), Bk, sz) + 12
        ly.text(unit, Bd, 60, x, 1236, INK, "lm", al)
        if plus:
            q = fa(t, 1.5, 0.3); qq = st(t, 1.5, 0.45); s = 1 + 0.35 * (1 - qq); xx = x + ly.tw(unit, Bd, 60) + 28
            ly.rrect((xx, 1200 - 34 * s, xx + 76 * s, 1200 + 34 * s), 34 * s, fill=ACC, a=al * q); ly.text("+", Bk, int(48 * s), xx + 38 * s, 1200, (255, 255, 255), "mm", al * q)
        if caption: ly.text(caption, Md, 34, CX0, 1360, SOFT, "lm", al * fa(t, 2.0, 0.4))
        ly.fin(out)
    return g


# 20) 스펙 두 줄: 항목별 큰 수치 카운트업 + 가로 막대 (VLT·TSER 같이 두세 지표를 한 카드에)
def L_specs(rows, en="SPEC", ko="", note=""):
    def g(out, t, a):
        ly, al = _base(out, t, a, en, ko)
        gap = 420 / max(1, len(rows))
        for i, r in enumerate(rows):
            ab, nm, v = r[0], r[1], r[2]; col = _CK.get(r[3] if len(r) > 3 else "acc")
            y = 1000 + i * gap; t0 = 0.3 + i * 0.7; q = fa(t, t0, 0.3) * al; p = st(t, t0, 1.3)
            ly.text(ab, Bd, 34, CX0, y + 18, INK, "lm", q, sp=3); ly.text(nm, Rg, 28, CX0, y + 62, SOFT, "lm", q)
            ly.text("%", Bd, 52, CX1, y + 52, INK, "rm", q); ly.text(str(int(round(v * p))), Bk, 120, CX1 - ly.tw("%", Bd, 52) - 10, y + 40, col, "rm", q)
            ly.rrect((CX0, y + 116, CX1, y + 128), 6, fill=(240, 242, 247), a=q); ly.rrect((CX0, y + 116, CX0 + (CX1 - CX0) * v / 100 * p, y + 128), 6, fill=col, a=q)
            if p > 0.98:
                k = (t * 0.5 + i * 0.3) % 1; xx = CX0 + (CX1 - CX0) * v / 100 * k; ly.circ(xx, y + 122, 5, fill=(255, 255, 255), a=q * 0.9)
        if note: ly.text(note, Rg, 24, CX1, 1470, SOFT, "rm", al * fa(t, 1.8, 0.4))
        ly.fin(out)
    return g


# 21) 사용 환경 레인: 두 운전 패턴의 일조 노출 막대 + 권하는 필름 칩 (hl=강조 줄)
def L_lanes(rows, hl=1, en="DAILY SUN EXPOSURE", ko="개념"):
    def g(out, t, a):
        ly, al = _base(out, t, a, en, ko)
        for i, (nm, v, chip) in enumerate(rows):
            y = 1030 + i * 230; on = i == hl; w = 1.0 if on else 0.35; q = al * w * fa(t, 0.15 + 0.25 * i, 0.3); p = st(t, 0.3 + 0.25 * i, 1.4)
            ly.text(nm, Bd, 42, CX0, y, INK, "lm", q)
            ly.rrect((CX0, y + 58, CX1, y + 82), 12, fill=(240, 242, 247), a=q); ly.rrect((CX0, y + 58, CX0 + (CX1 - CX0) * v * p, y + 82), 12, fill=ACC if on else (196, 202, 214), a=q)
            _pill(ly, CX1, y + 136, chip, fa(t, 1.0 + 0.25 * i, 0.3) * al, INK if on else (150, 155, 168), 30, "r")
        ly.fin(out)
    return g
