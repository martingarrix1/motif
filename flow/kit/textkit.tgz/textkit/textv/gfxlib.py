# MOTIF 그래프 라이브러리 — Claude가 직접 다듬은 고급 모션그래픽 부품 (2026-11-22)
# render.py가 gfx.py보다 먼저 불러온다. 릴스마다 gfx.py에는 "g_이름 = L_부품(설정...)" 몇 줄만 쓴다.
#
# 마틴 기준(요약): 애플 키노트·프리미엄 자동차 브로슈어 톤 / 무채색(INK·SOFT·HAIR) 계층 + ACC는 포인트 한 곳 /
# 넓은 면을 색·그라데이션으로 채우지 않기 / 클립아트(저울·체크박스) 금지 → 큰 타이포·가는 선·점 /
# 카드가 뜬 뒤 멈춰 있지 않게: 등장 → 변형·카운트 → 결론, 그 뒤에도 미세한 흐름 하나 /
# 대사의 동작어(쭈글쭈글·반사·쌓인다·사라진다)는 그래픽이 그대로 움직인다 / 수치는 0부터 카운트업 + 세로 막대 동행 /
# 색감·외관처럼 도식이 안 되는 건 실차 사진 카드.
#
# 공통 인자: en=카드 왼쪽 위 영문 소제목, ko=오른쪽 위 한글 라벨. 시간 t는 문장 시작 후 초.

CB = (90, 880, 1000, 1520)            # 카드 영역
CX0, CX1, CY0, CY1 = 150, 940, 975, 1470   # 내용 영역


def _base(out, t, a, en, ko):
    al = a * fa(t, 0, 0.3); ly = Ly(); card(out, ly, CB, al)
    if en: ly.text(en, Md, 22, CX0, 925, SOFT, "lm", al, sp=5)
    if ko: ly.text(ko, Rg, 22, CX1, 925, SOFT, "rm", al)
    return ly, al


def _fmt(v, dec):
    return f"{v:.{dec}f}" if dec else f"{int(round(v)):,}"


def _pill(ly, x, y, txt, al, col=INK, sz=24, anc="l"):
    w = ly.tw(txt, Bd, sz) + 36; h = sz + 22
    x0 = x if anc == "l" else (x - w / 2 if anc == "m" else x - w)
    ly.rrect((x0, y - h / 2, x0 + w, y + h / 2), h / 2, fill=col, a=al)
    ly.text(txt, Bd, sz, x0 + w / 2, y, (255, 255, 255), "mm", al)


def _vbar(ly, x, y0, y1, p, al, maxv, val, w=56, col=ACC, ticks=True, t=0):
    """세로 막대: 0~maxv 눈금 트랙 + 단색 채움 + 끝 값 가는 선."""
    ly.rrect((x - w / 2, y0, x + w / 2, y1), w / 2, fill=(244, 246, 250), a=al)
    if ticks:
        for k in range(0, 5):
            yy = y1 - (y1 - y0) * k / 4
            ly.line([(x + w / 2 + 10, yy), (x + w / 2 + 22, yy)], HAIR, 1.5, al)
            ly.text(_fmt(maxv * k / 4, 0), Rg, 18, x + w / 2 + 30, yy, SOFT, "lm", al)
    h = (y1 - y0) * min(1, val / maxv) * p
    if h > 2: ly.rrect((x - w / 2, y1 - h, x + w / 2, y1), min(w / 2, h / 2), fill=col, a=al)
    if p > 0.98:   # 끝 값 표시선 + 미세한 맥동
        yy = y1 - h; q = (t * 0.7) % 1
        ly.line([(x - w / 2 - 16, yy), (x + w / 2 + 6, yy)], INK, 1.5, al)
        ly.rrect((x - w / 2 - 4 * q, yy - 3 - 6 * q, x + w / 2 + 4 * q, yy + 3 + 6 * q), 8, outline=col, w=1.5, a=al * (1 - q) * 0.7)


# 1) 수치 하나: 큰 카운트업 숫자 + 같은 속도로 차오르는 세로 막대 (TSER·VLT·차단율)
def L_stat(value, unit="%", label="", note="", en="PERFORMANCE", ko="", dec=0, maxv=100, col=None):
    col = col or ACC
    def g(out, t, a):
        ly, al = _base(out, t, a, en, ko)
        p = st(t, 0.35, 1.8)
        v = value * p
        tx = _fmt(v, dec)
        ly.text(tx, Bk, 190, CX0, 1150, INK, "ls", al)
        ly.text(unit, Bd, 70, CX0 + ly.tw(tx, Bk, 190) + 14, 1150, col, "ls", al)
        if label: ly.text(label, Bd, 40, CX0, 1240, INK, "lm", al * fa(t, 0.6, 0.4))
        if note:
            ly.line([(CX0, 1300), (CX0 + 470 * st(t, 1.4, 0.8), 1300)], HAIR, 1.5, al)
            ly.text(note, Rg, 27, CX0, 1350, SOFT, "lm", al * fa(t, 1.7, 0.4))
        _vbar(ly, 790, 1000, 1440, p, al, maxv, value, col=col, t=t)
        ly.fin(out)
    return g


# 2) 두 대상 비교 수치: 두 개의 숫자 카운트업 + 두 막대 (우세한 쪽만 ACC, 다른 쪽은 무채색)
def L_stat_pair(items, unit="%", en="COMPARISON", ko="", maxv=100, win=1, dec=0, diff=None):
    def g(out, t, a):
        ly, al = _base(out, t, a, en, ko)
        y0, y1 = 1060, 1400
        for i, (nm, val) in enumerate(items):
            x = 330 + i * 330; d0 = 0.3 + 0.45 * i; p = st(t, d0, 1.6)
            c = ACC if i == win else (205, 209, 218)
            w = 150
            ly.rrect((x - w / 2, y0, x + w / 2, y1), 26, fill=(245, 247, 250), a=al)
            h = (y1 - y0) * min(1, val / maxv) * p
            if h > 2: ly.rrect((x - w / 2, y1 - h, x + w / 2, y1), min(26, h / 2), fill=c, a=al)
            tx = _fmt(val * p, dec) + unit
            ly.text(tx, Bk, 64, x, y1 - h - 46, INK if i == win else SOFT, "mm", al * fa(t, d0, 0.3))
            ly.text(nm, Bd, 32, x, y1 + 42, INK if i == win else SOFT, "mm", al)
        if diff:   # 결론: 두 막대 끝을 잇는 가는 괄호선 + 차이 라벨
            q = st(t, 2.3, 0.7)
            xa, xb = 330, 660; ya = y1 - (y1 - y0) * min(1, items[0][1] / maxv); yb = y1 - (y1 - y0) * min(1, items[1][1] / maxv)
            ly.line([(xb + 70, yb), (xb + 70 + (790 - xb - 70) * q, yb)], HAIR, 1.5, al)
            ly.line([(780 - 20 * q, ya), (800, ya)], HAIR, 1.5, al)
            if q > 0.5:
                ly.line([(800, ya), (800, ya + (yb - ya) * st(t, 2.6, 0.5))], INK, 2, al)
                ly.text(diff, Bk, 46, 830, (ya + yb) / 2, ACC, "lm", al * fa(t, 2.8, 0.4))
        ly.fin(out)
    return g


# 3) 투과율 스펙트럼: 곡선이 그어지고 세로 스캔선이 계속 흐르며 값을 짚는다
def L_spectrum(curves, en="SPECTRUM", ko="파장별 투과율", hi=(780, 2500, "근적외선"), xr=(300, 2500)):
    X0, X1, YT, YB = 190, 920, 1000, 1400
    def px(nm): return X0 + (X1 - X0) * (nm - xr[0]) / (xr[1] - xr[0])
    def py(v): return YB - (YB - YT) * v / 100
    def val(pts, nm):
        for (a0, v0), (a1, v1) in zip(pts, pts[1:]):
            if a0 <= nm <= a1: return v0 + (v1 - v0) * (nm - a0) / max(1, a1 - a0)
        return pts[-1][1]
    def g(out, t, a):
        ly, al = _base(out, t, a, en, ko)
        ax = st(t, 0.1, 0.6)
        ly.line([(X0, YB), (X0 + (X1 - X0) * ax, YB)], INK, 1.5, al); ly.line([(X0, YB), (X0, YB - (YB - YT) * ax)], HAIR, 1.5, al)
        for v in (0, 50, 100): ly.text(f"{v}", Rg, 18, X0 - 14, py(v), SOFT, "rm", al)
        if hi:   # 강조 구간: 면 채움 대신 가는 사선 해칭
            hx0, hx1 = px(hi[0]), px(hi[1]); q = fa(t, 0.4, 0.5)
            for k in range(int(hx0), int(hx1), 22):
                ly.line([(k, YB), (min(hx1, k + 40), YT)], (232, 236, 246), 1.2, al * q)
            ly.text(hi[2], Md, 22, (hx0 + hx1) / 2, YT - 22, SOFT, "mm", al * q)
        for nm, lb in ((380, "UV"), (580, "가시광선")):
            ly.text(lb, Rg, 18, px(nm), YB + 26, SOFT, "mm", al)
        for ci, c in enumerate(curves):
            col = {"acc": ACC, "soft": (180, 184, 196), "red": RED, "ink": INK}[c.get("col", "acc")]
            p = st(t, 0.5 + 0.35 * ci, 1.6); end = xr[0] + (xr[1] - xr[0]) * p
            pts = [(px(nm), py(val(c["pts"], nm))) for nm in range(xr[0], int(end) + 1, 20)]
            if len(pts) > 1: ly.line(pts, col, 3 if ci == 0 else 2.4, al)
            if p > 0.97: ly.text(c["name"], Bd, 26, X1 - 4, py(c["pts"][-1][1]) - 24, col, "rm", al * fa(t, 2.2 + 0.2 * ci, 0.4))
        if t > 2.3:   # 계속 흐르는 스캔선
            nm = xr[0] + (xr[1] - xr[0]) * ((t - 2.3) * 0.22 % 1)
            ly.line([(px(nm), YT), (px(nm), YB)], HAIR, 1.2, al)
            for ci, c in enumerate(curves):
                col = {"acc": ACC, "soft": (180, 184, 196), "red": RED, "ink": INK}[c.get("col", "acc")]
                ly.circ(px(nm), py(val(c["pts"], nm)), 6, fill=col, a=al)
        ly.fin(out)
    return g


# 4) 빛의 흐름: 태양열이 필름에 닿아 반사(reflect) / 흡수 후 재방출(absorb) / 좌우 비교(compare)
def L_rays(mode="reflect", en="HEAT CONTROL", ko="", film="THE LX", other="흡수형 필름"):
    FY = 1270; SUN = (214, 176, 108)
    def stream(ly, al, t, x0, x1, kind, lab):
        cx = (x0 + x1) / 2; wid = x1 - x0
        # 필름 단면: 유리(가는 이중선) + 필름 층(굵은 선)
        ly.rrect((x0, FY - 10, x1, FY + 10), 6, fill=(248, 249, 252), outline=(206, 210, 220), w=1.5, a=al)
        ly.line([(x0 + 4, FY - 10), (x1 - 4, FY - 10)], ACC if kind == "reflect" else (120, 124, 138), 3, al)
        ly.text("실외", Rg, 22, x0 + 4, FY - 40, SOFT, "lm", al); ly.text("실내", Rg, 22, x0 + 4, FY + 44, SOFT, "lm", al)
        for k in range(9):
            ph = (t * 0.5 + k / 9) % 1
            sx, sy = x0 + wid * 0.05 + k * wid * 0.03, 990
            hx, hy = cx - wid * 0.12 + k * wid * 0.035, FY - 12
            if ph < 0.45:   # 들어오는 태양열
                q = ph / 0.45; x = sx + (hx - sx) * q; y = sy + (hy - sy) * q
                dx, dy = (hx - sx), (hy - sy); ln = math.hypot(dx, dy)
                ly.line([(x - 60 * dx / ln, y - 60 * dy / ln), (x, y)], SUN, 4, al * min(1, q * 4))
            else:
                q = (ph - 0.45) / 0.55
                if kind == "reflect":   # 반사: 같은 각도로 되돌아 나간다
                    x = hx + (hx - sx) * q * 0.9; y = hy - (hy - sy) * q * 0.9
                    dx, dy = (hx - sx), -(hy - sy); ln = math.hypot(dx, dy)
                    ly.line([(x - 60 * dx / ln, y - 60 * dy / ln), (x, y)], ACC, 4, al * (1 - q * 0.7))
                else:                   # 흡수: 필름이 달궈지고 실내로 열이 번진다
                    y = FY + 24 + 150 * q; x = hx + 18 * math.sin(q * 8 + k)
                    ly.circ(x, y, 4 + 6 * q, outline=RED, w=2, a=al * (1 - q) * 0.9)
        if kind == "absorb":
            glow = 0.45 + 0.35 * math.sin(t * 3.2)
            ly.line([(x0 + 6, FY), (x1 - 6, FY)], RED, 5, al * glow)
        ly.text(lab, Bd, 36, cx, 1470, ACC if kind == "reflect" else RED, "mm", al * fa(t, 0.9, 0.4))
    def g(out, t, a):
        ly, al = _base(out, t, a, en, ko)
        if mode == "compare":
            stream(ly, al * fa(t, 0.2, 0.4), t, CX0, 525, "absorb", other)
            ly.line([(545, 990), (545, 1490)], HAIR, 1.5, al)
            stream(ly, al * fa(t, 0.9, 0.4), t - 0.7, 565, CX1, "reflect", film)
        else:
            stream(ly, al, t, CX0 + 40, CX1 - 40, mode, (film + " · 반사") if mode == "reflect" else (other + " · 흡수"))
        ly.fin(out)
    return g


# 5) 필름 구조 단면: 층이 하나씩 밀려 들어와 쌓였다가 하나의 얇은 필름으로 합쳐진다
def L_layers(layers, en="STRUCTURE", ko="필름 구조", hi=None, note=""):
    n = len(layers)
    def g(out, t, a):
        ly, al = _base(out, t, a, en, ko)
        comp = st(t, 0.8 + 0.28 * n + 0.6, 0.9)       # 합쳐지는 정도
        gap0, gap1 = min(62, 380 / max(1, n)), 9
        gap = gap0 + (gap1 - gap0) * comp
        ybase = 1250 - (n - 1) * gap / 2
        for i, nm in enumerate(layers):
            d0 = 0.3 + 0.28 * i; p = st(t, d0, 0.7)
            y = ybase + i * gap; xs = 200 + 260 * (1 - p)
            col = ACC if (hi is not None and i == hi) else INK
            xs = xs * (1 - comp) + 330 * comp
            ly.rrect((xs, y - 8, xs + 430, y + 8), 8, fill=(250, 251, 253), outline=col if i == hi else (196, 202, 214), w=1.5, a=al * p)
            la = al * p * max(0, 1 - comp * 4)
            ly.line([(xs + 440, y), (700, y)], HAIR, 1.2, la)
            ly.text(nm, Bd if i == hi else Md, 28, 712, y, col, "lm", la)
        if comp > 0.05:
            ly.text(note or f"{n}개 층 · 하나의 필름", Bd, 40, 545, ybase + n * gap + 80, INK, "mm", al * comp)
            ly.line([(330, ybase - 34), (330 + 430 * comp, ybase - 34)], ACC, 2, al * comp)
        ly.fin(out)
    return g


# 6) 쭈글쭈글: 매끈한 필름 시트가 천천히 구겨지고 기포가 생긴다 (무채색, 결론 글자만 RED)
def L_crumple(start="출고", end="3년", label="필름 변질 · 시야 저하", en="DURABILITY", ko=""):
    def g(out, t, a):
        ly, al = _base(out, t, a, en, ko)
        x0, x1, ym, hh = 170, 920, 1130, 120
        amp = 26 * st(t, 0.8, 2.4)
        def wv(x, k): return amp * (0.6 * math.sin(x * 0.021 + t * 0.9 + k) + 0.4 * math.sin(x * 0.047 - t * 0.6 + 2 * k))
        for r in range(7):
            yy = ym - hh + r * hh * 2 / 6
            pts = [(x, yy + wv(x, r * 0.7)) for x in range(x0, x1 + 1, 10)]
            ly.line(pts, INK if r in (0, 6) else (206, 210, 220), 2 if r in (0, 6) else 1.2, al)
        rng = [(260, 0.2), (420, -0.5), (560, 0.4), (700, -0.2), (820, 0.6), (350, 0.7), (640, -0.7)]
        for k, (bx, by) in enumerate(rng):
            q = st(t, 1.5 + 0.22 * k, 0.6)
            if q > 0.02: ly.circ(bx, ym + by * hh + wv(bx, 3), 4 + 9 * q, outline=(150, 155, 168), w=1.5, a=al * q)
        # 타임라인
        q = st(t, 0.4, 2.0)
        ly.line([(x0, 1340), (x0 + (x1 - x0) * q, 1340)], INK, 2, al)
        ly.circ(x0, 1340, 7, fill=INK, a=al); ly.text(start, Md, 24, x0, 1378, SOFT, "lm", al)
        if q > 0.97:
            ly.circ(x1, 1340, 7, fill=RED, a=al); ly.text(end, Bd, 30, x1, 1380, RED, "rm", al)
        ly.text(label, Bd, 38, (x0 + x1) / 2, 1445, RED, "mm", al * fa(t, 2.3, 0.5))
        ly.fin(out)
    return g


# 7) 쌓이는 비용: 장부처럼 한 줄씩 쌓이고, 옆 세로 기둥이 같이 높아진 뒤 합계 한 줄
def L_ledger(rows, total="다 비용입니다", en="COST", ko=""):
    def g(out, t, a):
        ly, al = _base(out, t, a, en, ko)
        y = 1010; colh = 0
        for i, (txt, kind) in enumerate(rows):
            d0 = 0.3 + 0.55 * i; p = st(t, d0, 0.6)
            if p <= 0.01: continue
            c = RED if kind == "extra" else INK
            ly.text(f"{i + 1:02d}", Md, 22, CX0, y + 30 * (1 - p), SOFT, "lm", al * p)
            ly.text(txt, Bd, 40, CX0 + 60, y + 30 * (1 - p), c, "lm", al * p)
            ly.line([(CX0, y + 44), (CX0 + 520 * p, y + 44)], HAIR, 1.2, al)
            colh += 90 * p; y += 96
        # 오른쪽 기둥: 줄이 늘수록 높아짐 (무채색 + 추가분만 RED 윤곽)
        bx, by1 = 820, 1400
        ly.rrect((bx - 50, by1 - colh * 1.2, bx + 50, by1), 16, fill=(240, 242, 246), a=al)
        acc_h = 0
        for i, (txt, kind) in enumerate(rows):
            p = st(t, 0.3 + 0.55 * i, 0.6); h = 90 * 1.2 * p
            if kind == "extra" and h > 3:
                ly.rrect((bx - 50, by1 - acc_h - h, bx + 50, by1 - acc_h), 14, outline=RED, w=2, a=al)
            acc_h += h
        q = st(t, 0.4 + 0.55 * len(rows), 0.6)
        if q > 0.01:
            ly.line([(CX0, y + 10), (CX0 + 520 * q, y + 10)], INK, 2.5, al)
            ly.text(total, Bk, 54, CX0, y + 80, RED, "lm", al * q)
        ly.fin(out)
    return g


# 8) 두 선택지 대비: 좌우 칼럼이 번갈아 채워지고, 끝에 지는 쪽은 흐려지고 이기는 쪽에 점 하나
def L_versus(left, right, en="DIFFERENCE", ko="", win=1, mid="vs"):
    def g(out, t, a):
        ly, al = _base(out, t, a, en, ko)
        cols = [(CX0 + 10, left), (560, right)]
        end = 0.6 + 0.45 * max(len(left[1]), len(right[1])) * 2
        dim = st(t, end, 0.8)
        for ci, (x, (title, items)) in enumerate(cols):
            lose = ci != win
            cA = mixc(INK, (190, 194, 204), dim) if lose else INK
            ly.text(title, Bk, 46, x, 1010, cA, "lm", al * fa(t, 0.2 + 0.2 * ci, 0.3))
            if not lose and dim > 0.05: ly.circ(x + ly.tw(title, Bk, 46) + 22, 1004, 8, fill=ACC, a=al * dim)
            ly.line([(x, 1052), (x + 330 * st(t, 0.3 + 0.2 * ci, 0.6), 1052)], INK if not lose else HAIR, 2 if not lose else 1.5, al)
            for k, it in enumerate(items):
                d0 = 0.6 + 0.45 * (k * 2 + ci); p = st(t, d0, 0.5)
                ly.text(it, Md, 32, x, 1120 + k * 78 + 20 * (1 - p), cA if lose else INK, "lm", al * p)
        ly.text(mid, Md, 30, 530, 1260, SOFT, "mm", al * fa(t, 0.4, 0.3))
        ly.line([(530, 1010), (530, 1220)], HAIR, 1.2, al); ly.line([(530, 1300), (530, 1450)], HAIR, 1.2, al)
        ly.fin(out)
    return g


# 9) 라인업 계단: 가는 계단선 위에 등급 이름, 강조 등급에 점과 알약 배지 (색 블록 없음)
def L_ladder(steps, hi=0, badge="ENTRY", en="LINEUP", ko=""):
    n = len(steps)
    def g(out, t, a):
        ly, al = _base(out, t, a, en, ko)
        sw = (CX1 - CX0 - 20) / n; base = 1420; rise = 300 / max(1, n - 1)
        pts = [(CX0, base)]
        for i in range(n):
            y = base - rise * i; pts += [(CX0 + sw * i, y), (CX0 + sw * (i + 1), y)]
            if i < n - 1: pts.append((CX0 + sw * (i + 1), y - rise))
        q = st(t, 0.2, 1.6); m = max(2, int(len(pts) * q))
        ly.line(pts[:m], (196, 202, 214), 2, al)
        for i, nm in enumerate(steps):
            p = st(t, 0.4 + 0.3 * i, 0.5); y = base - rise * i; x = CX0 + sw * i + sw / 2
            c = ACC if i == hi else INK
            ly.text(nm, Bk if i == hi else Bd, 40 if i == hi else 32, x, y - 40 - 16 * (1 - p), c, "mm", al * p)
            if i == hi and p > 0.9:
                pu = (t * 0.8) % 1
                ly.circ(x, y, 7, fill=ACC, a=al); ly.circ(x, y, 7 + 14 * pu, outline=ACC, w=1.5, a=al * (1 - pu))
                _pill(ly, x, y - 110, badge, al * fa(t, 1.6, 0.4), INK, 22, "m")
        ly.fin(out)
    return g


# 10) 타임라인: 선이 그어지며 시점들이 차례로 찍히고, 작은 점 하나가 계속 선을 따라 흐른다
def L_timeline(points, en="TIMELINE", ko="", hi=-1):
    n = len(points)
    def g(out, t, a):
        ly, al = _base(out, t, a, en, ko)
        y = 1210; q = st(t, 0.2, 1.6)
        ly.line([(CX0, y), (CX0 + (CX1 - CX0) * q, y)], INK, 2, al)
        for i, (lb, sub) in enumerate(points):
            x = CX0 + (CX1 - CX0) * i / max(1, n - 1); p = st(t, 0.3 + 1.4 * i / max(1, n - 1), 0.5)
            ish = i == (hi % n)
            ly.circ(x, y, 9 if ish else 7, fill=ACC if ish else INK, a=al * p)
            up = i % 2 == 0
            ly.text(lb, Bk if ish else Bd, 44 if ish else 36, x, y + (-70 if up else 70), ACC if ish else INK, "mm", al * p)
            if sub: ly.text(sub, Md, 28, x, y + (-124 if up else 122), SOFT, "mm", al * p)
        if q > 0.98:
            f = (t * 0.25) % 1; ly.circ(CX0 + (CX1 - CX0) * f, y, 5, fill=ACC, a=al * 0.8)
        ly.fin(out)
    return g


# 11) 선택 기준 목록: 체크박스 대신 01·02 번호와 가늘게 뻗는 선, 끝에 ACC 점
def L_criteria(items, en="CHECK POINT", ko=""):
    def g(out, t, a):
        ly, al = _base(out, t, a, en, ko)
        gap = min(210, 440 / max(1, len(items)))
        for i, (ttl, sub) in enumerate(items):
            y = 1225 - (len(items) - 1) * gap / 2 - 30 + i * gap; d0 = 0.3 + 0.7 * i; p = st(t, d0, 0.6)
            ly.text(f"{i + 1:02d}", Bk, 44, CX0, y, ACC if p > 0.99 else (200, 204, 214), "lm", al * p)
            ly.text(ttl, Bd, 50, CX0 + 100, y, INK, "lm", al * p)
            if sub: ly.text(sub, Rg, 30, CX0 + 100, y + 56, SOFT, "lm", al * fa(t, d0 + 0.3, 0.4))
            ly.line([(CX0 + 100, y + 86), (CX0 + 100 + 640 * st(t, d0 + 0.2, 0.8), y + 86)], HAIR, 1.2, al)
        ly.fin(out)
    return g


# 12) 실차 사진 카드: 카드를 꽉 채운 사진이 천천히 다가가고 두 번째 컷으로 교차, 작은 검정 라벨
_phc = {}
def _photo(path, w, h):
    k = (path, w, h)
    if k not in _phc:
        im = Image.open(path if os.path.isabs(path) else os.path.join(D, path)).convert("RGB")
        s = max(w / im.width, h / im.height) * 1.12; im = im.resize((int(im.width * s), int(im.height * s)), Image.LANCZOS)
        _phc[k] = im
    return _phc[k]
def _mask(w, h, r=44):
    k = ("m", w, h)
    if k not in _phc:
        m = Image.new("L", (w, h), 0); ImageDraw.Draw(m).rounded_rectangle([0, 0, w - 1, h - 1], radius=r, fill=255); _phc[k] = m
    return _phc[k]
def _shot(path, w, h, z, fx=0.5, fy=0.5):
    im = _photo(path, w, h); cw, ch = w / z * 1.0, h / z * 1.0
    cw = min(cw, im.width); ch = min(ch, im.height)
    x0 = (im.width - cw) * fx; y0 = (im.height - ch) * fy
    return im.crop((int(x0), int(y0), int(x0 + cw), int(y0 + ch))).resize((w, h), Image.LANCZOS)
def L_photo(paths, label="", en=None, focus=None):
    focus = focus or [(0.5, 0.5)] * len(paths)
    def g(out, t, a):
        al = a * fa(t, 0, 0.35); ly = Ly(); card(out, ly, CB, al); ly.fin(out)
        w, h = CB[2] - CB[0], CB[3] - CB[1]
        n = len(paths); seg = 2.6
        i = min(n - 1, int(t / seg)); lt = t - i * seg
        z = 1.0 + 0.06 * (lt / seg) + 0.02 * i
        im = _shot(paths[i], w, h, z, *focus[i])
        if i + 1 < n and lt > seg - 0.5:   # 다음 컷과 교차
            k = (lt - (seg - 0.5)) / 0.5; im2 = _shot(paths[i + 1], w, h, 1.0, *focus[i + 1]); im = Image.blend(im, im2, k)
        im = im.convert("RGBA"); im.putalpha(_mask(w, h)); put(out, im, CB[0], CB[1], al)
        if label:
            l2 = Ly(); _pill(l2, CB[0] + 36, CB[3] - 52, label, al * fa(t, 0.4, 0.4), INK, 24); l2.fin(out)
        if en:
            l3 = Ly(); l3.text(en, Md, 22, CB[0] + 40, CB[1] + 46, (255, 255, 255), "lm", al * 0.9, sp=5); l3.fin(out)
    return g


# 13) 사진 비교 와이프: 한쪽은 눈부심·뿌연 시야(효과), 세로 구분선이 지나가며 선명한 화면이 드러난다
def L_wipe(path, before="일반 필름", after="THE LX", effect="glare", focus=(0.5, 0.5)):
    def g(out, t, a):
        al = a * fa(t, 0, 0.35); ly = Ly(); card(out, ly, CB, al); ly.fin(out)
        w, h = CB[2] - CB[0], CB[3] - CB[1]
        z = 1.02 + 0.04 * min(1, t / 4.5)
        clear = _shot(path, w, h, z, *focus)
        arr = np.asarray(clear).astype(np.float32)
        if effect == "glare":
            yy, xx = np.mgrid[0:h, 0:w]; bloom = np.exp(-(((xx - w * 0.62) / (w * 0.35)) ** 2 + ((yy - h * 0.3) / (h * 0.35)) ** 2))
            bad = arr * 0.75 + 255 * (0.55 * bloom[..., None] + 0.15)
            for k in range(4):   # 내부 반사 고스트 줄
                yk = int(h * (0.25 + 0.15 * k + 0.03 * math.sin(t + k))); bad[max(0, yk - 2):yk + 2] += 40
        elif effect == "haze":
            bad = arr * 0.55 + 255 * 0.38
        else:   # dark
            bad = arr * 0.35
        bad = Image.fromarray(np.clip(bad, 0, 255).astype(np.uint8))
        pos = w * (1 - st(t, 0.9, 1.6))     # 구분선이 오른쪽에서 왼쪽으로
        im = clear.copy(); im.paste(bad.crop((0, 0, max(1, int(pos)), h)), (0, 0))
        im = im.convert("RGBA"); im.putalpha(_mask(w, h)); put(out, im, CB[0], CB[1], al)
        l2 = Ly()
        if 4 < pos < w - 4: l2.line([(CB[0] + pos, CB[1] + 8), (CB[0] + pos, CB[3] - 8)], (255, 255, 255), 3, al)
        _pill(l2, CB[0] + 36, CB[1] + 52, before, al * (1 - st(t, 2.2, 0.4)), (60, 64, 76), 22)
        _pill(l2, CB[2] - 36, CB[1] + 52, after, al * fa(t, 1.2, 0.4), INK, 22, "r")
        l2.fin(out)
    return g


# 14) 링 게이지: 얇은 원호가 차오르며 가운데 숫자 카운트업 (기간·횟수·비율 강조)
def L_ring(value, unit="", label="", en="", ko="", maxv=100, dec=0, sub=""):
    def g(out, t, a):
        ly, al = _base(out, t, a, en, ko)
        cx, cy, r = 360, 1220, 190; p = st(t, 0.3, 1.8)
        steps = 120
        ring = [(cx + r * math.cos(-math.pi / 2 + 2 * math.pi * k / steps), cy + r * math.sin(-math.pi / 2 + 2 * math.pi * k / steps)) for k in range(steps + 1)]
        ly.line(ring, (236, 239, 245), 14, al)
        m = int(steps * min(1, value / maxv) * p)
        if m > 1: ly.line(ring[:m + 1], ACC, 14, al)
        tx = _fmt(value * p, dec)
        ly.text(tx, Bk, 120, cx, cy - 4, INK, "mm", al)
        if unit: ly.text(unit, Bd, 40, cx, cy + 82, SOFT, "mm", al)
        if label: ly.text(label, Bd, 44, 610, 1170, INK, "lm", al * fa(t, 1.0, 0.4))
        if sub: ly.text(sub, Rg, 27, 610, 1240, SOFT, "lm", al * fa(t, 1.4, 0.4))
        if p > 0.98:
            pu = (t * 0.6) % 1; ly.circ(cx, cy, r + 12 + 30 * pu, outline=ACC, w=1.2, a=al * (1 - pu) * 0.5)
        ly.fin(out)
    return g
