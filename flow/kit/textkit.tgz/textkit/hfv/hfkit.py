# MOTIF 릴스 HyperFrames 키트 — 화면 전체를 HTML + GSAP로 만들고 HyperFrames로 렌더링
# 2026-11-22 솔라가드 단일샵 릴스에서 마틴이 "하이퍼프레임 쪽이 훨씬 낫다"고 확정한 방식
# 사용 순서는 README.md 참고. 장면(카드·그래프) HTML/JS만 릴스마다 새로 쓴다.
import os, re, json, shutil, subprocess, glob, sys

K = os.path.dirname(os.path.abspath(__file__))
BRAND = os.path.join(K, "..", "brand")
HFV = "hyperframes@0.9.65"
ENV = dict(os.environ, DO_NOT_TRACK="1")

def esc(s): return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

# ── 부품 ──
ROLL = '<span class="dg"><span class="col">' + '<br>'.join('0123456789') + '</span></span>'   # 굴러가는 숫자 한 자리
CHECK = '<div class="chk"><div class="cc"></div><div class="ct"></div></div>'                   # 체크 표시(JS chk()로 등장)
def head(en, ko): return f'<div class="en">{en}</div><div class="ko">{ko}</div>'               # 카드 왼쪽 위 영문 · 오른쪽 위 한글

def cap_html(j, rows, size=64):
    """자막 한 문장. rows = [[(글자, 스타일)...], ...]  스타일: None 검정 · 'g' 회색 · 'b'/'p'/'bp' 그라데이션+형광펜 · '~' 앞말에 붙임"""
    out = []
    for r in rows:
        parts = []
        for k, (txt, st) in enumerate(r):
            glue = txt.startswith("~"); txt = txt.lstrip("~")
            if k and not glue: parts.append(" ")
            if st in (None, "g"):
                parts.append(f'<span class="{"cg" if st == "g" else "ci"}">{esc(txt)}</span>')
            else:
                parts.append(f'<span class="hl"><span class="band band-{st}"></span><span class="gt g{st}">{esc(txt)}</span></span>')
        out.append(f'<div class="row">{"".join(parts)}</div>')
    return f'<div class="cap" id="cap{j}" style="font-size:{size}px">{"".join(out)}</div>'

def timing(D, motif=True, tail=5.5):
    TM = json.load(open(os.path.join(D, "timing.json")))
    ST, SD, SC, VL = TM["sent_starts"], TM["sent_durs"], TM["scene_starts"], TM["voice_len"]
    END0 = ST[-1] - 0.85 if motif else ST[-1] + SD[-1] + 0.4
    return ST, SD, SC, END0, VL + tail

def project(name):
    P = f"/tmp/hf/{name}"
    os.makedirs(P + "/assets/fonts", exist_ok=True)
    if not os.path.exists(P + "/assets/gsap.min.js"):
        subprocess.run("npm pack gsap@3.15.0 -q && tar xzf gsap-3.15.0.tgz && cp package/dist/gsap.min.js assets/ && rm -rf package gsap-3.15.0.tgz", shell=True, cwd=P, check=True)
    for fn, body in [("package.json", '{"name":"reel","private":true,"type":"module"}'), ("hyperframes.json", '{"paths":{"blocks":"compositions","components":"compositions/components","assets":"assets"}}')]:
        if not os.path.exists(os.path.join(P, fn)): open(os.path.join(P, fn), "w").write(body)
    return P

def build(D, name, title, bgw, cap, scenes_html, scenes_js, size=None, assets=(), right="SOLAR GARD", motif=True,
          end=("솔라가드 THE LX 전주 유일 공식 특화샵", "시공 및 예약 문의", "010-4814-4506", "전주 덕진구 정여립로 1104")):
    """D: 녹음 폴더(timing.json) · bgw: 장면별 배경 글자 7개 · cap: 문장별 자막(마지막 '전주 모티프였습니다' 제외)
    scenes_html: id s0..s6 장면 div들 · scenes_js: 장면 애니메이션(GSAP, base_head.js 함수 사용) · assets: 작업 폴더 사진 파일 이름"""
    ST, SD, SC, END0, TOTAL = timing(D, motif)
    P = project(name); size = size or {}
    css = open(os.path.join(K, "base.css"), encoding="utf-8").read()
    jsh = open(os.path.join(K, "base_head.js"), encoding="utf-8").read()
    jst = open(os.path.join(K, "base_tail.js"), encoding="utf-8").read()
    r3 = lambda a: json.dumps([round(x, 3) for x in a])
    jsh = jsh.replace("__ST__", r3(ST)).replace("__SD__", r3(SD)).replace("__SC__", r3(SC)).replace("__END0__", f"{END0:.3f}").replace("__TOTAL__", f"{TOTAL:.3f}")
    caps = "\n".join(cap_html(j, r, size.get(j, 64)) for j, r in enumerate(cap))
    bg = "".join(f'<div class="bgw" id="bw{i}">{w}</div>' for i, w in enumerate(bgw))
    e1, e2, e3, e4 = end
    html = f'''<!doctype html>
<html lang="ko"><head><meta charset="UTF-8"/><meta name="viewport" content="width=1080, height=1920"/>
<script src="assets/gsap.min.js"></script><style>{css}</style></head>
<body><div id="root" data-composition-id="main" data-start="0" data-duration="{TOTAL:.3f}" data-width="1080" data-height="1920">
<div id="hdr"><div class="bar"></div><div class="t">{esc(title)}</div><div class="l">MOTIF</div><div class="r">{right}</div></div>
{bg}
{scenes_html}
{caps}
<img id="logo" src="assets/logo.png"/>
<div id="end"><img id="elogo" src="assets/logo.png"/><div id="ename">{e1}</div><div id="eline"></div>
<div id="eask">{e2}</div><div id="etel" class="gbp">{e3}</div><div id="eadr">{e4}</div></div>
</div>
<script>{jsh}
{scenes_js}
{jst}</script></body></html>'''
    open(P + "/index.html", "w", encoding="utf-8").write(html)
    for f in assets: shutil.copy(os.path.join(D, f), os.path.join(P, "assets", f))
    shutil.copy(os.path.join(BRAND, "motif_logo_dark.png"), P + "/assets/logo.png")
    from fontTools.ttLib import TTCollection
    from fontTools import subset
    text = "".join(sorted(set(re.sub(r"<[^>]+>", "", html)) | set("0123456789%/.,+-×=→↓↑?·! ")))
    for w, nm in [(400, "Regular"), (500, "Medium"), (700, "Bold"), (900, "Black")]:
        f = [x for x in TTCollection(f"/usr/share/fonts/opentype/noto/NotoSansCJK-{nm}.ttc").fonts if "KR" in x["name"].getDebugName(1)][0]
        f.save(f"/tmp/k{w}.otf"); o = subset.Options(); o.flavor = "woff2"
        font = subset.load_font(f"/tmp/k{w}.otf", o); s = subset.Subsetter(o); s.populate(text=text); s.subset(font)
        subset.save_font(font, f"{P}/assets/fonts/k{w}.woff2", o)
    return P, TOTAL

def snapshot(name, times, out, crop=None):
    """지정 시각 프레임을 한 장 시트로(Read로 확인). crop=(x0,y0,x1,y1)"""
    from PIL import Image
    P = f"/tmp/hf/{name}"; shutil.rmtree(P + "/.hyperframes/artifacts/snapshots", ignore_errors=True)
    subprocess.run(["npx", "--yes", HFV, "snapshot", "--at", ",".join(f"{t:.2f}" for t in times)], cwd=P, env=ENV, capture_output=True)
    fs = sorted(glob.glob(P + "/.hyperframes/artifacts/snapshots/*/frame-*.png"))[:len(times)]
    ims = [Image.open(f).convert("RGB") for f in fs]
    if crop: ims = [im.crop(crop) for im in ims]
    w = 300; ims = [im.resize((w, int(im.height * w / im.width))) for im in ims]
    sh = Image.new("RGB", (w * len(ims), max(i.height for i in ims)), "white")
    for k, im in enumerate(ims): sh.paste(im, (k * w, 0))
    sh.save(out); return out

def check(name):
    r = subprocess.run(["npx", "--yes", HFV, "check", "--json"], cwd=f"/tmp/hf/{name}", env=ENV, capture_output=True, text=True)
    return r.stdout.count('"severity": "error"')

def mix(D, TOTAL, kind="auto"):
    """피아노 20곡 중 하나(영상 길이에 맞춰 반복) + 목소리 → mix.wav (-16 LUFS, 덕킹)"""
    sys.path.insert(0, os.path.join(K, "..")); import make_reel as MR
    song = MR.pick_piano(kind, TOTAL, os.path.join(D, "piano.wav"))
    L = TOTAL
    subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-i", "voice.wav", "-i", "piano.wav", "-filter_complex",
        f"[0:a]aresample=48000,aformat=channel_layouts=stereo,loudnorm=I=-16:TP=-1.5,apad=whole_dur={L},asplit=2[v][vk];"
        "[1:a]loudnorm=I=-18,volume=-6dB[p];[p][vk]sidechaincompress=threshold=0.02:ratio=4:attack=30:release=600[pd];"
        "[v][pd]amix=inputs=2:normalize=0,loudnorm=I=-16:TP=-1.5[a]", "-map", "[a]", "-ar", "48000", "-t", str(L), "mix.wav"], cwd=D, check=True)
    return song

def render(D, name, out):
    """HyperFrames 렌더링(90초 약 8~9분) → mix.wav와 합쳐 out(mp4)"""
    v = os.path.join(D, "hf_video.mp4")
    subprocess.run(["npx", "--yes", HFV, "render", "--quality", "high", "--fps", "30", "--output", v], cwd=f"/tmp/hf/{name}", env=ENV, check=True, capture_output=True)
    subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-i", v, "-i", os.path.join(D, "mix.wav"), "-map", "0:v", "-map", "1:a", "-c:v", "copy",
                    "-c:a", "aac", "-b:a", "256k", "-shortest", "-movflags", "+faststart", out], check=True)
    return out
