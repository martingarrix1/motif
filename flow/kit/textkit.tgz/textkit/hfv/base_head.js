
const ST=__ST__, SD=__SD__, SC=__SC__, END0=__END0__, TOTAL=__TOTAL__;
const at=(j,f=0)=>ST[j]+SD[j]*f;
const tl = gsap.timeline({ paused: true });
const E3="power3.out", E4="power4.out";
const OPEN=0.15;   // 첫 프레임은 빈 오프화이트 화면. 요소는 이 시각부터 차례로 등장(2026-11-22 마틴: "처음엔 화이트에서 시작해서 모션 그래픽들이 나와야지")
tl.fromTo("#hdr .bar",{scaleY:0,transformOrigin:"50% 0%"},{scaleY:1,duration:.5,ease:E3},OPEN);
tl.fromTo(["#hdr .t","#hdr .l","#hdr .r"],{opacity:0,x:-20},{opacity:1,x:0,duration:.5,ease:E3,stagger:.08},OPEN+.1);
tl.fromTo("#logo",{opacity:0,y:20},{opacity:1,y:0,duration:.6,ease:E3},OPEN+.3);
function count(sel,a,b,t,d,idx=1,first=false){tl.fromTo(sel+" .dg:nth-child("+idx+") .col",{yPercent:-10*a},{yPercent:-10*b,duration:Math.max(d,1.2),ease:"power2.inOut",immediateRender:first},t);}
function pop(sel,t,d=.8){tl.fromTo(sel,{opacity:0,scale:.92,y:20},{opacity:1,scale:1,y:0,duration:d,ease:"power3.out"},t);}
function popHook(sel,t,d=.6){tl.fromTo(sel,{opacity:0,scale:.6,y:16},{opacity:1,scale:1,y:0,duration:d,ease:"back.out(1.8)"},t);}   // 튀는 효과는 첫 장면 후킹에서만
function inn(sel,t,d=.8,y=30){tl.fromTo(sel,{opacity:0,y:y},{opacity:1,y:0,duration:d,ease:"power3.out"},t);}
function out(sel,t,d=.6){tl.to(sel,{opacity:0,y:-20,duration:d,ease:"power2.inOut"},t);}
// 선 · 그래프는 왼쪽부터 서서히 그려진다(클립 리빌). stroke-dashoffset은 렌더러에서 한 번에 뿅 나타나니 쓰지 않는다(2026-11-22 마틴: "그래프가 서서히 움직이게, 앞으로 계속")
function draw(sel,t,d=2.0,ease="power1.inOut"){tl.fromTo(sel,{clipPath:"inset(0% 100% 0% 0%)"},{clipPath:"inset(0% 0% 0% 0%)",duration:d,ease:ease},t);}
function chk(sel,t){tl.fromTo(sel+" .cc",{scale:0},{scale:1,duration:.6,ease:"power3.out"},t);tl.fromTo(sel+" .ct",{opacity:0,scale:.6,rotation:45},{opacity:1,scale:1,rotation:45,duration:.5,ease:"power2.out"},t+.25);}
function card(sel,t){tl.fromTo(sel,{opacity:0,y:50,scale:.97},{opacity:1,y:0,scale:1,duration:1.0,ease:"power3.out"},t);}
function swap(a,b,t){tl.to(a,{opacity:0,y:-24,scale:.98,duration:.6,ease:"power2.inOut"},t);card(b,t+.25);}

// 장면 컨테이너와 배경 글자
for(let i=0;i<SC.length;i++){
  const t0=Math.max(SC[i]-.3,0), t1=(i+1<SC.length?SC[i+1]-.15:END0);
  if(i==0) tl.set("#s0",{opacity:1},0); else tl.fromTo("#s"+i,{opacity:0},{opacity:1,duration:.01},t0);
  tl.to("#s"+i,{opacity:0,duration:.35,ease:"power2.in"},t1-.2);
  tl.fromTo("#bw"+i,{opacity:0,x:120},{opacity:1,x:0,duration:.8,ease:E3},t0);
  tl.to("#bw"+i,{x:-260,duration:t1-t0,ease:"none"},t0);
  tl.to("#bw"+i,{opacity:0,duration:.35},t1-.2);
}
// 자막
for(let j=0;j<ST.length-1;j++){
  const t0=(j==0?0:ST[j]-.15), t1=(j==ST.length-2?END0-.2:ST[j+1]-.15);
  const rows="#cap"+j+" .row";
  tl.fromTo(rows,{opacity:0,y:34},{opacity:1,y:0,duration:.75,ease:"power3.out",stagger:.1},j==0?OPEN+.35:t0);
  tl.to("#cap"+j+" .band",{scaleX:1,duration:.8,ease:"power2.inOut",stagger:.12},t0+.3);
  tl.to(rows,{opacity:0,y:-18,duration:.4,ease:"power2.inOut"},t1-.4);
}

