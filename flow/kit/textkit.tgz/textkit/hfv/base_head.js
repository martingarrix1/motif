
const ST=__ST__, SD=__SD__, SC=__SC__, END0=__END0__, TOTAL=__TOTAL__;
const at=(j,f=0)=>ST[j]+SD[j]*f;
const tl = gsap.timeline({ paused: true });
const E3="power3.out", E4="power4.out";
function count(sel,a,b,t,d,idx=1,first=false){tl.fromTo(sel+" .dg:nth-child("+idx+") .col",{yPercent:-10*a},{yPercent:-10*b,duration:d,ease:"power3.out",immediateRender:first},t);}
function pop(sel,t,d=.55){tl.fromTo(sel,{opacity:0,scale:.6,y:16},{opacity:1,scale:1,y:0,duration:d,ease:"back.out(2)"},t);}
function inn(sel,t,d=.5,y=30){tl.fromTo(sel,{opacity:0,y:y},{opacity:1,y:0,duration:d,ease:E3},t);}
function out(sel,t,d=.35){tl.to(sel,{opacity:0,y:-24,duration:d,ease:"power2.in"},t);}
function chk(sel,t){tl.fromTo(sel+" .cc",{scale:0},{scale:1,duration:.35,ease:"back.out(2.4)"},t);tl.fromTo(sel+" .ct",{opacity:0,scale:.3,rotation:45},{opacity:1,scale:1,rotation:45,duration:.35,ease:"back.out(2.5)"},t+.15);}
function card(sel,t){tl.fromTo(sel,{opacity:0,y:60,scale:.96},{opacity:1,y:0,scale:1,duration:.7,ease:E4},t);}
function swap(a,b,t){tl.to(a,{opacity:0,y:-30,scale:.97,duration:.4,ease:"power2.in"},t);card(b,t+.15);}

// 장면 컨테이너와 배경 글자
for(let i=0;i<SC.length;i++){
  const t0=Math.max(SC[i]-.3,0), t1=(i+1<SC.length?SC[i+1]-.15:END0);
  if(i==0) tl.set("#s0",{opacity:1},0); else tl.fromTo("#s"+i,{opacity:0},{opacity:1,duration:.01},t0);
  tl.to("#s"+i,{opacity:0,duration:.35,ease:"power2.in"},t1-.2);
  tl.fromTo("#bw"+i,{opacity:0,x:120},{opacity:1,x:0,duration:.8,ease:E3},t0);
  tl.to("#bw"+i,{x:-260,duration:t1-t0,ease:"none"},t0);
  tl.to("#bw"+i,{opacity:0,duration:.35},t1-.2);
}
// 자막
for(let j=0;j<ST.length-1;j++){
  const t0=(j==0?0:ST[j]-.15), t1=(j==ST.length-2?END0-.2:ST[j+1]-.15);
  const rows="#cap"+j+" .row";
  if(j==0) tl.set(rows,{opacity:1},0); else tl.fromTo(rows,{opacity:0,y:34},{opacity:1,y:0,duration:.5,ease:E3,stagger:.07},t0);
  tl.to("#cap"+j+" .band",{scaleX:1,duration:.5,ease:"power2.out",stagger:.1},t0+.3);
  tl.to(rows,{opacity:0,y:-22,duration:.25,ease:"power2.in"},t1-.25);
}

