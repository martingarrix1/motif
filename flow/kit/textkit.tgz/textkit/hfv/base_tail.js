// ── 엔드카드 ──
tl.to(["#hdr","#logo"],{opacity:0,duration:.4},END0-.4);
tl.fromTo("#elogo",{opacity:0,y:30,scale:.92},{opacity:1,y:0,scale:1,duration:.8,ease:E4},END0);
inn("#ename",END0+.25); tl.fromTo("#eline",{opacity:0,scaleX:0},{opacity:1,scaleX:1,duration:.5,ease:E3},END0+.45);
inn("#eask",END0+.55); inn("#etel",END0+.65,.6,30); inn("#eadr",END0+.8);
tl.to("#end",{opacity:0,duration:1.5,ease:"power1.in"},TOTAL-1.6);
tl.set({}, {}, TOTAL);
window.__timelines["main"] = tl;
tl.seek(0);
