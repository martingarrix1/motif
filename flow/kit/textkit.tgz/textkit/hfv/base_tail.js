// ── 엔드카드 ──
tl.to(["#hdr","#logo"],{opacity:0,duration:.4},END0-.4);
tl.fromTo("#elogo",{opacity:0,y:30,scale:.92},{opacity:1,y:0,scale:1,duration:.8,ease:E4},END0);
inn("#ename",END0+.25); tl.fromTo("#eline",{opacity:0,scaleX:0},{opacity:1,scaleX:1,duration:.5,ease:E3},END0+.45);
inn("#eask",END0+.55); inn("#etel",END0+.65,.6,30); inn("#eadr",END0+.8);
{const bk=document.createElement("div");bk.id="blackout";bk.style.cssText="position:absolute;inset:0;background:#000;opacity:0;z-index:999";document.getElementById("root").appendChild(bk);
tl.to("#blackout",{opacity:1,duration:1.8,ease:"power1.in"},TOTAL-1.9);}   // 끝은 검정으로 페이드아웃(2026-11-22 마틴)
tl.set({}, {}, TOTAL);
window.__timelines["main"] = tl;
tl.seek(0);
