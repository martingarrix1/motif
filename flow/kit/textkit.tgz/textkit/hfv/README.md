# MOTIF 릴스 HyperFrames 키트 (hfv)

2026-11-22 마틴 확정: 릴스 화면 전체(헤더 · 장면 카드 · 그래프 · 자막 · 배경 글자 · 로고 · 엔드카드)를 HTML + GSAP로 짜고 HyperFrames로 렌더링한다.
파이썬으로 프레임을 그리던 방식(cityv)과 나란히 비교해 "하이퍼프레임 쪽이 훨씬 낫다"고 함. 디자인 기준은 "도시의 밤" 기준작(오프화이트 · 흰 카드 · 그라데이션 핵심어 + 형광펜 띠).

## 순서
1. 대사 승인 → `script.txt` → `python3 ~/mk/textkit/make_reel.py voice <폴더>` (일레븐랩스 B 녹음 + 제미나이 검수, timing.json 생성)
2. 장면 설계: 문장마다 그래픽이 바뀌게. 그래프 색은 무채색 또는 파랑. XY축 그래프 적극 사용. 수치는 원문에 있는 것만.
3. 빌드 스크립트 작성(예시 `example/build_single.py` 복사): CAP(자막) · BGW(배경 글자 7개) · TITLE · scenes_html(s0~s6) · scenes_js
   → `build()` → `snapshot(name, [시각...], "sheet.jpg")` 로 확인(Read) → 고치기 반복
4. `mix(D, TOTAL)` (클래식 피아노 20곡 중 하나, 영상 길이에 맞춰 반복) → `render(D, name, out.mp4)` (90초 약 8~9분, 백그라운드로 돌리고 기다림)

## base_head.js 함수 (장면 JS에서 사용)
- `at(j, f)` j번째 문장 시작 + 길이×f 시각
- `card(sel, t)` 카드 아래에서 올라오며 등장 · `swap(a, b, t)` 카드 교체
- `pop(sel, t)` 알약·배지 튀어나오기 · `inn(sel, t)` 아래에서 떠오르기 · `out(sel, t)`
- `count(sel, a, b, t, d, 자릿수번째, 첫트윈?)` 굴러가는 숫자(ROLL). 같은 자리를 두 번 움직일 땐 keyframes 한 트윈으로(두 트윈이면 되감기 때 꼬임)
- `chk(sel, t)` 체크 표시 등장(CHECK 부품)
- 장면 컨테이너(#s0~#s6) 전환 · 배경 글자 흐름 · 자막 등장/형광펜/퇴장은 자동

## 주의(실제로 겪은 것)
- 숫자를 textContent로 바꾸지 않는다(되감기 때 안 돌아옴). ROLL + yPercent만.
- SVG path 선 그리기(stroke-dashoffset)는 렌더러에서 안 보일 때가 있다. 체크는 HTML(.cc/.ct)로, 축·화살표는 pathLength="1" + dashoffset으로 확인됨.
- SVG rect 크기 변화는 GSAP transformOrigin:"50% 100%"를 트윈에 직접 준다(CSS transform-origin 말고).
- 같은 요소에 fromTo 여러 개를 겹치지 않는다.
- 모티프 버전이 아니면 build(motif=False)로 엔드카드 시각만 바뀐다. 기본형(THE LX 하단 로고 · 질문 엔드카드)은 base.css/#end를 손봐 쓴다.

## 시작 화면(2026-11-22 마틴)
- 첫 프레임은 아무것도 없는 오프화이트 화면. 헤더 · 로고 · 첫 자막은 base_head.js가 OPEN(0.15초)부터 차례로 들여보낸다.
- 첫 장면 카드와 그래픽도 처음부터 떠 있게 두지 말고 card("#c0", OPEN) 처럼 등장시킨다. 후킹 글씨도 0초에 이미 보이게 하지 않는다.
