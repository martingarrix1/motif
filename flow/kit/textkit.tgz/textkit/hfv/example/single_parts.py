def head(en, ko): return f'<div class="en">{en}</div><div class="ko">{ko}</div>'
CHECK = '<div class="chk"><div class="cc"></div><div class="ct"></div></div>'

# ── 장면 HTML ──
tiles = "".join(
    (f'<div class="tile solar" id="t{k}" style="left:{54 + (k % 4) * 200}px;top:{330 + (k // 4) * 140}px"><span>SOLAR GARD</span></div>' if k == 5 else
     f'<div class="tile" id="t{k}" style="left:{54 + (k % 4) * 200}px;top:{330 + (k // 4) * 140}px"><i></i><b></b></div>')
    for k in range(8))
bars = "".join(
    f'<rect class="bar" id="bar{k}" x="{130 + k * 88}" y="{540 - h}" width="62" height="{h}" rx="10" fill="{"url(#gbar)" if k == 0 else "#ced2dc"}"/>'
    for k, h in enumerate([150, 132, 158, 120, 146, 128, 152, 138]))
crit = "".join(
    f'<div class="card crit" id="cr{k}" style="top:{290 + k * 222}px;height:196px"><div class="cno {"gp" if k == 2 else "gb"}">{no}</div><div class="cline"></div>'
    f'<div class="cnm">{nm}</div><div class="csub">{sub}</div><div class="cchk">{CHECK}</div></div>'
    for k, (no, nm, sub) in enumerate([("01", "제조원의 신뢰도", "누가 만들었는가"), ("02", "성능의 지속성", "얼마나 오래 유지되는가"), ("03", "고객님들의 평가", "실제로 써 본 사람의 판단")]))
nodes = "".join(
    f'<div class="node" id="nd{k}" style="left:{74 + 740 * u}px"></div><div class="nlab" id="nl{k}" style="left:{74 + 740 * u}px">{nm}</div>'
    for k, (nm, u) in enumerate([("첫 시공", 0), ("여름 · 겨울", 0.333), ("수년 사용", 0.667), ("차량 교체", 1)]))
shades = "".join(
    f'<div class="chip" id="ch{k}" style="left:{54 + k * 158}px;background:linear-gradient(160deg,rgb({g + 18},{g + 22},{g + 34}),rgb({g},{g + 4},{g + 14}))"><div class="glare"></div></div>'
    f'<div class="chlab" id="chl{k}" style="left:{54 + k * 158}px">{nm}</div><div class="chchk" id="chc{k}" style="left:{54 + k * 158 + 52}px">{CHECK}</div>'
    for k, (nm, g) in enumerate([("LX 15", 38), ("LX 25", 68), ("LX 40", 108), ("LX 55", 148), ("LX 70", 194)]))

