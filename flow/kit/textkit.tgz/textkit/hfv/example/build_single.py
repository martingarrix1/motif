# 예시: 솔라가드 단일샵 릴스(2026-11-22) — python3 build_single.py <녹음 폴더>
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from hfkit import *
X = os.path.dirname(os.path.abspath(__file__))
D = sys.argv[1]
exec(open(X + "/single_parts.py", encoding="utf-8").read())   # tiles · bars · crit · nodes · shades 부품 HTML
scenes_html = eval("f'''" + open(X + "/single_scenes.html", encoding="utf-8").read() + "'''")
scenes_js = open(X + "/single_scenes.js", encoding="utf-8").read()
TITLE = "모티프가 솔라가드 하나만 남긴 이유"
BGW = ["BRANDS", "DECISION", "CRITERIA", "REPURCHASE", "SHADES", "CRAFT", "FOCUS"]
CAP = eval(open(X + "/single_cap.txt", encoding="utf-8").read())
SIZE = {3: 60, 8: 56, 9: 58, 12: 58, 13: 58, 14: 58, 17: 60}
P, TOTAL = build(D, "single", TITLE, BGW, CAP, scenes_html, scenes_js, SIZE, assets=["p1.jpg", "p2.jpg"])
print(P, TOTAL, "errors:", check("single"))
