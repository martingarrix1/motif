// ── 1 후킹 ──
const gN=at(2)-.1; tl.fromTo("#n0 .dg:nth-child(2) .col",{yPercent:0},{keyframes:[{yPercent:0,duration:.25},{yPercent:-80,duration:1.2,ease:"power3.out"},{yPercent:-80,duration:gN-1.45},{yPercent:-10,duration:.9,ease:"power3.inOut"}]},0);
tl.fromTo("#c0 .tile",{opacity:0,scale:.55,y:30},{opacity:1,scale:1,y:0,duration:.5,ease:"back.out(1.8)",stagger:.09},.15);
tl.to("#c0 .tile:not(.solar)",{y:-14,duration:.14,ease:"power1.out",yoyo:true,repeat:5,stagger:.03},at(1));
pop("#p0a",at(1));
tl.fromTo("#p0a",{scale:1},{scale:1.12,duration:.18,yoyo:true,repeat:1,ease:"power1.inOut"},at(1)+.55);
const g=at(2)-.1;
tl.to("#p0a",{opacity:0,duration:.25},g);
[0,1,2,3,4,6,7].forEach((k,n)=>tl.to("#t"+k,{y:70,rotation:(k%2?9:-9),opacity:0,duration:.5,ease:"power2.in"},g+n*.05));

tl.to("#t5",{x:90,y:-110,scale:1.9,duration:.9,ease:"power3.inOut"},g+.25);
tl.to("#t5",{boxShadow:"0 24px 60px rgba(70,80,255,.55)",duration:.5,yoyo:true,repeat:3,ease:"sine.inOut"},g+1.1);
pop("#p0b",g+.9);

// ── 2 사업적 결정 ──
card("#c1a",SC[1]-.25);
tl.to("#c1a .axis",{strokeDashoffset:0,duration:.8,ease:"power2.out"},SC[1]+.1);
tl.fromTo("#c1a .bar",{scaleY:0,transformOrigin:"50% 100%"},{scaleY:1,transformOrigin:"50% 100%",duration:.6,ease:"back.out(1.4)",stagger:.07},SC[1]+.4);
tl.to(["#bar7","#bar6","#bar5","#bar4","#bar3","#bar2","#bar1"],{scaleY:0,transformOrigin:"50% 100%",duration:.4,ease:"power2.in",stagger:.13},at(3,.3));
tl.to("#bar0",{scaleY:1.9,transformOrigin:"50% 100%",duration:.8,ease:"power3.out"},at(3,.3)+1.0);
pop("#p1a",at(3,.6));
swap("#c1a","#c1b",ST[4]-.25);
tl.fromTo("#q1",{opacity:0,scale:.9},{opacity:1,scale:1,duration:.45,ease:E3},ST[4]);
tl.to("#k1",{scaleX:1,duration:.45,ease:"power2.inOut"},at(4,.42));
tl.to("#q1",{scale:.94,duration:.3},at(4,.42)+.3);
inn("#m1",at(4,.68),.6,40); inn("#o1",at(4,.8));

// ── 3 판단 기준 ──
card("#c2a",SC[2]-.25);
count("#n2",0,3,SC[2]+.3,1.4,1,true);
tl.fromTo("#orb",{rotation:0},{rotation:300,duration:ST[6]-SC[2],ease:"none"},SC[2]-.25);
tl.to("#c2a",{opacity:0,scale:.92,duration:.4,ease:"power2.in"},ST[6]-.35);
[[0,at(6,0)],[1,at(6,.5)],[2,at(7,.35)]].forEach(([k,t])=>{
  tl.fromTo("#cr"+k,{opacity:0,x:120},{opacity:1,x:0,duration:.6,ease:E4},t-.25);
  chk("#cr"+k+" .cchk",t+.2);});
tl.to("#cr2",{boxShadow:"0 30px 70px rgba(128,82,242,.35)",duration:.5,ease:"sine.inOut",yoyo:true,repeat:1},at(7,.6));

// ── 4 재구매 ──
card("#c3",SC[3]-.25);
const T4=SC[3]+.3, D4=SD[8]*.72;
tl.to("#tlf",{scaleX:1,duration:D4,ease:"power1.inOut"},T4);
[0,1,2,3].forEach(k=>{const t=T4+D4*[0,.333,.667,1][k];
  tl.to("#nd"+k,{borderColor:"#245cff",scale:1.25,duration:.25,ease:"power2.out"},t);
  tl.to("#nd"+k,{scale:1,duration:.3},t+.25);
  tl.to("#nl"+k,{color:"#16171c",duration:.3},t);});
tl.to("#ar1",{strokeDashoffset:0,duration:.5,ease:"power2.out"},at(8,.5)); pop("#p3a",at(8,.5)+.35);
tl.to("#ar2",{strokeDashoffset:0,duration:.4,ease:"power2.out"},at(8,.72)); pop("#p3b",at(8,.72)+.3);
inn("#m3",at(9,.35),.6,30);

// ── 5 농도 ──
card("#c4",SC[4]-.25);
tl.fromTo("#c4 .chip",{opacity:0,y:80},{opacity:1,y:0,duration:.7,ease:E4,stagger:.12},SC[4]+.2);
tl.fromTo("#c4 .chlab",{opacity:0,y:20},{opacity:1,y:0,duration:.4,ease:E3,stagger:.12},SC[4]+.5);
tl.to("#c4 .glare",{left:"140%",duration:1.1,ease:"power2.inOut",stagger:.12},SC[4]+1.2);
for(let k=0;k<5;k++) chk("#chc"+k,at(10,.55)+k*.12);
tl.fromTo(["#n4","#u4"],{opacity:0},{opacity:1,duration:.3},ST[11]-.2);
count("#n4",0,5,ST[11]-.1,1.0,1,true);
tl.to("#c4 .glare",{left:"-60%",duration:.01},ST[11]-.2);
tl.to("#c4 .glare",{left:"140%",duration:1.0,ease:"power2.inOut",stagger:.1},ST[11]+.2);
tl.to("#c4 .chchk",{opacity:0,duration:.25},at(12,.15));
tl.fromTo("#r4",{opacity:0,y:30},{opacity:1,y:0,duration:.45,ease:E3},at(12,.2));
tl.to("#k4",{scaleX:1,duration:.4,ease:"power2.inOut"},at(12,.4));
tl.to("#aw4",{strokeDashoffset:0,duration:.35},at(12,.5));
tl.fromTo("#p4",{scale:.6,opacity:0},{scale:1,opacity:1,duration:.5,ease:"back.out(2)"},at(12,.6));

// ── 6 집중 · 전문성 ──
card("#c5a",SC[5]-.25);
tl.fromTo("#im5",{scale:1.05},{scale:1.17,duration:ST[14]-SC[5]+.5,ease:"none"},SC[5]-.25);
tl.fromTo("#sh5",{x:0},{x:1700,duration:1.4,ease:"power2.inOut"},SC[5]+.6);
tl.fromTo("#c5a .brow",{opacity:0,x:-40},{opacity:1,x:0,duration:.5,ease:E3,stagger:.3},at(13,.25));
tl.to("#f5a",{scaleX:1,duration:1.4,ease:"power3.out"},at(13,.35));
tl.to("#f5b",{scaleX:1,duration:1.4,ease:"power3.out"},at(13,.62));
swap("#c5a","#c5b",ST[14]-.25);
tl.fromTo("#b5a",{opacity:0,x:-60},{opacity:1,x:0,duration:.5,ease:E3},ST[14]);
tl.fromTo("#e5",{opacity:0,scale:.5},{opacity:1,scale:1,duration:.4,ease:"back.out(2)"},at(14,.25));
tl.fromTo("#b5b",{opacity:0,x:60},{opacity:1,x:0,duration:.5,ease:E3},at(14,.4));
tl.to("#sl5",{scaleY:1,duration:.35,ease:"power3.out"},at(14,.6));
tl.to("#b5b",{x:12,duration:.07,yoyo:true,repeat:3},at(14,.6)+.3);
inn("#o5",at(14,.72));

// ── 7 제 차 · 가족 · 책임 ──
card("#c6a",SC[6]-.25);
tl.fromTo("#im6",{scale:1.04},{scale:1.16,duration:ST[17]-SC[6]+.5,ease:"none"},SC[6]-.25);
tl.fromTo("#sh6",{x:0},{x:1700,duration:1.4,ease:"power2.inOut"},SC[6]+.7);
pop("#p6a",at(15,0)); pop("#p6b",at(15,.38));
tl.fromTo("#tg6",{opacity:0,x:-30},{opacity:1,x:0,duration:.45,ease:E3},at(16,.15));
swap("#c6a","#c6b",ST[17]-.25);
tl.to("#ax6",{strokeDashoffset:0,duration:.7,ease:"power2.out"},ST[17]);
tl.fromTo("#v6a",{scaleY:0},{scaleY:.85,duration:.6,ease:E3},ST[17]+.1);
tl.fromTo("#v6b",{scaleY:0},{scaleY:.25,duration:.6,ease:E3},ST[17]+.2);
tl.to("#v6a",{scaleY:.18,duration:1.6,ease:"power2.inOut"},ST[17]+.9);
tl.to("#v6b",{scaleY:.95,duration:1.6,ease:"power2.inOut"},ST[17]+.9);
pop("#p6c",at(18,.1));
tl.to("#v6b",{boxShadow:"0 20px 60px rgba(70,80,255,.6)",duration:.5,yoyo:true,repeat:3,ease:"sine.inOut"},at(18,.2));

