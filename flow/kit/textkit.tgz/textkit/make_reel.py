#!/usr/bin/env python3
"""MOTIF 릴스 한 번에 만들기 (키트 v2)

사용:
  python3 make_reel.py plan   <작업폴더>        # script.txt + 사진 → job.json (제미나이가 장면 부품 배치)
  python3 make_reel.py voice  <작업폴더>        # 일레븐랩스 B 녹음(문장별) + 제미나이 검수
  python3 make_reel.py stills <작업폴더>        # 장면 7개 끝 모습 한 장(sheet.jpg)으로 점검
  python3 make_reel.py render <작업폴더>        # 최종 mp4 (피아노 자동 선택·믹싱 포함)
  python3 make_reel.py check  <작업폴더>        # 자동 점검(겹침·작은 글씨·제목 넘침) + 걸린 장면만 제미나이가 다시 짬
  python3 make_reel.py all    <작업폴더>        # (plan) → voice(검수·자동 재녹음) → check → stills → render 한 번에
  옵션: --redo 3,7  (해당 문장 번호만 다시 녹음, 1부터)   --nocheck (제미나이 검수 생략)

작업폴더:
  script.txt  대사. 장면 사이는 빈 줄, 한 줄 = 한 문장. (마틴 승인본 그대로)
  사진 파일들 (jpg/png)
  job.json    plan 이 만들고, 필요하면 Claude가 고친다
키: ~/.eleven/key, ~/.gemini/key (motif-api-keys 스킬이 드라이브에서 넣어 줌)
"""
import sys, os, json, re, glob, hashlib, subprocess, base64, random, time, urllib.request, urllib.error, shutil

KIT = os.path.dirname(os.path.abspath(__file__))
VOICE_B = os.environ.get("MOTIF_VOICE_ID") or "5WQiuyr3CgBT8RI5vL9r"
VOICE_SETTINGS = json.loads(os.environ["MOTIF_VOICE_SETTINGS"]) if os.environ.get("MOTIF_VOICE_SETTINGS") else {"stability": 0.6, "similarity_boost": 1.0, "style": 0.0, "use_speaker_boost": True, "speed": 0.9}
GAP_SENT, GAP_SCENE = 0.4, 0.75
GAP_SIGN = 1.4   # 마무리 멘트 앞 쉼(2026-11-22 마틴: 한 박자 쉬어야 여운이 있다)
def tail(job): return 5.5 if job.get("logo") == "motif" else 4.0
FPS = 30

def key(name):
    p = os.path.expanduser({"eleven": "~/.eleven/key", "gemini": "~/.gemini/key"}[name])
    if not os.path.exists(p):
        sys.exit(f"[키 없음] {p} — motif-api-keys 스킬로 드라이브에서 키를 불러오세요")
    return open(p).read().strip()

def sh(cmd):
    subprocess.run(cmd, check=True)

def dur(f):
    return float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", f],
                                capture_output=True, text=True).stdout.strip())

def read_script(d):
    raw = open(os.path.join(d, "script.txt"), encoding="utf-8").read().strip()
    scenes = [[l.strip() for l in blk.split("\n") if l.strip()] for blk in re.split(r"\n\s*\n", raw)]
    sents, groups = [], []
    for sc in scenes:
        groups.append(list(range(len(sents), len(sents) + len(sc))))
        sents += sc
    return sents, groups

def gemini(parts, model="gemini-3.8-flash", timeout=600):
    body = {"contents": [{"role": "user", "parts": parts}]}
    req = urllib.request.Request(f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent",
                                 data=json.dumps(body).encode(),
                                 headers={"x-goog-api-key": key("gemini"), "Content-Type": "application/json"})
    r = json.load(urllib.request.urlopen(req, timeout=timeout))
    return "".join(p.get("text", "") for p in r["candidates"][0]["content"]["parts"] if not p.get("thought")).strip()

# ---------------- plan ----------------
GEN = re.compile(r"^(sheet|ec|_|chk|frame|motif_reel_)", re.I)
def list_photos(d):
    return sorted(os.path.basename(p) for p in glob.glob(os.path.join(d, "*"))
                  if p.lower().endswith((".jpg", ".jpeg", ".png")) and not GEN.match(os.path.basename(p)))
def cmd_plan(d):
    sents, groups = read_script(d)
    photos = list_photos(d)
    spec = open(os.path.join(KIT, "scene/PARTS_SPEC.md"), encoding="utf-8").read()
    hist_f = os.path.join(KIT, "history.json")
    hist = json.load(open(hist_f)) if os.path.exists(hist_f) else []
    recent = [p for h in hist[-3:] for p in h.get("parts", [])]
    scen_txt = "\n".join(f"장면{i+1}: " + " / ".join(sents[j] for j in g) for i, g in enumerate(groups))
    q = f"""너는 MOTIF(전주 썬팅 전문점) 릴스 화면 연출가다. 아래 대사의 각 장면에 맞는 화면 부품을 골라 JSON으로만 답하라(설명·``` 없이).
[부품 명세]
{spec}
[대사]
{scen_txt}
[사용 가능한 사진 파일] {photos}
[최근 릴스에서 쓴 부품 — 가능하면 피하라] {recent}
[마틴 스타일]
{open(os.path.join(KIT,"scene/STYLE.md"),encoding="utf-8").read()}
규칙:
- 제목 두 줄은 각 6~12자. ~요로 끝내지 말 것(릴스 금지). "갈립니다"→"달라집니다", "튕겨"→"반사". 수치를 의인화하지 말 것.
- 부품 안 글자는 짧게: 항목 2~3개, 설명은 18자 이내. 작은 글씨가 많아지는 부품은 피한다.
- 대사에 숫자가 있으면 숫자 부품(count_up·odometer·before_after_num 등)으로 0부터 올라가게. "XX" 같은 자리표시 금지.
- "전주 모티프였습니다" 같은 브랜드 마무리 문장이 든 장면은 그 문장 앞까지의 내용으로 연출한다(엔드카드가 따로 뜬다).
- 장면마다 하나: {{"tag":"영문 대문자 짧게","title":["첫 줄 6~10자","둘째 줄(파랑) 6~12자"],"part":"부품이름","params":{{...}}}}
- 제목은 대사 핵심을 짧게. 대사에 없는 수치·주장 금지. 필름을 유리라고 쓰지 말 것.
- 같은 부품을 한 릴스에서 두 번 쓰지 말 것. 사진 부품은 사진이 있을 때만, 사진은 골고루.
- badge 부품의 로고는 대사 속 제품과 맞게: THE LX가 아니면 thelx·lxsg 로고 금지(솔라가드 프리미엄 다른 라인업은 "solargard", 매장 소개는 "motif").
- 큰 글씨 부품(big_word 등)의 단어는 8자 이내로, 줄바꿈되지 않게.
- 사진은 [사용 가능한 사진 파일]에 있는 이름만. 목록이 비었으면 사진 부품을 쓰지 말 것.
- quote_block·typewriter에 대사를 옮길 때는 대사 문장을 그대로(어미까지) 쓴다.
- 첫 장면은 후킹: 사진이 있으면 사진 부품, 마지막 장면은 quote_block 또는 big_word로 여운.
- params 문자열에 [[강조]] ((회색)) ~~취소선~~ 사용 가능.
출력 형식: {{"product":"제품명(엔드카드용, 예: 솔라가드 프리미엄 [[S라인]])","scenes":[...]}}"""
    txt = gemini([{"text": q}], model="gemini-pro-latest", timeout=900)
    txt = txt[txt.find("{"): txt.rfind("}") + 1]
    plan = json.loads(txt)
    rnd = random.Random(hashlib.md5(open(os.path.join(d, "script.txt"), "rb").read()).hexdigest())
    for i, sc in enumerate(plan["scenes"]):
        sc["sentences"] = groups[i] if i < len(groups) else []
        sc.setdefault("variant", {"layout": rnd.randint(0, 2), "motion": rnd.randint(0, 2), "accent": rnd.randint(0, 2)})
    logo = "motif" if any(re.search("모티프.*였습니다", x) for x in sents) else "thelx"
    job = {"name": os.path.basename(os.path.abspath(d)), "logo": logo, "piano": "auto", "product": plan.get("product", ""), "scenes": plan["scenes"]}
    jf = os.path.join(d, "job.json")
    if os.path.exists(jf):  # 기존 설정 유지
        old = json.load(open(jf)); job["piano"] = old.get("piano", "auto")
        if old.get("logo_fixed"): job["logo"] = old["logo"]
    json.dump(job, open(jf, "w"), ensure_ascii=False, indent=1)
    for i, sc in enumerate(job["scenes"]):
        print(f"{i+1}. [{sc['part']}] {sc.get('tag','')} | {' / '.join(sc.get('title',[]))}")
    print("→ job.json 저장")

# ---------------- voice ----------------
def tts(text, prev, nxt, out, seed=None):
    body = {"text": text, "model_id": "eleven_multilingual_v2", "language_code": "ko", "voice_settings": VOICE_SETTINGS,
            "previous_text": prev, "next_text": nxt}
    if seed is not None: body["seed"] = seed
    req = urllib.request.Request(f"https://api.elevenlabs.io/v1/text-to-speech/{VOICE_B}?output_format=mp3_44100_128",
                                 data=json.dumps(body).encode(), headers={"xi-api-key": key("eleven"), "Content-Type": "application/json"})
    for a in range(3):
        try:
            open(out, "wb").write(urllib.request.urlopen(req, timeout=120).read()); return
        except urllib.error.HTTPError as e:
            if a == 2: sys.exit(f"[일레븐랩스 오류] {e.code} {e.read()[:300]}")
            time.sleep(2)

def trim(src, dst):
    # 앞뒤 무음 제거
    sh(["ffmpeg", "-y", "-loglevel", "error", "-i", src, "-af",
        "silenceremove=start_periods=1:start_threshold=-45dB,areverse,silenceremove=start_periods=1:start_threshold=-45dB,areverse,aresample=44100",
        "-ac", "1", dst])

def say_forms(d, sents):
    """화면용 문장 → 읽기용 문장(숫자·영문을 한글 읽기로). vo/say.json에 저장, 손으로 고쳐도 된다."""
    f = os.path.join(d, "vo", "say.json")
    m = json.load(open(f)) if os.path.exists(f) else {}
    need = [x for x in sents if x not in m]
    if need:
        q = ("다음 한국어 문장들을 성우가 읽을 형태로 바꿔라. 숫자·단위·영문 약어·브랜드만 한글 읽기로 바꾸고 나머지 글자는 그대로 둔다. "
             "예: 3년→삼 년, 10만 원→십만 원, 99.9%→구십구 점 구 퍼센트, S라인→에스라인, LX→엘엑스, THE LX→더 엘엑스, TSER→티에스이알, IR→아이알, nm→나노미터, PPF→피피에프. "
             "JSON 배열로만 답하라(입력과 같은 순서·개수).\n" + json.dumps(need, ensure_ascii=False))
        try:
            t = gemini([{"text": q}], model="gemini-flash-latest"); out = json.loads(t[t.find("["): t.rfind("]") + 1])
            if len(out) == len(need): m.update(dict(zip(need, out)))
        except Exception as e: print("[읽기 변환 실패, 원문으로 녹음]", e)
        json.dump(m, open(f, "w"), ensure_ascii=False, indent=1)
    return [m.get(x, x) for x in sents]

def voice_check(d, sents, says):
    q = ("한국어 남성 내레이션이다. 아래 번호 문장이 순서대로 녹음되어 있다. 실제로 들은 것만 근거로, 다시 녹음해야 할 문장(다른 단어, 빠진 말, 틀린 발음, 끝이 잘림, 잡음)의 번호만 골라 "
         'JSON으로만 답하라: {"redo":[번호...],"why":["번호: 이유 한 줄"]}. 문제 없으면 {"redo":[],"why":[]}.\n' +
         "\n".join(f"{i+1}. {x}" for i, x in enumerate(says)))
    sh(["ffmpeg", "-y", "-loglevel", "error", "-i", f"{d}/voice.wav", "-b:a", "64k", f"{d}/_chk.mp3"])
    data = base64.b64encode(open(f"{d}/_chk.mp3", "rb").read()).decode()
    t = gemini([{"inline_data": {"mime_type": "audio/mp3", "data": data}}, {"text": q}], model="gemini-flash-latest")
    r = json.loads(t[t.find("{"): t.rfind("}") + 1]); return [int(x) for x in r.get("redo", []) if 1 <= int(x) <= len(sents)], r.get("why", [])

def cmd_voice(d, redo=(), check=True, _round=0):
    sents, groups = read_script(d)
    vd = os.path.join(d, "vo"); os.makedirs(vd, exist_ok=True)
    says = say_forms(d, sents)
    for i, s in enumerate(says):
        h = hashlib.md5(s.encode()).hexdigest()[:8]
        raw, cut = f"{vd}/s{i+1:02d}_{h}.mp3", f"{vd}/s{i+1:02d}.wav"
        if (i + 1) in redo:
            for f in glob.glob(f"{vd}/s{i+1:02d}_*.mp3"): os.remove(f)
        if not os.path.exists(raw):
            for f_ in glob.glob(f"{vd}/s{i+1:02d}_*.mp3"): os.remove(f_)
            tts(s, says[i-1] if i else "", says[i+1] if i + 1 < len(says) else "", raw,
                seed=random.randint(1, 10**6) if (i + 1) in redo else None)
            trim(raw, cut)
        elif not os.path.exists(cut) or os.path.getmtime(cut) < os.path.getmtime(raw):
            trim(raw, cut)
    # 이어 붙이기 + 시각 계산
    scene_of = {j: gi for gi, g in enumerate(groups) for j in g}
    lst, t, starts = [], 0.0, []
    sil = {}
    for g in (GAP_SENT, GAP_SCENE, GAP_SIGN):
        f = f"{vd}/sil_{g}.wav"
        sh(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "anullsrc=r=44100:cl=mono", "-t", str(g), f]); sil[g] = f
    for i in range(len(sents)):
        starts.append(round(t, 3)); f = f"{vd}/s{i+1:02d}.wav"; lst.append(f); t += dur(f)
        if i + 1 < len(sents):
            g = GAP_SCENE if scene_of[i + 1] != scene_of[i] else GAP_SENT
            if re.search("모티프.*였습니다", sents[i + 1]): g = GAP_SIGN   # 마지막 질문 뒤 한 박자 쉬고 마무리 멘트(여운)
            lst.append(sil[g]); t += g
    with open(f"{vd}/list.txt", "w") as fh:
        for f in lst: fh.write(f"file '{os.path.abspath(f)}'\n")
    sh(["ffmpeg", "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", f"{vd}/list.txt", "-ar", "44100", "-ac", "1", f"{d}/voice.wav"])
    total = dur(f"{d}/voice.wav")
    json.dump({"sent_starts": starts, "voice_len": total, "groups": groups, "sent_durs": [round(dur(f"{vd}/s{i+1:02d}.wav"), 3) for i in range(len(sents))],
               "scene_starts": [starts[g[0]] for g in groups], "sentences": sents}, open(f"{d}/timing.json", "w"), ensure_ascii=False)
    print(f"녹음 완료: {total:.1f}초")
    if check:
        try:
            bad, why = voice_check(d, sents, says)
        except Exception as e:
            print("[제미나이 검수 실패]", e); return
        if bad and _round < 2:
            print(f"[검수] 다시 녹음: {bad} — " + " / ".join(why)); return cmd_voice(d, set(bad), True, _round + 1)
        print("[검수] 문제 없음" if not bad else "[검수] 남은 문제: " + " / ".join(why))

# ---------------- piano ----------------
def pick_piano(kind, length, out):
    rot_f = os.path.join(KIT, "piano/rotation.json")
    rot = json.load(open(rot_f)) if os.path.exists(rot_f) else {}
    kinds = ["calm", "grand"] if kind == "auto" else [kind]
    files = sorted(f for k in kinds for f in glob.glob(os.path.join(KIT, f"piano/{k}_*.mp3")))
    if not files: return None
    rr = random.Random(time.time())
    f = min(files, key=lambda x: rot.get(os.path.basename(x), rr.random()))  # 가장 오래 안 쓴 곡(새 작업 공간이면 무작위)
    rot[os.path.basename(f)] = time.time(); json.dump(rot, open(rot_f, "w"), indent=1)
    L = dur(f)
    loop = ["-stream_loop", "-1"] if L < length else []
    sh(["ffmpeg", "-y", "-loglevel", "error", *loop, "-i", f, "-t", str(length),
        "-af", f"afade=t=in:d=1.2,afade=t=out:st={length-3}:d=3", "-ar", "48000", "-ac", "2", out])
    return os.path.basename(f)

# ---------------- html / render ----------------
def absify(v, d):
    if isinstance(v, dict): return {k: absify(x, d) for k, x in v.items()}
    if isinstance(v, list): return [absify(x, d) for x in v]
    if isinstance(v, str) and v.lower().endswith((".jpg", ".jpeg", ".png")) and os.path.exists(os.path.join(d, v)):
        return "file://" + os.path.abspath(os.path.join(d, v))
    return v

def build_html(d, job, timing, duration):
    starts = timing["scene_starts"] + [duration]
    scenes = []
    for i, sc in enumerate(job["scenes"]):
        scenes.append({"start": starts[i], "end": starts[i + 1], "tag": sc.get("tag", ""), "title": sc.get("title", ["", ""]),
                       "part": sc["part"], "params": absify(sc.get("params", {}), d), "variant": sc.get("variant", {})})
    subs = [{"t": t, "text": s} for t, s in zip(timing["sent_starts"], timing["sentences"])]
    sents = timing["sentences"]; lg = job.get("logo", "thelx")
    bi = next((i for i, x in enumerate(sents) if re.search("모티프.*였습니다", x)), None)
    if lg == "motif":
        ec = {"start": (timing["sent_starts"][bi] - 0.2) if bi is not None else timing["voice_len"] + 0.4, "logo": "motif",
              "product": job.get("product", ""), "address": "전주 덕진구 정여립로 1104 · 010-4814-4506"}
    elif lg == "none": ec = {"start": timing["voice_len"] + 0.4, "q": sents[-1]}
    else: ec = {"start": timing["voice_len"] + 0.4, "q": sents[-1], "logo": "lxsg", "product": job.get("product", "")}
    if bi is not None: subs = [x for x in subs if not re.search("모티프.*였습니다", x["text"])]
    reel = {"duration": duration, "logo": lg, "scenes": scenes, "subs": subs, "endcard": ec}
    parts = "".join(f'<script src="scene/parts/{os.path.basename(p)}"></script>' for p in sorted(glob.glob(os.path.join(KIT, "scene/parts/*.js"))))
    html = (f'<!DOCTYPE html><html><head><meta charset="utf-8"><base href="file://{KIT}/"></head><body>'
            f'<script>window.REEL={json.dumps(reel, ensure_ascii=False)};</script><script src="scene/engine.js"></script>{parts}'
            f'<script>seek(0)</script></body></html>')
    open(os.path.join(d, "reel.html"), "w", encoding="utf-8").write(html)
    return scenes

def shoot(d, times, outdir):
    import asyncio
    from playwright.async_api import async_playwright
    os.makedirs(outdir, exist_ok=True)
    async def main():
        async with async_playwright() as p:
            chrome = shutil.which("google-chrome") or shutil.which("chromium")
            b = await p.chromium.launch(executable_path=chrome, args=["--no-sandbox", "--allow-file-access-from-files"]) if chrome else await p.chromium.launch()
            pg = await b.new_page(viewport={"width": 1080, "height": 1920})
            errs = []; pg.on("pageerror", lambda e: errs.append(str(e)[:200]))
            await pg.goto("file://" + os.path.abspath(os.path.join(d, "reel.html"))); await pg.wait_for_timeout(800)
            for i, t in enumerate(times):
                await pg.evaluate(f"seek({t})"); await pg.screenshot(path=f"{outdir}/{i:05d}.jpg", type="jpeg", quality=90)
            await b.close()
            if errs: print("[화면 오류]", errs[:5])
    asyncio.run(main())

def fake_timing(d):
    sents, groups = read_script(d)
    t, starts = 0.0, []
    for i, s in enumerate(sents): starts.append(t); t += max(2.5, len(s) * 0.17) + GAP_SENT
    return {"sent_starts": starts, "voice_len": t, "scene_starts": [starts[g[0]] for g in groups], "sentences": sents}

def cmd_stills(d):
    job = json.load(open(os.path.join(d, "job.json")))
    tf = os.path.join(d, "timing.json")
    timing = json.load(open(tf)) if os.path.exists(tf) else fake_timing(d)
    duration = timing["voice_len"] + tail(job)
    scenes = build_html(d, job, timing, duration)
    times = [min(sc["end"] - 0.4, sc["start"] + 6) for sc in scenes]
    shoot(d, times, os.path.join(d, "_stills"))
    from PIL import Image
    ims = [Image.open(f"{d}/_stills/{i:05d}.jpg").resize((360, 640)) for i in range(len(times))]
    sheet = Image.new("RGB", (360 * len(ims), 640), "white")
    for i, im in enumerate(ims): sheet.paste(im, (i * 360, 0))
    sheet.save(os.path.join(d, "sheet.jpg"), quality=85)
    print("→ sheet.jpg (장면 끝 모습)")

def check_scenes(d, job, timing, duration):
    import asyncio
    from playwright.async_api import async_playwright
    scenes = build_html(d, job, timing, duration)
    async def main():
        async with async_playwright() as p:
            chrome = shutil.which("google-chrome") or shutil.which("chromium")
            b = await p.chromium.launch(executable_path=chrome, args=["--no-sandbox", "--allow-file-access-from-files"]) if chrome else await p.chromium.launch()
            pg = await b.new_page(viewport={"width": 1080, "height": 1920})
            errs = []; pg.on("pageerror", lambda e: errs.append(str(e)[:200]))
            await pg.goto("file://" + os.path.abspath(os.path.join(d, "reel.html"))); await pg.wait_for_timeout(800)
            res = {}
            for i, sc in enumerate(scenes):
                await pg.evaluate(f"seek({min(sc['end'] - 0.4, sc['start'] + 6)})")
                iss = await pg.evaluate(f"checkScene({i})")
                if iss: res[i] = iss
            await b.close()
            if errs: res[-1] = ["화면 스크립트 오류: " + e for e in errs[:3]]
            return res
    return asyncio.run(main())

def cmd_check(d, fix=True):
    """장면마다 겹침·작은 글씨·제목 넘침·~요 제목·부품 오류를 자동 점검하고, 걸린 장면만 제미나이에게 다시 짜게 한다(최대 2번)."""
    job = json.load(open(os.path.join(d, "job.json")))
    tf = os.path.join(d, "timing.json"); timing = json.load(open(tf)) if os.path.exists(tf) else fake_timing(d)
    duration = timing["voice_len"] + tail(job)
    for rnd in range(3):
        res = check_scenes(d, job, timing, duration)
        if not res: print("[자동 점검] 문제 없음"); return {}
        print(f"[자동 점검 {rnd+1}] " + " | ".join(f"{k+1}장면: {', '.join(v)}" for k, v in res.items()))
        if not fix or rnd == 2 or -1 in res: return res
        sents, groups = read_script(d); spec = open(os.path.join(KIT, "scene/PARTS_SPEC.md"), encoding="utf-8").read()
        used = [s_["part"] for s_ in job["scenes"]]
        q = (f"MOTIF 릴스 장면 JSON 일부를 고쳐라. 아래 문제가 있는 장면만 다시 만들어 JSON으로만 답하라: {{\"fix\":{{\"장면번호\":{{장면 객체}}}}}}\n"
             f"[부품 명세]\n{spec}\n[마틴 스타일]\n{open(os.path.join(KIT,'scene/STYLE.md'),encoding='utf-8').read()}\n"
             f"[이미 쓴 부품 — 겹치지 않게] {used}\n"
             + "\n".join(f"장면{k+1} 대사: {' / '.join(sents[j] for j in groups[k])}\n현재: {json.dumps(job['scenes'][k], ensure_ascii=False)}\n문제: {', '.join(v)}" for k, v in res.items()))
        try:
            t = gemini([{"text": q}], model="gemini-pro-latest", timeout=900); fx = json.loads(t[t.find("{"): t.rfind("}") + 1])["fix"]
            for k, v in fx.items():
                k = int(k) - 1; v["sentences"] = job["scenes"][k]["sentences"]; v.setdefault("variant", job["scenes"][k].get("variant", {})); job["scenes"][k] = v
            json.dump(job, open(os.path.join(d, "job.json"), "w"), ensure_ascii=False, indent=1)
        except Exception as e:
            print("[자동 수정 실패]", e); return res
    return res

def cmd_render(d):
    job = json.load(open(os.path.join(d, "job.json")))
    timing = json.load(open(os.path.join(d, "timing.json")))
    duration = round(timing["voice_len"] + tail(job), 2)
    build_html(d, job, timing, duration)
    fr = os.path.join(d, "_frames"); shutil.rmtree(fr, ignore_errors=True)
    t0 = time.time()
    shoot(d, [i / FPS for i in range(int(duration * FPS))], fr)
    print(f"화면 {time.time()-t0:.0f}초")
    piano = pick_piano(job.get("piano", "auto"), duration, os.path.join(d, "piano.wav"))
    out = os.path.join(d, f"motif_reel_{job['name']}.mp4")
    if piano:
        fc = (f"[0:a]aresample=48000,aformat=channel_layouts=stereo,loudnorm=I=-17:TP=-2,apad=whole_dur={duration},asplit=2[v][sc];"
              f"[1:a]loudnorm=I=-22:TP=-3[p];[p][sc]sidechaincompress=threshold=0.02:ratio=4:attack=30:release=600[pd];"
              f"[v][pd]amix=inputs=2:duration=first:normalize=0,loudnorm=I=-16:TP=-1.5[a]")
        sh(["ffmpeg", "-y", "-loglevel", "error", "-i", f"{d}/voice.wav", "-i", f"{d}/piano.wav", "-filter_complex", fc, "-map", "[a]", "-t", str(duration), f"{d}/mix.wav"])
    else:
        sh(["ffmpeg", "-y", "-loglevel", "error", "-i", f"{d}/voice.wav", "-af", f"apad=whole_dur={duration},loudnorm=I=-16:TP=-1.5", "-ar", "48000", "-ac", "2", f"{d}/mix.wav"])
    sh(["ffmpeg", "-y", "-loglevel", "error", "-framerate", str(FPS), "-i", f"{fr}/%05d.jpg", "-i", f"{d}/mix.wav",
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "18", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k", "-shortest", out])
    shutil.rmtree(fr, ignore_errors=True)
    hist_f = os.path.join(KIT, "history.json")
    hist = json.load(open(hist_f)) if os.path.exists(hist_f) else []
    hist.append({"name": job["name"], "parts": [s["part"] for s in job["scenes"]], "piano": piano, "time": time.strftime("%Y-%m-%d %H:%M")})
    json.dump(hist[-30:], open(hist_f, "w"), ensure_ascii=False, indent=1)
    print(f"완성: {out} ({duration:.1f}초, 피아노 {piano})")

if __name__ == "__main__":
    a = sys.argv[1:]
    if len(a) < 2: sys.exit(__doc__)
    cmd, d = a[0], a[1]
    redo = set()
    if "--redo" in a: redo = {int(x) for x in a[a.index("--redo") + 1].split(",")}
    check = "--nocheck" not in a
    if cmd == "plan": cmd_plan(d)
    elif cmd == "voice": cmd_voice(d, redo, check)
    elif cmd == "stills": cmd_stills(d)
    elif cmd == "render": cmd_render(d)
    elif cmd == "check": cmd_check(d)
    elif cmd == "all":
        if not os.path.exists(os.path.join(d, "job.json")): cmd_plan(d)
        cmd_voice(d, redo, check); cmd_check(d); cmd_stills(d); cmd_render(d)
    else: sys.exit(__doc__)
