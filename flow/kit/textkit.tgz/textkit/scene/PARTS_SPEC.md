# MOTIF 화면 부품 명세 (부품 30개)

각 부품은 장면 가운데 영역(920x760px, area 요소 안)에 그린다. 헤드라인·태그·자막·로고는 엔진이 그리므로 부품은 그리지 않는다.
사진 경로는 params 안의 파일 이름(예: "car_front.jpg") 그대로 img src로 쓴다.
문자열 안의 [[단어]] 파랑 강조, ((단어)) 회색, ~~단어~~ 빨간 취소선 → E.rich(문자열)로 변환해 innerHTML에 넣는다.
variant = {layout:0|1|2, motion:0|1|2, accent:0|1|2} — 같은 부품도 배치·등장 모션·강조 방식이 달라지게 한다.
  motion 0: 아래에서 떠오름(E.rise) / 1: 마스크 드러남(E.reveal) / 2: 살짝 확대되며 페이드(scale .94→1)
  accent 0: 파란 글자 / 1: 파란 밑줄이 그어짐 / 2: 옅은 파란 배경 상자(#E8EEFF)
등장 타이밍은 params.at(배열, 초, 장면 시작 기준)이 있으면 그 시각에, 없으면 0.5초부터 0.35초 간격으로 순서대로.

## 숫자
1. count_up — {label, value, unit:"%", from:0, decimals:0, caption, at:[]} 아주 큰 숫자(파랑 220px+) 카운트업, 위에 라벨, 아래 캡션
2. ring_gauge — {value(0~100), label, caption} 원형 링 게이지가 차오르며 가운데 숫자
3. half_gauge — {value(0~100), min_label, max_label, label} 반원 게이지 + 바늘
4. odometer — {value(정수 또는 소수 문자열), unit, label} 자리마다 숫자가 롤러처럼 굴러 멈춤
5. before_after_num — {before:{label,value,unit}, after:{label,value,unit}, arrow_text} 왼쪽 회색 숫자 → 화살표 → 오른쪽 파란 숫자

## 그래프
6. hbar — {items:[{label,value,display,highlight:bool}], max, caption} 가로 막대 2~5개 차오름(값 비례), 막대 오른쪽에 display 글씨(진하게, 막대 밖)
7. vbar — {items:[{label,value,display,highlight}], max, caption} 세로 막대
8. line_trend — {points:[숫자...], labels:[...], unit, caption, highlight_index} 선이 그려지며 점 표시
9. percent_grid — {value(0~100), label, caption} 10x10 칸이 value 칸만큼 파랗게 차오름
10. film_compare — {left:{name,specs:[[k,v],...]}, right:{name,specs:[[k,v],...]}, winner:"left"|"right"} 두 필름 사양 카드 나란히, winner 쪽 파란 테두리

## 글자
11. big_word — {word, sub} 화면 가운데 큰 단어 하나가 위에서 떨어져 멈춤(살짝 튕김 없이 부드럽게), 아래 작은 문장
12. typewriter — {text, caption} 한 글자씩 타이핑, 커서 깜빡임(시간 기반)
13. strike_correct — {wrong, right, prefix} "prefix = wrong(빨간 취소선 그어짐) → right(파랑)" 
14. qa_split — {q, a} 위 카드 질문(회색 Q), 아래 카드 답(파랑 A)
15. quote_block — {text, by} 파란 왼쪽 막대 인용 블록, 큰 글씨 여러 줄(\n 줄바꿈)

## 사진
16. photo_zoom — {src, caption, labels:[{text, x%, y%}]} 큰 사진 카드 느린 켄번스 줌(1.0→1.08), 선택 라벨 핀
17. photo_pair — {left:{src,label}, right:{src,label}, caption} 사진 두 장 나란히
18. photo_slider — {before:{src,label}, after:{src,label}} 전후 비교 슬라이더가 왼→오 움직임
19. photo_hotspots — {src, spots:[{x%,y%,text}]} 사진 위 점이 차례로 맥동하며 말풍선 라벨
20. photo_stack — {srcs:[3장], caption} 카드 3장이 겹쳐 쌓였다가 부채처럼 펼쳐짐

## 구조
21. num_list — {items:[{title, desc}]} 번호 원 + 제목 + 회색 설명 카드 2~4개 차례로
22. checklist — {items:[문자열]} 체크 표시가 그려지며 항목 등장
23. timeline — {steps:[{title, desc}]} 세로 타임라인, 점과 선이 이어지며 단계 등장
24. icon_triple — {items:[{icon:"sun"|"car"|"shield"|"eye"|"thermo"|"moon"|"suv"|"sedan"|"compact", label, value, bar(0~1)}]} 3칸, 아이콘은 SVG로 직접 그림, 아래 막대
25. package_card — {name, items:[문자열], price, badge} 패키지 카드(배지, 항목 목록, 가격)

## 도식
26. sun_reflect — {reflect, absorb, transmit, labels:{reflect,absorb,transmit}} 햇빛 화살표가 필름에 닿아 반사·흡수·투과로 나뉨(SVG), 각 % 표시
27. glass_layers — {layers:[{name,desc}]} 유리 단면 위로 필름 층이 하나씩 쌓임(옆에서 본 단면)
28. night_view — {left:{label,dark(0~1)}, right:{label,dark}} 밤 도로 시야 두 칸, 어둡기 차이(그라데이션 도로·가로등 점 SVG)
29. spec_table — {rows:[[항목,값],...], highlight_row} 표가 줄 단위로 나타남, 강조 행 파랑
30. badge — {logo:"thelx"|"lxsg"|"solargard"|"motif", line1, line2} 인증 배지: 로고(brand/ 폴더 PNG, 흰 판 없이) + 두 줄 문구, 얇은 파란 테두리가 그려짐
