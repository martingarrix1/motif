/* MOTIF 릴스 화면 엔진 v2
   - 1080x1920, window.seek(t)로 프레임 단위 렌더링
   - 공통: 진행 바, 페이지 번호, 태그+헤드라인, 자막, 하단 로고, 장면 전환
   - 장면 안의 시각 요소는 parts/*.js 의 PARTS[이름] 이 그린다
   설정은 window.REEL 로 들어온다 (make_reel.py 가 주입)
   REEL = { duration, logo:'thelx'|'lxsg'|'motif'|'none', scenes:[{start,end,tag,title:[l1,l2],part,params,variant}], subs:[{t,text}] }
*/
(function(){
const W=1080,H=1920;
const C={bg:'#F6F5F1',ink:'#111111',blue:'#1F5BFF',gray:'#8A8A8A',line:'#E4E2DC',card:'#FFFFFF',red:'#E5484D'};
const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x));
const easeOut=x=>1-Math.pow(1-clamp(x),3);
const easeInOut=x=>{x=clamp(x);return x<.5?4*x*x*x:1-Math.pow(-2*x+2,3)/2};
// p(lt, start, dur): 0..1 진행도 (easeOut)
const p=(lt,s,d=0.6)=>easeOut((lt-s)/d);
function el(tag,cls,parent,html){const e=document.createElement(tag);if(cls)e.className=cls;if(html!=null)e.innerHTML=html;if(parent)parent.appendChild(e);return e;}
// 아래에서 떠오르며 나타나기
function rise(e,k,dist=40){e.style.opacity=k;e.style.transform=`translateY(${(1-k)*dist}px)`;}
// 마스크로 드러나기(왼→오)
function reveal(e,k){e.style.clipPath=`inset(0 ${(1-k)*100}% 0 0)`;}
function fmtNum(v,dec=0){return dec?v.toFixed(dec):Math.round(v).toLocaleString('ko-KR');}
// 강조 문법: 문장 안의 [[단어]] 는 파란 강조, ((단어)) 는 회색 약화, ~~단어~~ 는 빨간 취소선
function rich(s){return String(s).replace(/\[\[(.+?)\]\]/g,'<span class="hl">$1</span>').replace(/\(\((.+?)\)\)/g,'<span class="dim">$1</span>').replace(/~~(.+?)~~/g,'<span class="strike">$1</span>');}
window.E={W,H,C,clamp,easeOut,easeInOut,p,el,rise,reveal,fmtNum,rich,
  AREA:{x:80,y:660,w:920,h:760}};  // 부품이 그릴 영역(가운데)

const css=`
*{box-sizing:border-box;margin:0;padding:0}
html,body{width:${W}px;height:${H}px;overflow:hidden;background:${C.bg};font-family:"Noto Sans CJK KR","Noto Sans KR",sans-serif;color:${C.ink};-webkit-font-smoothing:antialiased}
#stage{position:absolute;inset:0}
#bar{position:absolute;left:0;top:0;height:6px;background:${C.blue}}
#page{position:absolute;right:80px;top:110px;font-size:26px;color:${C.gray};letter-spacing:2px;font-weight:500}
.scene{position:absolute;inset:0}
.tag{position:absolute;left:80px;top:230px;background:${C.blue};color:#fff;font-size:24px;font-weight:700;letter-spacing:1.5px;padding:10px 22px;border-radius:999px}
.title{position:absolute;left:80px;top:300px;width:920px;font-weight:900;font-size:92px;line-height:1.16;letter-spacing:-2px}
.title .l2{color:${C.blue}}
.title .ln{display:block;overflow:hidden}
.title .ln span{display:inline-block}
.area *{word-break:keep-all;overflow-wrap:normal}
.area{position:absolute;left:80px;top:660px;width:920px;height:760px}
.card{background:${C.card};border-radius:32px;box-shadow:0 14px 40px rgba(0,0,0,.07)}
.cap{font-size:30px;color:${C.gray};font-weight:500}
.hl{color:${C.blue}} .dim{color:#9A9A9A} .strike{color:${C.red};text-decoration:line-through;text-decoration-thickness:6px}
#sub{position:absolute;left:80px;right:80px;top:1490px;min-height:150px;display:flex;align-items:center;justify-content:center;background:rgba(26,26,26,.9);border-radius:24px;color:#fff;font-size:36px;font-weight:500;line-height:1.45;text-align:center;padding:26px 40px;word-break:keep-all}
#logo{position:absolute;left:50%;top:1730px;transform:translateX(-50%);height:96px}
#logo img{height:100%}
#endcard{position:absolute;inset:0;background:${C.bg};display:none;flex-direction:column;align-items:center;justify-content:center;gap:34px}
#endcard img{height:84px}
#endcard .p{font-size:46px;font-weight:700}
#endcard .a{font-size:30px;color:${C.gray};font-weight:500}
#endcard .q{font-size:52px;font-weight:900;text-align:center;line-height:1.3;padding:0 90px;word-break:keep-all}
`;
const st=document.createElement('style');st.textContent=css;document.head.appendChild(st);

let built=false,R,stage,bar,page,sub,scenes=[];
function build(){
  R=window.REEL;stage=el('div',null,document.body);stage.id='stage';
  bar=el('div',null,stage);bar.id='bar';page=el('div',null,stage);page.id='page';
  R.scenes.forEach((sc,i)=>{
    const root=el('div','scene',stage);
    const tag=el('div','tag',root,sc.tag||'');
    const t=el('div','title',root);
    const l=(sc.title||['','']).map((x,j)=>{const ln=el('div','ln'+(j?' l2':''),t);return el('span',null,ln,rich(x||''));});
    const areaBox=el('div','area',root);
    const area=el('div',null,areaBox);area.style.cssText='position:absolute;left:0;top:0;width:920px;height:760px;transform-origin:0 0';
    const part=window.PARTS[sc.part];
    let state=null;
    try{ state=part?part.build(area,sc.params||{},sc.variant||{}):null; }catch(e){ area.innerHTML='<div style="color:red;font-size:30px">part error: '+sc.part+' '+e.message+'</div>'; }
    scenes.push({sc,root,tag,l,area,part,state,fitted:false});
  });
  sub=el('div',null,stage);sub.id='sub';
  if(R.logo&&R.logo!=='none'){const lg=el('div',null,stage);lg.id='logo';const im=el('img',null,lg);im.src='brand/'+({thelx:'thelx_ink_dark.png',lxsg:'lxsg_ink_dark.png',motif:'motif_logo_dark.png',solargard:'solargard_premium_ink_dark.png'}[R.logo]||'thelx_ink_dark.png');if(R.logo==='motif'){lg.style.height='54px';lg.style.top='1760px';}}
  if(R.endcard){const ec=el('div',null,stage);ec.id='endcard';const E2=R.endcard;
    if(E2.q){el('div','q',ec,rich(E2.q));}
    if(E2.logo&&E2.logo!=='none'){const im=el('img',null,ec);im.src='brand/'+({thelx:'thelx_ink_dark.png',lxsg:'lxsg_ink_dark.png',motif:'motif_logo_dark.png',solargard:'solargard_premium_ink_dark.png'}[E2.logo]);if(E2.logo==='motif')im.style.height='70px';}
    if(E2.product)el('div','p',ec,rich(E2.product));
    if(E2.address)el('div','a',ec,E2.address);
    R._ec=ec;}
  built=true;
}
// 부품 내용이 영역을 채우도록 끝 상태 기준으로 자동 확대·가운데 정렬
function fitTitle(S){
  const t=S.root.querySelector('.title');if(!t)return;S.root.style.display='block';
  let fs=92;t.style.fontSize=fs+'px';
  const over=()=>S.l.some(e=>e.scrollWidth>920)||t.querySelectorAll('.ln').length&&[...t.querySelectorAll('.ln')].some(ln=>ln.getBoundingClientRect().height>fs*1.25);
  while(fs>58&&S.l.some(e=>e.getBoundingClientRect().width>920)){fs-=4;t.style.fontSize=fs+'px';}
}
function bgOf(n){for(let p=n;p;p=p.parentElement){const b=getComputedStyle(p).backgroundColor;if(b&&b!=='rgba(0, 0, 0, 0)'&&b!=='transparent')return b;}return 'rgb(246, 245, 241)';}
function lum(c){const m=(c.match(/[\d.]+/g)||[0,0,0]).map(Number);return (0.299*m[0]+0.587*m[1]+0.114*m[2])/255;}
function fixContrast(root){root.querySelectorAll('.hl,.dim').forEach(h=>{if(lum(bgOf(h.parentElement))<0.55){h.style.color='#fff';h.style.textDecoration='underline';h.style.textDecorationThickness='4px';h.style.textUnderlineOffset='8px';}});}
function fit(S){
  fitTitle(S);fixContrast(S.area);
  S.fitted=true;if(!S.part||S.state==null)return;
  const dur=S.sc.end-S.sc.start;
  S.root.style.display='block';S.root.style.opacity=1;S.root.style.transform='none';
  try{S.part.update(S.state,dur+5,dur,S.sc.params||{},S.sc.variant||{});}catch(e){}
  const a=S.area.getBoundingClientRect();let x0=1e9,y0=1e9,x1=-1e9,y1=-1e9;
  const vis=n=>{const cs=getComputedStyle(n);return cs.display!=='none'&&cs.visibility!=='hidden'&&parseFloat(cs.opacity)>0.05;};
  S.area.querySelectorAll('*').forEach(n=>{
    if(n.closest('svg')&&n.tagName.toLowerCase()!=='svg')return;
    const cs=getComputedStyle(n);
    const painted=n.childElementCount===0||/^(svg|img|canvas)$/i.test(n.tagName)||(cs.backgroundColor!=='rgba(0, 0, 0, 0)'&&cs.backgroundColor!=='transparent')||cs.boxShadow!=='none'||parseFloat(cs.borderTopWidth)>0;
    if(!painted||!vis(n))return;
    if(n.childElementCount===0&&!(n.textContent||'').trim()&&!/^(svg|img|canvas)$/i.test(n.tagName)&&cs.backgroundColor==='rgba(0, 0, 0, 0)'&&parseFloat(cs.borderTopWidth)===0)return;
    let r=n.getBoundingClientRect();let L=r.left,T=r.top,R2=r.right,B=r.bottom;
    for(let p=n.parentElement;p&&p!==S.area;p=p.parentElement){const ps=getComputedStyle(p);
      if(!vis(p))return;
      if(ps.overflow!=='visible'){const q=p.getBoundingClientRect();L=Math.max(L,q.left);T=Math.max(T,q.top);R2=Math.min(R2,q.right);B=Math.min(B,q.bottom);}}
    if(R2-L<2||B-T<2)return;
    x0=Math.min(x0,L);y0=Math.min(y0,T);x1=Math.max(x1,R2);y1=Math.max(y1,B);});
  if(x1<=x0)return;
  const bw=x1-x0,bh=y1-y0;let s=Math.min(880/bw,740/bh,1.8);
  if(s>0.97&&s<1.06)s=1;
  const cx=(x0+x1)/2-a.left,cy=(y0+y1)/2-a.top;
  const tx=460-cx*s,ty=380-cy*s;
  S.area.style.transform=`translate(${tx}px,${ty}px) scale(${s})`;
}
window.checkScene=function(i){
  const S=scenes[i];const out=[];const r=S.root;
  const title=r.querySelector('.title');const tb=title.getBoundingClientRect();
  if(S.l.some(e=>e.getBoundingClientRect().width>925))out.push('제목 줄이 화면 폭(920px)을 넘음 — 더 짧게');
  [...title.querySelectorAll('.ln')].forEach((ln,j)=>{if(ln.getBoundingClientRect().height>parseFloat(title.style.fontSize||92)*1.6)out.push(`제목 ${j+1}줄이 두 줄로 넘어감 — 더 짧게`);});
  const txt=r.innerText||'';if(/요[.!?]?(\s|$)/.test(title.innerText))out.push('제목이 ~요로 끝남(릴스 금지)');
  const sub=document.getElementById('sub').getBoundingClientRect();
  let minF=99,x0=1e9,x1=-1e9,y0=1e9,y1=-1e9,err=S.area.innerText.includes('part error');
  const m=new DOMMatrix(getComputedStyle(S.area).transform);const sc=m.a||1;
  S.area.querySelectorAll('*').forEach(n=>{const cs=getComputedStyle(n);if(cs.display==='none'||parseFloat(cs.opacity)<0.05)return;
    const own=[...n.childNodes].some(c=>c.nodeType===3&&c.textContent.trim());
    const b=n.getBoundingClientRect();if(b.width<2||b.height<2)return;
    if(own){const f=parseFloat(cs.fontSize)*sc;if(n.closest('svg')){}else minF=Math.min(minF,f);x0=Math.min(x0,b.left);x1=Math.max(x1,b.right);}
    y0=Math.min(y0,b.top);y1=Math.max(y1,b.bottom);});
  S.area.querySelectorAll('*').forEach(n=>{const own=[...n.childNodes].some(c=>c.nodeType===3&&c.textContent.trim());if(!own)return;const cs=getComputedStyle(n);if(parseFloat(cs.opacity)<0.05)return;
    const lh=parseFloat(cs.lineHeight)||parseFloat(cs.fontSize)*1.3;const rb=n.getBoundingClientRect();const L=n.textContent.trim();
    if(!n.closest('svg')&&rb.height>lh*1.6&&(L.replace(/\s/g,'').length<=10||parseFloat(cs.fontSize)>=100))out.push('글자가 어색하게 줄바꿈됨: '+L.slice(0,12));
    if(Math.abs(lum(cs.color)-lum(bgOf(n)))<0.18)out.push('글자 색이 배경과 비슷해 안 보임: '+n.textContent.trim().slice(0,12));});
  if(err)out.push('부품 오류: '+S.area.innerText.slice(0,80));
  if(minF<24)out.push(`부품 안 글씨가 너무 작음(${minF.toFixed(0)}px) — 항목·글자 수를 줄일 것`);
  if(x0<40||x1>1040)out.push('부품 글자가 화면 밖으로 나감');
  if(y1>sub.top+4)out.push('부품이 자막 상자와 겹침');
  if(y0<tb.bottom-4)out.push('부품이 제목과 겹침');
  return out;};
window.seek=function(t){
  if(!built)build();
  scenes.forEach(S=>{if(!S.fitted)fit(S);});
  bar.style.width=(clamp(t/R.duration)*W)+'px';
  const n=scenes.length;
  scenes.forEach((S,i)=>{
    const {sc}=S;const lt=t-sc.start;const dur=sc.end-sc.start;const last=i===n-1;
    // 전환: 등장 0.45s, 퇴장 0.35s (마지막 장면은 퇴장 없음)
    const inK=easeOut(lt/0.45), outK=last?0:easeInOut((t-(sc.end-0.35))/0.35);
    const vis=t>=sc.start-0.01&&(last||t<sc.end);
    S.root.style.display=vis?'block':'none';
    if(!vis)return;
    S.root.style.opacity=Math.min(inK,1-outK);
    S.root.style.transform=`translateY(${(1-inK)*24-outK*30}px)`;
    if(lt>=0){page.textContent=String(i+1).padStart(2,'0')+' / '+String(n).padStart(2,'0');}
    rise(S.tag,p(lt,0.05,0.5),20);
    S.l.forEach((e,j)=>{const k=p(lt,0.12+j*0.14,0.6);e.style.transform=`translateY(${(1-k)*110}%)`;});
    if(S.part&&S.state!=null){try{S.part.update(S.state,Math.max(0,lt),dur,sc.params||{},sc.variant||{});}catch(e){}}
  });
  if(R._ec){const k=easeOut((t-R.endcard.start)/0.7);
    if(t>=R.endcard.start){R._ec.style.display='flex';R._ec.style.opacity=k;[...R._ec.children].forEach((c,j)=>rise(c,easeOut((t-R.endcard.start-0.15*j)/0.7),50));}
    else R._ec.style.display='none';}
  // 자막
  let cur=null;for(const s of R.subs){if(t>=s.t)cur=s;}
  if(R._ec&&t>=R.endcard.start)cur=null;
  if(cur){if(sub.dataset.t!==String(cur.t)){sub.innerHTML=rich(cur.text);sub.dataset.t=String(cur.t);}
    sub.style.opacity=easeOut((t-cur.t)/0.25);sub.style.display='flex';} else sub.style.display='none';
};
})();
