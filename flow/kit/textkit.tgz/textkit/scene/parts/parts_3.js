window.PARTS = window.PARTS || {};

PARTS.photo_zoom = {
    build(area, params, variant) {
        const el = E.el('div', 'card', area, '');
        el.style.width = '100%';
        el.style.height = '100%';
        el.style.position = 'relative';
        el.style.overflow = 'hidden';

        const imgWrap = E.el('div', '', el, '');
        imgWrap.style.width = '100%';
        imgWrap.style.height = '100%';
        imgWrap.style.transformOrigin = 'center';
        
        const img = E.el('img', '', imgWrap, '');
        img.src = params.src || '';
        img.style.width = '100%';
        img.style.height = '100%';
        img.style.objectFit = 'cover';

        const labels = [];
        (params.labels || []).forEach(lb => {
            const wrap = E.el('div', '', el, '');
            wrap.style.position = 'absolute';
            wrap.style.left = (lb.x || 50) + '%';
            wrap.style.top = (lb.y || 50) + '%';
            wrap.style.zIndex = '2';
            
            const dot = E.el('div', '', wrap, '');
            dot.style.width = '24px';
            dot.style.height = '24px';
            dot.style.backgroundColor = '#1F5BFF';
            dot.style.borderRadius = '50%';
            dot.style.transform = 'translate(-50%, -50%)';
            dot.style.boxShadow = '0 0 0 6px #FFFFFF, 0 4px 12px rgba(0,0,0,0.3)';

            const txt = E.el('div', '', wrap, E.rich(lb.text || ''));
            txt.style.position = 'absolute';
            txt.style.top = '20px';
            txt.style.left = '50%';
            txt.style.transform = 'translateX(-50%)';
            txt.style.whiteSpace = 'nowrap';
            txt.style.backgroundColor = E.C.card;
            txt.style.padding = '12px 24px';
            txt.style.borderRadius = '24px';
            txt.style.fontWeight = '700';
            txt.style.fontSize = '36px';
            txt.style.boxShadow = '0 6px 16px rgba(0,0,0,0.15)';
            txt.style.color = E.C.ink;

            if (variant.layout === 1) {
                txt.style.backgroundColor = 'transparent';
                txt.style.boxShadow = 'none';
                txt.style.borderBottom = '6px solid #1F5BFF';
                txt.style.borderRadius = '0';
            } else if (variant.layout === 2) {
                txt.style.backgroundColor = E.C.ink;
                txt.style.color = E.C.card;
            }

            if (variant.accent === 1) {
                txt.style.color = '#1F5BFF';
            } else if (variant.accent === 2) {
                txt.style.backgroundColor = '#1F5BFF';
                txt.style.color = E.C.card;
            }

            labels.push({ wrap, txt });
        });

        let cap = null;
        if (params.caption) {
            cap = E.el('div', 'cap', el, E.rich(params.caption));
            cap.style.position = 'absolute';
            cap.style.bottom = '40px';
            cap.style.left = '40px';
            cap.style.backgroundColor = 'rgba(255,255,255,0.9)';
            cap.style.padding = '16px 32px';
            cap.style.borderRadius = '24px';
            cap.style.fontWeight = '500';
            cap.style.fontSize = '30px';
            cap.style.color = E.C.ink;
            cap.style.zIndex = '3';
        }

        return { el, imgWrap, labels, cap };
    },
    update(state, lt, dur, params, variant) {
        const at = params.at && params.at[0] !== undefined ? params.at[0] : 0.5;
        const p = E.p(lt, at, 0.8);
        const pScale = E.p(lt, at, dur || 5);

        if (variant.motion === 0) {
            E.rise(state.el, p);
        } else if (variant.motion === 1) {
            E.reveal(state.el, p);
        } else {
            state.el.style.opacity = Math.max(state.el.style.opacity || 0, p);
            state.el.style.transform = `scale(${0.94 + 0.06 * p})`;
        }

        state.imgWrap.style.transform = `scale(${1 + pScale * 0.08})`;

        state.labels.forEach((lb, i) => {
            const lp = E.p(lt, at + 0.5 + i * 0.2, 0.5);
            lb.wrap.style.opacity = Math.max(lb.wrap.style.opacity || 0, lp);
            lb.wrap.style.transform = `scale(${0.5 + 0.5 * lp})`;
        });

        if (state.cap) {
            const cp = E.p(lt, at + 0.3, 0.6);
            state.cap.style.opacity = Math.max(state.cap.style.opacity || 0, cp);
            state.cap.style.transform = `translateY(${(1 - cp) * 20}px)`;
        }
    }
};

PARTS.photo_pair = {
    build(area, params, variant) {
        const el = E.el('div', '', area, '');
        el.style.width = '100%';
        el.style.height = '100%';
        el.style.position = 'relative';
        el.style.display = 'flex';
        el.style.gap = '32px';
        el.style.padding = '40px';
        
        if (variant.layout === 2) {
            el.style.flexDirection = 'column';
        } else {
            el.style.flexDirection = 'row';
        }

        const createCard = (d) => {
            const card = E.el('div', 'card', el, '');
            card.style.flex = '1';
            card.style.position = 'relative';
            card.style.overflow = 'hidden';
            card.style.borderRadius = '32px';

            if (variant.layout === 1) {
                card.style.transform = 'skewY(-5deg)';
            }

            const img = E.el('img', '', card, '');
            img.src = d.src || '';
            img.style.width = '100%';
            img.style.height = '100%';
            img.style.objectFit = 'cover';
            
            if (variant.layout === 1) {
                img.style.transform = 'skewY(5deg) scale(1.2)';
            }

            const lb = E.el('div', '', card, E.rich(d.label || ''));
            lb.style.position = 'absolute';
            lb.style.bottom = '32px';
            lb.style.left = '32px';
            lb.style.backgroundColor = E.C.card;
            lb.style.padding = '12px 32px';
            lb.style.borderRadius = '40px';
            lb.style.fontWeight = '700';
            lb.style.fontSize = '36px';
            lb.style.color = E.C.ink;
            
            if (variant.accent === 1) {
                lb.style.color = '#1F5BFF';
            } else if (variant.accent === 2) {
                lb.style.backgroundColor = '#1F5BFF';
                lb.style.color = E.C.card;
            }

            return { card, img, lb };
        };

        const left = createCard(params.left || {});
        const right = createCard(params.right || {});
        
        if (variant.layout === 2) {
            right.card.style.marginLeft = '40px';
            left.card.style.marginRight = '40px';
        }

        let cap = null;
        if (params.caption) {
            cap = E.el('div', 'cap', area, E.rich(params.caption));
            cap.style.position = 'absolute';
            cap.style.top = '-60px';
            cap.style.left = '0';
            cap.style.width = '100%';
            cap.style.textAlign = 'center';
            cap.style.fontSize = '30px';
            cap.style.fontWeight = '700';
        }

        return { el, left, right, cap };
    },
    update(state, lt, dur, params, variant) {
        const at = params.at && params.at[0] !== undefined ? params.at[0] : 0.5;
        
        const pl = E.p(lt, at, 0.6);
        const pr = E.p(lt, at + 0.2, 0.6);

        const applyMo = (c, p) => {
            if (variant.motion === 0) {
                E.rise(c, p);
            } else if (variant.motion === 1) {
                E.reveal(c, p);
            } else {
                c.style.opacity = Math.max(c.style.opacity || 0, p);
                let tr = variant.layout === 1 ? 'skewY(-5deg)' : '';
                c.style.transform = `${tr} scale(${0.9 + 0.1 * p})`;
            }
        };

        applyMo(state.left.card, pl);
        applyMo(state.right.card, pr);

        if (state.cap) {
            state.cap.style.opacity = Math.max(state.cap.style.opacity || 0, E.p(lt, at, 0.4));
        }
    }
};

PARTS.photo_slider = {
    build(area, params, variant) {
        const el = E.el('div', 'card', area, '');
        el.style.width = '100%';
        el.style.height = '100%';
        el.style.position = 'relative';
        el.style.overflow = 'hidden';
        el.style.borderRadius = '32px';

        const beforeWrap = E.el('div', '', el, '');
        beforeWrap.style.width = '100%';
        beforeWrap.style.height = '100%';
        beforeWrap.style.position = 'absolute';
        
        const beforeImg = E.el('img', '', beforeWrap, '');
        beforeImg.src = (params.before || {}).src || '';
        beforeImg.style.width = '100%';
        beforeImg.style.height = '100%';
        beforeImg.style.objectFit = 'cover';

        const beforeLb = E.el('div', '', beforeWrap, E.rich((params.before || {}).label || 'Before'));
        beforeLb.style.position = 'absolute';
        beforeLb.style.top = '32px';
        beforeLb.style.right = '32px';
        beforeLb.style.backgroundColor = E.C.card;
        beforeLb.style.padding = '12px 32px';
        beforeLb.style.borderRadius = '40px';
        beforeLb.style.fontWeight = '700';
        beforeLb.style.fontSize = '36px';
        beforeLb.style.color = E.C.ink;

        const afterWrap = E.el('div', '', el, '');
        afterWrap.style.width = '100%';
        afterWrap.style.height = '100%';
        afterWrap.style.position = 'absolute';
        
        const afterImg = E.el('img', '', afterWrap, '');
        afterImg.src = (params.after || {}).src || '';
        afterImg.style.width = '100%';
        afterImg.style.height = '100%';
        afterImg.style.objectFit = 'cover';

        const afterLb = E.el('div', '', afterWrap, E.rich((params.after || {}).label || 'After'));
        afterLb.style.position = 'absolute';
        afterLb.style.top = '32px';
        afterLb.style.left = '32px';
        afterLb.style.backgroundColor = '#1F5BFF';
        afterLb.style.color = E.C.card;
        afterLb.style.padding = '12px 32px';
        afterLb.style.borderRadius = '40px';
        afterLb.style.fontWeight = '700';
        afterLb.style.fontSize = '36px';

        const handleLine = E.el('div', '', el, '');
        handleLine.style.position = 'absolute';
        handleLine.style.width = '6px';
        handleLine.style.height = '100%';
        handleLine.style.backgroundColor = '#FFFFFF';
        handleLine.style.top = '0';
        handleLine.style.boxShadow = '0 0 16px rgba(0,0,0,0.4)';
        handleLine.style.transform = 'translateX(-50%)';

        const handle = E.el('div', '', handleLine, '');
        handle.style.position = 'absolute';
        handle.style.top = '50%';
        handle.style.left = '50%';
        handle.style.transform = 'translate(-50%, -50%)';
        handle.style.backgroundColor = '#FFFFFF';
        handle.style.boxShadow = '0 6px 16px rgba(0,0,0,0.4)';
        handle.style.display = 'flex';
        handle.style.alignItems = 'center';
        handle.style.justifyContent = 'center';
        handle.style.color = E.C.ink;

        if (variant.layout === 0) {
            handle.style.width = '64px';
            handle.style.height = '64px';
            handle.style.borderRadius = '50%';
            handle.innerHTML = '<svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8L22 12L18 16M6 8L2 12L6 16M2 12H22"/></svg>';
        } else if (variant.layout === 1) {
            handle.style.width = '12px';
            handle.style.height = '80px';
            handle.style.borderRadius = '6px';
        } else {
            handle.style.width = '48px';
            handle.style.height = '48px';
            handle.style.transform = 'translate(-50%, -50%) rotate(45deg)';
        }
        
        if (variant.accent === 1) {
            handle.style.color = '#1F5BFF';
        } else if (variant.accent === 2) {
            handleLine.style.backgroundColor = '#1F5BFF';
            handle.style.backgroundColor = '#1F5BFF';
            handle.style.color = '#FFFFFF';
        }

        return { el, afterWrap, handleLine };
    },
    update(state, lt, dur, params, variant) {
        const at = params.at && params.at[0] !== undefined ? params.at[0] : 0.5;
        
        const pEntry = E.p(lt, at, 0.6);
        if (variant.motion === 0) {
            E.rise(state.el, pEntry);
        } else if (variant.motion === 1) {
            E.reveal(state.el, pEntry);
        } else {
            state.el.style.opacity = Math.max(state.el.style.opacity || 0, pEntry);
            state.el.style.transform = `scale(${0.9 + 0.1 * pEntry})`;
        }

        const pSlide = E.easeInOut(E.clamp((lt - (at + 0.6)) / 1.5, 0, 1));
        const pct = 10 + 80 * pSlide;
        const curPct = pEntry < 1 ? 50 : pct; 

        state.afterWrap.style.clipPath = `inset(0 ${100 - curPct}% 0 0)`;
        state.handleLine.style.left = `${curPct}%`;
    }
};

PARTS.photo_hotspots = {
    build(area, params, variant) {
        const el = E.el('div', 'card', area, '');
        el.style.width = '100%';
        el.style.height = '100%';
        el.style.position = 'relative';
        el.style.overflow = 'hidden';
        el.style.borderRadius = '32px';

        const img = E.el('img', '', el, '');
        img.src = params.src || '';
        img.style.width = '100%';
        img.style.height = '100%';
        img.style.objectFit = 'cover';

        const spots = (params.spots || []).map(sp => {
            const wrap = E.el('div', '', el, '');
            wrap.style.position = 'absolute';
            wrap.style.left = (sp.x || 50) + '%';
            wrap.style.top = (sp.y || 50) + '%';

            const ring = E.el('div', '', wrap, '');
            ring.style.position = 'absolute';
            ring.style.width = '48px';
            ring.style.height = '48px';
            ring.style.borderRadius = '50%';
            ring.style.backgroundColor = variant.accent === 2 ? '#FFFFFF' : '#1F5BFF';
            ring.style.transform = 'translate(-50%, -50%)';

            const dot = E.el('div', '', wrap, '');
            dot.style.position = 'absolute';
            dot.style.width = '24px';
            dot.style.height = '24px';
            dot.style.borderRadius = '50%';
            dot.style.backgroundColor = variant.accent === 2 ? '#1F5BFF' : '#FFFFFF';
            dot.style.transform = 'translate(-50%, -50%)';
            dot.style.boxShadow = '0 4px 12px rgba(0,0,0,0.3)';

            const txt = E.el('div', '', wrap, E.rich(sp.text || ''));
            txt.style.position = 'absolute';
            txt.style.whiteSpace = 'nowrap';
            txt.style.backgroundColor = variant.accent === 1 ? '#1F5BFF' : E.C.card;
            txt.style.color = variant.accent === 1 ? E.C.card : E.C.ink;
            txt.style.padding = '12px 24px';
            txt.style.borderRadius = '32px';
            txt.style.fontWeight = '700';
            txt.style.fontSize = '36px';
            txt.style.boxShadow = '0 6px 16px rgba(0,0,0,0.2)';

            if (variant.layout === 0) {
                txt.style.bottom = '32px';
                txt.style.left = '50%';
                txt.style.transform = 'translateX(-50%)';
            } else if (variant.layout === 1) {
                txt.style.top = '32px';
                txt.style.left = '50%';
                txt.style.transform = 'translateX(-50%)';
            } else {
                txt.style.left = '32px';
                txt.style.top = '50%';
                txt.style.transform = 'translateY(-50%)';
            }

            return { wrap, ring, dot, txt };
        });

        return { el, spots };
    },
    update(state, lt, dur, params, variant) {
        const at = params.at && params.at[0] !== undefined ? params.at[0] : 0.5;
        const pEntry = E.p(lt, at, 0.6);

        if (variant.motion === 0) {
            E.rise(state.el, pEntry);
        } else if (variant.motion === 1) {
            E.reveal(state.el, pEntry);
        } else {
            state.el.style.opacity = Math.max(state.el.style.opacity || 0, pEntry);
            state.el.style.transform = `scale(${0.94 + 0.06 * pEntry})`;
        }

        state.spots.forEach((sp, i) => {
            const tStart = at + 0.5 + i * 0.3;
            const pSpot = E.p(lt, tStart, 0.5);
            
            sp.wrap.style.opacity = Math.max(sp.wrap.style.opacity || 0, pSpot);
            
            const timeSince = Math.max(0, lt - tStart);
            const cycle = (timeSince % 1.5) / 1.5; 
            const rScale = 1 + cycle * 1.5;
            const rAlpha = 1 - cycle;
            sp.ring.style.transform = `translate(-50%, -50%) scale(${rScale})`;
            sp.ring.style.opacity = pSpot >= 1 ? rAlpha : Math.min(rAlpha, pSpot);

            sp.txt.style.opacity = Math.max(sp.txt.style.opacity || 0, pSpot);
            const offset = (1 - pSpot) * 30;
            if (variant.layout === 0) {
                sp.txt.style.transform = `translate(-50%, ${offset}px)`;
            } else if (variant.layout === 1) {
                sp.txt.style.transform = `translate(-50%, ${-offset}px)`;
            } else {
                sp.txt.style.transform = `translate(${offset}px, -50%)`;
            }
        });
    }
};

PARTS.photo_stack = {
    build(area, params, variant) {
        const el = E.el('div', '', area, '');
        el.style.width = '100%';
        el.style.height = '100%';
        el.style.position = 'relative';
        el.style.display = 'flex';
        el.style.alignItems = 'center';
        el.style.justifyContent = 'center';
        el.style.padding = '40px';

        const srcs = params.srcs || [];
        const cards = [];

        for (let i = 0; i < 3; i++) {
            const card = E.el('div', 'card', el, '');
            card.style.position = 'absolute';
            card.style.width = '700px';
            card.style.height = '600px';
            card.style.overflow = 'hidden';
            card.style.borderRadius = '32px';
            card.style.transformOrigin = variant.layout === 2 ? 'bottom center' : 'center center';
            
            if (variant.accent === 1) {
                card.style.border = `6px solid #1F5BFF`;
            }
            if (variant.accent === 2) {
                card.style.boxShadow = `16px 16px 0 #1F5BFF`;
            }

            const img = E.el('img', '', card, '');
            img.src = srcs[i] || '';
            img.style.width = '100%';
            img.style.height = '100%';
            img.style.objectFit = 'cover';

            cards.push(card);
        }

        cards[0].style.zIndex = '3';
        cards[1].style.zIndex = '2';
        cards[2].style.zIndex = '1';

        let cap = null;
        if (params.caption) {
            cap = E.el('div', 'cap', el, E.rich(params.caption));
            cap.style.position = 'absolute';
            cap.style.bottom = '24px';
            cap.style.textAlign = 'center';
            cap.style.width = '100%';
            cap.style.fontSize = '30px';
            cap.style.fontWeight = '700';
            cap.style.color = E.C.ink;
        }

        return { el, cards, cap };
    },
    update(state, lt, dur, params, variant) {
        const at = params.at && params.at[0] !== undefined ? params.at[0] : 0.5;
        
        const pEntry = E.p(lt, at, 0.6);
        if (variant.motion === 0) {
            state.cards.forEach(c => E.rise(c, pEntry));
        } else if (variant.motion === 1) {
            state.cards.forEach(c => E.reveal(c, pEntry));
        } else {
            state.cards.forEach(c => {
                c.style.opacity = Math.max(c.style.opacity || 0, pEntry);
                c.style.transform = `scale(${0.9 + 0.1 * pEntry})`;
            });
        }

        const pSpread = E.easeInOut(E.clamp((lt - (at + 0.6)) / 0.8, 0, 1));
        
        if (variant.layout === 0) {
            state.cards[1].style.transform = `translate(${-120 * pSpread}px, ${20 * pSpread}px) rotate(${-10 * pSpread}deg) scale(${0.9 + 0.1 * pEntry})`;
            state.cards[2].style.transform = `translate(${120 * pSpread}px, ${40 * pSpread}px) rotate(${10 * pSpread}deg) scale(${0.9 + 0.1 * pEntry})`;
        } else if (variant.layout === 1) {
            state.cards[1].style.transform = `translate(${40 * pSpread}px, ${40 * pSpread}px) scale(${0.9 + 0.1 * pEntry})`;
            state.cards[2].style.transform = `translate(${80 * pSpread}px, ${80 * pSpread}px) scale(${0.9 + 0.1 * pEntry})`;
        } else {
            state.cards[1].style.transform = `rotate(${-15 * pSpread}deg) scale(${0.9 + 0.1 * pEntry})`;
            state.cards[2].style.transform = `rotate(${15 * pSpread}deg) scale(${0.9 + 0.1 * pEntry})`;
        }

        if (state.cap) {
            const cp = E.p(lt, at + 1.2, 0.5);
            state.cap.style.opacity = Math.max(state.cap.style.opacity || 0, cp);
            state.cap.style.transform = `translateY(${(1 - cp) * 20}px)`;
        }
    }
};

PARTS.num_list = {
    build(area, params, variant) {
        const el = E.el('div', '', area, '');
        el.style.width = '100%';
        el.style.height = '100%';
        el.style.display = 'flex';
        el.style.padding = '40px 60px';
        
        const itemsData = params.items || [];
        
        if (variant.layout === 0) {
            el.style.flexDirection = 'column';
            el.style.justifyContent = 'center';
            el.style.gap = '40px';
        } else if (variant.layout === 1) {
            el.style.flexWrap = 'wrap';
            el.style.alignContent = 'center';
            el.style.gap = '40px';
        } else {
            el.style.flexDirection = 'column';
            el.style.justifyContent = 'center';
            el.style.gap = '40px';
        }

        const items = itemsData.map((d, i) => {
            const it = E.el('div', '', el, '');
            it.style.display = 'flex';
            it.style.alignItems = 'flex-start';
            it.style.gap = '24px';
            
            if (variant.layout === 1) {
                it.style.width = 'calc(50% - 20px)';
                it.style.flexDirection = 'column';
            } else if (variant.layout === 2) {
                it.style.marginLeft = i % 2 === 1 ? '160px' : '0px';
            } else {
                it.style.width = '100%';
            }

            const num = E.el('div', '', it, String(i + 1));
            num.style.width = '80px';
            num.style.height = '80px';
            num.style.flexShrink = '0';
            num.style.borderRadius = '50%';
            num.style.display = 'flex';
            num.style.alignItems = 'center';
            num.style.justifyContent = 'center';
            num.style.fontWeight = '900';
            num.style.fontSize = '48px';
            num.style.backgroundColor = E.C.ink;
            num.style.color = E.C.card;

            if (variant.accent === 1) {
                num.style.backgroundColor = '#1F5BFF';
            } else if (variant.accent === 2) {
                num.style.backgroundColor = '#E8EEFF';
                num.style.color = '#1F5BFF';
            }

            const content = E.el('div', 'card', it, '');
            content.style.flex = '1';
            content.style.padding = '36px';
            content.style.borderRadius = '32px';
            if (variant.layout === 1) content.style.width = '100%';

            const title = E.el('div', '', content, E.rich(d.title || ''));
            title.style.fontWeight = '700';
            title.style.fontSize = '40px';
            title.style.color = E.C.ink;
            title.style.marginBottom = '12px';

            const desc = E.el('div', '', content, E.rich(d.desc || ''));
            desc.style.fontWeight = '400';
            desc.style.fontSize = '36px';
            desc.style.color = E.C.gray;

            return it;
        });

        return { items };
    },
    update(state, lt, dur, params, variant) {
        const at = params.at && params.at.length ? params.at : [];
        
        state.items.forEach((it, i) => {
            const tStart = at[i] !== undefined ? at[i] : 0.5 + i * 0.35;
            const p = E.p(lt, tStart, 0.6);
            
            if (variant.motion === 0) {
                E.rise(it, p);
            } else if (variant.motion === 1) {
                E.reveal(it, p);
            } else {
                it.style.opacity = Math.max(it.style.opacity || 0, p);
                it.style.transform = `scale(${0.9 + 0.1 * p})`;
            }
        });
    }
};

PARTS.checklist = {
    build(area, params, variant) {
        const el = E.el('div', '', area, '');
        el.style.width = '100%';
        el.style.height = '100%';
        el.style.display = 'flex';
        el.style.flexDirection = 'column';
        el.style.justifyContent = 'center';
        el.style.gap = '48px';
        el.style.padding = '40px 60px';

        const itemsData = params.items || [];
        const items = itemsData.map(txt => {
            const it = E.el('div', 'card', el, '');
            it.style.display = 'flex';
            it.style.alignItems = 'center';
            it.style.padding = '32px 40px';
            it.style.borderRadius = '32px';
            it.style.gap = '32px';
            
            let checkWrap, path;
            
            if (variant.layout === 0) {
                checkWrap = E.el('div', '', it, '');
                checkWrap.style.width = '64px';
                checkWrap.style.height = '64px';
                checkWrap.style.borderRadius = '50%';
                checkWrap.style.backgroundColor = variant.accent === 2 ? '#E8EEFF' : E.C.line;
                checkWrap.style.display = 'flex';
                checkWrap.style.alignItems = 'center';
                checkWrap.style.justifyContent = 'center';
                checkWrap.style.flexShrink = '0';
                
                checkWrap.innerHTML = `<svg width="40" height="40" viewBox="0 0 24 24" fill="none"><path d="M5 12L10 17L20 7" stroke="${variant.accent === 1 ? '#1F5BFF' : E.C.ink}" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
                path = checkWrap.querySelector('path');
            } else if (variant.layout === 1) {
                it.style.backgroundColor = 'transparent';
                it.style.boxShadow = 'none';
                it.style.borderBottom = '4px solid ' + E.C.line;
                it.style.borderRadius = '0';
                it.style.paddingLeft = '0';
                
                checkWrap = E.el('div', '', it, '');
                checkWrap.innerHTML = `<svg width="48" height="48" viewBox="0 0 24 24" fill="none"><path d="M5 12L10 17L20 7" stroke="${variant.accent === 1 ? '#1F5BFF' : E.C.ink}" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
                path = checkWrap.querySelector('path');
            } else {
                it.style.borderLeft = `12px solid ${variant.accent === 1 ? '#1F5BFF' : E.C.ink}`;
                it.style.borderRadius = '16px';
                
                checkWrap = E.el('div', '', it, '');
                checkWrap.innerHTML = `<svg width="48" height="48" viewBox="0 0 24 24" fill="none"><path d="M5 12L10 17L20 7" stroke="#1F5BFF" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
                path = checkWrap.querySelector('path');
            }

            path.style.strokeDasharray = '40';
            path.style.strokeDashoffset = '40';

            const t = E.el('div', '', it, E.rich(txt));
            t.style.fontWeight = '700';
            t.style.fontSize = '40px';
            t.style.color = E.C.ink;
            if (variant.accent === 2) t.style.color = '#1F5BFF';

            return { it, path, t };
        });

        return { items };
    },
    update(state, lt, dur, params, variant) {
        const at = params.at && params.at.length ? params.at : [];
        
        state.items.forEach((obj, i) => {
            const tStart = at[i] !== undefined ? at[i] : 0.5 + i * 0.35;
            const pEntry = E.p(lt, tStart, 0.5);
            
            if (variant.motion === 0) {
                E.rise(obj.it, pEntry);
            } else if (variant.motion === 1) {
                E.reveal(obj.it, pEntry);
            } else {
                obj.it.style.opacity = Math.max(obj.it.style.opacity || 0, pEntry);
                obj.it.style.transform = `scale(${0.95 + 0.05 * pEntry})`;
            }

            const pCheck = E.p(lt, tStart + 0.3, 0.4);
            obj.path.style.strokeDashoffset = Math.min(obj.path.style.strokeDashoffset || 40, 40 * (1 - pCheck));
        });
    }
};

PARTS.timeline = {
    build(area, params, variant) {
        const el = E.el('div', '', area, '');
        el.style.width = '100%';
        el.style.height = '100%';
        el.style.position = 'relative';
        el.style.display = 'flex';
        el.style.flexDirection = 'column';
        el.style.justifyContent = 'center';
        
        const stepsData = params.steps || [];
        
        const svgWrap = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        svgWrap.style.position = 'absolute';
        svgWrap.style.top = '0';
        svgWrap.style.left = '0';
        svgWrap.style.width = '100%';
        svgWrap.style.height = '100%';
        svgWrap.style.zIndex = '0';
        el.appendChild(svgWrap);

        const linePath = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        linePath.setAttribute('fill', 'none');
        linePath.setAttribute('stroke', variant.accent === 1 ? '#1F5BFF' : E.C.line);
        linePath.setAttribute('stroke-width', '6');
        if (variant.accent === 2) linePath.setAttribute('stroke-dasharray', '12 12');
        svgWrap.appendChild(linePath);
        
        const items = [];
        const positions = [];

        const totalHeight = 650;
        const startY = (760 - totalHeight) / 2;
        const gapY = totalHeight / (Math.max(2, stepsData.length) - 1);

        stepsData.forEach((d, i) => {
            const cy = startY + i * gapY;
            let cx = 160;

            if (variant.layout === 1) cx = 460;
            else if (variant.layout === 2) cx = i % 2 === 0 ? 300 : 620;

            positions.push({ x: cx, y: cy });

            const wrap = E.el('div', '', el, '');
            wrap.style.position = 'absolute';
            wrap.style.top = cy + 'px';
            wrap.style.left = cx + 'px';
            wrap.style.transform = 'translate(-50%, -50%)';
            wrap.style.zIndex = '1';

            const dot = E.el('div', '', wrap, '');
            dot.style.position = 'absolute';
            dot.style.width = '32px';
            dot.style.height = '32px';
            dot.style.borderRadius = '50%';
            dot.style.backgroundColor = variant.accent === 1 ? '#1F5BFF' : E.C.ink;
            dot.style.transform = 'translate(-50%, -50%)';
            dot.style.boxShadow = '0 0 0 8px ' + E.C.bg;

            const content = E.el('div', '', wrap, '');
            content.style.position = 'absolute';
            content.style.top = '0';
            content.style.transform = 'translateY(-50%)';
            content.style.width = '400px';

            if (variant.layout === 0) {
                content.style.left = '60px';
            } else if (variant.layout === 1) {
                content.style.left = i % 2 === 0 ? '60px' : '-460px';
                if (i % 2 !== 0) content.style.textAlign = 'right';
            } else {
                content.style.left = i % 2 === 0 ? '-460px' : '60px';
                if (i % 2 === 0) content.style.textAlign = 'right';
            }

            const title = E.el('div', '', content, E.rich(d.title || ''));
            title.style.fontWeight = '700';
            title.style.fontSize = '40px';
            title.style.color = E.C.ink;
            title.style.marginBottom = '12px';

            const desc = E.el('div', '', content, E.rich(d.desc || ''));
            desc.style.fontWeight = '400';
            desc.style.fontSize = '36px';
            desc.style.color = E.C.gray;

            items.push({ wrap, dot, content });
        });

        let dStr = '';
        positions.forEach((p, i) => {
            if (i === 0) {
                dStr += `M ${p.x} ${p.y} `;
            } else {
                if (variant.layout === 0 || variant.layout === 1) {
                    dStr += `L ${p.x} ${p.y} `;
                } else {
                    const prev = positions[i - 1];
                    dStr += `C ${prev.x} ${prev.y + gapY / 2}, ${p.x} ${p.y - gapY / 2}, ${p.x} ${p.y} `;
                }
            }
        });
        linePath.setAttribute('d', dStr);

        const estLen = variant.layout === 2 ? 1200 : totalHeight;
        linePath.style.strokeDasharray = estLen;
        linePath.style.strokeDashoffset = estLen;

        return { el, items, linePath, estLen };
    },
    update(state, lt, dur, params, variant) {
        const at = params.at && params.at.length ? params.at : [];
        
        const tLineStart = at[0] !== undefined ? at[0] : 0.5;
        const pLine = E.p(lt, tLineStart, 1.5);
        state.linePath.style.strokeDashoffset = Math.min(state.linePath.style.strokeDashoffset || state.estLen, state.estLen * (1 - pLine));

        state.items.forEach((obj, i) => {
            const tStart = at[i] !== undefined ? at[i] : 0.5 + i * 0.4;
            const pEntry = E.p(lt, tStart, 0.6);
            
            if (variant.motion === 0) {
                obj.content.style.opacity = Math.max(obj.content.style.opacity || 0, pEntry);
                obj.content.style.transform = `translateY(calc(-50% + ${(1 - pEntry) * 40}px))`;
            } else if (variant.motion === 1) {
                obj.content.style.opacity = Math.max(obj.content.style.opacity || 0, pEntry);
                obj.content.style.clipPath = `inset(0 ${(1 - pEntry) * 100}% 0 0)`;
            } else {
                obj.content.style.opacity = Math.max(obj.content.style.opacity || 0, pEntry);
                obj.content.style.transform = `translateY(-50%) scale(${0.9 + 0.1 * pEntry})`;
            }
            
            const pDot = E.p(lt, tStart, 0.4);
            obj.dot.style.transform = `translate(-50%, -50%) scale(${pDot})`;
        });
    }
};