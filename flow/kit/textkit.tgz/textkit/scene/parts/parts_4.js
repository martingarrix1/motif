window.PARTS = window.PARTS || {};

PARTS.icon_triple = {
  build: function(area, params, variant) {
    var items = params.items || [];
    var state = { items: [], els: [] };
    
    var container = E.el("div", "", area);
    container.style.display = "flex";
    container.style.width = "100%";
    container.style.height = "100%";
    container.style.boxSizing = "border-box";
    
    if (variant.layout === 0) {
      container.style.flexDirection = "row";
      container.style.alignItems = "center";
      container.style.justifyContent = "space-between";
      container.style.padding = "0 30px";
    } else if (variant.layout === 1) {
      container.style.flexDirection = "column";
      container.style.alignItems = "center";
      container.style.justifyContent = "center";
      container.style.gap = "60px";
    } else {
      container.className = "card";
      container.style.position = "absolute";
      container.style.top = "50%";
      container.style.left = "50%";
      container.style.transform = "translate(-50%, -50%)";
      container.style.width = "880px";
      container.style.height = "560px";
      container.style.flexDirection = "row";
      container.style.alignItems = "center";
      container.style.justifyContent = "space-evenly";
      container.style.padding = "50px";
    }

    var accentColor = variant.accent === 0 ? E.C.blue : (variant.accent === 1 ? E.C.blue : E.C.ink);
    var bgColor = variant.accent === 2 ? "#E8EEFF" : E.C.card;

    items.forEach(function(it, i) {
      var box = E.el("div", "", container);
      box.style.display = "flex";
      box.style.flexDirection = "column";
      box.style.alignItems = "center";
      box.style.width = variant.layout === 1 ? "800px" : "260px";
      if (variant.layout === 1) box.style.flexDirection = "row";
      box.style.background = variant.layout === 1 ? bgColor : "transparent";
      box.style.borderRadius = "20px";
      box.style.padding = variant.layout === 1 ? "40px 60px" : "0";
      
      var iconWrap = E.el("div", "", box);
      iconWrap.style.width = "140px";
      iconWrap.style.height = "140px";
      if (variant.layout === 1) iconWrap.style.marginRight = "50px";
      else iconWrap.style.marginBottom = "30px";
      
      var svg = '<svg width="100%" height="100%" viewBox="0 0 100 100" fill="none" stroke="' + accentColor + '" stroke-width="8" stroke-linecap="round" stroke-linejoin="round">';
      if (it.icon === "sun") svg += '<circle cx="50" cy="50" r="16"/><path d="M50 15v-5 M50 90v-5 M15 50h-5 M90 50h-5 M25 25l-5-5 M75 75l5 5 M25 75l-5 5 M75 25l5-5"/>';
      else if (it.icon === "car" || it.icon === "suv" || it.icon === "sedan" || it.icon === "compact") svg += '<path d="M15 65h70 M20 65v10h10v-10 M70 65v10h10v-10 M15 65l10-30h50l10 30"/>';
      else if (it.icon === "shield") svg += '<path d="M50 15c20 0 35 10 35 10v30c0 30-35 40-35 40S15 85 15 55V25s15-10 35-10z"/>';
      else if (it.icon === "eye") svg += '<path d="M10 50c15-20 30-30 40-30s25 10 40 30c-15 20-30 30-40 30s-25-10-40-30z"/><circle cx="50" cy="50" r="15"/>';
      else if (it.icon === "thermo") svg += '<path d="M50 20v35 M50 20a10 10 0 0 1 10 10v30a20 20 0 1 1-20 0V30a10 10 0 0 1 10-10z M50 65v10"/>';
      else if (it.icon === "moon") svg += '<path d="M65 25a30 30 0 1 1-40 40 30 30 0 0 0 40-40z"/>';
      else svg += '<circle cx="50" cy="50" r="30"/>';
      svg += '</svg>';
      iconWrap.innerHTML = svg;
      
      var textWrap = E.el("div", "", box);
      textWrap.style.display = "flex";
      textWrap.style.flexDirection = "column";
      textWrap.style.flex = "1";
      textWrap.style.alignItems = variant.layout === 1 ? "flex-start" : "center";
      
      var labelEl = E.el("div", "cap dim", textWrap, E.rich(it.label || ""));
      labelEl.style.fontSize = "36px";
      labelEl.style.marginBottom = "12px";
      
      var valEl = E.el("div", "", textWrap);
      valEl.style.fontSize = "80px";
      valEl.style.fontWeight = "700";
      valEl.style.color = E.C.ink;
      
      var rawVal = it.value || "";
      var isNum = false;
      var numMatch = String(rawVal).trim().match(/^([^\d]*)(\d+(?:\.\d+)?)([^\d]*)$/);
      if(numMatch && String(rawVal).indexOf("~") === -1 && String(rawVal).indexOf("-") === -1) {
          isNum = true;
      } else {
          valEl.innerHTML = E.rich(rawVal);
      }
      
      var barWrap = null, barIn = null;
      if (it.bar !== undefined) {
        barWrap = E.el("div", "", textWrap);
        barWrap.style.width = variant.layout === 1 ? "100%" : "220px";
        barWrap.style.height = "16px";
        barWrap.style.background = E.C.line;
        barWrap.style.borderRadius = "8px";
        barWrap.style.marginTop = "24px";
        barWrap.style.overflow = "hidden";
        
        barIn = E.el("div", "", barWrap);
        barIn.style.height = "100%";
        barIn.style.width = "0%";
        barIn.style.background = accentColor;
        barIn.style.borderRadius = "8px";
      }
      
      state.els.push({
          box: box, 
          bar: barIn, 
          barVal: E.clamp(it.bar||0, 0, 1),
          valEl: valEl,
          isNum: isNum,
          numMatch: numMatch
      });
    });
    
    return state;
  },
  update: function(state, lt, dur, params, variant) {
    var t = (params.at && params.at[0]) ? params.at[0] : 0.5;
    state.els.forEach(function(item, i) {
      var delay = t + i * 0.2;
      var p = E.p(lt, delay, 0.6);
      
      item.box.style.opacity = Math.max(0, p);
      if (variant.motion === 0) {
        item.box.style.transform = "translateY(" + (40 * (1 - p)) + "px)";
      } else if (variant.motion === 1) {
        item.box.style.clipPath = "inset(0 " + (100 * (1-p)) + "% 0 0)";
      } else {
        item.box.style.transform = "scale(" + (0.94 + 0.06 * p) + ")";
      }
      
      if(item.isNum) {
          var num = parseFloat(item.numMatch[2]);
          var current = num * p;
          if(num % 1 === 0) current = Math.round(current);
          else current = current.toFixed(1);
          item.valEl.innerHTML = item.numMatch[1] + current + item.numMatch[3];
      }
      
      if (item.bar) {
        var bp = E.p(lt, delay + 0.3, 0.6);
        item.bar.style.width = (item.barVal * 100 * bp) + "%";
      }
    });
  }
};

PARTS.package_card = {
  build: function(area, params, variant) {
    var state = { card: null };
    
    var wrap = E.el("div", "", area);
    wrap.style.position = "absolute";
    wrap.style.width = "100%";
    wrap.style.height = "100%";
    wrap.style.display = "flex";
    wrap.style.alignItems = "center";
    wrap.style.justifyContent = "center";
    
    var card = E.el("div", "card", wrap);
    card.style.display = "flex";
    card.style.flexDirection = "column";
    card.style.boxSizing = "border-box";
    card.style.position = "relative";
    
    if (variant.layout === 0) {
      card.style.width = "880px";
      card.style.padding = "80px";
      card.style.alignItems = "flex-start";
    } else if (variant.layout === 1) {
      card.style.width = "780px";
      card.style.height = "720px";
      card.style.padding = "80px";
      card.style.alignItems = "center";
      card.style.justifyContent = "center";
      card.style.textAlign = "center";
    } else {
      card.style.width = "720px";
      card.style.padding = "100px 60px";
      card.style.alignItems = "center";
    }
    
    if (variant.accent === 2) {
      card.style.background = "#E8EEFF";
    }
    
    if (params.badge) {
      var badge = E.el("div", "", card, E.rich(params.badge));
      badge.style.background = variant.accent === 0 ? E.C.blue : E.C.ink;
      badge.style.color = "#FFF";
      badge.style.padding = "12px 32px";
      badge.style.borderRadius = "24px";
      badge.style.fontSize = "36px";
      badge.style.fontWeight = "700";
      badge.style.marginBottom = "32px";
    }
    
    var title = E.el("div", "hl", card, E.rich(params.name || ""));
    title.style.fontSize = "64px";
    title.style.marginBottom = "50px";
    title.style.color = E.C.ink;
    
    var ul = E.el("ul", "", card);
    ul.style.listStyle = "none";
    ul.style.padding = "0";
    ul.style.margin = "0 0 50px 0";
    ul.style.width = "100%";
    
    var items = params.items || [];
    items.forEach(function(txt) {
      var li = E.el("li", "", ul);
      li.style.fontSize = "40px";
      li.style.color = E.C.gray;
      li.style.marginBottom = "24px";
      li.style.display = "flex";
      li.style.alignItems = "center";
      if (variant.layout === 1 || variant.layout === 2) {
        li.style.justifyContent = "center";
      }
      if (variant.accent === 1) {
        li.innerHTML = '<span style="color:' + E.C.blue + ';margin-right:16px;font-size:44px;">✔</span><span>' + E.rich(txt) + '</span>';
      } else {
        li.innerHTML = '<span style="width:12px;height:12px;border-radius:6px;background:' + E.C.line + ';margin-right:16px;"></span><span>' + E.rich(txt) + '</span>';
      }
    });
    
    if (params.price) {
      var price = E.el("div", "", card, E.rich(params.price));
      price.style.fontSize = "80px";
      price.style.fontWeight = "900";
      price.style.color = E.C.ink;
      price.style.marginTop = variant.layout === 1 ? "auto" : "0";
    }
    
    state.card = card;
    return state;
  },
  update: function(state, lt, dur, params, variant) {
    var t = (params.at && params.at[0]) ? params.at[0] : 0.5;
    var p = E.p(lt, t, 0.7);
    
    state.card.style.opacity = Math.max(0, p);
    if (variant.motion === 0) {
      state.card.style.transform = "translateY(" + (60 * (1 - p)) + "px)";
    } else if (variant.motion === 1) {
      state.card.style.clipPath = "inset(" + (100 * (1-p)) + "% 0 0 0)";
    } else {
      state.card.style.transform = "scale(" + (0.9 + 0.1 * p) + ")";
    }
  }
};

PARTS.sun_reflect = {
  build: function(area, params, variant) {
    var state = { els: [] };
    var wrap = E.el("div", "", area);
    wrap.style.position = "absolute";
    wrap.style.width = "100%";
    wrap.style.height = "100%";
    
    var cx = 460, cy = 380;
    var filmX = variant.layout === 1 ? 600 : 460;
    
    var svg = E.el("svg", "", wrap);
    svg.style.position = "absolute";
    svg.style.width = "100%";
    svg.style.height = "100%";
    svg.setAttribute("viewBox", "0 0 920 760");
    
    var f1 = document.createElementNS("http://www.w3.org/2000/svg", "rect");
    f1.setAttribute("x", filmX - 30);
    f1.setAttribute("y", cy - 300);
    f1.setAttribute("width", "60");
    f1.setAttribute("height", "600");
    f1.setAttribute("fill", variant.accent === 2 ? "#E8EEFF" : E.C.card);
    f1.setAttribute("stroke", E.C.line);
    f1.setAttribute("stroke-width", "8");
    f1.setAttribute("rx", "15");
    svg.appendChild(f1);
    
    var makePath = function(d, color) {
      var p = document.createElementNS("http://www.w3.org/2000/svg", "path");
      p.setAttribute("d", d);
      p.setAttribute("fill", "none");
      p.setAttribute("stroke", color);
      p.setAttribute("stroke-width", "12");
      p.setAttribute("stroke-linecap", "round");
      p.setAttribute("stroke-linejoin", "round");
      svg.appendChild(p);
      var len = p.getTotalLength();
      p.setAttribute("stroke-dasharray", len);
      p.setAttribute("stroke-dashoffset", len);
      return { p: p, len: len };
    };
    
    var cInc = "#FFB800";
    var cRef = E.C.blue;
    var cAbs = E.C.ink;
    var cTra = E.C.gray;
    
    var incP = makePath("M 50 " + cy + " L " + (filmX - 30) + " " + cy + " l -30 -20 m 30 20 l -30 20", cInc);
    var refP = makePath("M " + (filmX - 30) + " " + cy + " Q " + (filmX - 150) + " " + (cy - 50) + " " + (filmX - 250) + " " + (cy - 200) + " l 30 0 m -30 0 l 10 30", cRef);
    var absP = makePath("M " + filmX + " " + cy + " L " + filmX + " " + (cy + 250) + " l -20 -30 m 20 30 l 20 -30", cAbs);
    var traP = makePath("M " + (filmX + 30) + " " + cy + " L " + (filmX + 350) + " " + cy + " l -30 -20 m 30 20 l -30 20", cTra);
    
    state.paths = [incP, refP, absP, traP];
    
    var labels = params.labels || {};
    var mkLbl = function(x, y, txt, val, color) {
      var d = E.el("div", "", wrap);
      d.style.position = "absolute";
      d.style.left = x + "px";
      d.style.top = y + "px";
      d.style.transform = "translate(-50%, -50%)";
      d.style.textAlign = "center";
      d.style.opacity = "0";
      
      var t = E.el("div", "cap dim", d, E.rich(txt));
      t.style.fontSize = "36px";
      
      var v = E.el("div", "", d);
      v.style.fontSize = "80px";
      v.style.fontWeight = "900";
      v.style.color = color;
      
      var isNum = false;
      var numMatch = String(val).trim().match(/^([^\d]*)(\d+(?:\.\d+)?)([^\d]*)$/);
      if(numMatch && String(val).indexOf("~") === -1 && String(val).indexOf("-") === -1) {
          isNum = true;
      } else {
          v.innerHTML = E.rich(val);
      }
      
      state.els.push({
          el: d,
          valEl: v,
          isNum: isNum,
          numMatch: numMatch
      });
    };
    
    mkLbl(filmX - 250, cy - 280, labels.reflect || "반사율", (params.reflect || "0") + "%", cRef);
    mkLbl(filmX, cy + 330, labels.absorb || "흡수율", (params.absorb || "0") + "%", cAbs);
    mkLbl(filmX + 250, cy - 80, labels.transmit || "투과율", (params.transmit || "0") + "%", cTra);
    
    return state;
  },
  update: function(state, lt, dur, params, variant) {
    var t = (params.at && params.at[0]) ? params.at[0] : 0.5;
    
    var pInc = E.p(lt, t, 0.4);
    state.paths[0].p.setAttribute("stroke-dashoffset", state.paths[0].len * (1 - pInc));
    
    var pOut = E.p(lt, t + 0.4, 0.6);
    for (var i = 1; i <= 3; i++) {
      state.paths[i].p.setAttribute("stroke-dashoffset", state.paths[i].len * (1 - pOut));
    }
    
    state.els.forEach(function(item, i) {
      var pL = E.p(lt, t + 0.5 + i * 0.1, 0.5);
      item.el.style.opacity = Math.max(0, pL);
      
      if (variant.motion === 1) {
        item.el.style.clipPath = "inset(" + (100 * (1-pL)) + "% 0 0 0)";
        item.el.style.transform = "translate(-50%, -50%)";
      } else {
        item.el.style.transform = "translate(-50%, calc(-50% + " + (40 * (1 - pL)) + "px))";
      }
      
      if(item.isNum) {
          var num = parseFloat(item.numMatch[2]);
          var current = num * pL;
          if(num % 1 === 0) current = Math.round(current);
          else current = current.toFixed(1);
          item.valEl.innerHTML = item.numMatch[1] + current + item.numMatch[3];
      }
    });
  }
};

PARTS.glass_layers = {
  build: function(area, params, variant) {
    var state = { layers: [] };
    var layers = params.layers || [];
    
    var wrap = E.el("div", "", area);
    wrap.style.position = "absolute";
    wrap.style.width = "100%";
    wrap.style.height = "100%";
    wrap.style.display = "flex";
    
    var cx = 460, cy = 380;
    
    layers.forEach(function(ly, i) {
      var g = E.el("div", "", wrap);
      g.style.position = "absolute";
      g.style.display = "flex";
      g.style.flexDirection = "column";
      
      var box = E.el("div", "", g);
      box.style.background = variant.accent === 0 ? E.C.blue : (variant.accent === 1 ? E.C.ink : "#E8EEFF");
      box.style.border = "4px solid " + E.C.card;
      box.style.boxSizing = "border-box";
      
      var txtWrap = E.el("div", "", g);
      var nm = E.el("div", "", txtWrap, E.rich(ly.name || ""));
      nm.style.fontWeight = "700";
      nm.style.fontSize = "40px";
      nm.style.color = E.C.ink;
      nm.style.whiteSpace = "nowrap";
      
      var dc = E.el("div", "cap dim", txtWrap, E.rich(ly.desc || ""));
      dc.style.fontSize = "32px";
      dc.style.whiteSpace = "nowrap";
      
      if (variant.layout === 0) {
        var lh = 80;
        var totalH = layers.length * lh;
        var startY = cy + totalH / 2;
        g.style.left = "180px";
        g.style.top = startY + "px";
        
        box.style.width = "600px";
        box.style.height = lh + "px";
        box.style.borderRadius = "20px";
        
        txtWrap.style.position = "absolute";
        txtWrap.style.left = "640px";
        txtWrap.style.top = "10px";
        
        state.layers.push({ el: g, targetY: startY - i * lh - lh });
      } else if (variant.layout === 1) {
        var lw = 100;
        var totalW = layers.length * lw;
        var startX = cx - totalW / 2;
        g.style.top = "100px";
        g.style.left = startX + "px";
        
        box.style.width = lw + "px";
        box.style.height = "560px";
        box.style.borderRadius = "20px";
        
        txtWrap.style.position = "absolute";
        txtWrap.style.top = "580px";
        txtWrap.style.left = "50%";
        txtWrap.style.transform = "translateX(-50%)";
        txtWrap.style.textAlign = "center";
        
        state.layers.push({ el: g, targetX: startX + i * lw });
      } else {
        var ox = cx - 200;
        var oy = cy + 200;
        g.style.left = ox + "px";
        g.style.top = oy + "px";
        
        box.style.width = "400px";
        box.style.height = "500px";
        box.style.borderRadius = "30px";
        box.style.transform = "skewY(-30deg)";
        box.style.opacity = "0.8";
        box.style.background = variant.accent === 0 ? "rgba(31,91,255,0.1)" : "rgba(17,17,17,0.1)";
        box.style.border = "6px solid " + E.C.blue;
        
        txtWrap.style.position = "absolute";
        txtWrap.style.bottom = "-80px";
        txtWrap.style.left = "0";
        
        state.layers.push({ el: g, targetX: ox + i * 80, targetY: oy - i * 50 });
      }
    });
    
    return state;
  },
  update: function(state, lt, dur, params, variant) {
    var t = (params.at && params.at[0]) ? params.at[0] : 0.5;
    
    state.layers.forEach(function(item, i) {
      var p = E.p(lt, t + i * 0.3, 0.7);
      
      if (variant.layout === 0) {
        var start = item.targetY + 100;
        item.el.style.top = (start + (item.targetY - start) * p) + "px";
        item.el.style.opacity = Math.max(0, p);
      } else if (variant.layout === 1) {
        var startX = item.targetX - 100;
        item.el.style.left = (startX + (item.targetX - startX) * p) + "px";
        item.el.style.opacity = Math.max(0, p);
      } else {
        var sx = item.targetX - 50;
        var sy = item.targetY + 50;
        item.el.style.left = (sx + (item.targetX - sx) * p) + "px";
        item.el.style.top = (sy + (item.targetY - sy) * p) + "px";
        item.el.style.opacity = Math.max(0, p);
      }
    });
  }
};

PARTS.night_view = {
  build: function(area, params, variant) {
    var state = { views: [] };
    
    var wrap = E.el("div", "", area);
    wrap.style.position = "absolute";
    wrap.style.width = "100%";
    wrap.style.height = "100%";
    wrap.style.display = "flex";
    wrap.style.justifyContent = "center";
    wrap.style.alignItems = "center";
    wrap.style.gap = "40px";
    
    var leftP = params.left || { label: "타사", dark: 0.8 };
    var rightP = params.right || { label: "자사", dark: 0.2 };
    var items = [leftP, rightP];
    
    items.forEach(function(it) {
      var box = E.el("div", "card", wrap);
      box.style.width = "420px";
      box.style.height = "640px";
      box.style.position = "relative";
      box.style.overflow = "hidden";
      box.style.background = "#111";
      
      if (variant.layout === 1) box.style.borderRadius = "210px";
      
      var svg = E.el("svg", "", box);
      svg.style.position = "absolute";
      svg.style.width = "100%";
      svg.style.height = "100%";
      svg.setAttribute("viewBox", "0 0 420 640");
      svg.innerHTML = '<path d="M 210 320 L -100 640 L 520 640 Z" fill="#222"/>' +
                      '<path d="M 210 320 L 210 640" stroke="#FFF" stroke-width="6" stroke-dasharray="20 40"/>' +
                      '<rect x="160" y="480" width="100" height="60" rx="10" fill="#333"/>' +
                      '<circle cx="175" cy="510" r="10" fill="#FFB800" filter="blur(1px)"/>' +
                      '<circle cx="245" cy="510" r="10" fill="#FFB800" filter="blur(1px)"/>' +
                      '<circle cx="60" cy="220" r="25" fill="#FFF" filter="blur(12px)"/>' +
                      '<circle cx="360" cy="260" r="20" fill="#FFF" filter="blur(10px)"/>';
      
      var overlay = E.el("div", "", box);
      overlay.style.position = "absolute";
      overlay.style.width = "100%";
      overlay.style.height = "100%";
      overlay.style.background = "rgba(0,0,0," + E.clamp(it.dark, 0, 1) + ")";
      
      var lblWrap = E.el("div", "", box);
      lblWrap.style.position = "absolute";
      lblWrap.style.bottom = "50px";
      lblWrap.style.left = "0";
      lblWrap.style.width = "100%";
      lblWrap.style.textAlign = "center";
      
      var lbl = E.el("span", "", lblWrap, E.rich(it.label || ""));
      lbl.style.background = variant.accent === 0 ? E.C.blue : "#FFF";
      lbl.style.color = variant.accent === 0 ? "#FFF" : E.C.ink;
      lbl.style.padding = "12px 32px";
      lbl.style.borderRadius = "24px";
      lbl.style.fontSize = "36px";
      lbl.style.fontWeight = "700";
      
      state.views.push(box);
    });
    
    return state;
  },
  update: function(state, lt, dur, params, variant) {
    var t = (params.at && params.at[0]) ? params.at[0] : 0.5;
    
    state.views.forEach(function(box, i) {
      var p = E.p(lt, t + i * 0.3, 0.7);
      box.style.opacity = Math.max(0, p);
      if (variant.motion === 0) {
        box.style.transform = "translateY(" + (60 * (1 - p)) + "px)";
      } else if (variant.motion === 1) {
        box.style.clipPath = "inset(0 0 " + (100 * (1-p)) + "% 0)";
      } else {
        box.style.transform = "scale(" + (0.9 + 0.1 * p) + ")";
      }
    });
  }
};

PARTS.spec_table = {
  build: function(area, params, variant) {
    var state = { rows: [] };
    
    var wrap = E.el("div", "", area);
    wrap.style.position = "absolute";
    wrap.style.width = "100%";
    wrap.style.height = "100%";
    wrap.style.display = "flex";
    wrap.style.alignItems = "center";
    wrap.style.justifyContent = "center";
    
    var tableWrap = E.el("div", "", wrap);
    tableWrap.style.width = "880px";
    
    if (variant.layout === 2) {
      tableWrap.className = "card";
      tableWrap.style.padding = "60px";
    }
    
    var rowsData = params.rows || [];
    var hlRow = params.highlight_row !== undefined ? params.highlight_row : -1;
    
    rowsData.forEach(function(rData, i) {
      var r = E.el("div", "", tableWrap);
      r.style.display = "flex";
      r.style.justifyContent = "space-between";
      r.style.alignItems = "center";
      r.style.padding = "36px 30px";
      r.style.borderBottom = "2px solid " + E.C.line;
      r.style.opacity = "0";
      
      if (i === 0 && variant.layout !== 2) r.style.borderTop = "4px solid " + E.C.ink;
      if (i === rowsData.length - 1 && variant.layout !== 2) r.style.borderBottom = "4px solid " + E.C.ink;
      
      if (i === hlRow) {
        if (variant.accent === 0) {
          r.style.background = "#E8EEFF";
          r.style.borderRadius = "16px";
          r.style.borderBottom = "none";
        }
      }
      
      var col1 = E.el("div", "", r, E.rich(rData[0] || ""));
      col1.style.fontSize = "40px";
      col1.style.fontWeight = "500";
      col1.style.color = (i === hlRow && (variant.accent === 1 || variant.accent === 0)) ? E.C.blue : E.C.gray;
      
      var col2 = E.el("div", "", r, E.rich(rData[1] || ""));
      col2.style.fontSize = "48px";
      col2.style.fontWeight = "700";
      col2.style.color = (i === hlRow && (variant.accent === 0 || variant.accent === 1)) ? E.C.blue : E.C.ink;
      
      state.rows.push(r);
    });
    
    return state;
  },
  update: function(state, lt, dur, params, variant) {
    var t = (params.at && params.at[0]) ? params.at[0] : 0.5;
    
    state.rows.forEach(function(r, i) {
      var p = E.p(lt, t + i * 0.15, 0.5);
      
      r.style.opacity = Math.max(0, p);
      if (variant.motion === 0) {
        r.style.transform = "translateY(" + (40 * (1 - p)) + "px)";
      } else if (variant.motion === 1) {
        r.style.transform = "translateX(" + (-40 * (1 - p)) + "px)";
      }
    });
  }
};

PARTS.badge = {
  build: function(area, params, variant) {
    var state = {};
    
    var wrap = E.el("div", "", area);
    wrap.style.position = "absolute";
    wrap.style.width = "100%";
    wrap.style.height = "100%";
    wrap.style.display = "flex";
    wrap.style.flexDirection = "column";
    wrap.style.alignItems = "center";
    wrap.style.justifyContent = "center";
    
    var badgeW = 600, badgeH = 600;
    var shapeWrap = E.el("div", "", wrap);
    shapeWrap.style.position = "relative";
    shapeWrap.style.width = badgeW + "px";
    shapeWrap.style.height = badgeH + "px";
    shapeWrap.style.display = "flex";
    shapeWrap.style.alignItems = "center";
    shapeWrap.style.justifyContent = "center";
    shapeWrap.style.marginBottom = "50px";
    
    var svg = E.el("svg", "", shapeWrap);
    svg.style.position = "absolute";
    svg.style.width = "100%";
    svg.style.height = "100%";
    svg.setAttribute("viewBox", "0 0 600 600");
    
    var pathStr = "";
    if (variant.layout === 0) {
      pathStr = "M60,30 h480 a30,30 0 0 1 30,30 v480 a30,30 0 0 1 -30,30 h-480 a30,30 0 0 1 -30,-30 v-480 a30,30 0 0 1 30,-30 z";
    } else if (variant.layout === 1) {
      pathStr = "M300,30 a270,270 0 1,0 0,540 a270,270 0 1,0 0,-540";
    } else {
      pathStr = "M180,30 h240 l150,150 v240 l-150,150 h-240 l-150,-150 v-240 z";
    }
    
    var pBg = document.createElementNS("http://www.w3.org/2000/svg", "path");
    pBg.setAttribute("d", pathStr);
    pBg.setAttribute("fill", variant.accent === 2 ? "#E8EEFF" : E.C.card);
    svg.appendChild(pBg);
    
    var pLine = document.createElementNS("http://www.w3.org/2000/svg", "path");
    pLine.setAttribute("d", pathStr);
    pLine.setAttribute("fill", "none");
    pLine.setAttribute("stroke", variant.accent === 0 ? E.C.blue : (variant.accent === 1 ? E.C.blue : E.C.ink));
    pLine.setAttribute("stroke-width", "8");
    svg.appendChild(pLine);
    
    var len = pLine.getTotalLength();
    pLine.setAttribute("stroke-dasharray", len);
    pLine.setAttribute("stroke-dashoffset", len);
    
    var logoImg = E.el("img", "", shapeWrap);
    var logoMap = {
        "thelx": "brand/thelx_ink_dark.png",
        "lxsg": "brand/lxsg_ink_dark.png",
        "solargard_premium": "brand/solargard_premium_ink_dark.png",
        "solargard": "brand/solargard_premium_ink_dark.png",
        "motif": "brand/motif_logo_dark.png"
    };
    logoImg.src = logoMap[params.logo] || logoMap["motif"];
    logoImg.style.maxWidth = "520px";
    logoImg.style.maxHeight = "240px";
    logoImg.style.objectFit = "contain";
    logoImg.style.position = "relative";
    logoImg.style.zIndex = "10";
    
    var textWrap = E.el("div", "", wrap);
    textWrap.style.textAlign = "center";
    
    var l1 = E.el("div", "", textWrap, E.rich(params.line1 || ""));
    l1.style.fontSize = "48px";
    l1.style.fontWeight = "700";
    l1.style.color = E.C.ink;
    l1.style.marginBottom = "16px";
    
    var l2 = E.el("div", "cap dim", textWrap, E.rich(params.line2 || ""));
    l2.style.fontSize = "36px";
    
    state.shapeWrap = shapeWrap;
    state.pLine = pLine;
    state.len = len;
    state.textWrap = textWrap;
    
    return state;
  },
  update: function(state, lt, dur, params, variant) {
    var t = (params.at && params.at[0]) ? params.at[0] : 0.5;
    var p = E.p(lt, t, 0.8);
    
    state.shapeWrap.style.opacity = Math.max(0, p);
    if (variant.motion === 0) {
      state.shapeWrap.style.transform = "translateY(" + (60 * (1 - p)) + "px)";
    } else if (variant.motion === 1) {
      state.shapeWrap.style.transform = "scale(" + (0.8 + 0.2 * p) + ")";
    }
    
    var pt = E.p(lt, t + 0.3, 0.8);
    state.pLine.setAttribute("stroke-dashoffset", state.len * (1 - pt));
    
    var pText = E.p(lt, t + 0.5, 0.6);
    state.textWrap.style.opacity = Math.max(0, pText);
    state.textWrap.style.transform = "translateY(" + (30 * (1 - pText)) + "px)";
  }
};