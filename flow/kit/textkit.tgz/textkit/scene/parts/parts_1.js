window.PARTS = window.PARTS || {};

window.PARTS.count_up = {
    build(area, params, variant) {
        const wrap = window.E.el('div', '', area);
        wrap.style.position = 'absolute';
        wrap.style.width = '100%';
        wrap.style.height = '100%';
        wrap.style.display = 'flex';
        wrap.style.justifyContent = 'center';
        wrap.style.alignItems = 'center';
        
        if (variant.layout === 1) {
            wrap.style.flexDirection = 'row';
            wrap.style.gap = '60px';
        } else if (variant.layout === 2) {
            wrap.style.flexDirection = 'column';
            wrap.className = 'card';
            wrap.style.width = '840px';
            wrap.style.height = '540px';
            wrap.style.left = '40px';
            wrap.style.top = '110px';
        } else {
            wrap.style.flexDirection = 'column';
        }

        const label = window.E.el('div', 'hl', wrap);
        label.style.fontSize = '40px';
        label.style.fontWeight = '700';
        label.style.color = window.E.C.gray;
        label.innerHTML = window.E.rich(params.label || '');

        const numWrap = window.E.el('div', '', wrap);
        numWrap.style.display = 'flex';
        numWrap.style.alignItems = 'baseline';
        numWrap.style.gap = '12px';

        const num = window.E.el('div', '', numWrap);
        num.style.fontSize = '240px';
        num.style.fontWeight = '900';
        num.style.fontFamily = 'Noto Sans CJK KR';
        num.style.lineHeight = '1';
        
        if (variant.accent === 0) {
            num.style.color = window.E.C.blue;
        } else if (variant.accent === 1) {
            num.style.color = window.E.C.ink;
            numWrap.style.borderBottom = `8px solid ${window.E.C.blue}`;
        } else if (variant.accent === 2) {
            numWrap.style.backgroundColor = '#E8EEFF';
            numWrap.style.padding = '0 40px';
            numWrap.style.borderRadius = '32px';
            num.style.color = window.E.C.blue;
        }

        const unit = window.E.el('div', '', numWrap);
        unit.style.fontSize = '80px';
        unit.style.fontWeight = '700';
        unit.style.color = window.E.C.gray;
        unit.innerHTML = window.E.rich(params.unit || '%');

        const cap = window.E.el('div', 'cap', wrap);
        cap.style.marginTop = '24px';
        cap.style.fontSize = '36px';
        cap.innerHTML = window.E.rich(params.caption || '');

        return { wrap, label, numWrap, num, unit, cap };
    },
    update(state, lt, dur, params, variant) {
        const t = params.at && params.at[0] !== undefined ? params.at[0] : 0.5;
        const k = window.E.clamp(window.E.easeOut(window.E.p(lt, t, 1.2)), 0, 1);
        
        const toVal = params.value !== undefined ? params.value : 0;
        const isNum = !isNaN(Number(toVal));
        
        if (isNum) {
            const from = params.from || 0;
            const to = Number(toVal);
            const dec = params.decimals || 0;
            const cur = from + (to - from) * k;
            state.num.innerHTML = window.E.fmtNum(cur, dec);
        } else {
            state.num.innerHTML = toVal;
        }
        
        if (variant.motion === 0) {
            state.wrap.style.transform = `translateY(${60 * (1 - k)}px)`;
            state.wrap.style.opacity = k;
        } else if (variant.motion === 1) {
            state.wrap.style.clipPath = `inset(0 ${100 * (1 - k)}% 0 0)`;
            state.wrap.style.opacity = k;
        } else if (variant.motion === 2) {
            state.wrap.style.transform = `scale(${0.94 + 0.06 * k})`;
            state.wrap.style.opacity = k;
        }
    }
};

window.PARTS.ring_gauge = {
    build(area, params, variant) {
        const wrap = window.E.el('div', '', area);
        wrap.style.position = 'absolute';
        wrap.style.width = '100%';
        wrap.style.height = '100%';
        wrap.style.display = 'flex';
        wrap.style.flexDirection = 'column';
        wrap.style.justifyContent = 'center';
        wrap.style.alignItems = 'center';
        
        if (variant.layout === 2) {
            wrap.className = 'card';
            wrap.style.width = '840px';
            wrap.style.height = '600px';
            wrap.style.left = '40px';
            wrap.style.top = '80px';
        }

        const svgWrap = window.E.el('div', '', wrap);
        svgWrap.style.position = 'relative';
        svgWrap.style.width = '500px';
        svgWrap.style.height = '500px';

        const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        svg.setAttribute('viewBox', '0 0 500 500');
        svg.style.width = '100%';
        svg.style.height = '100%';
        svg.style.transform = 'rotate(-90deg)';
        svgWrap.appendChild(svg);

        const bg = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        bg.setAttribute('cx', '250');
        bg.setAttribute('cy', '250');
        bg.setAttribute('r', '210');
        bg.setAttribute('fill', 'none');
        bg.setAttribute('stroke', window.E.C.line);
        bg.setAttribute('stroke-width', '32');
        svg.appendChild(bg);

        const fg = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        fg.setAttribute('cx', '250');
        fg.setAttribute('cy', '250');
        fg.setAttribute('r', '210');
        fg.setAttribute('fill', 'none');
        fg.setAttribute('stroke', variant.accent === 0 ? window.E.C.blue : (variant.accent === 1 ? window.E.C.blue : window.E.C.ink));
        fg.setAttribute('stroke-width', '32');
        fg.setAttribute('stroke-linecap', 'round');
        svg.appendChild(fg);

        const centerText = window.E.el('div', '', svgWrap);
        centerText.style.position = 'absolute';
        centerText.style.top = '0';
        centerText.style.left = '0';
        centerText.style.width = '100%';
        centerText.style.height = '100%';
        centerText.style.display = 'flex';
        centerText.style.flexDirection = 'column';
        centerText.style.justifyContent = 'center';
        centerText.style.alignItems = 'center';

        const val = window.E.el('div', '', centerText);
        val.style.fontSize = '200px';
        val.style.fontWeight = '900';
        val.style.color = window.E.C.ink;
        if(variant.accent === 2) {
            val.style.backgroundColor = '#E8EEFF';
            val.style.padding = '0 20px';
            val.style.borderRadius = '16px';
            val.style.color = window.E.C.blue;
        }

        const label = window.E.el('div', 'hl', wrap);
        label.style.marginTop = '40px';
        label.style.fontSize = '40px';
        label.innerHTML = window.E.rich(params.label || '');

        const cap = window.E.el('div', 'cap', wrap);
        cap.style.marginTop = '16px';
        cap.style.fontSize = '36px';
        cap.innerHTML = window.E.rich(params.caption || '');

        return { wrap, fg, val };
    },
    update(state, lt, dur, params, variant) {
        const t = params.at && params.at[0] !== undefined ? params.at[0] : 0.5;
        const k = window.E.clamp(window.E.easeOut(window.E.p(lt, t, 1)), 0, 1);
        
        const r = 210;
        const circ = 2 * Math.PI * r;
        
        const valToParse = params.value !== undefined ? params.value : 0;
        const isNum = !isNaN(Number(valToParse));
        const v = isNum ? Number(valToParse) : 100;
        const targetLen = circ * (v / 100);
        
        state.fg.setAttribute('stroke-dasharray', `${circ}`);
        state.fg.setAttribute('stroke-dashoffset', `${circ - targetLen * k}`);
        
        if (isNum) {
            state.val.innerHTML = window.E.fmtNum(v * k, 0) + '%';
        } else {
            state.val.innerHTML = valToParse;
        }
        
        if (variant.motion === 0) {
            state.wrap.style.transform = `translateY(${40 * (1 - k)}px)`;
            state.wrap.style.opacity = k;
        } else if (variant.motion === 1) {
            state.wrap.style.clipPath = `inset(0 ${100 * (1 - k)}% 0 0)`;
            state.wrap.style.opacity = k;
        } else if (variant.motion === 2) {
            state.wrap.style.transform = `scale(${0.94 + 0.06 * k})`;
            state.wrap.style.opacity = k;
        }
    }
};

window.PARTS.half_gauge = {
    build(area, params, variant) {
        const wrap = window.E.el('div', '', area);
        wrap.style.position = 'absolute';
        wrap.style.width = '100%';
        wrap.style.height = '100%';
        wrap.style.display = 'flex';
        wrap.style.flexDirection = 'column';
        wrap.style.justifyContent = 'center';
        wrap.style.alignItems = 'center';

        if (variant.layout === 2) {
            wrap.className = 'card';
            wrap.style.width = '840px';
            wrap.style.height = '540px';
            wrap.style.left = '40px';
            wrap.style.top = '110px';
        }

        const label = window.E.el('div', 'hl', wrap);
        label.style.marginBottom = '32px';
        label.style.fontSize = '40px';
        label.innerHTML = window.E.rich(params.label || '');
        if(variant.accent === 1) {
            label.style.borderBottom = `4px solid ${window.E.C.blue}`;
        } else if (variant.accent === 2) {
            label.style.backgroundColor = '#E8EEFF';
            label.style.padding = '12px 24px';
            label.style.borderRadius = '16px';
            label.style.color = window.E.C.blue;
        }

        const svgWrap = window.E.el('div', '', wrap);
        svgWrap.style.position = 'relative';
        svgWrap.style.width = '700px';
        svgWrap.style.height = '400px';

        const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        svg.setAttribute('viewBox', '0 0 700 400');
        svg.style.width = '100%';
        svg.style.height = '100%';
        svgWrap.appendChild(svg);

        const bg = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        bg.setAttribute('d', 'M 50 350 A 300 300 0 0 1 650 350');
        bg.setAttribute('fill', 'none');
        bg.setAttribute('stroke', window.E.C.line);
        bg.setAttribute('stroke-width', '40');
        svg.appendChild(bg);

        const fg = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        fg.setAttribute('d', 'M 50 350 A 300 300 0 0 1 650 350');
        fg.setAttribute('fill', 'none');
        fg.setAttribute('stroke', variant.accent === 0 ? window.E.C.blue : window.E.C.ink);
        fg.setAttribute('stroke-width', '40');
        fg.setAttribute('stroke-linecap', 'round');
        svg.appendChild(fg);

        const needle = document.createElementNS('http://www.w3.org/2000/svg', 'polygon');
        needle.setAttribute('points', '340,350 360,350 350,50');
        needle.setAttribute('fill', window.E.C.blue);
        svg.appendChild(needle);
        
        const dot = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        dot.setAttribute('cx', '350');
        dot.setAttribute('cy', '350');
        dot.setAttribute('r', '20');
        dot.setAttribute('fill', window.E.C.ink);
        svg.appendChild(dot);

        const minL = window.E.el('div', 'cap', svgWrap);
        minL.style.position = 'absolute';
        minL.style.left = '20px';
        minL.style.bottom = '10px';
        minL.style.fontSize = '36px';
        minL.innerHTML = window.E.rich(params.min_label || '0');

        const maxL = window.E.el('div', 'cap', svgWrap);
        maxL.style.position = 'absolute';
        maxL.style.right = '20px';
        maxL.style.bottom = '10px';
        maxL.style.fontSize = '36px';
        maxL.innerHTML = window.E.rich(params.max_label || '100');

        return { wrap, fg, needle };
    },
    update(state, lt, dur, params, variant) {
        const t = params.at && params.at[0] !== undefined ? params.at[0] : 0.5;
        const k = window.E.clamp(window.E.easeOut(window.E.p(lt, t, 1)), 0, 1);
        
        const valToParse = params.value !== undefined ? params.value : 0;
        const isNum = !isNaN(Number(valToParse));
        const v = isNum ? Number(valToParse) : 100;
        
        const circ = Math.PI * 300;
        const targetLen = circ * (v / 100);
        
        state.fg.setAttribute('stroke-dasharray', `${circ}`);
        state.fg.setAttribute('stroke-dashoffset', `${circ - targetLen * k}`);
        
        const angle = (v * k / 100) * 180 - 90;
        state.needle.setAttribute('transform', `rotate(${angle}, 350, 350)`);
        
        if (variant.motion === 0) {
            state.wrap.style.transform = `translateY(${40 * (1 - k)}px)`;
            state.wrap.style.opacity = k;
        } else if (variant.motion === 1) {
            state.wrap.style.clipPath = `inset(0 ${100 * (1 - k)}% 0 0)`;
            state.wrap.style.opacity = k;
        } else if (variant.motion === 2) {
            state.wrap.style.transform = `scale(${0.94 + 0.06 * k})`;
            state.wrap.style.opacity = k;
        }
    }
};

window.PARTS.odometer = {
    build(area, params, variant) {
        const wrap = window.E.el('div', '', area);
        wrap.style.position = 'absolute';
        wrap.style.width = '100%';
        wrap.style.height = '100%';
        wrap.style.display = 'flex';
        wrap.style.flexDirection = 'column';
        wrap.style.justifyContent = 'center';
        wrap.style.alignItems = 'center';
        
        if (variant.layout === 2) {
            wrap.className = 'card';
            wrap.style.width = '840px';
            wrap.style.height = '500px';
            wrap.style.left = '40px';
            wrap.style.top = '130px';
        }

        const label = window.E.el('div', 'hl', wrap);
        label.style.marginBottom = '32px';
        label.style.fontSize = '40px';
        label.innerHTML = window.E.rich(params.label || '');
        if(variant.accent === 1) {
            label.style.borderBottom = `4px solid ${window.E.C.blue}`;
        }

        const valWrap = window.E.el('div', '', wrap);
        valWrap.style.display = 'flex';
        valWrap.style.alignItems = 'baseline';
        valWrap.style.fontSize = '240px';
        valWrap.style.fontWeight = '900';
        valWrap.style.fontFamily = 'Noto Sans CJK KR';
        valWrap.style.lineHeight = '1';
        valWrap.style.color = variant.accent === 0 ? window.E.C.blue : window.E.C.ink;
        
        if(variant.accent === 2) {
            valWrap.style.backgroundColor = '#E8EEFF';
            valWrap.style.padding = '24px 48px';
            valWrap.style.borderRadius = '32px';
            valWrap.style.color = window.E.C.blue;
        }

        const strVal = String(params.value || 0);
        const isNum = !isNaN(Number(strVal));
        const digits = [];

        if (isNum) {
            const chars = strVal.split('');
            chars.forEach(ch => {
                if (/[0-9]/.test(ch)) {
                    const col = window.E.el('div', '', valWrap);
                    col.style.display = 'inline-flex';
                    col.style.flexDirection = 'column';
                    col.style.height = '240px';
                    col.style.overflow = 'hidden';
                    
                    const strip = window.E.el('div', '', col);
                    strip.style.display = 'flex';
                    strip.style.flexDirection = 'column';
                    strip.style.willChange = 'transform';
                    
                    for(let i=0; i<=9; i++) {
                        const d = window.E.el('div', '', strip);
                        d.style.height = '240px';
                        d.style.display = 'flex';
                        d.style.alignItems = 'center';
                        d.style.justifyContent = 'center';
                        d.innerHTML = i;
                    }
                    digits.push({ strip, target: parseInt(ch, 10) });
                } else {
                    const staticChar = window.E.el('div', '', valWrap);
                    staticChar.style.height = '240px';
                    staticChar.style.display = 'flex';
                    staticChar.style.alignItems = 'center';
                    staticChar.innerHTML = ch;
                }
            });
        } else {
            const staticText = window.E.el('div', '', valWrap);
            staticText.style.height = '240px';
            staticText.style.display = 'flex';
            staticText.style.alignItems = 'center';
            staticText.innerHTML = strVal;
        }

        if (params.unit) {
            const unit = window.E.el('div', '', valWrap);
            unit.style.fontSize = '80px';
            unit.style.fontWeight = '700';
            unit.style.marginLeft = '24px';
            unit.style.color = window.E.C.gray;
            unit.innerHTML = window.E.rich(params.unit);
        }

        return { wrap, digits };
    },
    update(state, lt, dur, params, variant) {
        const t = params.at && params.at[0] !== undefined ? params.at[0] : 0.5;
        const mainK = window.E.clamp(window.E.easeOut(window.E.p(lt, t, 1.2)), 0, 1);
        
        state.digits.forEach((dObj, i) => {
            const dk = window.E.clamp(window.E.easeOut(window.E.p(lt, t + i * 0.1, 1.0)), 0, 1);
            const moveY = -(dObj.target * 240 * dk);
            dObj.strip.style.transform = `translateY(${moveY}px)`;
        });

        if (variant.motion === 0) {
            state.wrap.style.transform = `translateY(${60 * (1 - mainK)}px)`;
            state.wrap.style.opacity = mainK;
        } else if (variant.motion === 1) {
            state.wrap.style.clipPath = `inset(0 ${100 * (1 - mainK)}% 0 0)`;
            state.wrap.style.opacity = mainK;
        } else if (variant.motion === 2) {
            state.wrap.style.transform = `scale(${0.94 + 0.06 * mainK})`;
            state.wrap.style.opacity = mainK;
        }
    }
};

window.PARTS.before_after_num = {
    build(area, params, variant) {
        const wrap = window.E.el('div', '', area);
        wrap.style.position = 'absolute';
        wrap.style.width = '100%';
        wrap.style.height = '100%';
        wrap.style.display = 'flex';
        wrap.style.justifyContent = 'center';
        wrap.style.alignItems = 'center';
        wrap.style.gap = '60px';

        if (variant.layout === 2) {
            wrap.className = 'card';
            wrap.style.width = '840px';
            wrap.style.height = '500px';
            wrap.style.left = '40px';
            wrap.style.top = '130px';
            wrap.style.flexDirection = 'column';
            wrap.style.gap = '40px';
        } else if (variant.layout === 1) {
            wrap.style.alignItems = 'flex-end';
        }

        const buildBlock = (data, isAfter) => {
            const b = window.E.el('div', '', wrap);
            b.style.display = 'flex';
            b.style.flexDirection = 'column';
            b.style.alignItems = 'center';
            if(variant.layout === 2) {
                b.style.flexDirection = 'row';
                b.style.width = '100%';
                b.style.justifyContent = 'space-between';
                b.style.padding = '0 60px';
                b.style.boxSizing = 'border-box';
            }

            const l = window.E.el('div', 'cap', b);
            l.style.fontSize = '40px';
            l.style.marginBottom = variant.layout === 2 ? '0' : '16px';
            l.innerHTML = window.E.rich(data.label || '');

            const vWrap = window.E.el('div', '', b);
            vWrap.style.display = 'flex';
            vWrap.style.alignItems = 'baseline';

            const v = window.E.el('div', '', vWrap);
            v.style.fontSize = '200px';
            v.style.fontWeight = '900';
            v.style.color = isAfter ? window.E.C.blue : window.E.C.gray;
            
            const isNum = !isNaN(Number(data.value));
            if (isNum) {
                v.innerHTML = window.E.fmtNum(Number(data.value), 0);
            } else {
                v.innerHTML = data.value || '';
            }

            if(isAfter && variant.accent === 1) {
                vWrap.style.borderBottom = `8px solid ${window.E.C.blue}`;
            } else if (isAfter && variant.accent === 2) {
                vWrap.style.backgroundColor = '#E8EEFF';
                vWrap.style.padding = '8px 24px';
                vWrap.style.borderRadius = '16px';
                v.style.color = window.E.C.blue;
            }

            const u = window.E.el('div', '', vWrap);
            u.style.fontSize = '60px';
            u.style.marginLeft = '16px';
            u.style.fontWeight = '700';
            u.style.color = isAfter ? window.E.C.ink : window.E.C.gray;
            u.innerHTML = window.E.rich(data.unit || '');

            return b;
        };

        const b1 = buildBlock(params.before || {}, false);

        const arrowWrap = window.E.el('div', '', wrap);
        arrowWrap.style.display = 'flex';
        arrowWrap.style.flexDirection = 'column';
        arrowWrap.style.alignItems = 'center';
        
        const aTxt = window.E.el('div', 'cap', arrowWrap);
        aTxt.style.fontSize = '36px';
        aTxt.style.color = window.E.C.blue;
        aTxt.innerHTML = window.E.rich(params.arrow_text || '');

        const arrow = window.E.el('div', '', arrowWrap);
        arrow.style.fontSize = '60px';
        arrow.style.color = window.E.C.line;
        arrow.innerHTML = variant.layout === 2 ? '▼' : '▶';

        const b2 = buildBlock(params.after || {}, true);

        return { wrap, b1, arrowWrap, b2 };
    },
    update(state, lt, dur, params, variant) {
        const t1 = params.at && params.at[0] !== undefined ? params.at[0] : 0.5;
        const t2 = t1 + 0.3;
        const t3 = t2 + 0.3;

        const k1 = window.E.clamp(window.E.easeOut(window.E.p(lt, t1, 0.8)), 0, 1);
        const k2 = window.E.clamp(window.E.easeOut(window.E.p(lt, t2, 0.8)), 0, 1);
        const k3 = window.E.clamp(window.E.easeOut(window.E.p(lt, t3, 0.8)), 0, 1);

        state.b1.style.opacity = k1;
        state.b1.style.transform = `translateY(${20*(1-k1)}px)`;

        state.arrowWrap.style.opacity = k2;
        state.arrowWrap.style.transform = `translateY(${20*(1-k2)}px)`;

        state.b2.style.opacity = k3;
        state.b2.style.transform = `translateY(${20*(1-k3)}px)`;
        
        if(variant.motion === 1) {
            state.wrap.style.clipPath = `inset(0 ${100 * (1 - k3)}% 0 0)`;
        } else if (variant.motion === 2) {
            state.wrap.style.transform = `scale(${0.94 + 0.06 * k3})`;
        }
    }
};

window.PARTS.hbar = {
    build(area, params, variant) {
        const wrap = window.E.el('div', '', area);
        wrap.style.position = 'absolute';
        wrap.style.width = '100%';
        wrap.style.height = '100%';
        wrap.style.display = 'flex';
        wrap.style.flexDirection = 'column';
        wrap.style.justifyContent = 'center';
        wrap.style.padding = '0 60px';
        wrap.style.boxSizing = 'border-box';
        
        if (variant.layout === 2) {
            wrap.className = 'card';
            wrap.style.width = '840px';
            wrap.style.height = '600px';
            wrap.style.left = '40px';
            wrap.style.top = '80px';
            wrap.style.padding = '60px';
        }

        const items = params.items || [];
        const max = params.max || 100;
        const barHeights = variant.layout === 1 ? '70px' : '50px';

        const bars = [];
        items.forEach(item => {
            const row = window.E.el('div', '', wrap);
            row.style.display = 'flex';
            row.style.alignItems = 'center';
            row.style.marginBottom = '40px';
            row.style.width = '100%';

            const lbl = window.E.el('div', 'hl', row);
            lbl.style.width = '180px';
            lbl.style.fontSize = '40px';
            lbl.style.textAlign = 'right';
            lbl.style.marginRight = '24px';
            lbl.innerHTML = window.E.rich(item.label || '');

            const barWrap = window.E.el('div', '', row);
            barWrap.style.flex = '1';
            barWrap.style.height = barHeights;
            barWrap.style.backgroundColor = window.E.C.line;
            barWrap.style.borderRadius = '24px';
            barWrap.style.overflow = 'hidden';
            barWrap.style.position = 'relative';

            const fill = window.E.el('div', '', barWrap);
            fill.style.height = '100%';
            fill.style.width = '0%';
            fill.style.borderRadius = '24px';
            
            let color = window.E.C.gray;
            if (item.highlight) {
                color = variant.accent === 0 ? window.E.C.blue : (variant.accent === 1 ? window.E.C.blue : window.E.C.ink);
            }
            fill.style.backgroundColor = color;

            const disp = window.E.el('div', '', row);
            disp.style.width = '160px';
            disp.style.marginLeft = '24px';
            disp.style.fontSize = '48px';
            disp.style.fontWeight = '900';
            disp.style.color = item.highlight ? color : window.E.C.ink;
            if(item.highlight && variant.accent === 2) {
                disp.style.backgroundColor = '#E8EEFF';
                disp.style.padding = '8px 16px';
                disp.style.borderRadius = '12px';
                disp.style.color = window.E.C.blue;
            }
            disp.innerHTML = window.E.rich(item.display || '');

            bars.push({ fill, targetW: (item.value / max) * 100 });
        });

        const cap = window.E.el('div', 'cap', wrap);
        cap.style.textAlign = 'center';
        cap.style.marginTop = '24px';
        cap.style.fontSize = '36px';
        cap.innerHTML = window.E.rich(params.caption || '');

        return { wrap, bars };
    },
    update(state, lt, dur, params, variant) {
        const t = params.at && params.at[0] !== undefined ? params.at[0] : 0.5;
        let mainK = window.E.clamp(window.E.easeOut(window.E.p(lt, t, 1.2)), 0, 1);
        
        state.bars.forEach((b, i) => {
            const k = window.E.clamp(window.E.easeOut(window.E.p(lt, t + i * 0.15, 0.8)), 0, 1);
            b.fill.style.width = `${b.targetW * k}%`;
        });
        
        if (variant.motion === 0) {
            state.wrap.style.transform = `translateY(${40 * (1 - mainK)}px)`;
            state.wrap.style.opacity = mainK;
        } else if (variant.motion === 1) {
            state.wrap.style.clipPath = `inset(0 ${100 * (1 - mainK)}% 0 0)`;
            state.wrap.style.opacity = mainK;
        } else if (variant.motion === 2) {
            state.wrap.style.transform = `scale(${0.94 + 0.06 * mainK})`;
            state.wrap.style.opacity = mainK;
        }
    }
};

window.PARTS.vbar = {
    build(area, params, variant) {
        const wrap = window.E.el('div', '', area);
        wrap.style.position = 'absolute';
        wrap.style.width = '100%';
        wrap.style.height = '100%';
        wrap.style.display = 'flex';
        wrap.style.flexDirection = 'column';
        wrap.style.justifyContent = 'flex-end';
        wrap.style.alignItems = 'center';
        wrap.style.paddingBottom = '100px';
        wrap.style.boxSizing = 'border-box';

        if (variant.layout === 2) {
            wrap.className = 'card';
            wrap.style.width = '840px';
            wrap.style.height = '600px';
            wrap.style.left = '40px';
            wrap.style.top = '80px';
            wrap.style.paddingBottom = '60px';
        }

        const cap = window.E.el('div', 'cap', wrap);
        cap.style.position = 'absolute';
        cap.style.top = '40px';
        cap.style.fontSize = '36px';
        cap.innerHTML = window.E.rich(params.caption || '');

        const chartWrap = window.E.el('div', '', wrap);
        chartWrap.style.display = 'flex';
        chartWrap.style.alignItems = 'flex-end';
        chartWrap.style.justifyContent = 'center';
        chartWrap.style.gap = variant.layout === 1 ? '80px' : '60px';
        chartWrap.style.height = '420px';
        chartWrap.style.width = '100%';

        const items = params.items || [];
        const max = params.max || 100;
        const bars = [];

        items.forEach(item => {
            const col = window.E.el('div', '', chartWrap);
            col.style.display = 'flex';
            col.style.flexDirection = 'column';
            col.style.alignItems = 'center';
            col.style.height = '100%';
            col.style.justifyContent = 'flex-end';

            const disp = window.E.el('div', '', col);
            disp.style.fontSize = '40px';
            disp.style.fontWeight = '900';
            disp.style.marginBottom = '16px';
            let color = item.highlight ? (variant.accent === 0 ? window.E.C.blue : (variant.accent === 1 ? window.E.C.blue : window.E.C.ink)) : window.E.C.gray;
            disp.style.color = color;
            if(item.highlight && variant.accent === 2) {
                disp.style.backgroundColor = '#E8EEFF';
                disp.style.padding = '8px 16px';
                disp.style.borderRadius = '12px';
                disp.style.color = window.E.C.blue;
            }
            disp.innerHTML = window.E.rich(item.display || '');

            const barWrap = window.E.el('div', '', col);
            barWrap.style.width = variant.layout === 1 ? '100px' : '80px';
            barWrap.style.height = '320px';
            barWrap.style.backgroundColor = window.E.C.line;
            barWrap.style.borderRadius = '24px 24px 0 0';
            barWrap.style.position = 'relative';
            barWrap.style.display = 'flex';
            barWrap.style.alignItems = 'flex-end';
            barWrap.style.overflow = 'hidden';

            const fill = window.E.el('div', '', barWrap);
            fill.style.width = '100%';
            fill.style.height = '0%';
            fill.style.backgroundColor = color;

            const lbl = window.E.el('div', 'hl', col);
            lbl.style.marginTop = '20px';
            lbl.style.fontSize = '36px';
            lbl.innerHTML = window.E.rich(item.label || '');

            bars.push({ fill, targetH: (item.value / max) * 100, disp, col });
        });

        return { wrap, bars };
    },
    update(state, lt, dur, params, variant) {
        const t = params.at && params.at[0] !== undefined ? params.at[0] : 0.5;
        const mainK = window.E.clamp(window.E.easeOut(window.E.p(lt, t, 1.2)), 0, 1);

        state.bars.forEach((b, i) => {
            const k = window.E.clamp(window.E.easeOut(window.E.p(lt, t + i * 0.1, 0.8)), 0, 1);
            b.fill.style.height = `${b.targetH * k}%`;
            b.disp.style.opacity = k;
            b.disp.style.transform = `translateY(${10 * (1 - k)}px)`;
        });

        if (variant.motion === 0) {
            state.wrap.style.transform = `translateY(${60 * (1 - mainK)}px)`;
            state.wrap.style.opacity = mainK;
        } else if (variant.motion === 1) {
            state.wrap.style.clipPath = `inset(${100 * (1 - mainK)}% 0 0 0)`;
            state.wrap.style.opacity = mainK;
        } else if (variant.motion === 2) {
            state.wrap.style.transform = `scale(${0.94 + 0.06 * mainK})`;
            state.wrap.style.opacity = mainK;
        }
    }
};

window.PARTS.line_trend = {
    build(area, params, variant) {
        const wrap = window.E.el('div', '', area);
        wrap.style.position = 'absolute';
        wrap.style.width = '100%';
        wrap.style.height = '100%';
        wrap.style.display = 'flex';
        wrap.style.flexDirection = 'column';
        wrap.style.alignItems = 'center';
        wrap.style.justifyContent = 'center';

        if (variant.layout === 2) {
            wrap.className = 'card';
            wrap.style.width = '840px';
            wrap.style.height = '600px';
            wrap.style.left = '40px';
            wrap.style.top = '80px';
        }

        const pts = params.points || [];
        const lbls = params.labels || [];
        const hIdx = params.highlight_index !== undefined ? params.highlight_index : pts.length - 1;

        const maxV = Math.max(...pts, 1);
        const minV = Math.min(...pts, 0);
        const range = maxV - minV || 1;

        const svgWrap = window.E.el('div', '', wrap);
        svgWrap.style.position = 'relative';
        svgWrap.style.width = '800px';
        svgWrap.style.height = '460px';

        const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        svg.setAttribute('viewBox', '0 0 800 460');
        svg.style.width = '100%';
        svg.style.height = '100%';
        svgWrap.appendChild(svg);

        const w = 700, h = 300;
        const ox = 50, oy = 380;
        const gap = pts.length > 1 ? w / (pts.length - 1) : w;

        let d = '';
        const coords = [];
        pts.forEach((v, i) => {
            const cx = ox + i * gap;
            const cy = oy - ((v - minV) / range) * h;
            coords.push({x: cx, y: cy, v, lbl: lbls[i]});
            if(i===0) d += `M ${cx} ${cy} `;
            else d += `L ${cx} ${cy} `;
        });

        const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        path.setAttribute('d', d);
        path.setAttribute('fill', 'none');
        path.setAttribute('stroke', variant.accent === 0 ? window.E.C.blue : window.E.C.ink);
        path.setAttribute('stroke-width', variant.layout === 1 ? '16' : '10');
        path.setAttribute('stroke-linecap', 'round');
        path.setAttribute('stroke-linejoin', 'round');
        svg.appendChild(path);

        const len = path.getTotalLength() || 1500;
        path.setAttribute('stroke-dasharray', len);
        path.setAttribute('stroke-dashoffset', len);

        const dots = [];
        coords.forEach((c, i) => {
            const isH = (i === hIdx);
            const color = isH ? window.E.C.blue : window.E.C.line;
            const radius = isH ? (variant.layout === 1 ? '18' : '14') : '8';

            const dot = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
            dot.setAttribute('cx', c.x);
            dot.setAttribute('cy', c.y);
            dot.setAttribute('r', radius);
            dot.setAttribute('fill', color);
            svg.appendChild(dot);

            const vText = window.E.el('div', '', svgWrap);
            vText.style.position = 'absolute';
            vText.style.left = `${c.x}px`;
            vText.style.top = `${c.y - 48}px`;
            vText.style.transform = 'translate(-50%, -100%)';
            vText.style.fontSize = isH ? '44px' : '36px';
            vText.style.fontWeight = isH ? '900' : '500';
            vText.style.color = isH ? window.E.C.blue : window.E.C.gray;
            if (isH && variant.accent === 2) {
                vText.style.backgroundColor = '#E8EEFF';
                vText.style.padding = '8px 16px';
                vText.style.borderRadius = '12px';
            } else if (isH && variant.accent === 1) {
                vText.style.borderBottom = `6px solid ${window.E.C.blue}`;
            }
            vText.innerHTML = window.E.fmtNum(c.v, 0) + (params.unit || '');

            const lText = window.E.el('div', 'cap', svgWrap);
            lText.style.position = 'absolute';
            lText.style.left = `${c.x}px`;
            lText.style.top = `${oy + 24}px`;
            lText.style.transform = 'translate(-50%, 0)';
            lText.style.fontSize = '36px';
            lText.innerHTML = window.E.rich(c.lbl || '');

            dots.push({dot, vText, lText, x: c.x});
        });

        const cap = window.E.el('div', 'cap', wrap);
        cap.style.marginTop = '24px';
        cap.style.fontSize = '36px';
        cap.innerHTML = window.E.rich(params.caption || '');

        return { wrap, path, len, dots, w, ox };
    },
    update(state, lt, dur, params, variant) {
        const t = params.at && params.at[0] !== undefined ? params.at[0] : 0.5;
        const mainK = window.E.clamp(window.E.easeOut(window.E.p(lt, t, 1.5)), 0, 1);

        state.path.setAttribute('stroke-dashoffset', state.len * (1 - mainK));

        const curX = state.ox + state.w * mainK;

        state.dots.forEach(d => {
            let opacity = 0;
            if (curX >= d.x) opacity = 1;
            d.dot.style.opacity = opacity;
            d.vText.style.opacity = opacity;
            d.lText.style.opacity = opacity;
        });

        if (variant.motion === 0) {
            state.wrap.style.transform = `translateY(${40 * (1 - mainK)}px)`;
            state.wrap.style.opacity = mainK;
        } else if (variant.motion === 1) {
            state.wrap.style.clipPath = `inset(0 ${100 * (1 - mainK)}% 0 0)`;
            state.wrap.style.opacity = mainK;
        } else if (variant.motion === 2) {
            state.wrap.style.transform = `scale(${0.94 + 0.06 * mainK})`;
            state.wrap.style.opacity = mainK;
        }
    }
};