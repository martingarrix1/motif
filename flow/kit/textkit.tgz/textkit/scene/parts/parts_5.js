window.PARTS = window.PARTS || {};

PARTS.strike_correct = {
  build(area, params, variant) {
    const p = { prefix: '이전 정보', wrong: '잘못된 내용', right: '올바른 내용', ...params };
    const align = variant.layout === 0 ? 'flex-start' : variant.layout === 1 ? 'center' : 'flex-end';
    
    area.style.display = 'flex';
    area.style.flexDirection = 'column';
    area.style.justifyContent = 'center';
    area.style.alignItems = align;
    area.style.padding = '0 40px';
    area.style.boxSizing = 'border-box';
    
    const wrapper = E.el('div', '', area);
    wrapper.style.display = 'flex';
    wrapper.style.flexDirection = 'column';
    wrapper.style.alignItems = align;
    wrapper.style.width = '100%';
    
    const l1 = E.el('div', '', wrapper, p.prefix);
    l1.style.fontSize = '64px';
    l1.style.fontWeight = '500';
    l1.style.color = E.C.ink;
    l1.style.whiteSpace = 'nowrap';
    
    const l2 = E.el('div', '', wrapper);
    l2.style.fontSize = '110px';
    l2.style.fontWeight = '700';
    l2.style.color = E.C.gray;
    l2.style.whiteSpace = 'nowrap';
    l2.style.position = 'relative';
    l2.style.marginTop = '20px';
    
    const l2Txt = E.el('span', '', l2, p.wrong);
    const strike = E.el('div', '', l2);
    strike.style.position = 'absolute';
    strike.style.left = '0';
    strike.style.top = '50%';
    strike.style.height = variant.accent === 2 ? '12px' : '8px';
    strike.style.backgroundColor = E.C.red;
    strike.style.transform = 'translateY(-50%)';
    strike.style.transformOrigin = 'left center';
    
    const l3 = E.el('div', '', wrapper);
    l3.style.fontSize = '120px';
    l3.style.fontWeight = '900';
    l3.style.color = E.C.blue;
    l3.style.whiteSpace = 'nowrap';
    l3.style.position = 'relative';
    l3.style.marginTop = '20px';
    
    const l3Txt = E.el('span', '', l3, '→ ' + p.right);
    const under = E.el('div', '', l3);
    under.style.position = 'absolute';
    under.style.left = '0';
    under.style.bottom = '10px';
    under.style.height = variant.accent === 1 ? '16px' : '10px';
    under.style.backgroundColor = E.C.blue;
    under.style.transformOrigin = 'left center';
    
    return { wrapper, l1, l2, strike, l3, under, align };
  },
  update(state, lt, dur, params, variant) {
    const k1 = E.p(lt, 0, 0.4);
    const k2 = E.p(lt, 0.2, 0.5);
    const k3 = E.p(lt, 0.6, 0.4);
    const k4 = E.p(lt, 0.8, 0.4);
    const k5 = E.p(lt, 1.0, 0.4);
    
    state.l1.style.opacity = k1;
    state.l1.style.transform = `translateY(${40 - k1*40}px)`;
    
    state.l2.style.opacity = k2;
    state.l2.style.transform = `translateY(${40 - k2*40}px)`;
    state.strike.style.width = `${k3 * 100}%`;
    
    state.l3.style.opacity = k4;
    state.l3.style.transform = `translateY(${40 - k4*40}px)`;
    state.under.style.width = `${k5 * 100}%`;
    
    const maxW = 920 - 80;
    [state.l1, state.l2, state.l3].forEach(el => {
      el.style.transformOrigin = state.align === 'flex-start' ? 'left center' : state.align === 'center' ? 'center center' : 'right center';
      const w = el.scrollWidth;
      if (w > maxW) {
        const sc = maxW / w;
        const match = el.style.transform.match(/translateY\(([^)]+)px\)/);
        const curY = match ? parseFloat(match[1]) : 0;
        el.style.transform = `translateY(${curY}px) scale(${sc})`;
      }
    });
  }
};

PARTS.sun_reflect = {
  build(area, params, variant) {
    const p = { reflect: 30, absorb: 40, transmit: 30, labels: { reflect: '반사', absorb: '흡수', transmit: '투과' }, ...params };
    const pL = p.labels || { reflect: '반사', absorb: '흡수', transmit: '투과' };
    
    area.innerHTML = `
      <svg width="920" height="760" style="position:absolute;top:0;left:0;">
        <defs>
          <marker id="arrSun" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto">
            <path d="M0 0 L6 3 L0 6 Z" fill="#F59E0B" />
          </marker>
          <marker id="arrRef" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto">
            <path d="M0 0 L6 3 L0 6 Z" fill="${E.C.blue}" />
          </marker>
          <marker id="arrTra" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto">
            <path d="M0 0 L6 3 L0 6 Z" fill="#60A5FA" />
          </marker>
        </defs>
        <rect x="448" y="100" width="24" height="560" fill="#333" rx="4" />
        <rect x="440" y="100" width="8" height="560" fill="${E.C.blue}" rx="2" />
        
        <circle id="abC1" cx="460" cy="380" r="0" fill="none" stroke="#F59E0B" stroke-width="4" opacity="0" />
        <circle id="abC2" cx="460" cy="380" r="0" fill="#F59E0B" opacity="0" />
        
        <path id="pSun" d="M120 160 L425 365" stroke="#F59E0B" stroke-width="16" fill="none" marker-end="url(#arrSun)" stroke-linecap="round" />
        <path id="pRef" d="M435 390 L150 620" stroke="${E.C.blue}" stroke-width="12" fill="none" marker-end="url(#arrRef)" stroke-linecap="round" />
        <path id="pTra" d="M480 380 L800 380" stroke="#60A5FA" stroke-width="6" fill="none" marker-end="url(#arrTra)" stroke-linecap="round" stroke-dasharray="10 10" />
      </svg>
    `;
    
    const pSun = area.querySelector('#pSun');
    const pRef = area.querySelector('#pRef');
    const pTra = area.querySelector('#pTra');
    const abC1 = area.querySelector('#abC1');
    const abC2 = area.querySelector('#abC2');
    
    const lSun = 370;
    const lRef = 370;
    const lTra = 320;
    
    pSun.style.strokeDasharray = lSun;
    pRef.style.strokeDasharray = lRef;
    pTra.style.strokeDasharray = lTra;
    
    const makeLabel = (x, y, color) => {
      const el = E.el('div', '', area);
      el.style.position = 'absolute';
      el.style.left = x + 'px';
      el.style.top = y + 'px';
      el.style.transform = 'translate(-50%, -50%)';
      el.style.textAlign = 'center';
      
      const vEl = E.el('div', '', el);
      vEl.style.fontSize = '72px';
      vEl.style.fontWeight = '900';
      vEl.style.color = color;
      vEl.style.lineHeight = '1';
      
      const lEl = E.el('div', '', el);
      lEl.style.fontSize = '36px';
      lEl.style.fontWeight = '500';
      lEl.style.color = E.C.gray;
      lEl.style.marginTop = '8px';
      
      return { el, vEl, lEl };
    };
    
    const layAcc = variant.layout === 2 ? 40 : 0;
    const lRefEl = makeLabel(250 - layAcc, 600, E.C.blue);
    lRefEl.lEl.innerText = pL.reflect;
    
    const lAbEl = makeLabel(460, 240, '#F59E0B');
    lAbEl.lEl.innerText = pL.absorb;
    
    const lTraEl = makeLabel(720 + layAcc, 300, '#60A5FA');
    lTraEl.lEl.innerText = pL.transmit;
    
    return { pSun, pRef, pTra, abC1, abC2, lSun, lRef, lTra, lRefEl, lAbEl, lTraEl, p };
  },
  update(state, lt, dur, params, variant) {
    const kSun = E.p(lt, 0, 0.5);
    state.pSun.style.strokeDashoffset = state.lSun * (1 - kSun);
    
    const kOut = E.p(lt, 0.5, 0.6);
    state.pRef.style.strokeDashoffset = state.lRef * (1 - kOut);
    state.pTra.style.strokeDashoffset = state.lTra * (1 - kOut);
    
    state.abC2.setAttribute('r', 10 + kOut * 20);
    state.abC2.setAttribute('opacity', kOut);
    
    const glowAcc = variant.accent === 2 ? 2 : 1;
    state.abC1.setAttribute('r', 30 + kOut * 30 * glowAcc);
    state.abC1.setAttribute('opacity', (1 - kOut) * 0.8);
    
    state.lRefEl.vEl.innerText = Math.round(state.p.reflect * kOut) + '%';
    state.lAbEl.vEl.innerText = Math.round(state.p.absorb * kOut) + '%';
    state.lTraEl.vEl.innerText = Math.round(state.p.transmit * kOut) + '%';
    
    state.lRefEl.el.style.opacity = kOut;
    state.lAbEl.el.style.opacity = kOut;
    state.lTraEl.el.style.opacity = kOut;
    
    const dy = 20 - kOut * 20;
    state.lRefEl.el.style.transform = `translate(-50%, calc(-50% + ${dy}px))`;
    state.lAbEl.el.style.transform = `translate(-50%, calc(-50% + ${dy}px))`;
    state.lTraEl.el.style.transform = `translate(-50%, calc(-50% + ${dy}px))`;
  }
};

PARTS.glass_layers = {
  build(area, params, variant) {
    const p = { layers: [{name:'유리', desc:'기본 창'}, {name:'보호', desc:'필름층'}], ...params };
    const layers = p.layers.slice(0, 5);
    
    area.innerHTML = `<svg width="920" height="760" style="position:absolute;left:0;top:0;"></svg>`;
    const svg = area.querySelector('svg');
    
    const layerEls = [];
    const w = 280, h = 320, th = 12;
    const basex = 420;
    const basey = -100;
    
    const p0 = {x: basex, y: basey};
    const px = {x: basex + w, y: basey + w/2};
    const pxy = {x: basex + w - h, y: basey + w/2 + h/2};
    const py = {x: basex - h, y: basey + h/2};
    
    const zGap = layers.length > 3 ? 80 : 110;
    
    layers.forEach((l, i) => {
      const g = document.createElementNS('http://www.w3.org/2000/svg', 'g');
      svg.appendChild(g);
      
      const isGlass = i === 0;
      const cTop = isGlass ? 'rgba(186, 230, 253, 0.6)' : `rgba(31, 91, 255, ${0.2 + i*0.15})`;
      const cLeft = isGlass ? 'rgba(125, 211, 252, 0.8)' : `rgba(30, 58, 138, ${0.4 + i*0.1})`;
      const cRight = isGlass ? 'rgba(56, 189, 248, 0.8)' : `rgba(29, 78, 216, ${0.5 + i*0.1})`;
      
      const polyTop = document.createElementNS('http://www.w3.org/2000/svg', 'polygon');
      polyTop.setAttribute('points', `${p0.x},${p0.y} ${px.x},${px.y} ${pxy.x},${pxy.y} ${py.x},${py.y}`);
      polyTop.setAttribute('fill', cTop);
      polyTop.setAttribute('stroke', isGlass ? '#FFF' : 'rgba(255,255,255,0.3)');
      polyTop.setAttribute('stroke-width', '2');
      
      const polyLeft = document.createElementNS('http://www.w3.org/2000/svg', 'polygon');
      polyLeft.setAttribute('points', `${py.x},${py.y} ${pxy.x},${pxy.y} ${pxy.x},${pxy.y+th} ${py.x},${py.y+th}`);
      polyLeft.setAttribute('fill', cLeft);
      
      const polyRight = document.createElementNS('http://www.w3.org/2000/svg', 'polygon');
      polyRight.setAttribute('points', `${pxy.x},${pxy.y} ${px.x},${px.y} ${px.x},${px.y+th} ${pxy.x},${pxy.y+th}`);
      polyRight.setAttribute('fill', cRight);
      
      g.appendChild(polyLeft);
      g.appendChild(polyRight);
      g.appendChild(polyTop);
      
      const textG = E.el('div', '', area);
      textG.style.position = 'absolute';
      const targetX = pxy.x + (variant.layout === 0 ? 80 : 140);
      const targetY = pxy.y;
      textG.style.left = targetX + 'px';
      
      const tName = E.el('div', '', textG, l.name);
      tName.style.fontSize = '36px';
      tName.style.fontWeight = '700';
      tName.style.color = E.C.ink;
      
      const tDesc = E.el('div', '', textG, l.desc);
      tDesc.style.fontSize = '30px';
      tDesc.style.color = E.C.gray;
      tDesc.style.whiteSpace = 'nowrap';
      
      layerEls.push({ g, textG, targetY, tName, tDesc });
    });
    
    return { layerEls, zGap };
  },
  update(state, lt, dur, params, variant) {
    state.layerEls.forEach((l, i) => {
      const st = i * 0.2;
      const k = E.p(lt, st, 0.6);
      
      const finalZ = 540 - i * state.zGap;
      const startZ = finalZ + 200;
      const z = startZ - (startZ - finalZ) * k;
      
      l.g.setAttribute('transform', `translate(0, ${z})`);
      l.g.setAttribute('opacity', k);
      
      l.textG.style.top = (l.targetY + z - 20) + 'px';
      l.textG.style.opacity = k;
      l.textG.style.transform = `translateX(${20 - k*20}px)`;
    });
  }
};

PARTS.night_view = {
  build(area, params, variant) {
    const p = { left: { label: '일반 틴팅', dark: 0.2 }, right: { label: '루마 버텍스', dark: 0.85 }, ...params };
    
    area.style.display = 'flex';
    area.style.justifyContent = 'space-between';
    area.style.alignItems = 'center';
    area.style.padding = '0 20px';
    area.style.boxSizing = 'border-box';
    area.style.backgroundColor = E.C.bg;
    
    const makeCard = (data) => {
      const card = E.el('div', 'card', area);
      card.style.width = '430px';
      card.style.height = '620px';
      card.style.position = 'relative';
      card.style.overflow = 'hidden';
      
      const svg = `
        <svg width="430" height="620" style="position:absolute;left:0;top:0;">
          <defs>
            <linearGradient id="headlight" x1="0" y1="1" x2="0" y2="0">
              <stop offset="0%" stop-color="rgba(255,255,220,0.5)" />
              <stop offset="100%" stop-color="rgba(255,255,220,0)" />
            </linearGradient>
            <radialGradient id="glow" cx="0.5" cy="0.5" r="0.5">
              <stop offset="0%" stop-color="rgba(253, 224, 71, 1)" />
              <stop offset="100%" stop-color="rgba(253, 224, 71, 0)" />
            </radialGradient>
            <radialGradient id="redGlow" cx="0.5" cy="0.5" r="0.5">
              <stop offset="0%" stop-color="rgba(239, 68, 68, 1)" />
              <stop offset="100%" stop-color="rgba(239, 68, 68, 0)" />
            </radialGradient>
          </defs>
          <rect x="0" y="0" width="430" height="250" fill="#0F172A" />
          <rect x="0" y="250" width="430" height="370" fill="#020617" />
          
          <polygon points="0,620 430,620 255,250 175,250" fill="#1E293B" />
          
          <polygon points="213,620 217,620 216,520 214,520" fill="#FFF" opacity="0.6" />
          <polygon points="214,450 216,450 215.5,380 214.5,380" fill="#FFF" opacity="0.5" />
          <polygon points="214.5,330 215.5,330 215.2,290 214.8,290" fill="#FFF" opacity="0.4" />
          <polygon points="214.8,270 215.2,270 215.1,250 214.9,250" fill="#FFF" opacity="0.3" />
          
          <circle cx="150" cy="230" r="8" fill="url(#glow)" />
          <circle cx="120" cy="180" r="16" fill="url(#glow)" />
          <circle cx="70" cy="100" r="30" fill="url(#glow)" />
          
          <circle cx="280" cy="230" r="8" fill="url(#glow)" />
          <circle cx="310" cy="180" r="16" fill="url(#glow)" />
          <circle cx="360" cy="100" r="30" fill="url(#glow)" />
          
          <circle cx="205" cy="270" r="6" fill="url(#redGlow)" />
          <circle cx="225" cy="270" r="6" fill="url(#redGlow)" />
          
          <polygon points="115,620 315,620 235,350 195,350" fill="url(#headlight)" />
          
          <rect class="dark-film" x="0" y="0" width="430" height="620" fill="#000" opacity="0" />
        </svg>
      `;
      card.innerHTML = svg;
      
      const film = card.querySelector('.dark-film');
      const label = E.el('div', '', card, data.label);
      label.style.position = 'absolute';
      label.style.bottom = '30px';
      label.style.left = '50%';
      label.style.transform = 'translateX(-50%)';
      label.style.backgroundColor = 'rgba(255,255,255,0.9)';
      label.style.color = '#111';
      label.style.padding = '8px 24px';
      label.style.borderRadius = '30px';
      label.style.fontSize = '34px';
      label.style.fontWeight = '700';
      label.style.boxShadow = '0 8px 16px rgba(0,0,0,0.2)';
      label.style.whiteSpace = 'nowrap';
      
      return { card, film, targetDark: data.dark || 0, label };
    };
    
    const left = makeCard(p.left);
    const right = makeCard(p.right);
    
    if (variant.accent === 2) {
      left.card.style.border = `4px solid ${E.C.blue}`;
      right.card.style.border = `4px solid ${E.C.blue}`;
    }
    
    return { left, right };
  },
  update(state, lt, dur, params, variant) {
    const kCard = E.p(lt, 0, 0.5);
    state.left.card.style.transform = `translateY(${40 - kCard*40}px)`;
    state.left.card.style.opacity = kCard;
    state.right.card.style.transform = `translateY(${40 - kCard*40}px)`;
    state.right.card.style.opacity = kCard;
    
    const kDark = E.p(lt, 0.4, 0.6);
    state.left.film.setAttribute('opacity', state.left.targetDark * kDark);
    state.right.film.setAttribute('opacity', state.right.targetDark * kDark);
    
    const kLabel = E.p(lt, 0.6, 0.4);
    state.left.label.style.opacity = kLabel;
    state.left.label.style.transform = `translate(-50%, ${20 - kLabel*20}px)`;
    state.right.label.style.opacity = kLabel;
    state.right.label.style.transform = `translate(-50%, ${20 - kLabel*20}px)`;
  }
};
