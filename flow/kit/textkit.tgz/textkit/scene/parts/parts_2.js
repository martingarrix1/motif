window.PARTS = window.PARTS || {};

PARTS.percent_grid = {
    build(area, params, variant) {
        const rawVal = params.value !== undefined ? String(params.value) : '0';
        const isNum = !isNaN(Number(rawVal)) && rawVal.trim() !== '';
        const vNum = parseFloat(rawVal) || 0;
        const v = E.clamp(vNum, 0, 100);

        const l = variant.layout || 0;
        const a = variant.accent || 0;

        const wrap = E.el('div', '', area, '');
        wrap.style.display = 'flex';
        wrap.style.alignItems = 'center';
        wrap.style.justifyContent = 'center';
        wrap.style.width = '100%';
        wrap.style.height = '100%';
        wrap.style.gap = '80px';
        if (l === 2) wrap.style.flexDirection = 'column';
        else if (l === 1) wrap.style.flexDirection = 'row-reverse';

        const gridWrap = E.el('div', '', wrap, '');
        gridWrap.style.display = 'grid';
        gridWrap.style.gridTemplateColumns = 'repeat(10, 1fr)';
        gridWrap.style.gap = '8px';
        gridWrap.style.width = l === 2 ? '500px' : '560px';
        gridWrap.style.height = l === 2 ? '500px' : '560px';

        const cells = [];
        for (let i = 0; i < 100; i++) {
            const cell = E.el('div', '', gridWrap, '');
            cell.style.backgroundColor = E.C.line;
            cell.style.borderRadius = '6px';
            cells.push(cell);
        }

        const textWrap = E.el('div', '', wrap, '');
        textWrap.style.display = 'flex';
        textWrap.style.flexDirection = 'column';
        textWrap.style.gap = '24px';
        if (l === 2) textWrap.style.alignItems = 'center';

        const lbl = E.el('div', '', textWrap, E.rich(params.label || ''));
        lbl.style.fontSize = '64px';
        lbl.style.fontWeight = '700';
        lbl.style.color = E.C.ink;

        const cap = E.el('div', 'cap', textWrap, E.rich(params.caption || ''));
        cap.style.fontSize = '36px';

        return { wrap, gridWrap, cells, lbl, cap, v, a, l, variant, isNum };
    },
    update(state, lt, dur, params, variant) {
        const times = params.at || [0.5, 0.85, 1.2];
        const m = variant.motion || 0;

        const kGrid = E.p(lt, times[0], 0.6);
        const kText = E.p(lt, times[1] || 0.85, 0.6);

        if (m === 0) {
            state.gridWrap.style.opacity = kGrid; state.gridWrap.style.transform = `translateY(${(1 - kGrid) * 40}px)`;
            state.lbl.style.opacity = kText; state.lbl.style.transform = `translateY(${(1 - kText) * 40}px)`;
            state.cap.style.opacity = kText; state.cap.style.transform = `translateY(${(1 - kText) * 40}px)`;
        } else if (m === 1) {
            state.gridWrap.style.clipPath = `inset(0 ${(1 - kGrid) * 100}% 0 0)`; state.gridWrap.style.opacity = kGrid > 0 ? 1 : 0;
            state.lbl.style.clipPath = `inset(0 ${(1 - kText) * 100}% 0 0)`; state.lbl.style.opacity = kText > 0 ? 1 : 0;
            state.cap.style.clipPath = `inset(0 ${(1 - kText) * 100}% 0 0)`; state.cap.style.opacity = kText > 0 ? 1 : 0;
        } else {
            state.gridWrap.style.opacity = kGrid; state.gridWrap.style.transform = `scale(${0.94 + 0.06 * kGrid})`;
            state.lbl.style.opacity = kText; state.lbl.style.transform = `scale(${0.94 + 0.06 * kText})`;
            state.cap.style.opacity = kText; state.cap.style.transform = `scale(${0.94 + 0.06 * kText})`;
        }

        const fillP = state.isNum ? E.p(lt, times[0] + 0.2, 1.0) : (lt > times[0] ? 1 : 0);
        const targetIdx = Math.floor(state.v * fillP);

        state.cells.forEach((cell, i) => {
            const row = Math.floor(i / 10);
            const col = i % 10;
            const fillOrder = (9 - row) * 10 + col;
            const isFilled = fillOrder < targetIdx;

            if (isFilled) {
                if (state.a === 0) {
                    cell.style.backgroundColor = E.C.blue;
                    cell.style.border = 'none';
                } else if (state.a === 1) {
                    cell.style.backgroundColor = 'transparent';
                    cell.style.border = `4px solid ${E.C.blue}`;
                } else {
                    cell.style.backgroundColor = '#E8EEFF';
                    cell.style.border = `2px solid ${E.C.blue}`;
                }
            } else {
                cell.style.backgroundColor = E.C.line;
                cell.style.border = 'none';
            }
        });
    }
};

PARTS.film_compare = {
    build(area, params, variant) {
        const wrap = E.el('div', '', area, '');
        wrap.style.display = 'flex';
        wrap.style.width = '100%';
        wrap.style.height = '100%';
        wrap.style.alignItems = 'center';
        wrap.style.justifyContent = 'center';

        const l = variant.layout || 0;
        const a = variant.accent || 0;

        if (l === 0) {
            wrap.style.flexDirection = 'row';
            wrap.style.gap = '60px';
        } else if (l === 1) {
            wrap.style.flexDirection = 'column';
            wrap.style.gap = '60px';
        } else {
            wrap.style.position = 'relative';
        }

        const createCard = (data, isWinner) => {
            const card = E.el('div', 'card', wrap, '');
            if (l !== 2) {
                card.style.width = l === 0 ? '440px' : '820px';
                card.style.height = l === 0 ? '620px' : '340px';
            } else {
                card.style.position = 'absolute';
                card.style.width = '480px';
                card.style.height = '620px';
            }
            card.style.padding = '48px';
            card.style.boxSizing = 'border-box';
            card.style.display = 'flex';
            card.style.flexDirection = 'column';

            const title = E.el('div', '', card, E.rich(data?.name || ''));
            title.style.fontSize = '48px';
            title.style.fontWeight = '700';
            title.style.color = E.C.ink;
            title.style.marginBottom = '40px';
            title.style.textAlign = 'center';

            const specsWrap = E.el('div', '', card, '');
            specsWrap.style.display = 'flex';
            specsWrap.style.flexDirection = 'column';
            specsWrap.style.gap = '20px';
            specsWrap.style.flex = '1';
            specsWrap.style.justifyContent = 'center';

            (data?.specs || []).forEach(sp => {
                const row = E.el('div', '', specsWrap, '');
                row.style.display = 'flex';
                row.style.justifyContent = 'space-between';
                row.style.alignItems = 'center';

                const k = E.el('div', '', row, E.rich(sp[0] || ''));
                k.style.color = E.C.gray;
                k.style.fontSize = '36px';

                const v = E.el('div', '', row, E.rich(sp[1] || ''));
                v.style.color = E.C.ink;
                v.style.fontSize = '40px';
                v.style.fontWeight = '500';
            });

            return { card, isWinner };
        };

        const c1 = createCard(params.left, params.winner === 'left');
        const c2 = createCard(params.right, params.winner === 'right');

        if (l === 2) {
            c1.card.style.left = '40px';
            c1.card.style.top = '60px';
            c2.card.style.right = '40px';
            c2.card.style.top = '60px';
            if (c1.isWinner) c1.card.style.zIndex = '2';
            if (c2.isWinner) c2.card.style.zIndex = '2';
        }

        return { wrap, c1, c2, l, a, variant, winner: params.winner };
    },
    update(state, lt, dur, params, variant) {
        const times = params.at || [0.5, 0.85, 1.2];
        const m = variant.motion || 0;
        const k1 = E.p(lt, times[0], 0.6);
        const k2 = E.p(lt, times[1] || 0.85, 0.6);
        const kWin = E.p(lt, times[2] || 1.2, 0.6);

        const applyM = (el, k) => {
            if (m === 0) { el.style.opacity = k; el.style.transform = `translateY(${(1 - k) * 40}px)`; }
            else if (m === 1) { el.style.opacity = k > 0 ? 1 : 0; el.style.clipPath = `inset(0 ${(1 - k) * 100}% 0 0)`; }
            else { el.style.opacity = k; el.style.transform = `scale(${0.94 + 0.06 * k})`; }
        };

        applyM(state.c1.card, k1);
        applyM(state.c2.card, k2);

        if (state.l === 2) {
            if (m === 0) {
                state.c1.card.style.transform = `translateY(${(1 - k1) * 40}px) ${state.c1.isWinner ? `scale(${1 + 0.05 * kWin})` : `scale(${1 - 0.05 * kWin})`}`;
                state.c2.card.style.transform = `translateY(${(1 - k2) * 40}px) ${state.c2.isWinner ? `scale(${1 + 0.05 * kWin})` : `scale(${1 - 0.05 * kWin})`}`;
            } else {
                state.c1.card.style.transform = state.c1.isWinner ? `scale(${0.94 + 0.06 * k1 + 0.05 * kWin})` : `scale(${0.94 + 0.06 * k1 - 0.05 * kWin})`;
                state.c2.card.style.transform = state.c2.isWinner ? `scale(${0.94 + 0.06 * k2 + 0.05 * kWin})` : `scale(${0.94 + 0.06 * k2 - 0.05 * kWin})`;
            }
        }

        const updateWinner = (c) => {
            if (c.isWinner) {
                if (state.a === 0) {
                    c.card.style.border = `${6 * kWin}px solid ${E.C.blue}`;
                } else if (state.a === 1) {
                    c.card.style.boxShadow = `0px ${10 * kWin}px ${30 * kWin}px ${E.C.blue}40`;
                } else {
                    const cBg = 255 - 20 * kWin;
                    c.card.style.backgroundColor = `rgb(${cBg}, ${238 - 10 * kWin}, 255)`;
                }
            } else {
                c.card.style.border = 'none';
                c.card.style.backgroundColor = E.C.card;
                c.card.style.boxShadow = '0px 10px 30px rgba(0,0,0,0.05)';
            }
        };

        updateWinner(state.c1);
        updateWinner(state.c2);
    }
};

PARTS.big_word = {
    build(area, params, variant) {
        const wrap = E.el('div', '', area, '');
        wrap.style.display = 'flex';
        wrap.style.flexDirection = 'column';
        wrap.style.width = '100%';
        wrap.style.height = '100%';
        wrap.style.justifyContent = 'center';

        const l = variant.layout || 0;
        if (l === 0) wrap.style.alignItems = 'center';
        else if (l === 1) { wrap.style.alignItems = 'flex-start'; wrap.style.paddingLeft = '100px'; }
        else { wrap.style.alignItems = 'flex-end'; wrap.style.paddingRight = '100px'; }

        const w = E.el('div', '', wrap, '');
        w.style.fontSize = '240px';
        w.style.fontWeight = '900';
        w.style.color = E.C.ink;
        w.style.lineHeight = '1.1';

        const rawWord = params.word || '';
        const isNum = !isNaN(Number(rawWord)) && String(rawWord).trim() !== '';
        const targetNum = isNum ? Number(rawWord) : 0;
        const a = variant.accent || 0;

        const updateWord = (val) => {
            let html = String(val);
            if (a === 0) html = `<span style="color:${E.C.blue}">${html}</span>`;
            else if (a === 1) html = `<span style="border-bottom:16px solid ${E.C.blue}">${html}</span>`;
            else html = `<span style="background-color:#E8EEFF; padding:0 32px; border-radius:40px; color:${E.C.blue}">${html}</span>`;
            return html;
        };

        w.innerHTML = updateWord(rawWord);

        const sub = E.el('div', '', wrap, E.rich(params.sub || ''));
        sub.style.fontSize = '48px';
        sub.style.fontWeight = '500';
        sub.style.color = E.C.gray;
        sub.style.marginTop = '32px';

        return { w, sub, variant, isNum, targetNum, rawWord, updateWord };
    },
    update(state, lt, dur, params, variant) {
        const times = params.at || [0.5, 1.0];
        const m = variant.motion || 0;

        const kw = E.p(lt, times[0], 0.8);
        if (m === 0) {
            state.w.style.opacity = kw;
            state.w.style.transform = `translateY(${(1 - kw) * -100}px)`;
        } else if (m === 1) {
            state.w.style.clipPath = `inset(0 ${(1 - kw) * 100}% 0 0)`;
            state.w.style.opacity = kw > 0 ? 1 : 0;
        } else {
            state.w.style.opacity = kw;
            state.w.style.transform = `scale(${1.2 - 0.2 * kw})`;
        }

        if (state.isNum) {
            const cur = Math.floor(state.targetNum * kw);
            state.w.innerHTML = state.updateWord(cur);
        }

        const ks = E.p(lt, times[1] || 0.85, 0.6);
        state.sub.style.opacity = ks;
        state.sub.style.transform = `translateY(${(1 - ks) * 30}px)`;
    }
};

PARTS.typewriter = {
    build(area, params, variant) {
        const wrap = E.el('div', '', area, '');
        wrap.style.display = 'flex';
        wrap.style.flexDirection = 'column';
        wrap.style.width = '100%';
        wrap.style.height = '100%';

        const l = variant.layout || 0;
        if (l === 0) {
            wrap.style.justifyContent = 'center';
            wrap.style.alignItems = 'center';
            wrap.style.textAlign = 'center';
        } else if (l === 1) {
            wrap.style.justifyContent = 'flex-start';
            wrap.style.alignItems = 'flex-start';
            wrap.style.padding = '100px';
        } else {
            wrap.style.justifyContent = 'flex-end';
            wrap.style.alignItems = 'flex-end';
            wrap.style.padding = '100px';
            wrap.style.textAlign = 'right';
        }

        const t = E.el('div', '', wrap, '');
        t.style.fontSize = '120px';
        t.style.fontWeight = '700';
        t.style.color = E.C.ink;
        t.style.wordBreak = 'keep-all';
        t.style.lineHeight = '1.3';

        const c = E.el('div', 'cap', wrap, E.rich(params.caption || ''));
        c.style.marginTop = '32px';
        c.style.fontSize = '36px';
        c.style.opacity = '0';

        t.innerHTML = E.rich(params.text || '');

        const walk = (node) => {
            if (node.nodeType === 3) {
                const text = node.nodeValue;
                const frag = document.createDocumentFragment();
                for (let char of text) {
                    const s = document.createElement('span');
                    s.textContent = char;
                    s.style.opacity = '0';
                    frag.appendChild(s);
                }
                node.parentNode.replaceChild(frag, node);
            } else if (node.nodeType === 1) {
                Array.from(node.childNodes).forEach(walk);
            }
        };
        walk(t);

        const chars = Array.from(t.querySelectorAll('span'));

        const cursor = E.el('span', '', t, '|');
        cursor.style.color = E.C.blue;
        cursor.style.fontWeight = '400';
        cursor.style.marginLeft = '12px';

        return { wrap, t, c, chars, cursor, variant };
    },
    update(state, lt, dur, params, variant) {
        const start = (params.at && params.at[0]) ? params.at[0] : 0.5;
        const speed = 0.05;

        const totalLen = state.chars.length;
        let visibleChars = Math.floor((lt - start) / speed);
        visibleChars = E.clamp(visibleChars, 0, totalLen);

        state.chars.forEach((span, i) => {
            span.style.opacity = i < visibleChars ? '1' : '0';
        });

        if (lt < start) {
            state.cursor.style.opacity = '0';
        } else {
            const isTyping = visibleChars > 0 && visibleChars < totalLen;
            if (isTyping) {
                state.cursor.style.opacity = '1';
            } else {
                const blink = Math.floor(lt * 2) % 2 === 0;
                state.cursor.style.opacity = blink ? '1' : '0';
            }
        }

        const m = variant.motion || 0;
        const kc = E.p(lt, start + totalLen * speed + 0.3, 0.6);
        state.c.style.opacity = kc;
        if (m === 0) state.c.style.transform = `translateY(${(1 - kc) * 30}px)`;
        else if (m === 1) state.c.style.clipPath = `inset(0 ${(1 - kc) * 100}% 0 0)`;
        else state.c.style.transform = `scale(${0.94 + 0.06 * kc})`;

        const a = variant.accent || 0;
        if (visibleChars === totalLen && a !== 0) {
            const kAcc = E.p(lt, start + totalLen * speed, 0.6);
            if (a === 1) {
                state.t.style.textShadow = `0px 8px 30px ${E.C.blue}${Math.floor(kAcc * 80).toString(16).padStart(2, '0')}`;
            } else {
                state.t.style.transform = `scale(${1 + 0.05 * kAcc})`;
            }
        } else {
            state.t.style.textShadow = 'none';
            state.t.style.transform = 'scale(1)';
        }
    }
};

PARTS.strike_correct = {
    build(area, params, variant) {
        const wrap = E.el('div', '', area, '');
        wrap.style.display = 'flex';
        wrap.style.width = '100%';
        wrap.style.height = '100%';
        wrap.style.alignItems = 'center';
        wrap.style.justifyContent = 'center';
        wrap.style.fontSize = '120px';
        wrap.style.fontWeight = '700';
        wrap.style.color = E.C.ink;

        const l = variant.layout || 0;
        if (l === 1) {
            wrap.style.flexDirection = 'column';
            wrap.style.gap = '40px';
        } else {
            wrap.style.flexDirection = 'row';
            wrap.style.gap = '40px';
        }

        const pfx = E.el('div', '', wrap, E.rich(params.prefix || ''));

        const wWrap = E.el('div', '', wrap, '');
        wWrap.style.position = 'relative';

        const w = E.el('div', '', wWrap, E.rich(params.wrong || ''));
        w.style.color = E.C.gray;

        const strike = E.el('div', '', wWrap, '');
        strike.style.position = 'absolute';
        strike.style.top = '50%';
        strike.style.left = '0';
        strike.style.height = '10px';
        strike.style.backgroundColor = E.C.red;
        strike.style.width = '0%';

        const arrow = E.el('div', '', wrap, l === 2 ? '➔' : '→');
        arrow.style.color = E.C.line;
        if (l === 1) arrow.style.transform = 'rotate(90deg)';

        const r = E.el('div', '', wrap, E.rich(params.right || ''));
        r.style.color = E.C.blue;

        const a = variant.accent || 0;
        if (a === 1) r.style.borderBottom = `10px solid ${E.C.blue}`;
        if (a === 2) {
            r.style.backgroundColor = '#E8EEFF';
            r.style.padding = '12px 32px';
            r.style.borderRadius = '24px';
        }

        return { pfx, wWrap, w, strike, arrow, r, variant };
    },
    update(state, lt, dur, params, variant) {
        const times = params.at || [0.5, 0.9, 1.3, 1.7];
        const m = variant.motion || 0;

        const kp = E.p(lt, times[0], 0.6);
        const kw = E.p(lt, times[1], 0.6);
        const kStr = E.p(lt, times[2], 0.4);
        const kr = E.p(lt, times[3], 0.6);

        const applyM = (el, k) => {
            if (m === 0) { el.style.opacity = k; el.style.transform = `translateY(${(1 - k) * 30}px)`; }
            else if (m === 1) { el.style.opacity = k > 0 ? 1 : 0; el.style.clipPath = `inset(0 ${(1 - k) * 100}% 0 0)`; }
            else { el.style.opacity = k; el.style.transform = `scale(${0.94 + 0.06 * k})`; }
        };

        applyM(state.pfx, kp);
        applyM(state.wWrap, kw);
        applyM(state.arrow, kw);

        state.strike.style.width = `${kStr * 100}%`;

        applyM(state.r, kr);

        const a = variant.accent || 0;
        if (kr > 0) {
            if (a === 0) state.r.style.transform = `scale(${1 + 0.1 * kr})`;
            else if (a === 1) state.r.style.transform = `translateY(${(1 - kr) * 30}px)`;
            else state.r.style.transform = `scale(${0.9 + 0.1 * kr})`;
        }
    }
};

PARTS.qa_split = {
    build(area, params, variant) {
        const wrap = E.el('div', '', area, '');
        wrap.style.display = 'flex';
        wrap.style.width = '100%';
        wrap.style.height = '100%';
        wrap.style.alignItems = 'center';
        wrap.style.justifyContent = 'center';

        const l = variant.layout || 0;
        if (l === 0) {
            wrap.style.flexDirection = 'column';
            wrap.style.gap = '60px';
        } else if (l === 1) {
            wrap.style.flexDirection = 'row';
            wrap.style.gap = '60px';
        } else {
            wrap.style.position = 'relative';
        }

        const createQaCard = (type, text) => {
            const card = E.el('div', 'card', wrap, '');
            if (l !== 2) {
                card.style.width = l === 0 ? '860px' : '440px';
                card.style.height = l === 0 ? '300px' : '500px';
            } else {
                card.style.position = 'absolute';
                card.style.width = '680px';
                card.style.height = '300px';
            }
            card.style.padding = '48px';
            card.style.boxSizing = 'border-box';
            card.style.display = 'flex';
            card.style.flexDirection = 'column';
            card.style.justifyContent = 'center';

            const badge = E.el('div', '', card, type);
            badge.style.fontSize = '48px';
            badge.style.fontWeight = '900';
            badge.style.marginBottom = '24px';

            const t = E.el('div', '', card, E.rich(text || ''));
            t.style.fontSize = '44px';
            t.style.fontWeight = '700';
            t.style.lineHeight = '1.4';
            t.style.wordBreak = 'keep-all';

            if (type === 'Q') {
                badge.style.color = E.C.gray;
                t.style.color = E.C.ink;
                card.style.backgroundColor = E.C.card;
            } else {
                badge.style.color = E.C.blue;
                t.style.color = E.C.card;
                card.style.backgroundColor = E.C.blue;
            }

            return { card, badge, t };
        };

        const q = createQaCard('Q', params.q);
        const a = createQaCard('A', params.a);

        if (l === 2) {
            q.card.style.left = '60px';
            q.card.style.top = '60px';
            a.card.style.right = '60px';
            a.card.style.bottom = '60px';
        }

        return { q, a, variant };
    },
    update(state, lt, dur, params, variant) {
        const times = params.at || [0.5, 1.0];
        const m = variant.motion || 0;
        const a = variant.accent || 0;

        const kq = E.p(lt, times[0], 0.6);
        const ka = E.p(lt, times[1], 0.6);

        const applyM = (el, k, reverse = false) => {
            const dir = reverse ? -40 : 40;
            if (m === 0) { el.style.opacity = k; el.style.transform = `translateY(${(1 - k) * dir}px)`; }
            else if (m === 1) { el.style.opacity = k > 0 ? 1 : 0; el.style.clipPath = `inset(0 ${(1 - k) * 100}% 0 0)`; }
            else { el.style.opacity = k; el.style.transform = `scale(${0.94 + 0.06 * k})`; }
        };

        applyM(state.q.card, kq);
        applyM(state.a.card, ka, true);

        if (a === 1) {
            state.a.card.style.boxShadow = `0px ${10 * ka}px ${30 * ka}px ${E.C.blue}60`;
        } else if (a === 2) {
            const bounce = Math.sin(ka * Math.PI) * 10;
            if (m === 0) state.a.card.style.transform = `translateY(${(1 - ka) * -40 - bounce}px)`;
        }
    }
};

PARTS.quote_block = {
    build(area, params, variant) {
        const wrap = E.el('div', '', area, '');
        wrap.style.display = 'flex';
        wrap.style.width = '100%';
        wrap.style.height = '100%';
        wrap.style.alignItems = 'center';
        wrap.style.justifyContent = 'center';

        const l = variant.layout || 0;

        const box = E.el('div', '', wrap, '');
        box.style.display = 'flex';
        box.style.flexDirection = 'column';

        let bar;
        if (l === 0) {
            box.style.borderLeft = `12px solid ${E.C.blue}`;
            box.style.paddingLeft = '60px';
        } else if (l === 1) {
            bar = E.el('div', '', box, '“');
            bar.style.fontSize = '200px';
            bar.style.color = E.C.blue;
            bar.style.lineHeight = '0.8';
            bar.style.marginBottom = '20px';
        } else {
            box.style.border = `6px solid ${E.C.blue}`;
            box.style.borderRadius = '40px';
            box.style.padding = '80px';
            box.style.alignItems = 'center';
            box.style.textAlign = 'center';
        }

        const textStr = (params.text || '').replace(/\n/g, '<br/>');
        const t = E.el('div', '', box, E.rich(textStr));
        t.style.fontSize = '72px';
        t.style.fontWeight = '700';
        t.style.color = E.C.ink;
        t.style.lineHeight = '1.5';
        t.style.wordBreak = 'keep-all';

        const by = E.el('div', 'cap', box, E.rich(params.by || ''));
        by.style.marginTop = '48px';
        by.style.fontSize = '36px';
        if (l === 2) by.style.color = E.C.blue;

        return { wrap, box, t, by, bar, variant, l };
    },
    update(state, lt, dur, params, variant) {
        const times = params.at || [0.5, 0.8, 1.1];
        const m = variant.motion || 0;
        const a = variant.accent || 0;

        const kb = E.p(lt, times[0], 0.6);
        const kt = E.p(lt, times[1], 0.6);
        const kBy = E.p(lt, times[2], 0.6);

        if (state.l === 0) {
            state.box.style.borderColor = `rgba(31, 91, 255, ${kb})`;
            state.box.style.transform = `translateY(${(1 - kb) * 30}px)`;
        } else if (state.l === 1) {
            state.bar.style.opacity = kb;
            state.bar.style.transform = `scale(${kb})`;
        } else {
            state.box.style.opacity = kb;
            state.box.style.transform = `scale(${0.9 + 0.1 * kb})`;
        }

        if (m === 0) {
            state.t.style.opacity = kt; state.t.style.transform = `translateY(${(1 - kt) * 40}px)`;
            state.by.style.opacity = kBy; state.by.style.transform = `translateY(${(1 - kBy) * 40}px)`;
        } else if (m === 1) {
            state.t.style.opacity = kt > 0 ? 1 : 0; state.t.style.clipPath = `inset(0 ${(1 - kt) * 100}% 0 0)`;
            state.by.style.opacity = kBy > 0 ? 1 : 0; state.by.style.clipPath = `inset(0 ${(1 - kBy) * 100}% 0 0)`;
        } else {
            state.t.style.opacity = kt; state.t.style.transform = `scale(${0.94 + 0.06 * kt})`;
            state.by.style.opacity = kBy; state.by.style.transform = `scale(${0.94 + 0.06 * kBy})`;
        }

        if (a === 1) {
            state.t.style.textShadow = `0px 4px 16px rgba(0,0,0,${0.15 * kt})`;
        } else if (a === 2) {
            state.box.style.backgroundColor = `rgba(232, 238, 255, ${kb * 0.5})`;
            if (state.l !== 2) state.box.style.padding = '60px';
        }
    }
};