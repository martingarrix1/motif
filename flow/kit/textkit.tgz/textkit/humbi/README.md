# 험비 (마틴의 치즈냥이 캐릭터) — 마틴이 "험비 넣어줘"라고 할 때만
- 마틴의 치즈냥이 험비를 본뜬 캐릭터(샌디 캐러멜 털 · 이마 M자 줄무늬 · 올리브 그린 눈). 2026-11-21 LX 블랙 릴스에서 처음 씀.
- 텍스트 버전 릴스를 만든 뒤: python3 ~/mk/textkit/humbi/humbi.py <릴스 폴더>  → *_humbi.mp4 (약 40초)
- 표정 자동 선택(첫 문장 놀람 · 질문 궁금 · ~셈이죠 확신 · 원리 생각 · 마무리 뿌듯). 바꾸려면 폴더에 humbi.json.
- 그림을 고칠 때만 humbi.js 수정 후 python3 sprites.py (playwright + google-chrome 필요) → sp/ PNG 24장 갱신.
- 이름 주의: 치즈냥이는 험비, 깜비는 검정 고양이(다른 아이).
- 목소리(2026-11-21 마틴 선택): 일레븐랩스 "MOTIF 험비 (치즈냥이)" voice_id WWaMzLGNibuiLVQIGfIc "MOTIF 험비 2" (voice_id.txt) — 보이스 디자인 시안 2번(통통 튀는 애니메이션 톤). 2026-11-21 1번은 피치가 너무 높다고 바꿈. 샘플 voice_sample.mp3. 모델 eleven_multilingual_v2, language_code ko.
- 험비 버전(2026-11-21 마틴): 내레이션 전체를 험비 목소리로, 마지막 멘트는 "전주 모티프 험비였습니다." 하나만(B 목소리 없음).
  1) script.txt 마지막 줄을 "전주 모티프 험비였습니다."로 (job.json·vo/say.json의 같은 문장도)
  2) MOTIF_VOICE_ID=$(cat voice_id.txt) MOTIF_VOICE_SETTINGS='{"stability":0.5,"similarity_boost":0.85,"style":0.2,"use_speaker_boost":true,"speed":1.2}' python3 ../textv/make_text.py all <폴더>  (험비 목소리는 B보다 느려서 speed 1.2)
  3) python3 humbi.py <폴더>
- B 목소리 모티프 버전에 험비만 얹을 때는 끝에 험비가 "전주 모티프 험비였습니다."를 덧붙인다(HUMBI_SAY="" 로 끔).
- 손동작(2026-11-21): 표정별 앞발 — 기본 설명 흔들기 · 궁금/생각 턱 괴기 · 놀람 두 발 번쩍 · 확신 치켜들기 · 뿌듯 손 흔들기. 앞발 그림은 arm.py → sp/arm.png
