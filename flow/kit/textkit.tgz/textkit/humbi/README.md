# 험비 (마틴의 치즈냥이 캐릭터) — 마틴이 "험비 넣어줘"라고 할 때만
- 마틴의 치즈냥이 험비를 본뜬 캐릭터(샌디 캐러멜 털 · 이마 M자 줄무늬 · 올리브 그린 눈). 2026-11-21 LX 블랙 릴스에서 처음 씀.
- 텍스트 버전 릴스를 만든 뒤: python3 ~/mk/textkit/humbi/humbi.py <릴스 폴더>  → *_humbi.mp4 (약 40초)
- 표정 자동 선택(첫 문장 놀람 · 질문 궁금 · ~셈이죠 확신 · 원리 생각 · 마무리 뿌듯). 바꾸려면 폴더에 humbi.json.
- 그림을 고칠 때만 humbi.js 수정 후 python3 sprites.py (playwright + google-chrome 필요) → sp/ PNG 24장 갱신.
- 이름 주의: 치즈냥이는 험비, 깜비는 검정 고양이(다른 아이).
- 목소리(2026-11-21 마틴 선택): 일레븐랩스 "MOTIF 험비 (치즈냥이)" voice_id lqV3Hk0F2tcECuUWF7xl (voice_id.txt) — 보이스 디자인으로 만든 시안 1번(10대~20대 여성 느낌의 자연스러운 한국어). 샘플 voice_sample.mp3. 모델 eleven_multilingual_v2, language_code ko.
- 험비 버전 마무리(2026-11-21 마틴): 모티프 버전(대사에 "전주 모티프였습니다")이면 B 멘트 뒤 엔드카드에서 험비 목소리로 "전주 모티프 험비였습니다."가 자동으로 나온다(뿌듯 표정으로 입 움직임). 다른 멘트는 HUMBI_SAY="..." , 끄려면 HUMBI_SAY="".
