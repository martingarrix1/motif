"""험비 앞발(팔) 스프라이트 — 어깨가 아래 가운데, 위쪽으로 뻗은 모양. 단위: 1u = 2px"""
from PIL import Image, ImageDraw
OR=(217,168,114,255); ST=(168,113,62,255); CR=(246,235,220,255)
def make(path):
    S=4  # 슈퍼샘플
    W,H=60*2*S,110*2*S; im=Image.new('RGBA',(W,H),(0,0,0,0)); d=ImageDraw.Draw(im)
    u=lambda v:int(v*2*S)
    cx=30; base=95  # 어깨(피벗) 위치(u)
    d.rounded_rectangle([u(cx-15),u(base-66),u(cx+15),u(base+8)],radius=u(15),fill=OR)
    for y in (base-20,base-36): d.line([u(cx-13),u(y),u(cx-4),u(y+3)],fill=ST,width=u(4))
    for y in (base-28,): d.line([u(cx+13),u(y),u(cx+4),u(y+3)],fill=ST,width=u(4))
    d.ellipse([u(cx-19),u(base-88),u(cx+19),u(base-52)],fill=CR,outline=OR,width=u(4))
    for dx in (-8,0,8): d.line([u(cx+dx),u(base-87),u(cx+dx),u(base-79)],fill=(214,190,170,255),width=u(2.5))
    d.ellipse([u(cx-7),u(base-70),u(cx+7),u(base-60)],fill=(227,163,160,255))
    im=im.resize((W//S,H//S),Image.LANCZOS); im.save(path)
    return (cx*2, base*2)  # 피벗(px)
if __name__=='__main__':
    import os; print(make(os.path.join(os.path.dirname(os.path.abspath(__file__)),'sp','arm.png')))
