import asyncio,os
from playwright.async_api import async_playwright
JS=open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'humbi.js')).read()
SP=os.path.join(os.path.dirname(os.path.abspath(__file__)),'sp');os.makedirs(SP,exist_ok=True)
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
    pg=await b.new_page(viewport={'width':600,'height':680},device_scale_factor=1)
    await pg.set_content('<html><body style="margin:0;background:transparent"><div id=c></div><script>'+JS+'</script></body></html>')
    for n in ['base','curious','surprise','think','sure','proud']:
      for talk in (0,1):
        for bl in (0,1):
          await pg.evaluate(f"document.getElementById('c').innerHTML=cat('{n}',{talk},{bl}).replace('width=\"300\" height=\"340\"','width=\"600\" height=\"680\"')")
          await pg.locator('svg').screenshot(path=f'{SP}/{n}_{talk}{bl}.png',omit_background=True)
    await b.close()
asyncio.run(main())
