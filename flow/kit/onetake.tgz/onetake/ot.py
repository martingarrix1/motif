#!/usr/bin/env python3
"""MOTIF 원테이크 릴스 키트 — 명령 한 줄 제작
  python3 ot.py voice  <폴더> [p3_1 ...]  녹음(B 목소리 0.9) → timing.json · voice.wav (이름 주면 그 문장만 다시)
  python3 ot.py vcheck <폴더>             제미나이 목소리 검수(다시 녹음할 문장 최대 3개)
  python3 ot.py build  <폴더>             scenes.json → hf/index.html + sfx.json
  python3 ot.py sheet  <폴더>             초안 렌더(30fps) → sheet.jpg(2.5초 간격) · draft.mp4(소리 포함)
  python3 ot.py final  <폴더> [calm|grand] 120fps 렌더 + 모션 블러 + 효과음 · 피아노 · 목소리 -16 LUFS → final.mp4
  python3 ot.py mix    <폴더> <영상.mp4> [out.mp4] [calm|grand]   소리만 다시 입히기
  python3 ot.py scheck <폴더>             효과음 트랙 제미나이 검수
  python3 ot.py all    <폴더>             build → sheet → final
폴더에는 script.json(승인 대사) · scenes.json(장면별 제목 · 부품) · say.json(읽기 변환, 선택) · 사진만 둔다.
"""
import json, os, sys, re, math, random, shutil, subprocess, glob, time
KIT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, KIT)
import parts as PT, voice as VO

HF = "hyperframes@0.9.65"
ENV = dict(os.environ, DO_NOT_TRACK="1")
SND_DB = {"whoosh": -9, "whoosh_low": -8, "land": -12, "pop": -16, "tick": -21, "punch": -16}
SND_FILE = {"whoosh": "whoosh.wav", "whoosh_low": "whoosh_low.wav", "land": "land.wav", "pop": "pop_soft.wav", "tick": "tick_soft.wav", "punch": "punch.wav"}
CLOSER = "전주 모티프였습니다."
BRAND_URL = "https://raw.githubusercontent.com/martingarrix1/motif/smartstore-assets/flow/brand/"


def sh(cmd, **k):
    return subprocess.run(cmd, check=True, **k)


def dur(f): return VO.dur(f)


def brand(name):
    for d in [os.environ.get("MOTIF_BRAND", ""), os.path.join(KIT, "..", "brand"), os.path.expanduser("~/mk/brand"),
              os.path.expanduser("~/mk/textkit/brand")]:
        f = os.path.join(d, name + ".png")
        if d and os.path.exists(f): return f
    os.makedirs("/tmp/ot_brand", exist_ok=True); f = f"/tmp/ot_brand/{name}.png"
    if not os.path.exists(f): sh(["curl", "-sSL", "-o", f, BRAND_URL + name + ".png"])
    return f


# ---------------------------------------------------------------- 배치
def layout(n, seed):
    """큰 종이 위 장면 자리: 중심 간 1,600~2,000px, 기울기 -8~+8°, 격자 · 한 줄 금지, 서로 1,500px 이상 떨어짐"""
    R = random.Random(seed); pos = [(540, 900, 0)]; last_ang = None
    while len(pos) < n:
        for _ in range(400):
            ang = R.uniform(-math.pi * .15, math.pi * 1.05)   # 대체로 아래로 흐르되 방향은 들쭉날쭉
            if last_ang is not None and abs(ang - last_ang) < .55: continue
            d = R.uniform(1650, 1980); x = pos[-1][0] + d * math.cos(ang); y = pos[-1][1] + d * math.sin(ang)
            if not (-900 < x < 5600 and -600 < y): continue
            if all(math.hypot(x - a, y - b) > 1550 for a, b, _ in pos[:-1]):
                r = R.choice([-1, 1]) * R.uniform(3.5, 7.5)
                if pos[-1][2] and (r > 0) == (pos[-1][2] > 0) and R.random() < .7: r = -r
                pos.append((round(x), round(y), round(r, 1))); last_ang = ang; break
        else:
            pos.append((pos[-1][0] + 1700, pos[-1][1] + 600, 4))
    return pos


def rect_of(p):  # 장면이 차지하는 종이 영역(넉넉히)
    x, y, _ = p; return (x - 600, y - 960, x + 600, y + 1000)


def scatter_deco(pos, words, seed):
    R = random.Random(seed + 7); xs = [p[0] for p in pos]; ys = [p[1] for p in pos]
    X0, X1, Y0, Y1 = min(xs) - 1500, max(xs) + 1200, min(ys) - 1200, max(ys) + 1000
    deco, cross, occ = [], [], [rect_of(p) for p in pos]
    def free(r): return all(r[2] < o[0] or r[0] > o[2] or r[3] < o[1] or r[1] > o[3] for o in occ)
    for w in words:
        for _ in range(300):
            x, y = R.uniform(X0, X1), R.uniform(Y0, Y1); wd = PT.tw(w, 560) * .95
            rr = (x, y, x + wd, y + 640)
            if free(rr): occ.append(rr); deco.append((round(x), round(y), round(R.uniform(-8, 8), 1), w)); break
    for _ in range(10):
        for _ in range(200):
            x, y = R.uniform(X0, X1), R.uniform(Y0, Y1)
            if free((x - 80, y - 80, x + 140, y + 140)): cross.append((round(x), round(y))); occ.append((x - 300, y - 300, x + 300, y + 300)); break
    return deco, cross


# ---------------------------------------------------------------- 캡션
def autowrap(s, n=13):
    words, lines, cur = s.split(" "), [], ""
    for w in words:
        if cur and len(cur) + 1 + len(w) > n: lines.append(cur); cur = w
        else: cur = (cur + " " + w).strip()
    if cur: lines.append(cur)
    return "|".join(lines)


def cap_div(cid, text):
    lines = "".join(f'<span class="ln"><span class="inner">{PT.mark(l)}</span></span>' for l in text.split("|"))
    return f'<div class="cap" id="{cid}">{lines}</div>'


# ---------------------------------------------------------------- 빌드
def build(d):
    S = json.load(open(os.path.join(d, "scenes.json"), encoding="utf-8"))
    T = json.load(open(os.path.join(d, "timing.json"), encoding="utf-8"))
    rows, VE = T["scenes"], T["voice_end"]; n = len(rows)
    sc = S["scenes"]; assert len(sc) == n, f"scenes.json 장면 수({len(sc)})와 대본 장면 수({n})가 다릅니다"
    seed = S.get("seed", 5); R = random.Random(seed)
    last = rows[-1][-1]; motif_end = last[2].strip() == CLOSER
    end_mode = S.get("end", "motif" if motif_end else "question")
    pos = [tuple(p) for p in S["pos"]] if S.get("pos") else layout(n + 1, seed)
    pos[-1] = (pos[-1][0], pos[-1][1], 0)
    overview = S.get("overview", True)
    DUR = round(VE + (5.5 if overview else 4.2) + (1.6 if S.get("end", "") == "question" or (S.get("end") is None and rows[-1][-1][2].strip() != CLOSER) else 0), 2)
    hf = os.path.join(d, "hf"); os.makedirs(os.path.join(hf, "assets", "fonts"), exist_ok=True)
    events, flies, builds, caps, partjs, scenes_html = [], [], [], [], [], ""
    for i in range(n):
        R2 = random.Random(seed * 31 + i)
        r0 = rows[i]; t_sc = r0[0][0]
        if i == 0:
            tb = .3
        else:
            # 앞 장면 마지막 문장이 끝나면 날아가고, 카메라가 거의 도착한 뒤(80%) 빈 자리에서 장면을 짓기 시작
            prev_end = rows[i - 1][-1][0] + rows[i - 1][-1][1]
            du = round(R2.uniform(1.12, 1.22), 2); dip = round(R2.uniform(.71, .77), 2); tf = max(prev_end + .05, t_sc - .9)
            flies.append({"t": round(tf, 3), "p": pos[i], "du": du, "dip": dip}); events.append(("whoosh", tf + du * .5))
            tb = tf + du * .8
        ready = tb + .42   # 카드가 착지한 시각: 그래프 · 부품은 이 뒤에 시작
        builds.append({"i": i + 1, "t": round(tb, 3)}); events.append(("land", tb + PT.react(1) + .14))
        # 캡션
        cs = sc[i].get("caps") or []
        chtml = ""; seq = []
        for k, row in enumerate(r0):
            if row[2].strip() == CLOSER: continue
            item = cs[k] if k < len(cs) else None
            items = item if isinstance(item, list) else [{"text": item or autowrap(row[2]), "fr": 0}] if not isinstance(item, dict) else [item]
            for p_, it in enumerate(items):
                it = it if isinstance(it, dict) else {"text": it, "fr": 0}
                cid = f"c{i+1}_{k}_{p_}"; chtml += cap_div(cid, it["text"])
                seq.append((max(row[0] + row[1] * it.get("fr", 0) - .12, tb + .3), "#" + cid))   # 문장도 카드 뒤에 올라옴
        for m, (t, cid) in enumerate(seq):
            out = seq[m + 1][0] - .2 if m + 1 < len(seq) else None
            caps.append({"id": cid, "in": round(t, 3), "out": None if out is None else round(out, 3)})
        # 부품
        chtml_parts = ""
        for m, pdef in enumerate(sc[i].get("parts", [])):
            pdef = dict(pdef); name = pdef.pop("type")
            for key in ("img",):
                if key in pdef: pdef[key] = asset(d, hf, pdef[key])
            if "swap" in pdef and "img" in pdef["swap"]: pdef["swap"]["img"] = asset(d, hf, pdef["swap"]["img"])
            K = PT.Ctx(i, r0, t_sc, f"s{i+1}p{m}", ready=ready)
            if name not in PT.REG: raise SystemExit(f"없는 부품: {name}  (가능: {', '.join(sorted(PT.REG))})")
            out_at = pdef.pop("out", None)
            chtml_parts += PT.REG[name](K, pdef)
            if out_at is not None: K.j(f'A.hide("#{K.pid}",{K.at(out_at, 0):.3f},.5);')   # 다음 부품에 자리 내주기
            partjs += [f"// 장면 {i+1} · {name}"] + K.js; events += K.ev
        x, y, r = pos[i]
        eng = f'<div class="eng">{PT.esc(sc[i].get("eng",""))}</div>' if sc[i].get("eng") else ""
        scenes_html += (f'<div class="scene" id="s{i+1}" style="left:{x-540}px;top:{y-900}px;transform:rotate({r}deg)">'
                        f'<div class="hd"><i></i>{PT.esc(sc[i]["head"])}</div><div class="no">{i+1:02d} / {n:02d}</div>'
                        f'<div class="card">{eng}{chtml_parts}</div>{chtml}</div>')
    # 엔드카드
    x, y, _ = pos[n]; end = None
    if end_mode == "motif":
        tE = last[0]
        if caps and caps[-1]["out"] is None: caps[-1]["out"] = round(tE - 1.35, 3)
        flies.append({"t": round(tE - 1.45, 3), "p": pos[n], "du": 1.2, "dip": .7}); events.append(("whoosh", tE - 1.45 + .6))
        lines = S.get("end_lines", ["솔라가드 THE LX 전주 유일 공식 특화샵", "[[010-4814-4506]]", "((전주 덕진구 정여립로 1104))"])
        logo = "motif_logo_dark"; end = {"t": round(tE, 3)}
    else:
        # 마지막 문장은 그 장면에서 다 듣고 난 뒤, 엔드카드(질문 · 제품명 · 로고)로 날아감
        tE = VE + .35
        if caps and caps[-1]["out"] is None: caps[-1]["out"] = round(VE + .15, 3)
        flies.append({"t": round(tE - 1.1 + .85, 3), "p": pos[n], "du": 1.2, "dip": .72}); events.append(("whoosh", tE - 1.1 + .85 + .6))
        tE += .85
        lines = [S.get("question") or autowrap(last[2], 12), S.get("product", "솔라가드 THE LX")]
        logo = S.get("end_logo", "lxsg_ink_dark"); end = {"t": round(tE + .3, 3)}
    events.append(("land", end["t"] - .3 + .3))
    end_html = "".join(f'<div class="ln {"eq" if (end_mode!="motif" and k==0) else ""}"><span class="inner">{PT.mark(l).replace("|","<br>")}</span></div>' for k, l in enumerate(lines))
    scenes_html += f'<div class="scene" id="s{n+1}" style="left:{x-540}px;top:{y-900}px"><div id="end"><img id="elogo" src="assets/{logo}.png">{end_html}</div></div>'
    shutil.copy(brand(logo), os.path.join(hf, "assets", logo + ".png"))
    blogo = S.get("logo", "motif_logo_dark" if end_mode == "motif" else "thelx_ink_dark")
    shutil.copy(brand(blogo), os.path.join(hf, "assets", blogo + ".png"))
    # 종이 장식 · 전체 공개
    deco, cross = scatter_deco(pos, S.get("deco", ["MOTIF", "LX", "TSER", "VLT"]), seed)
    DECO = "".join(f'<div class="deco" style="left:{a}px;top:{b}px;transform:rotate({c}deg)">{PT.esc(t)}</div>' for a, b, c, t in deco)
    CROSS = "".join(f'<div class="cross" style="left:{a}px;top:{b}px"></div>' for a, b in cross)
    ov = None
    if overview:
        xs = [p[0] for p in pos]; ys = [p[1] for p in pos]
        cx, cy = (min(xs) + max(xs)) / 2, (min(ys) + max(ys)) / 2 + 60
        s = round(min(1080 / (max(xs) - min(xs) + 1900), 1920 / (max(ys) - min(ys) + 2500)), 3)
        ov = {"t": round(VE + .7, 3), "d": 3.0, "x": round(cx), "y": round(cy), "s": s, "r": -2}
        events.append(("whoosh_low", VE + .7 + 0.9))
    OT = {"pos": pos, "dur": DUR, "voice_end": VE, "seed": seed, "flies": flies, "builds": builds, "caps": caps, "end": end, "overview": ov}
    css = open(os.path.join(KIT, "engine", "base.css"), encoding="utf-8").read()
    js = open(os.path.join(KIT, "engine", "engine.js"), encoding="utf-8").read().replace("__OT__", json.dumps(OT, ensure_ascii=False)).replace("__PARTJS__", "\n".join(partjs))
    html = f'''<!doctype html><html lang="ko"><head><meta charset="UTF-8"/><meta name="viewport" content="width=1080, height=1920"/>
<script src="assets/gsap.min.js"></script><script src="assets/motion-kit.js"></script><style>{css}</style></head><body>
<div id="root" data-composition-id="main" data-start="0" data-duration="{DUR}" data-width="1080" data-height="1920">
<div class="clip abs" data-start="0" data-duration="{DUR}" data-track-index="0" style="left:0;top:0;width:1080px;height:1920px">
<div id="lens" class="abs"><div id="world" class="abs">{DECO}{CROSS}{scenes_html}</div></div>
<img id="blogo" class="abs" src="assets/{blogo}.png">
<div id="black" class="abs"></div></div></div>
<script>{js}</script></body></html>'''
    open(os.path.join(hf, "index.html"), "w", encoding="utf-8").write(html)
    for f in ("gsap.min.js", "motion-kit.js"): shutil.copy(os.path.join(KIT, "vendor", f), os.path.join(hf, "assets", f))
    for fn, body in [("package.json", '{"name":"reel","private":true,"type":"module"}'),
                     ("hyperframes.json", '{"paths":{"blocks":"compositions","components":"compositions/components","assets":"assets"}}')]:
        open(os.path.join(hf, fn), "w").write(body)
    fonts(html, os.path.join(hf, "assets", "fonts"))
    ev = clean_events(events, DUR)
    json.dump({"dur": DUR, "voice_end": VE, "events": ev}, open(os.path.join(d, "sfx.json"), "w"), ensure_ascii=False, indent=0)
    print(f"빌드 완료: {n}장면 · {DUR}초 · 부품 {sum(len(s.get('parts',[])) for s in sc)}개 · 효과음 {len(ev)}개 → {hf}/index.html")
    r = subprocess.run(["npx", "--yes", HF, "check", "--json"], cwd=hf, env=ENV, capture_output=True, text=True)
    try:
        out = json.loads(r.stdout[r.stdout.find("{"):])
        for sec in ("lint", "runtime", "contrast", "craft"):
            for x in (out.get(sec) or {}).get("findings", []) or []:
                if x.get("severity") == "error": print(f" 오류[{sec}]", x.get("code"), x.get("message", "")[:140])
        print("점검:", ", ".join(f"{k} 오류 {v.get('errorCount',0)}" for k, v in out.items() if isinstance(v, dict) and "errorCount" in v),
              "(layout의 content_overlap은 숨겨 둔 요소까지 세므로 sheet.jpg로 판단)")
    except Exception:
        print("check:", r.stdout[-400:], r.stderr[-300:])


def asset(d, hf, rel):
    src = rel if os.path.isabs(rel) else os.path.join(d, rel)
    name = re.sub(r"[^\w.-]", "_", os.path.basename(src))
    shutil.copy(src, os.path.join(hf, "assets", name)); return "assets/" + name


def fonts(html, out):
    from fontTools.ttLib import TTCollection
    from fontTools import subset
    text = "".join(sorted(set(re.sub(r"<[^>]+>", "", html)) | set("0123456789%/.,+-×=≠?·→ ")))
    for src, dst in [("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc", "kr-regular"), ("/usr/share/fonts/opentype/noto/NotoSansCJK-Black.ttc", "kr-black")]:
        f = [f for f in TTCollection(src).fonts if "KR" in f["name"].getDebugName(1)][0]; f.save(f"/tmp/{dst}.otf")
        o = subset.Options(); o.flavor = "woff2"
        font = subset.load_font(f"/tmp/{dst}.otf", o); s = subset.Subsetter(o); s.populate(text=text); s.subset(font)
        subset.save_font(font, os.path.join(out, f"{dst}.woff2"), o)


def clean_events(ev, DUR):
    """같은 소리 0.1초 안 중복 제거, 0.3초 안에 세 개 넘게 몰리면 작은 소리부터 뺌 — 쌓이지 않게"""
    ev = sorted((n, round(t, 3)) for n, t in ev if 0 <= t < DUR - 1.5)
    ev.sort(key=lambda e: e[1]); out = []
    for n, t in ev:
        if any(m == n and abs(t - u) < {"tick": .09, "pop": .35, "land": .25}.get(n, .12) for m, u in out[-8:]): continue
        near = [e for e in out if t - e[1] < .3]
        if len(near) >= 3 and n in ("pop", "tick"): continue
        out.append((n, t))
    return out


# ---------------------------------------------------------------- 렌더 · 소리
def hf_cmd():
    """npx 래퍼 없이 node로 직접 실행(긴 렌더 중 래퍼가 먼저 끝나 '부모 종료'로 취소되는 일을 막음)"""
    try:
        cache = subprocess.check_output(["npm", "config", "get", "cache"], text=True).strip()
        for pj in glob.glob(os.path.join(cache, "_npx", "*", "node_modules", "hyperframes", "package.json")):
            J = json.load(open(pj))
            if J.get("version") == HF.split("@")[1]:
                b = J["bin"]; b = b if isinstance(b, str) else list(b.values())[0]
                return ["node", os.path.join(os.path.dirname(pj), b)]
    except Exception:
        pass
    return ["npx", "--yes", HF]


def render(d, fps, quality, outname):
    hf = os.path.join(d, "hf")
    # stdin을 열어 둔 파이프로 준다: 백그라운드(</dev/null)로 돌리면 HyperFrames가 '부모 종료'로 보고 렌더를 취소함
    p = subprocess.Popen([*hf_cmd(), "render", "--quality", quality, "--fps", str(fps), "--output", os.path.join(d, outname)], cwd=hf, env=ENV, stdin=subprocess.PIPE)
    if p.wait() != 0: raise SystemExit("렌더 실패 — 위 로그 확인")
    return os.path.join(d, outname)


def sheet(d):
    v = render(d, 30, "draft", "draft_v.mp4"); L = dur(v)
    ts = [x * 2.5 for x in range(int(L / 2.5) + 1)]
    sh(["ffmpeg", "-loglevel", "error", "-y", "-i", v, "-vf", "fps=0.4,scale=270:480,tile=8x" + str(math.ceil(len(ts) / 8)), "-frames:v", "1", os.path.join(d, "sheet.jpg")])
    mix(d, v, os.path.join(d, "draft.mp4"))
    print("sheet.jpg · draft.mp4")


def load(f):
    raw = subprocess.check_output(["ffmpeg", "-loglevel", "error", "-i", f, "-ac", "2", "-ar", "48000", "-f", "f32le", "-"])
    import numpy as np
    return np.frombuffer(raw, np.float32).reshape(-1, 2).copy()


def pick_piano(kind, L, out):
    cands = [os.environ.get("MOTIF_PIANO", ""), os.path.join(KIT, "..", "textkit", "piano"), os.path.expanduser("~/mk/textkit/piano"), "/home/claude/mk/textkit/piano"]
    pdir = next((p for p in cands if p and os.path.isdir(p)), None)
    if not pdir:   # 피아노 20곡이 없으면 MOTIF 기본 키트를 받아 옴(약 1분)
        sh(["sh", "-c", "curl -sSL https://raw.githubusercontent.com/martingarrix1/motif/smartstore-assets/flow/kit/bootstrap.sh | sh -s ~/mk"])
        pdir = os.path.expanduser("~/mk/textkit/piano")
    rot_f = os.path.join(pdir, "rotation.json"); rot = json.load(open(rot_f)) if os.path.exists(rot_f) else {}
    kinds = ["calm", "grand"] if kind == "auto" else [kind]
    files = sorted(f for k in kinds for f in glob.glob(os.path.join(pdir, f"{k}_*.mp3")))
    rr = random.Random(time.time()); f = min(files, key=lambda x: rot.get(os.path.basename(x), rr.random()))
    rot[os.path.basename(f)] = time.time(); json.dump(rot, open(rot_f, "w"), indent=1)
    # 곡이 짧으면 두 번 이어 붙임(3초 크로스페이드)
    src = f
    if dur(f) < L + 1:
        src = "/tmp/_ot_pia2.wav"; sh(["ffmpeg", "-loglevel", "error", "-y", "-i", f, "-i", f, "-filter_complex", "[0][1]acrossfade=d=3", src])
    sh(["ffmpeg", "-loglevel", "error", "-y", "-stream_loop", "-1", "-i", src, "-t", f"{L:.2f}", "-af",
        f"loudnorm=I=-18:TP=-3,volume=-6dB,afade=t=in:d=1.2,afade=t=out:st={L-2.6:.2f}:d=2.4", "-ar", "48000", "-ac", "2", out])
    print("피아노:", os.path.basename(f)); return out


def mix(d, video, out, kind="calm"):
    import numpy as np
    J = json.load(open(os.path.join(d, "sfx.json"))); L = dur(video); N = int(L * 48000) + 1
    sfx = np.zeros((N, 2), np.float32); cache = {}
    sdir = os.path.join(KIT, "sfx")
    for n, t in J["events"]:
        if n not in cache:
            a = load(os.path.join(sdir, SND_FILE[n])); pk = int(np.argmax(np.abs(a).sum(1)))
            cache[n] = (a * 10 ** (SND_DB[n] / 20), pk)
        a, pk = cache[n]; s = int(t * 48000) - pk
        if s < 0: a = a[-s:]; s = 0
        e = min(N, s + len(a)); sfx[s:e] += a[:e - s]
    fo = int((L - 1.6) * 48000); fade = np.ones(N, np.float32); fade[fo:] = np.linspace(1, 0, N - fo)
    sfx *= fade[:, None]
    sfx.tofile("/tmp/_ot_sfx.f32")
    pia = pick_piano(kind, L, "/tmp/_ot_pia.wav")
    vo = os.path.join(d, "voice.wav")
    inp = ["-i", video, "-i", vo, "-f", "f32le", "-ar", "48000", "-ac", "2", "-i", "/tmp/_ot_sfx.f32"]
    if pia: inp += ["-i", pia]
    fc = f"[1:a]aformat=channel_layouts=stereo,apad=whole_dur={L:.3f},asplit=2[v][sc];"
    if pia: fc += "[3:a][sc]sidechaincompress=threshold=0.04:ratio=3:attack=30:release=500[p];[v][2:a][p]amix=inputs=3:normalize=0:duration=longest"
    else: fc += "[sc]anullsink;[v][2:a]amix=inputs=2:normalize=0:duration=longest"
    fc += f",alimiter=limit=0.7,loudnorm=I=-16:TP=-1.5,afade=t=out:st={L-1.6:.2f}:d=1.5[a]"
    sh(["ffmpeg", "-loglevel", "error", "-y", *inp, "-filter_complex", fc, "-map", "0:v", "-map", "[a]", "-c:v", "copy",
        "-c:a", "aac", "-b:a", "256k", "-ar", "48000", "-t", f"{L:.3f}", "-movflags", "+faststart", out])
    # 효과음만 따로(검수용)
    sh(["ffmpeg", "-loglevel", "error", "-y", "-f", "f32le", "-ar", "48000", "-ac", "2", "-i", "/tmp/_ot_sfx.f32", os.path.join(d, "sfx_only.wav")])
    print("소리 입힘:", out)


def final(d, kind="calm"):
    raw = render(d, 120, "high", "raw120.mp4")
    v = os.path.join(d, "video30.mp4")
    sh(["ffmpeg", "-loglevel", "error", "-y", "-i", raw, "-vf", "tmix=frames=4,fps=30", "-c:v", "libx264", "-crf", "16", "-preset", "medium", "-pix_fmt", "yuv420p", v])
    mix(d, v, os.path.join(d, "final.mp4"), kind)


if __name__ == "__main__":
    cmd, d = sys.argv[1], os.path.abspath(sys.argv[2])
    if cmd == "voice": VO.record(d, set(sys.argv[3:]))
    elif cmd == "assemble": VO.assemble(d)
    elif cmd == "vcheck": VO.vcheck(d)
    elif cmd == "build": build(d)
    elif cmd == "sheet": build(d); sheet(d)
    elif cmd == "final": final(d, sys.argv[3] if len(sys.argv) > 3 else "calm")
    elif cmd == "mix": mix(d, sys.argv[3], sys.argv[4] if len(sys.argv) > 4 else os.path.join(d, "remix.mp4"), sys.argv[5] if len(sys.argv) > 5 else "calm")
    elif cmd == "scheck": VO.sfx_check(os.path.join(d, "sfx_only.wav"), json.load(open(os.path.join(d, "sfx.json")))["events"])
    elif cmd == "all": build(d); sheet(d); final(d)
    else: print(__doc__)
