// MOTIF 원테이크 엔진 — 카메라 · 장면 짓기 · 캡션 · 엔드카드 · 손카메라. ot.py가 OT(설정)와 PARTJS(부품 동작)를 채운다.
const {F,C,curve,dur,react,cut,wiggle}=MotionKit;
const OT=__OT__;
const W=document.getElementById("world");
const c={x:OT.pos[0][0],y:OT.pos[0][1],r:0,s:1.08};
const ap=()=>{W.style.transform=`translate(540px,960px) rotate(${-c.r}deg) scale(${c.s}) translate(${-c.x}px,${-c.y}px)`};
const tl=gsap.timeline({paused:true});
const Q=s=>document.querySelector(s), QA=s=>[...document.querySelectorAll(s)];
gsap.set(".h,.hd,.no,.card,#elogo,#blogo",{autoAlpha:0});
gsap.set(".cap .inner,#end .inner",{yPercent:110});

// 카메라: x는 무겁게, y는 착지 곡선으로 조금 길게(휘는 경로), 회전은 whip, 줄은 중간에 빠졌다 돌아옴
function fly(t,p,du,dip){const [x,y,r]=p;
  tl.to(c,{x,duration:du,ease:C.heavy,onUpdate:ap},t).to(c,{y,duration:du*1.08,ease:C.land,onUpdate:ap},t)
    .to(c,{r,duration:du,ease:C.whip,onUpdate:ap},t)
    .to(c,{s:dip,duration:du*.45,ease:curve("easings.inOutQuint"),onUpdate:ap},t).to(c,{s:1,duration:du*.65,ease:C.land,onUpdate:ap},t+du*.45);}
// 장면 짓기: 제목 cut → 카드 착지 → 번호
function build(i,t){const s="#s"+i;cut(tl,s+" .hd",t);cut(tl,s+" .no",t+react(2));
  const card=Q(s+" .card");tl.set(card,{autoAlpha:1},t+react(1)).fromTo(card,{y:160},{y:0,duration:dur(160,1.1),ease:C.land},t+react(1));}
function capIn(id,t){QA(id+" .inner").forEach((e,k)=>tl.fromTo(e,{yPercent:110},{yPercent:0,duration:F(34),ease:C.reveal},t+react(k,1.2)));}
function capOut(id,t){QA(id+" .inner").forEach((e,k)=>tl.to(e,{yPercent:-110,duration:F(16),ease:C.leave},t+F(k)));}

// 부품용 움직임 도구 (모두 fromTo · 시각 고정 → 되감기 안전)
const A={
  cut:(s,t)=>cut(tl,s,t),
  hide:(s,t,d=.3)=>tl.to(s,{autoAlpha:0,duration:d,ease:C.leave},t),
  fade:(s,t,d=.4,to=1)=>tl.fromTo(s,{autoAlpha:0},{autoAlpha:to,duration:d,ease:C.drift},t),
  dim:(s,t,to=.45,sc=.94)=>tl.to(s,{autoAlpha:to,scale:sc,duration:.6,ease:C.heavy},t),
  rise:(s,t,dy=60,st=0)=>tl.fromTo(s,{y:dy,autoAlpha:0},{y:0,autoAlpha:1,duration:dur(Math.abs(dy)),ease:C.land,stagger:st},t),
  slide:(s,t,dx=60)=>tl.fromTo(s,{x:dx,autoAlpha:0},{x:0,autoAlpha:1,duration:dur(Math.abs(dx)),ease:C.land},t),
  pop:(s,t,from=.6,st=0)=>tl.fromTo(s,{scale:from,autoAlpha:0},{scale:1,autoAlpha:1,duration:F(26),ease:C.land,stagger:st},t),
  stamp:(s,t,rot=-4)=>tl.fromTo(s,{scale:1.35,autoAlpha:0,rotation:rot},{scale:1,autoAlpha:1,rotation:rot,duration:F(26),ease:C.land},t),
  growX:(s,t,d=1.2,st=0)=>tl.fromTo(s,{scaleX:0},{scaleX:1,duration:d,ease:C.heavy,stagger:st},t),
  growY:(s,t,d=1.1,st=0)=>tl.fromTo(s,{scaleY:0},{scaleY:1,duration:d,ease:C.heavy,stagger:st},t),
  toX:(s,t,v,d=.6)=>tl.to(s,{scaleX:v,duration:d,ease:C.heavy},t),
  wipe:(s,t,d=1.4)=>tl.fromTo(s,{clipPath:"inset(0 100% 0 0)"},{clipPath:"inset(0 0% 0 0)",duration:d,ease:C.heavy},t),
  wipeL:(s,t,d=.8)=>tl.fromTo(s,{clipPath:"inset(0 0 0 100%)"},{clipPath:"inset(0 0 0 0%)",duration:d,ease:C.heavy},t),
  color:(s,t,bg,d=2.4)=>tl.to(s,{background:bg,duration:d,ease:C.heavy},t),
  pulse:(s,t,d=1.6)=>tl.fromTo(s,{scale:1},{scale:1.03,duration:d/2,ease:C.drift,yoyo:true,repeat:1},t),
  kb:(s,t,d=4,from=1.12)=>tl.fromTo(s,{scale:from},{scale:1,duration:d,ease:C.drift},t),
  // 숫자 카운트 (자릿수 고정, 소수점 dec)
  count:(s,a,b,t,d=1.2,dec=0)=>{const el=Q(s),o={v:a};tl.fromTo(o,{v:a},{v:b,duration:d,ease:C.heavy,onUpdate:()=>el.textContent=o.v.toFixed(dec)},t);},
  // SVG 선 그리기: 실선은 선을 따라, 점선은 왼쪽부터 드러냄. 점(dot)이 있으면 선 끝을 따라감
  draw:(s,t,d=1.6,dot)=>{const p=Q(s),L=p.getTotalLength();gsap.set(p,{autoAlpha:0});tl.set(p,{autoAlpha:1},t);
    if(p.classList.contains("dash")) tl.fromTo(p,{clipPath:"inset(0 100% 0 0)"},{clipPath:"inset(0 0% 0 0)",duration:d,ease:C.heavy},t);
    else {gsap.set(p,{strokeDasharray:L+" "+(L+10)});tl.fromTo(p,{strokeDashoffset:L},{strokeDashoffset:0,duration:d,ease:C.heavy},t);}
    if(dot){const D=Q(dot),o={v:0},mv=()=>{const q=p.getPointAtLength(o.v*L);D.setAttribute("cx",q.x);D.setAttribute("cy",q.y);};
      if(p.classList.contains("dash")){/* 점선은 x 기준으로 따라감 */const bb=p.getBBox();
        const fx=()=>{const X=bb.x+o.v*bb.width;let lo=0,hi=L;for(let k=0;k<22;k++){const m=(lo+hi)/2;(p.getPointAtLength(m).x<X)?lo=m:hi=m;}const q=p.getPointAtLength(lo);D.setAttribute("cx",q.x);D.setAttribute("cy",q.y);};
        tl.fromTo(o,{v:0},{v:1,duration:d,ease:C.heavy,onUpdate:fx},t);}
      else tl.fromTo(o,{v:0},{v:1,duration:d,ease:C.heavy,onUpdate:mv},t);
      tl.fromTo(D,{attr:{r:0}},{attr:{r:Number(D.dataset.r||9)},duration:F(18),ease:C.land},t);}},
  // 커서 이동 · 탭
  cursor:(s,x,y,t,d=.7)=>tl.to(s,{x,y,duration:d,ease:C.heavy},t),
  tap:(s,t,box)=>{tl.to(s,{scale:.82,duration:.1,ease:"power2.out",transformOrigin:"10% 5%"},t).to(s,{scale:1,duration:.35,ease:C.land},t+.1);
    if(box) tl.fromTo(box,{autoAlpha:0,scale:1.04},{autoAlpha:1,scale:1,duration:F(22),ease:C.land},t+.05);},
  // 원자 증착: 위에서 떨어져 사라짐
  rain:(s,t,dy=240)=>{tl.fromTo(s,{y:-80,autoAlpha:0},{y:dy,autoAlpha:1,duration:1.0,ease:C.heavy,stagger:{each:F(5),from:"random"}},t).to(s,{autoAlpha:0,duration:.3},t+2.1);},
};

ap();
tl.to(c,{s:1,duration:2.6,ease:C.drift,onUpdate:ap},0);
cut(tl,"#blogo",0.35);
OT.flies.forEach(f=>fly(f.t,f.p,f.du,f.dip));
OT.builds.forEach(b=>build(b.i,b.t));
OT.caps.forEach(k=>{capIn(k.id,k.in); if(k.out!=null) capOut(k.id,k.out);});

// ---- 부품 동작 ----
__PARTJS__

// ---- 엔드카드 ----
const E=OT.end;
if(E){
  tl.to("#blogo",{autoAlpha:0,duration:.4},E.t-1.0);
  // 카메라가 도착한 뒤 로고 → 글줄 차례로
  tl.set("#elogo",{autoAlpha:1},E.t-.3).fromTo("#elogo",{y:80,scale:.92},{y:0,scale:1,duration:dur(80,1.2),ease:C.land},E.t-.3);
  QA("#end .ln").forEach((e,k)=>tl.fromTo(e.querySelector(".inner"),{yPercent:110},{yPercent:0,duration:F(34),ease:C.reveal},E.t+.1+react(k+1,1.4)));
}
// 여운: 천천히 빠지며 종이 전체가 보이고(선택) 검정으로
if(OT.overview){const o=OT.overview;
  tl.to(c,{x:o.x,y:o.y,duration:o.d,ease:C.heavy,onUpdate:ap},o.t).to(c,{s:o.s,duration:o.d,ease:C.heavy,onUpdate:ap},o.t).to(c,{r:o.r,duration:o.d,ease:C.heavy,onUpdate:ap},o.t);
} else tl.to(c,{s:1.04,duration:OT.dur-OT.voice_end,ease:C.drift,onUpdate:ap},OT.voice_end);
tl.to("#black",{opacity:1,duration:1.4,ease:C.drift},OT.dur-1.6);
tl.to({},{duration:.01},OT.dur-.01);
wiggle(tl,"#lens",{x:7,y:5,rotation:.35},{freq:.45,seed:OT.seed,at:0,until:OT.dur});
window.__timelines={};window.__timelines["main"]=tl;tl.seek(0);
