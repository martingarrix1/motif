# 원테이크 부품 값 (카드 900×660 좌표 · at 규칙은 README)

공통: 대부분 x · y · w · h로 자리와 크기를 바꿀 수 있다. 색 이름 blue · blue2 · gray · purple · ink · light 또는 #코드. 그래프는 무채색 아니면 파란색.
XY 그래프 공통: x,y,w,h(그림 영역) · xr,yr(값 범위) · xticks [값 또는 [값,"글"]] · yticks · yunit · xlabel · ylabel · note {text, at, pos}
순서는 항상 축 → 눈금 · 라벨 → 선 · 막대 → 카운트 → 배지(앞 단계 70%쯤에 다음 시작).

| 부품 | 값 | 쓰임 |
|---|---|---|
| xy_bars | bars [{label, value, at, hi, color}], ymax, unit, dec, all_ticks | 보증기간 · 제품별 수치. 같은 at끼리 0.15초씩 따라 올라옴 |
| xy_grouped | groups [..], series [{name, values[], color, at}], ymax, unit | VLT/TSER/IRER 두 필름 비교 |
| xy_line | series [{pts [[x,y]..], style solid/dash, color, label, at, dur(≥1.6), fill, dot, smooth, label_dx/dy}], marks [{x,y,text,at}], gap {x, a, b, label, at} | 시간에 따른 변화 · 두 선 차이. 점이 선 끝을 따라감 |
| xy_area | xy_line과 같음(첫 선 아래 채움) | 파장별 투과율 · 스펙트럼 |
| xy_scatter | points [{x,y,label,hi,at}], trend {pts, at, color} | VLT 대비 TSER 위치 |
| hbars | rows [{label, value, unit, at, hi}], max, unit, gap | 가로 수치 비교 |
| ratio_stack | rows [{label, parts[%..]}], legend [..], colors ["re","ab","tr" 또는 #코드], y | 반사 · 흡수 · 투과 비중 |
| big_number | value, unit, prefix, label, dur, dec, badge, y | 가격 · 핵심 수치 하나 |
| film_pair | labels [A,B], row1, row2, q_at, ne_at, shift_at | 수치는 같고(=) 몇 년 뒤는 ?(≠) |
| sun_film | film, inside, cond, cond_at | 햇빛 → 필름 → 실내 |
| struct_pair | a/b {label, kind metal/dots} | 금속 박막 vs 입자 · 염료 |
| layers | layers(4), base, badge, badge_at, y | 스퍼터링 원자 증착 → 층 |
| swatch | label, x,y,w,h, from, to, shift_at, shift_dur | 필름 색이 바래 감 |
| tint_samples | samples [70,50,35,15], caption | 농도 샘플 줄 |
| two_cards | off {title, sub}, on {title, sub}, on_at, y | 남이 권한 구성 → 내 기준 |
| strike_swap | old, new, strike_at, new_at, x,y,w | 잘못된 상식 → 새 단어 |
| marker_tracks | rows [..], a [0~1..], b [..], legend, verdict {a:[이름,글], b:[..], at} | 사람마다 다른 조건 |
| chip_flood | chips [12개 안팎], stamp, stamp_at | 선택지 홍수 → 도장 |
| chips | items [{text, on, at}], x, y | 성능 지표 / 수명 지표(취소선) |
| capture | img, taps [{box [x,y,w,h], at}], swap {img, at}, est | 견적 페이지 캡처 + 커서 탭 |
| photo | img, badge, badge_at, kb, x,y,w,h | 실차 사진 + VLT 배지 |
| car_top | highlights [{zone, at, label}], dots {zone, n, at, clear_at}, y — zone: hood · windshield · roof · rear_glass · trunk · front_bumper · rear_bumper · doors · doors_b · glass · body | PPF 부위 · 검수 · 유리 |
| badge | text, x, y, at, style dark/soft/blue | 작은 알약 |
| (모든 부품) | out: at — 그 시각에 부품이 빠지며 다음 부품에 자리를 내줌 | 한 카드에서 그림 바꾸기 |
| focus | box [x,y,w,h], at | 파란 테두리로 짚기 |
| src | text, at | 출처 · 개념도 |
| labels | items [{text, x, y, at}] | 자유 라벨 |

글자 안 강조: [[그라데이션]] · ((회색)). 수치 · 문구는 승인된 대본 · 원문에 있는 것만, 개념도면 src "개념도"를 같이 넣는다.
