# 원테이크 부품 값 (카드 900×660 좌표 · at 규칙은 README)

공통: 대부분 x · y · w · h로 자리와 크기를 바꿀 수 있다. 색 이름 blue · blue2 · gray · purple · ink · light 또는 #코드. 그래프는 무채색 아니면 파란색.
XY 그래프 공통: x,y,w,h(그림 영역) · xr,yr(값 범위) · xticks [값 또는 [값,"글"]] · yticks · yunit · xlabel · ylabel · note {text, at, pos}
순서는 항상 축 → 눈금 · 라벨 → 선 · 막대 → 카운트 → 배지(앞 단계 70%쯤에 다음 시작).

| 부품 | 값 | 쓰임 |
|---|---|---|
| xy_bars | bars [{label, value, at, hi, color}], ymax, unit, dec, all_ticks | 보증기간 · 제품별 수치. 같은 at끼리 0.15초씩 따라 올라옴 |
| xy_grouped | groups [..], series [{name, values[], color, at}], ymax, unit | VLT/TSER/IRER 두 필름 비교 |
| xy_line | series [{pts [[x,y]..], style solid/dash, color, label, at, dur(≥1.6), fill, dot, smooth, label_dx/dy}], marks [{x,y,text,at}], gap {x, a, b, label, at} | 시간에 따른 변화 · 두 선 차이. 점이 선 끝을 따라감 |
| xy_area | xy_line과 같음(첫 선 아래 채움) | 파장별 투과율 · 스펙트럼 |
| xy_scatter | points [{x,y,label,hi,at}], trend {pts, at, color} | VLT 대비 TSER 위치 |
| hbars | rows [{label, value, unit, at, hi}], max, unit, gap | 가로 수치 비교 |
| ratio_stack | rows [{label, parts[%..]}], legend [..], colors ["re","ab","tr" 또는 #코드], y | 반사 · 흡수 · 투과 비중 |
| big_number | value, unit, prefix, label, dur, dec, badge, y | 가격 · 핵심 수치 하나 |
| film_pair | labels [A,B], row1, row2, q_at, ne_at, shift_at | 수치는 같고(=) 몇 년 뒤는 ?(≠) |
| sun_film | film, inside, cond, cond_at | 햇빛 → 필름 → 실내 |
| struct_pair | a/b {label, kind metal/dots} | 금속 박막 vs 입자 · 염료 |
| layers | layers(4), base, badge, badge_at, y | 스퍼터링 원자 증착 → 층 |
| swatch | label, x,y,w,h, from, to, shift_at, shift_dur | 필름 색이 바래 감 |
| tint_samples | samples [70,50,35,15], caption | 농도 샘플 줄 |
| two_cards | off {title, sub}, on {title, sub}, on_at, y | 남이 권한 구성 → 내 기준 |
| strike_swap | old, new, strike_at, new_at, x,y,w | 잘못된 상식 → 새 단어 |
| marker_tracks | rows [..], a [0~1..], b [..], legend, verdict {a:[이름,글], b:[..], at} | 사람마다 다른 조건 |
| chip_flood | chips [12개 안팎], stamp, stamp_at | 선택지 홍수 → 도장 |
| chips | items [{text, on, at}], x, y | 성능 지표 / 수명 지표(취소선) |
| capture | img, taps [{box [x,y,w,h], at}], swap {img, at}, est | 견적 페이지 캡처 + 커서 탭 |
| photo | img, badge, badge_at, kb, x,y,w,h | 실차 사진 + VLT 배지 |
| car_top | highlights [{zone, at, label}], dots {zone, n, at, clear_at}, y — zone: hood · windshield · roof · rear_glass · trunk · front_bumper · rear_bumper · doors · doors_b · glass · body | PPF 부위 · 검수 · 유리 |
| badge | text, x, y, at, style dark/soft/blue | 작은 알약 |
| (모든 부품) | out: at — 그 시각에 부품이 빠지며 다음 부품에 자리를 내줌 | 한 카드에서 그림 바꾸기 |
| focus | box [x,y,w,h], at | 파란 테두리로 짚기 |
| src | text, at | 출처 · 개념도 |
| labels | items [{text, x, y, at}] | 자유 라벨 |

글자 안 강조: [[그라데이션]] · ((회색)). 수치 · 문구는 승인된 대본 · 원문에 있는 것만, 개념도면 src "개념도"를 같이 넣는다.

## ring_gauge (2026-11-23 추가)
원형 게이지. value(0~100) · unit("%") · label · color · at · dur(1.6) · x · y · size(380) · dec.
배경 트랙(옅은 회색 원) 위에서 링과 가운데 숫자가 같은 곡선(C.heavy)으로 함께 차오른다.

## 막대 기준 트랙 (xy_bars · hbars 기본값)
막대 뒤에 100% 높이의 옅은 회색 트랙이 깔린다. 끄려면 "track": false.

## card_fan (2026-11-24 추가)
틈(가로선)에서 카드 2~4장이 가운데부터 바깥으로 솟아 부채꼴로 펼쳐짐. items [{title, sub, hi}] · at · spread(기본 13°).
hi 카드에는 광택 스윕이 한 번 지나간다. 패키지 구성 · 선택지 묶음에.

## 장면 공통 도구 (engine A.*)
- A.sheen(선택자, t): 옅은 빛줄기가 사선으로 한 번 지나감. 대상 안에 `<div class="sheen">`을 둔다.
- A.tense(선택자, t): 쪼개지거나 퍼지기 직전 짧게 오므라드는 예비 동작.

## scenes.json 전체 옵션 (2026-11-24 추가)
- "parallax": 0.3 — 배경 큰 글자 · 십자가 카메라보다 덜 움직여 한 겹 뒤에 있는 느낌(0이면 끔).
- "hook_zoom": 1.9 — 첫 장면 그래픽에 바짝 붙어 시작해 천천히 빠지며 맥락이 드러나는 달리 줌아웃 훅. hook_at(0.6) · hook_d(3.2). 기본은 끔.

## flip_card (2026-11-24)
3D로 뒤집히는 카드. front(회색 앞면) · front_tag · back(파란 뒷면) · back_tag · sub · at · flip_at.
뒤집히기 직전 살짝 오므라들고(예비 수축) 휘익 소리와 함께 -180° 회전. 통념 → 반박, 질문형 엔딩에.

## balance (2026-11-24)
저울. left(왼쪽 접시 블록) · right[블록 라벨들] · at · tip_at.
처음엔 왼쪽이 무겁게 기울었다가 오른쪽에 블록이 하나씩 쌓이며 무게가 넘어감. "A가 아니라 B로 따져야" 류 대사에.

## sun_equal (2026-11-24)
해에서 빛줄기가 작은 차(left)와 큰 차(right)에 똑같이 흐름. people_at에 두 차 운전석이 주황빛으로 데워짐. tag(선택).

## spec_sheet (2026-11-24)
사양표. title · rows [[항목, 값]] · strike(행 번호, 기본 마지막) · new · strike_at.
행이 차례로 들어오고 strike_at에 값에 취소선 → 위로 빠지고 새 값이 파랗게.
