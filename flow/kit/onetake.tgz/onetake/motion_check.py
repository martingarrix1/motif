# 사용법: python3 motion_check.py <릴스.mp4> [끝에서 제외할 초, 기본 6]
import sys, subprocess, numpy as np
src = sys.argv[1]; tail = float(sys.argv[2]) if len(sys.argv) > 2 else 6
dur = float(subprocess.check_output(["ffprobe","-v","error","-show_entries","format=duration","-of","csv=p=0",src]))
raw = subprocess.check_output(["ffmpeg","-loglevel","error","-i",src,"-vf","fps=2,scale=270:480,format=gray","-f","rawvideo","-"])
f = np.frombuffer(raw, np.uint8).reshape(-1,480,270).astype(np.int16)
d = [(np.abs(f[i]-f[i-1]) > 12).mean() for i in range(1, len(f))]
still, busy, run, start = [], [], 0.0, 0.0
for i, v in enumerate(d, 1):
    t = i / 2
    if t > dur - tail: break
    if v < 0.002:
        if run == 0: start = t - 0.5
        run += 0.5
    else:
        if run > 1.0: still.append((start, t - 0.5))
        run = 0
    if v > 0.40: busy.append(t)
if run > 1.0: still.append((start, start + run))
print(f"길이 {dur:.1f}초 · 마지막 {tail:.0f}초(엔드카드·여운) 제외")
print("멈춤 1초 초과:", ", ".join(f"{a:.1f}~{b:.1f}초" for a,b in still) or "없음")
print("화면 40% 이상 급변(장면 전환 시각이면 정상):", ", ".join(f"{t:.1f}초" for t in busy) or "없음")
