import json,os,urllib.request,sys
K=open(os.path.expanduser("~/.eleven/key")).read().strip()
S={
 "whoosh":("soft airy cinematic whoosh, smooth horizontal swipe transition, clean and subtle, no impact, premium",1.0),
 "pop":("soft gentle UI pop, small bubble tap, clean minimal interface sound, premium app",0.5),
 "tick":("very short soft digital tick, minimal clean UI counter tick, quiet",0.5),
 "land":("soft low muted thud, card placed gently on a table, warm subtle landing",0.6),
 "punch":("deep soft cinematic sub boom impact, short and clean, no distortion",1.0),
 "shimmer":("subtle bright airy shimmer chime, premium reveal sparkle, soft",1.2),
}
for n,(t,d) in S.items():
    req=urllib.request.Request("https://api.elevenlabs.io/v1/sound-generation?output_format=mp3_44100_128",data=json.dumps({"text":t,"duration_seconds":d,"prompt_influence":0.6}).encode(),headers={"xi-api-key":K,"Content-Type":"application/json"})
    try:
        open(f"{n}.mp3","wb").write(urllib.request.urlopen(req,timeout=120).read()); print(n,"ok")
    except urllib.error.HTTPError as e: print(n,e.code,e.read()[:200])
