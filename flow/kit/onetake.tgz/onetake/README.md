# MOTIF 원테이크 릴스 키트 (2026-11-23)

릴스마다 코드를 새로 쓰지 않는다. 승인된 대본(script.json)과 장면 설정표(scenes.json)만 쓰면 명령 한 줄로 원테이크 릴스가 나온다.
기준작: "TSER이 같은 두 필름"(examples/tser) · 원칙은 motif-motion 스킬 3-1 · 3-3 · 3-4를 그대로 따른다.

## 준비 (새 작업 공간에서 1회, 약 1분)
    curl -sSL https://raw.githubusercontent.com/martingarrix1/motif/smartstore-assets/flow/kit/bootstrap.sh | sh -s ~/mk   # 피아노 20곡 · 로고
    curl -sSL https://raw.githubusercontent.com/martingarrix1/motif/smartstore-assets/flow/kit/onetake.tgz | tar xz -C ~/mk # 이 키트 → ~/mk/onetake
    pip install -q --break-system-packages brotli fonttools numpy
    키: motif-api-keys 스킬 → ~/.eleven/key, ~/.gemini/key (B 목소리 voice_id는 키트에 기본값)
    Node 22 + npx (HyperFrames 0.9.65는 처음 실행 때 자동 설치)

## 만드는 순서
    D=~/reels/<이름>; mkdir -p $D   # script.json · scenes.json · (say.json) · 사진
    python3 ~/mk/onetake/ot.py voice  $D    # 문장별 녹음 → timing.json · voice.wav
    python3 ~/mk/onetake/ot.py vcheck $D    # 제미나이 목소리 검수 → 걸린 문장만: ot.py voice $D p4_0 p6_2
    python3 ~/mk/onetake/ot.py sheet  $D    # 빌드 + 초안(30fps) → sheet.jpg(2.5초 간격) · draft.mp4(소리 포함)
    python3 ~/mk/onetake/ot.py scheck $D    # 효과음 제미나이 검수(거슬리는 소리 최대 3개)
    python3 ~/mk/onetake/ot.py final  $D    # 120fps 렌더 + 모션 블러(tmix) + 소리 → final.mp4
  - 장면 하나만 보고 싶으면: build 후 `cd $D/hf && npx --yes hyperframes@0.9.65 snapshot --at 3.5,12 --no-end -o /tmp/snap .`
  - 시간: 작업 공간 CPU 2개 기준 75초 릴스 초안 약 5분, final 약 25분(백그라운드로 돌린다).
  - 피아노만 바꾸기: `ot.py mix $D $D/video30.mp4 $D/final.mp4 grand`

## script.json
장면별 문장 배열. 마지막 문장이 "전주 모티프였습니다."면 모티프 엔드카드(로고 · 전주 유일 공식 특화샵 · 전화 · 주소)로 날아간다.
없으면 기본 게시 형식: 하단 THE LX 로고, 엔드카드는 마지막 질문 + 제품명(묶음 로고)만.
    [["TSER이 같은 두 필름.","몇 년 뒤의 상태까지 같을까요?"], [...], ...]
say.json(선택): 화면 글자 → 읽는 글자. {"LX는 10년":"엘엑스는 십 년","7년":"칠 년"}  (TSER · VLT · PPF · LX 등은 기본으로 들어 있음)

## scenes.json
    {"seed": 5,                       // 종이 위 배치 · 카메라 이동이 달라짐(같은 값이면 같은 결과)
     "deco": ["TSER","LX","VLT"],     // 종이 바닥 큰 회색 글자
     "overview": true,                // 끝에 크게 빠져 종이 전체를 보여 줌(false면 엔드카드에서 천천히 밀고 끝)
     "logo": "motif_logo_dark",       // 하단 로고(생략 시 자동)  "end": "motif" | "question"
     "scenes": [
       {"head": "같은 TSER, 다른 몇 년",  // 맨 위 작은 주제 제목
        "eng": "SAME TSER",              // 카드 왼쪽 위 작은 영문 라벨
        "caps": ["[[TSER]]이 같은|두 필름.", ...],   // 문장별 캡션. | 줄바꿈, [[ ]] 그라데이션 강조, (( )) 회색. 생략하면 13자 자동 줄바꿈
        "parts": [{"type": "film_pair", "q_at": 1, "shift_at": 2}]}
     ]}
- 장면 수 = 대본 장면 수. 한 장면에 부품 여러 개를 겹쳐 쓸 수 있다(카드 900×660 좌표).
- 시각 at: `1` = 1번 문장 시작 +0.2초 · `[1, 0.6]` = 1번 문장 시작 +0.6초 · `{"t": 31.2}` = 절대 시각. 문장 번호는 장면 안에서 0부터.
- 캡션 한 문장을 둘로 나눌 때: `[{"text":"앞 절반|…","fr":0},{"text":"뒤 절반","fr":0.69}]` (fr = 문장 길이 중 시작 비율)
- 배치를 손으로 정하려면 "pos": [[x,y,기울기], …] (장면 수 + 1, 마지막이 엔드카드)

## 엔진이 알아서 하는 것
원테이크 카메라(x C.heavy · y C.land 1.08배 · 회전 C.whip · 중간 줌 0.71~0.77) · 장면 빈 자리에서 새로 짓기(제목 cut → 카드 착지 → 번호) ·
문장별 캡션(revealLines, 다음 문장 직전 퇴장) · 로고 엔드카드 · 전체 공개 · 검정 페이드아웃 · wiggle 손카메라 ·
효과음 자동 배치(카메라 최고속에 whoosh 최고점, 카드 착지 land, 칩 pop, 큰 숫자 카운트 tick + 도착 land, 도장 punch, 전체 공개 whoosh_low; 같은 소리 겹침 · 몰림 자동 제거) ·
클래식 피아노 20곡 순환(가장 오래 안 쓴 곡, 짧으면 이어 붙임, 목소리로 덕킹) · -16 LUFS · 120fps→tmix 모션 블러.
"전주 모티프였습니다." 앞 1초, 문장 사이 0.4초, 장면 사이 0.75초.

## 부품 (parts.py · 자세한 값은 PARTS.md)
XY 그래프: xy_bars · xy_grouped · xy_line · xy_area · xy_scatter · hbars · ratio_stack · big_number
도식 · 비교: film_pair · sun_film · struct_pair · layers · swatch · tint_samples · two_cards · strike_swap · marker_tracks · chip_flood · chips
화면 · 사진: capture(캡처 + 커서 탭 + 예상 견적) · photo(켄 번스 + 배지)
작은 것: badge · focus · src · labels
새 부품은 parts.py에 `def 이름(K, p): """설명"""` 하나를 더하면 바로 쓸 수 있다(K.rise/pop/count/cut + K.j("A.…") + K.snd).

## 폴더
ot.py(명령) · voice.py(녹음 · 검수) · parts.py(부품) · engine/engine.js · engine/base.css · sfx/(효과음 6종 -20 LUFS + gen.py) ·
vendor/(gsap 3.15 · motion-kit.js MIT Hugh Phan) · motion_check.py(멈춤 · 과밀 측정) · examples/(tser · pkg)
