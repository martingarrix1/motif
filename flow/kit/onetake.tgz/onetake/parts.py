"""원테이크 부품 라이브러리 — scenes.json의 "parts"에 이름과 값만 적으면 HTML + 움직임 + 효과음 시각이 만들어진다.
좌표는 모두 흰 카드(900×660) 기준. 위 38px에 영문 라벨, 내용은 y 90~610.
시각(at): 숫자 k = k번째 문장 시작 + 0.2초 · [k, 초] = k번째 문장 시작 + 초 · {"t": 절대초}. 생략하면 장면 시작.
목록과 값은 PARTS.md 참고.
"""
import json, math, re
try:
    import brotli  # noqa: 한글 폰트 woff2용
except ImportError:
    import subprocess, sys; subprocess.run([sys.executable, "-m", "pip", "install", "-q", "--break-system-packages", "brotli", "fonttools"])

BLUE, BLUE2, GRAYB, INK, MUTED, LIGHT = "#1a5cff", "#5b7cf0", "#9aa7c8", "#141416", "#8a8a8a", "#e8eaef"
GRAD = "linear-gradient(90deg,#1a5cff,#6a4ff0)"
COL = {"blue": BLUE, "blue2": BLUE2, "gray": GRAYB, "purple": "#9a8fc0", "ink": "#3a3c44", "light": "#c9cfdc"}


def col(c, default=BLUE):
    return COL.get(c, c) if c else default


# ---------- 곡선(효과음 시각 계산용, motion-kit과 같은 값) ----------
def bez(x1, y1, x2, y2):
    def f(p):
        lo, hi = 0.0, 1.0
        for _ in range(40):
            m = (lo + hi) / 2
            x = 3 * (1 - m) ** 2 * m * x1 + 3 * (1 - m) * m * m * x2 + m ** 3
            lo, hi = (m, hi) if x < p else (lo, m)
        m = (lo + hi) / 2
        return 3 * (1 - m) ** 2 * m * y1 + 3 * (1 - m) * m * m * y2 + m ** 3
    return f


HEAVY = bez(.75, 0, .18, 1)
LAND = bez(.1, .75, .15, 1)


def inv(ease, y):
    lo, hi = 0.0, 1.0
    for _ in range(40):
        m = (lo + hi) / 2
        lo, hi = (m, hi) if ease(m) < y else (lo, m)
    return (lo + hi) / 2


def F(n): return n / 60
REACT = [0, 4, 9, 15, 22, 30]
def react(i, sc=1): return F(round((REACT[i] if i < len(REACT) else REACT[-1] + 8 * (i - len(REACT) + 1)) * sc))
def mkdur(px, w=1): return F(round((9 + 1.15 * math.sqrt(max(0, px))) * w))


# ---------- 장면 맥락 ----------
class Ctx:
    def __init__(s, i, rows, scene_t, pid):
        s.i, s.rows, s.t0, s.pid = i, rows, scene_t, pid
        s.js, s.ev = [], []

    def st(s, k): return s.rows[min(k, len(s.rows) - 1)][0]
    def du(s, k): return s.rows[min(k, len(s.rows) - 1)][1]

    def at(s, spec, off=0.2):
        if spec is None: return s.t0 + off
        if isinstance(spec, dict): return float(spec["t"])
        if isinstance(spec, (list, tuple)): return s.st(int(spec[0])) + float(spec[1])
        return s.st(int(spec)) + off

    def j(s, code): s.js.append(code)
    def snd(s, name, t): s.ev.append((name, round(t, 3)))
    def id(s, n): return f"{s.pid}_{n}"

    # 움직임 + 효과음 한 번에
    def rise(s, sel, t, dy=60, st=0, n=1, sound="land"):
        s.j(f'A.rise({q(sel)},{t:.3f},{dy},{st});')
        if sound:
            for k in range(min(n, 3)): s.snd(sound, t + mkdur(abs(dy)) * .3 + k * st)

    def pop(s, sel, t, sound="pop", frm=.6):
        s.j(f'A.pop({q(sel)},{t:.3f},{frm});'); sound and s.snd(sound, t + .08)

    def cut(s, sel, t): s.j(f'A.cut({q(sel)},{t:.3f});')

    def count(s, sel, a, b, t, d=1.2, dec=0, ticks=True):
        s.j(f'A.count({q(sel)},{a},{b},{t:.3f},{d},{dec});')
        if ticks:
            span = abs(b - a)
            if span < 20 and dec == 0: s.snd("land", t + d * .97); return   # 작은 숫자는 도착 소리만
            step = max(1, round(span / 12)) if dec == 0 else max(span / 12, 10 ** -dec)
            v, last = step, -1
            while v < span - 1e-9:
                tt = t + inv(HEAVY, v / span) * d
                if tt - last > .07: s.snd("tick", tt); last = tt
                v += step
            s.snd("land", t + d * .97)


def q(sel): return json.dumps(sel)


def esc(t): return str(t).replace("<", "&lt;").replace(">", "&gt;")


def mark(t):
    """[[강조]] → 그라데이션, ((회색)) → 회색"""
    t = esc(t)
    t = re.sub(r"\[\[(.+?)\]\]", r'<span class="g">\1</span>', t)
    return re.sub(r"\(\((.+?)\)\)", r'<span class="mu">\1</span>', t)


def tw(text, px):
    """글자 폭 대략(한글 1em, 영문·숫자 0.6em)"""
    return sum(px * (1.0 if ord(ch) > 0x2E80 else 0.6 if ch != " " else 0.3) for ch in str(text))


# ---------- XY 좌표계 ----------
class Ax:
    def __init__(s, x, y, w, h, xr, yr):
        s.x, s.y, s.w, s.h, s.xr, s.yr = x, y, w, h, xr, yr

    def X(s, v): return s.x + (v - s.xr[0]) / (s.xr[1] - s.xr[0]) * s.w
    def Y(s, v): return s.y + s.h - (v - s.yr[0]) / (s.yr[1] - s.yr[0]) * s.h


def axes(K, ax, t, p, arrow=True):
    """축 → 눈금 · 라벨 순으로 그림. svg 안쪽 요소 문자열과 html 라벨 문자열을 돌려줌"""
    P = K.pid; x0, y0, x1, y1 = ax.x, ax.y + ax.h, ax.x + ax.w, ax.y
    svg = f'<path id="{P}_ay" class="ax" d="M{x0} {y0} L{x0} {y1-14}"/><path id="{P}_ax" class="ax" d="M{x0} {y0} L{x1+14} {y0}"/>'
    html = ""
    for k, v in enumerate(p.get("yticks", [])):
        yy = ax.Y(v)
        if v != ax.yr[0]: svg += f'<path class="grid h" id="{P}_gy{k}" d="M{x0} {yy} L{x1} {yy}"/>'
        html += f'<div class="tk h {P}_tk" style="left:{x0-90}px;top:{yy-15}px;width:76px;text-align:right">{esc(fmt(v))}{esc(p.get("yunit",""))}</div>'
    for k, v in enumerate(p.get("xticks", [])):
        lab = v[1] if isinstance(v, list) else fmt(v); vv = v[0] if isinstance(v, list) else v
        html += f'<div class="tk h {P}_tk" style="left:{ax.X(vv)-60}px;top:{y0+12}px;width:120px;text-align:center">{esc(lab)}</div>'
    if p.get("ylabel"): html += f'<div class="axl h {P}_al" style="left:{x0+16}px;top:{y1-34}px">{mark(p["ylabel"])}</div>'
    if p.get("xlabel"): html += f'<div class="axl h {P}_al" style="left:{x1-260}px;top:{y0+ (52 if p.get("xticks") else 14)}px;width:280px;text-align:right">{mark(p["xlabel"])}</div>'
    K.j(f'A.draw("#{P}_ay",{t:.3f},.55);A.draw("#{P}_ax",{t+.12:.3f},.7);')
    K.j(f'tl.fromTo("#{P} .grid",{{autoAlpha:0}},{{autoAlpha:1,duration:.5,ease:C.drift,stagger:F(4)}},{t+.35:.3f});')
    K.cut(f".{P}_tk", t + .45); K.cut(f".{P}_al", t + .5)
    return svg, html


def fmt(v): return str(int(v)) if float(v).is_integer() else str(v)


def smooth(pts, tension=1.0):
    """캣멀롬 → 베지어 (부드러운 곡선)"""
    if len(pts) < 3: return "M" + " L".join(f"{x:.1f} {y:.1f}" for x, y in pts)
    d = f"M{pts[0][0]:.1f} {pts[0][1]:.1f}"
    for i in range(len(pts) - 1):
        p0 = pts[i - 1] if i else pts[i]; p1, p2 = pts[i], pts[i + 1]; p3 = pts[i + 2] if i + 2 < len(pts) else p2
        c1 = (p1[0] + (p2[0] - p0[0]) / 6 * tension, p1[1] + (p2[1] - p0[1]) / 6 * tension)
        c2 = (p2[0] - (p3[0] - p1[0]) / 6 * tension, p2[1] - (p3[1] - p1[1]) / 6 * tension)
        d += f" C{c1[0]:.1f} {c1[1]:.1f}, {c2[0]:.1f} {c2[1]:.1f}, {p2[0]:.1f} {p2[1]:.1f}"
    return d


def wrap(P, inner, x=0, y=0, w=900, h=660, extra=""):
    return f'<div class="part" id="{P}" style="left:{x}px;top:{y}px;width:{w}px;height:{h}px{extra}">{inner}</div>'


def svgwrap(inner, w=900, h=660):
    return f'<svg class="xy" viewBox="0 0 {w} {h}" style="left:0;top:0;width:{w}px;height:{h}px">{inner}</svg>'


# =====================================================================
# XY 그래프 부품
# =====================================================================
def xy_bars(K, p):
    """세로 막대 + 축 + 카운트. bars: [{label, value, at, hi, color}], ymax, yticks, unit, note"""
    P = K.pid; bars = p["bars"]; n = len(bars); t0 = K.at(p.get("at"), .15)
    ax = Ax(p.get("x", 120), p.get("y", 120), p.get("w", 700), p.get("h", 370), [0, 1], [0, p.get("ymax", max(b["value"] for b in bars) * 1.2)])
    svg, html = axes(K, ax, t0, p)
    slot = ax.w / n; bw = min(p.get("bar_w", 96), slot * .62)
    for k, b in enumerate(bars):
        cx = ax.x + slot * (k + .5); top = ax.Y(b["value"]); hh = ax.y + ax.h - top
        c = col(b.get("color"), BLUE if b.get("hi", k == 0) else GRAYB)
        bg = f"linear-gradient(180deg,{c},{c}cc)" if c.startswith("#") and len(c) == 7 else c
        html += (f'<div class="vb" id="{P}_b{k}" style="left:{cx-bw/2}px;top:{top}px;width:{bw}px;height:{hh}px;background:{bg}"></div>'
                 f'<div class="vn h" id="{P}_n{k}" style="left:{cx-80}px;top:{top-60}px"><b id="{P}_m{k}">0</b>{esc(p.get("unit",""))}</div>'
                 f'<div class="vl h {P}_vl" style="left:{cx-80}px;top:{ax.y+ax.h+14}px">{esc(b["label"])}</div>')
        tb = K.at(b.get("at"), .4) if b.get("at") is not None else t0 + .8 + react(k)
        if b.get("at") is not None and isinstance(b.get("at"), (int, float)) and any(bb.get("at") == b.get("at") for bb in bars[:k]):
            tb += .15 * sum(1 for bb in bars[:k] if bb.get("at") == b.get("at"))
        K.j(f'A.growY("#{P}_b{k}",{tb:.3f},1.1);'); K.cut(f"#{P}_n{k}", tb)
        K.count(f"#{P}_m{k}", 0, b["value"], tb, 1.1, p.get("dec", 0), ticks=k == 0 or p.get("all_ticks"))
    K.cut(f".{P}_vl", t0 + .4)
    if p.get("note"): html += note(K, p["note"])
    return wrap(P, svgwrap(svg) + html)


def xy_grouped(K, p):
    """묶음 막대: groups(가로 항목) × series(비교 대상). 비교 대상은 0.3초 차이로 따라 올라옴"""
    P = K.pid; G = p["groups"]; SR = p["series"]; t0 = K.at(p.get("at"), .15)
    ymax = p.get("ymax", max(v for s in SR for v in s["values"]) * 1.15)
    ax = Ax(p.get("x", 120), p.get("y", 130), p.get("w", 700), p.get("h", 340), [0, 1], [0, ymax])
    svg, html = axes(K, ax, t0, p)
    slot = ax.w / len(G); bw = min(70, slot * .7 / len(SR))
    for g, name in enumerate(G):
        html += f'<div class="vl h {P}_vl" style="left:{ax.x+slot*(g+.5)-80}px;top:{ax.y+ax.h+14}px">{esc(name)}</div>'
        for s, se in enumerate(SR):
            v = se["values"][g]; cx = ax.x + slot * (g + .5) + (s - (len(SR) - 1) / 2) * (bw + 10); top = ax.Y(v)
            c = col(se.get("color"), [BLUE, GRAYB, "#c9cfdc"][s % 3])
            html += (f'<div class="vb" id="{P}_b{g}_{s}" style="left:{cx-bw/2}px;top:{top}px;width:{bw}px;height:{ax.y+ax.h-top}px;background:{c}"></div>'
                     f'<div class="vn sm h" id="{P}_n{g}_{s}" style="left:{cx-60}px;top:{top-44}px;width:120px"><b id="{P}_m{g}_{s}">0</b>{esc(p.get("unit",""))}</div>')
            tb = K.at(se.get("at"), .4) + g * .22 + s * .3 if se.get("at") is not None else t0 + .8 + g * .22 + s * .3
            K.j(f'A.growY("#{P}_b{g}_{s}",{tb:.3f},1.2);'); K.cut(f"#{P}_n{g}_{s}", tb)
            K.count(f"#{P}_m{g}_{s}", 0, v, tb, 1.2, p.get("dec", 0), ticks=(g == 0 and s == 0))
    lg = "".join(f'<i style="background:{col(se.get("color"),[BLUE,GRAYB,"#c9cfdc"][s%3])}"></i>{esc(se["name"])}' for s, se in enumerate(SR))
    html += f'<div class="leg h" id="{P}_lg" style="left:{ax.x}px;top:{p.get("y",130)-62}px">{lg}</div>'
    K.cut(f".{P}_vl", t0 + .4); K.cut(f"#{P}_lg", t0 + .6)
    if p.get("note"): html += note(K, p["note"])
    return wrap(P, svgwrap(svg) + html)


def xy_line(K, p):
    """선 그래프(여러 줄). series: [{pts:[[x,y]..], style:solid|dash, color, label, at, dur, fill, dot}]
    gap: {x, a, b, label, at} 두 선 사이 차이 표시. 선은 1.6초 이상 천천히 그려지고 점이 선 끝을 따라감"""
    P = K.pid; t0 = K.at(p.get("at"), .15)
    ax = Ax(p.get("x", 110), p.get("y", 110), p.get("w", 700), p.get("h", 360), p.get("xr", [0, 10]), p.get("yr", [0, 100]))
    svg, html = axes(K, ax, t0, p)
    defs = ""
    for s, se in enumerate(p["series"]):
        pts = [(ax.X(x), ax.Y(y)) for x, y in se["pts"]]
        c = col(se.get("color"), BLUE if s == 0 else "#9a8fc0"); style = se.get("style", "solid" if s == 0 else "dash")
        d = smooth(pts, se.get("tension", 1.0)) if se.get("smooth", True) else "M" + " L".join(f"{x:.1f} {y:.1f}" for x, y in pts)
        ts = K.at(se.get("at"), .1) if se.get("at") is not None else t0 + .7 + s * .3
        dd = max(1.6, se.get("dur", 2.4))
        if se.get("fill"):
            defs += f'<linearGradient id="{P}_gr{s}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="{c}" stop-opacity=".28"/><stop offset="1" stop-color="{c}" stop-opacity="0"/></linearGradient>'
            area = d + f" L{pts[-1][0]:.1f} {ax.y+ax.h} L{pts[0][0]:.1f} {ax.y+ax.h} Z"
            svg += f'<path id="{P}_f{s}" d="{area}" fill="url(#{P}_gr{s})" stroke="none"/>'
            K.j(f'A.wipe("#{P}_f{s}",{ts+.1:.3f},{dd:.2f});')
        svg += f'<path id="{P}_l{s}" class="{style}" d="{d}" style="stroke:{c}"/>'
        dot = se.get("dot", True)
        if dot: svg += f'<circle id="{P}_d{s}" class="dot" r="0" data-r="10" cx="{pts[0][0]:.1f}" cy="{pts[0][1]:.1f}" style="fill:{c}"/>'
        K.j(f'A.draw("#{P}_l{s}",{ts:.3f},{dd:.2f},{q("#"+P+"_d"+str(s)) if dot else "null"});'); K.snd("pop", ts + .05)
        if se.get("label"):
            lx, ly = pts[-1]; down = len(pts) > 1 and pts[-1][1] > pts[-2][1] + 4   # 내려가는 선이면 아래, 아니면 위에 이름
            if down and ly > ax.y + ax.h - 70: down = False   # 바닥 가까우면 눈금과 겹치지 않게 위로
            dy = se.get("label_dy", 14 if down else -50)
            html += f'<div class="sl h" id="{P}_sl{s}" style="left:{lx-284+se.get("label_dx",0)}px;top:{ly+dy}px;color:{c}">{mark(se["label"])}</div>'
            K.j(f'A.rise("#{P}_sl{s}",{ts+dd*.8:.3f},24);')
    for k, m in enumerate(p.get("marks", [])):   # 값 표시 점: {x,y,text,at}
        mx, my = ax.X(m["x"]), ax.Y(m["y"]); tm = K.at(m.get("at"), .3)
        html += f'<div class="mkv h" id="{P}_mk{k}" style="left:{mx-70}px;top:{my-70}px">{mark(m["text"])}</div>'
        K.pop(f"#{P}_mk{k}", tm)
    if p.get("gap"):
        g = p["gap"]; sa, sb = p["series"][g.get("a", 0)], p["series"][g.get("b", 1)]
        def yat(se, X):
            pts = se["pts"]
            for (x1, y1), (x2, y2) in zip(pts, pts[1:]):
                if x1 <= X <= x2: return y1 + (y2 - y1) * (X - x1) / max(1e-9, x2 - x1)
            return pts[-1][1]
        gx = ax.X(g.get("x", ax.xr[1])); ya, yb = ax.Y(yat(sa, g.get("x", ax.xr[1]))), ax.Y(yat(sb, g.get("x", ax.xr[1])))
        tg = K.at(g.get("at"), .4)
        svg += f'<path id="{P}_gp" class="gap" d="M{gx+18} {ya} L{gx+30} {ya} L{gx+30} {yb} L{gx+18} {yb}"/>'
        html += f'<div class="gapl h" id="{P}_gl" style="left:{gx+44}px;top:{(ya+yb)/2-20}px">{mark(g.get("label","차이"))}</div>'
        K.j(f'A.draw("#{P}_gp",{tg:.3f},.9);'); K.pop(f"#{P}_gl", tg + .6)
    if defs: svg = f"<defs>{defs}</defs>" + svg
    if p.get("note"): html += note(K, p["note"])
    return wrap(P, svgwrap(svg) + html)


def xy_area(K, p):
    """면 그래프: xy_line과 같고 첫 선 아래가 옅게 채워짐(스펙트럼 · 투과율 곡선)"""
    for s in p["series"]: s.setdefault("fill", True)
    return xy_line(K, p)


def xy_scatter(K, p):
    """점 그래프: points [{x,y,label,hi,at}] · trend: 추세선(선택). 점은 착지하듯 하나씩"""
    P = K.pid; t0 = K.at(p.get("at"), .15)
    ax = Ax(p.get("x", 110), p.get("y", 110), p.get("w", 700), p.get("h", 360), p.get("xr", [0, 100]), p.get("yr", [0, 100]))
    svg, html = axes(K, ax, t0, p)
    for k, pt in enumerate(p["points"]):
        X, Y = ax.X(pt["x"]), ax.Y(pt["y"]); hi = pt.get("hi")
        c = BLUE if hi else GRAYB; r = 16 if hi else 11
        html += f'<div class="sp h" id="{P}_p{k}" style="left:{X-r}px;top:{Y-r}px;width:{2*r}px;height:{2*r}px;background:{c}"></div>'
        if pt.get("label"):
            html += f'<div class="spl h" id="{P}_pl{k}" style="left:{X-100}px;top:{Y-r-44}px;color:{INK if hi else MUTED}">{mark(pt["label"])}</div>'
        tp = K.at(pt.get("at"), .3) if pt.get("at") is not None else t0 + .8 + react(k)
        K.pop(f"#{P}_p{k}", tp, frm=.3); pt.get("label") and K.cut(f"#{P}_pl{k}", tp + .12)
    if p.get("trend"):
        tr = p["trend"]; pts = [(ax.X(x), ax.Y(y)) for x, y in tr["pts"]]
        svg += f'<path id="{P}_tr" class="dash" d="{smooth(pts)}" style="stroke:{col(tr.get("color"),"#9a8fc0")}"/>'
        K.j(f'A.draw("#{P}_tr",{K.at(tr.get("at"),.3):.3f},1.6);')
    if p.get("note"): html += note(K, p["note"])
    return wrap(P, svgwrap(svg) + html)


def hbars(K, p):
    """가로 막대 비교: rows [{label, value, max, unit, at, hi}] · 숫자가 막대와 함께 올라감"""
    P = K.pid; t0 = K.at(p.get("at"), .3); rows = p["rows"]; x, y, w = p.get("x", 220), p.get("y", 140), p.get("w", 520)
    gap = p.get("gap", 110); html = ""; mx = p.get("max", max(r["value"] for r in rows))
    for k, r in enumerate(rows):
        yy = y + k * gap; c = BLUE if r.get("hi", k == 0) else GRAYB; ww = w * r["value"] / mx
        html += (f'<div class="rl2 h {P}_rl" style="left:40px;top:{yy-2}px;width:{x-60}px">{esc(r["label"])}</div>'
                 f'<div class="hb" id="{P}_b{k}" style="left:{x}px;top:{yy}px;width:{ww}px;background:{c}"></div>'
                 f'<div class="hn h" id="{P}_n{k}" style="left:{x+ww+16}px;top:{yy-14}px"><b id="{P}_m{k}">0</b>{esc(r.get("unit",p.get("unit","")))}</div>')
        tb = K.at(r.get("at"), .3) if r.get("at") is not None else t0 + .3 + react(k) * 2
        K.j(f'A.growX("#{P}_b{k}",{tb:.3f},1.2);'); K.cut(f"#{P}_n{k}", tb)
        K.count(f"#{P}_m{k}", 0, r["value"], tb, 1.2, p.get("dec", 0), ticks=k == 0)
    K.cut(f".{P}_rl", t0)
    if p.get("note"): html += note(K, p["note"])
    return wrap(P, html)


def ratio_stack(K, p):
    """비율 막대(반사/흡수/투과 등): rows [{label, parts:[..]}], legend, colors"""
    P = K.pid; t0 = K.at(p.get("at"), .0); y = p.get("y", 330); cols = p.get("colors", ["re", "ab", "tr"])
    html = ""
    for k, r in enumerate(p["rows"]):
        yy = y + k * 110
        segs = "".join(f'<s class="{cols[j] if not cols[j].startswith("#") else ""}" style="width:{v}%;{("background:"+cols[j]) if cols[j].startswith("#") else ""}"></s>' for j, v in enumerate(r["parts"]))
        html += f'<div class="rowl h {P}_rl" style="top:{yy-30}px">{esc(r["label"])}</div><div class="stack" id="{P}_s{k}" style="top:{yy}px">{segs}</div>'
    lg = "".join(f'<i class="{cols[j]}"></i>{esc(n)}' for j, n in enumerate(p.get("legend", [])))
    html += f'<div class="leg h" id="{P}_lg" style="left:120px;top:{y+2*110-20}px">{lg}</div>'
    K.cut(f".{P}_rl", t0 - .1)
    K.j(f'A.growX("#{P} .stack",{t0:.3f},1.3,F(9));'); K.snd("land", t0 + .8)
    K.cut(f"#{P}_lg", t0 + .9)
    return wrap(P, html)


# =====================================================================
# 도식 · 비교 부품
# =====================================================================
def film_pair(K, p):
    """필름 두 장 비교: 수치 막대는 같고(=) 몇 년 뒤는 ?(≠). shift_at에 B 필름 색이 바램"""
    P = K.pid; t0 = K.at(p.get("at"), .2); L = p.get("labels", ["필름 A", "필름 B"])
    html = (f'<div class="sw" id="{P}_A" style="left:110px"></div><div class="sw" id="{P}_B" style="left:510px"></div>'
            f'<div class="lab h {P}_lb" style="left:110px;top:345px">{esc(L[0])}</div><div class="lab h {P}_lb" style="left:510px;top:345px">{esc(L[1])}</div>'
            f'<div class="rowl h {P}_rl" style="top:420px">{esc(p.get("row1","TSER"))}</div><div class="hb" id="{P}_tA" style="left:110px;top:430px;width:280px"></div><div class="hb" id="{P}_tB" style="left:510px;top:430px;width:280px"></div>'
            f'<div class="sym h" id="{P}_eq" style="top:404px">=</div>'
            f'<div class="rowl h {P}_rl" style="top:520px">{esc(p.get("row2","몇 년 뒤"))}</div><div class="qm h" id="{P}_qA" style="left:220px;top:500px">?</div><div class="qm h" id="{P}_qB" style="left:620px;top:500px">?</div>'
            f'<div class="sym h" id="{P}_ne" style="top:504px">≠</div>')
    K.rise(f"#{P}_A,#{P}_B", t0, 80, F(5), n=1)
    K.cut(f".{P}_lb", t0 + .3); K.cut(f".{P}_rl", t0 + .45)
    K.j(f'A.growX("#{P}_tA,#{P}_tB",{t0+.5:.3f},1.2,F(4));')
    K.pop(f"#{P}_eq", t0 + 1.4, frm=.5)
    tq = K.at(p.get("q_at", 1)); K.j(f'A.pop("#{P}_qA,#{P}_qB",{tq:.3f},.6,F(6));'); K.snd("pop", tq + .08)
    if p.get("shift_at") is not None:
        K.j(f'A.color("#{P}_B",{K.at(p["shift_at"]):.3f},"linear-gradient(160deg,#5a4a78,#2c2440)",2.4);')
    K.pop(f"#{P}_ne", K.at(p.get("ne_at", 2), 1.2), frm=.5)
    return wrap(P, html)


def sun_film(K, p):
    """햇빛 → 필름 → 실내 도식. 광선 3줄이 필름에서 2줄로 줄어 들어감. cond: 아래 검정 알약 라벨"""
    P = K.pid; t0 = K.at(p.get("at"), .2)
    html = (f'<div class="sun" id="{P}_sun"></div>' + "".join(f'<div class="ray" id="{P}_r{k}" style="top:{200+k*70}px"></div>' for k in range(3)) +
            f'<div class="slab" id="{P}_slab"><span>{esc(p.get("film","필름"))}</span></div>' +
            "".join(f'<div class="ray2" id="{P}_o{k}" style="top:{236+k*70}px"></div>' for k in range(2)) +
            f'<div class="lab h {P}_lb" style="left:690px;top:150px;width:160px">{esc(p.get("inside","실내"))}</div>')
    K.j(f'tl.fromTo("#{P}_sun",{{scale:.4,autoAlpha:0}},{{scale:1,autoAlpha:1,duration:F(40),ease:C.land}},{t0:.3f});'); K.snd("land", t0 + .2)
    K.j(f'tl.fromTo("#{P}_slab",{{scaleY:0}},{{scaleY:1,duration:F(36),ease:C.land}},{t0+.15:.3f});')
    K.j(f'A.growX("#{P}_r0,#{P}_r1,#{P}_r2",{t0+.3:.3f},.9,F(6));')
    K.j(f'A.growX("#{P}_o0,#{P}_o1",{t0+1.1:.3f},.8,F(6));'); K.cut(f".{P}_lb", t0 + 1.4)
    if p.get("cond"):
        html += f'<div class="pill h" id="{P}_cd" style="left:70px;top:420px">{esc(p["cond"])}</div>'; K.cut(f"#{P}_cd", K.at(p.get("cond_at"), 2.0))
    return wrap(P, html)


def chips(K, p):
    """알약 칩 줄: items [{text, on, at}] — on=false면 회색 취소선"""
    P = K.pid; x0, y = p.get("x", 70), p.get("y", 520); html = ""; x = x0
    for k, it in enumerate(p["items"]):
        w = tw(it["text"], 32) + 60
        html += f'<div class="chip h {"on" if it.get("on",True) else "off"}" id="{P}_c{k}" style="left:{x}px;top:{y}px">{esc(it["text"])}</div>'
        x += w + 30
        tc = K.at(it.get("at"), .2 + k * .3)
        K.rise(f"#{P}_c{k}", tc, 40, sound="pop")
    return wrap(P, html)


def struct_pair(K, p):
    """두 구조 비교 블록: a/b {label, kind: metal|dots}"""
    P = K.pid; t0 = K.at(p.get("at"), .2); html = ""
    for k, key in enumerate(["a", "b"]):
        b = p[key]; x = 70 + k * 400
        inner = "<i></i>" * 4 if b.get("kind", "metal") == "metal" else "<u></u>"
        html += f'<div class="st {"" if b.get("kind","metal")=="metal" else "dots"}" id="{P}_{key}" style="left:{x}px">{inner}<b>{esc(b["label"])}</b></div>'
    K.rise(f"#{P}_a,#{P}_b", t0, 60, F(6), n=2)
    K.j(f'A.growX("#{P}_a i",{t0+.3:.3f},.6,F(4));')
    return wrap(P, html)


def focus(K, p):
    """파란 테두리로 한 곳 짚기: box [x,y,w,h]"""
    P = K.pid; x, y, w, h = p.get("box", [58, 88, 784, 204]); t = K.at(p.get("at"), .6)
    K.j(f'tl.fromTo("#{P}_f",{{scale:1.06,autoAlpha:0}},{{scale:1,autoAlpha:1,duration:F(30),ease:C.land}},{t:.3f});'); K.snd("pop", t + .1)
    return wrap(P, f'<div class="focus" id="{P}_f" style="left:{x}px;top:{y}px;width:{w}px;height:{h}px"></div>')


def swatch(K, p):
    """필름 색 견본 한 장: label, shift_at에 색이 바래 감(to)"""
    P = K.pid; t0 = K.at(p.get("at"), .2); x, y, w, h = p.get("x", 70), p.get("y", 110), p.get("w", 220), p.get("h", 290)
    html = (f'<div class="sw" id="{P}_s" style="left:{x}px;top:{y}px;width:{w}px;height:{h}px;background:{p.get("from","linear-gradient(160deg,#3b4048,#1c1f24)")}"></div>'
            f'<div class="lab h" id="{P}_l" style="left:{x}px;top:{y+h+20}px;width:{w}px">{esc(p.get("label",""))}</div>')
    K.rise(f"#{P}_s", t0, 60); K.cut(f"#{P}_l", t0 + .3)
    if p.get("shift_at") is not None:
        K.j(f'A.color("#{P}_s",{K.at(p["shift_at"],0):.3f},{q(p.get("to","linear-gradient(160deg,#6b5a8e,#3a2f55)"))},{p.get("shift_dur",3.2)});')
    return wrap(P, html)


def layers(K, p):
    """원자 증착 → 층이 쌓임(스퍼터링 단면). base 라벨, badge(선택)"""
    P = K.pid; t0 = K.at(p.get("at"), .2); n = p.get("layers", 4); y = p.get("y", 0)
    html = "".join(f'<div class="lay h" id="{P}_L{k}" style="top:{430-k*35+y}px"></div>' for k in range(n))
    html += f'<div class="base h" id="{P}_bs" style="top:{462+y}px">{esc(p.get("base","폴리에스터"))}</div>'
    html += "".join(f'<div class="at h" style="left:{100+i*58}px;top:{120+(i*37)%60+y}px"></div>' for i in range(12))
    K.j(f'A.rain("#{P} .at",{t0:.3f},{240});'); K.cut(f"#{P}_bs", t0 + .4)
    K.j(f'tl.fromTo("#{P} .lay",{{scaleY:0,autoAlpha:0}},{{scaleY:1,autoAlpha:1,duration:F(30),ease:C.land,stagger:F(9)}},{t0+.7:.3f});')
    K.snd("land", t0 + .8 + (n - 1) * F(9))
    if p.get("badge"):
        html += f'<div class="pill h" id="{P}_bd" style="left:{p.get("badge_x",560)}px;top:{110+y}px">{esc(p["badge"])}</div>'
        K.pop(f"#{P}_bd", K.at(p.get("badge_at"), 2.2))
    return wrap(P, html)


def two_cards(K, p):
    """두 카드 비교: off(회색 · 물러남) → on(파랑 테두리). off/on {title, sub}, on_at"""
    P = K.pid; t0 = K.at(p.get("at"), .1); o, n = p["off"], p["on"]
    html = (f'<div class="cc off3 h" id="{P}_a" style="top:{p.get("y",110)}px"><b>{mark(o["title"])}</b><span>{esc(o.get("sub",""))}</span></div>'
            f'<div class="cc on3 h" id="{P}_b" style="top:{p.get("y",110)+220}px"><b>{mark(n["title"])}</b><span>{esc(n.get("sub",""))}</span></div>')
    K.rise(f"#{P}_a", t0, 50); tn = K.at(p.get("on_at"), 1.4) if p.get("on_at") is not None else t0 + 1.2
    K.rise(f"#{P}_b", tn, 50); K.j(f'A.dim("#{P}_a",{tn+.1:.3f});')
    return wrap(P, html)


def strike_swap(K, p):
    """취소선 → 새 단어: old, new, at, new_at (문제 제기 · 잘못된 상식)"""
    P = K.pid; t0 = K.at(p.get("at"), .3); y = p.get("y", 120)
    html = (f'<div class="tb off2 h" id="{P}_a" style="left:{p.get("x",80)}px;top:{y}px;width:{p.get("w",740)}px"><b>{mark(p["old"])}</b></div>'
            f'<div class="strike h" id="{P}_k" style="left:{p.get("x",80)+20}px;top:{y+63}px;width:{min(p.get("w",740)-40,tw(p["old"],36)+20)}px"></div>'
            f'<div class="tb on2 h" id="{P}_b" style="left:{p.get("x",80)}px;top:{y+170}px;width:{p.get("w",740)}px"><b>{mark(p["new"])}</b></div>')
    K.j(f'A.slide("#{P}_a",{t0:.3f},60);'); K.snd("land", t0 + .2)
    ts = K.at(p.get("strike_at"), .8) if p.get("strike_at") is not None else t0 + 1.2
    K.j(f'tl.set("#{P}_k",{{autoAlpha:1}},{ts:.3f});A.growX("#{P}_k",{ts:.3f},.6);'); K.snd("pop", ts + .3)
    tn = K.at(p.get("new_at"), .3) if p.get("new_at") is not None else ts + .9
    K.j(f'A.slide("#{P}_b",{tn:.3f},60);'); K.snd("land", tn + .2)
    return wrap(P, html)


def chip_flood(K, p):
    """선택지 칩이 쏟아짐 → 흐려지고 검정 도장(stamp). chips 12개 안팎"""
    P = K.pid; t0 = K.at(p.get("at"), .4); html = ""
    for k, c in enumerate(p["chips"]):
        html += f'<div class="ch h" id="{P}_c{k}" style="left:{60+(k%3)*265}px;top:{110+(k//3)*95}px">{esc(c)}</div>'
        tc = t0 + react(k % 6) + (k // 6) * .35
        K.j(f'A.rise("#{P}_c{k}",{tc:.3f},40);')
        if k % 3 == 0: K.snd("pop", tc + .08)
    if p.get("stamp"):
        html += f'<div class="stamp h" id="{P}_st">{mark(p["stamp"])}</div>'
        ts = K.at(p.get("stamp_at"), 1.7); K.j(f'tl.to("#{P} .ch",{{autoAlpha:.35,duration:.5}},{ts-.1:.3f});A.stamp("#{P}_st",{ts:.3f});')
        K.snd("punch", ts + .12)
    return wrap(P, html)


def marker_tracks(K, p):
    """조건 트랙 위 두 사람 마커: rows[이름], a/b 위치(0~1), legend, verdict {a:[이름,글], b:[이름,글], at}"""
    P = K.pid; t0 = K.at(p.get("at"), .3); html = ""
    for k, r in enumerate(p["rows"]):
        y = 120 + k * 115
        html += (f'<div class="rl h {P}_rl" style="top:{y}px">{esc(r)}</div><div class="trk" id="{P}_t{k}" style="top:{y+45}px"></div>'
                 f'<div class="mk a h" id="{P}_a{k}" style="top:{y+30}px;left:{220+600*p["a"][k]}px"></div><div class="mk b h" id="{P}_b{k}" style="top:{y+30}px;left:{220+600*p["b"][k]}px"></div>')
        tt = t0 + .4 + k * .8
        K.j(f'A.slide("#{P}_a{k}",{tt:.3f},-120);A.slide("#{P}_b{k}",{tt+react(1):.3f},120);'); K.snd("pop", tt + .1)
    K.cut(f".{P}_rl", t0); K.j(f'A.growX("#{P} .trk",{t0+.05:.3f},.9,F(6));')
    lg = p.get("legend", ["A", "B"])
    html += f'<div class="leg2 h" id="{P}_lg"><i class="a"></i>{esc(lg[0])}<i class="b"></i>{esc(lg[1])}</div>'
    K.cut(f"#{P}_lg", t0 + .9)
    if p.get("verdict"):
        v = p["verdict"]; tv = K.at(v.get("at"), .4)
        html += (f'<div class="vs h" id="{P}_va" style="left:60px"><b>{esc(v["a"][0])}</b><span>{esc(v["a"][1])}</span></div>'
                 f'<div class="vs off h" id="{P}_vb" style="left:460px"><b>{esc(v["b"][0])}</b><span>{esc(v["b"][1])}</span></div>')
        K.j(f'tl.to(["#{P} .rl","#{P} .trk","#{P} .mk","#{P}_lg"],{{y:-30,duration:.6,ease:C.heavy}},{tv-.5:.3f});')
        K.rise(f"#{P}_va", tv, 60); K.rise(f"#{P}_vb", tv + 1.2, 60)
    return wrap(P, html)


def tint_samples(K, p):
    """농도 샘플 줄: samples [vlt…] 밝은 것 → 진한 것, 숫자가 같이 올라옴. caption"""
    P = K.pid; t0 = K.at(p.get("at"), .1); S = p.get("samples", [70, 50, 35, 15]); n = len(S); w = 170; gap = 26
    x0 = (900 - n * w - (n - 1) * gap) / 2; html = ""
    for k, v in enumerate(S):
        g = int(235 - (100 - v) * 2.1); g2 = max(10, g - 45)
        html += (f'<div class="smp1 h" id="{P}_s{k}" style="left:{x0+k*(w+gap)}px;background:linear-gradient(160deg,rgb({g},{g+4},{g+10}),rgb({g2},{g2+3},{g2+8}))">'
                 f'<span id="{P}_v{k}">0</span><em>%</em></div>')
        tk = t0 + .2 + react(k)
        K.j(f'A.rise("#{P}_s{k}",{tk:.3f},70);'); K.count(f"#{P}_v{k}", 0, v, tk + .1, 1.0, ticks=False)
        K.snd("pop", tk + .15)
    html += f'<div class="smpc h" id="{P}_cp">{mark(p.get("caption","VLT · 가시광선 투과율"))}</div>'; K.cut(f"#{P}_cp", t0 + 1.2)
    return wrap(P, html)


def photo(K, p):
    """사진 카드: img, badge(예: VLT 35%), 천천히 밀려 들어오는 켄 번스"""
    P = K.pid; t0 = K.at(p.get("at"), 0); x, y, w, h = p.get("x", 30), p.get("y", 76), p.get("w", 840), p.get("h", 560)
    html = f'<div class="shot" id="{P}_p" style="left:{x}px;top:{y}px;width:{w}px;height:{h}px"><img src="{p["img"]}" style="object-fit:cover"></div>'
    K.j(f'A.kb("#{P}_p img",{t0:.3f},{p.get("kb",4)});')
    if p.get("badge"):
        html += f'<div class="pill blue h" id="{P}_b" style="left:{x+24}px;top:{y+24}px">{esc(p["badge"])}</div>'; K.pop(f"#{P}_b", K.at(p.get("badge_at"), 1.0))
    return wrap(P, html)


def capture(K, p):
    """캡처 화면 + 커서 탭 + 예상 견적 막대. img, taps [{box:[x,y,w,h], at}], swap {img, at}, est(true면 오른쪽 위 막대)"""
    P = K.pid; t0 = K.at(p.get("at"), 0)
    html = f'<div class="shot" id="{P}_p"><img src="{p["img"]}"></div>'
    if p.get("swap"): html += f'<div class="shot h" id="{P}_p2"><img src="{p["swap"]["img"]}"></div>'
    K.j(f'A.kb("#{P}_p",{t0:.3f},1.5,1.05);')
    taps = p.get("taps", []); est = p.get("est")
    if est: html += f'<div class="est h" id="{P}_e"><span>{esc(est if isinstance(est,str) else "예상 견적")}</span><i id="{P}_eb"></i></div>'
    html += f'<svg class="cur h" id="{P}_cu" viewBox="0 0 40 52"><path d="M4 2 L4 40 L14 31 L21 48 L28 45 L21 29 L34 29 Z" fill="#141416" stroke="#fff" stroke-width="3" stroke-linejoin="round"/></svg>'
    if taps:
        t1 = K.at(taps[0].get("at"), .3)
        K.j(f'tl.set("#{P}_cu",{{autoAlpha:1,x:780,y:620}},{t1-.8:.3f});'); est and K.cut(f"#{P}_e", t1 - .8)
    for k, tp in enumerate(taps):
        bx, by, bw, bh = tp["box"]; tt = K.at(tp.get("at"), .3)
        html += f'<div class="tap h" id="{P}_t{k}" style="left:{bx}px;top:{by}px;width:{bw}px;height:{bh}px"></div>'
        K.j(f'A.cursor("#{P}_cu",{bx+bw*.45:.0f},{by+bh*.5:.0f},{tt-.6:.3f},.55);A.tap("#{P}_cu",{tt:.3f},"#{P}_t{k}");'); K.snd("pop", tt + .05)
        if est: K.j(f'A.toX("#{P}_eb",{tt+.05:.3f},{(k+1)/len(taps):.3f});')
        if p.get("swap") and tp.get("before_swap", True) is False: pass
    if p.get("swap"):
        ts = K.at(p["swap"].get("at"), .3)
        K.j(f'tl.to("#{P} .tap",{{autoAlpha:0,duration:.25}},{ts-.1:.3f});tl.fromTo("#{P}_p2",{{autoAlpha:0,x:60}},{{autoAlpha:1,x:0,duration:F(30),ease:C.land}},{ts:.3f});')
        K.snd("land", ts + .2)
    if est: K.j(f'gsap.set("#{P}_eb",{{scaleX:0}});')
    return wrap(P, html)


def big_number(K, p):
    """큰 숫자 카운트: value, unit, prefix, label, at, dec — 도착하면 배지가 안착하고 미세 맥동"""
    P = K.pid; t0 = K.at(p.get("at"), .2); y = p.get("y", 170)
    html = (f'<div class="bigl h" id="{P}_l" style="top:{y-10}px">{mark(p.get("label",""))}</div>'
            f'<div class="bign h" id="{P}_n" style="top:{y+40}px">{esc(p.get("prefix",""))}<b id="{P}_v">0</b><em>{esc(p.get("unit",""))}</em></div>')
    K.cut(f"#{P}_l", t0); K.cut(f"#{P}_n", t0 + .1)
    d = p.get("dur", 1.6); K.count(f"#{P}_v", 0, p["value"], t0 + .1, d, p.get("dec", 0))
    K.j(f'A.pulse("#{P}_n",{t0+.1+d+.1:.3f});')
    if p.get("badge"):
        html += f'<div class="pill blue h" id="{P}_b" style="left:{p.get("badge_x",300)}px;top:{y+260}px">{esc(p["badge"])}</div>'
        K.j(f'tl.fromTo("#{P}_b",{{y:30,autoAlpha:0}},{{y:0,autoAlpha:1,duration:.8,ease:"power3.out"}},{t0+d+.25:.3f});'); K.snd("land", t0 + d + .4)
    return wrap(P, html)


def badge(K, p):
    """작은 알약 라벨: text, x, y, at, style dark|soft|blue"""
    P = K.pid; t = K.at(p.get("at"), .3)
    K.pop(f"#{P}_b", t)
    return f'<div class="pill {p.get("style","dark")} h" id="{P}_b" style="left:{p.get("x",560)}px;top:{p.get("y",110)}px">{mark(p["text"])}</div>'


def note(K, n):
    """그래프 오른쪽 위 회색 메모(보증기간 ≠ 수명 등)"""
    P = K.pid; t = K.at(n.get("at"), .3)
    K.j(f'A.rise("#{P}_nt",{t:.3f},30);'); K.snd("pop", t + .1)
    return f'<div class="note h" id="{P}_nt" style="{n.get("pos","right:40px;top:90px")}">{mark(n["text"])}</div>'


def src(K, p):
    """출처 · 개념도 회색 캡션(카드 왼쪽 아래)"""
    P = K.pid; K.cut(f"#{P}_s", K.at(p.get("at"), .6))
    return f'<div class="src h" id="{P}_s">{esc(p["text"])}</div>'


def labels(K, p):
    """자유 위치 회색 라벨들: items [{text, x, y, at}]"""
    P = K.pid; html = ""
    for k, it in enumerate(p["items"]):
        html += f'<div class="axl h" id="{P}_{k}" style="left:{it["x"]}px;top:{it["y"]}px">{mark(it["text"])}</div>'; K.cut(f"#{P}_{k}", K.at(it.get("at"), .5))
    return html


REG = {k: v for k, v in globals().items() if callable(v) and v.__doc__ and k not in ("bez", "inv", "mark", "tw", "axes", "smooth", "wrap", "svgwrap", "fmt", "col", "q", "esc", "react", "mkdur", "F", "note")}
