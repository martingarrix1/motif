"""녹음 · 이어 붙이기 · 제미나이 검수
python3 ot.py voice <폴더> [p3_1 p5_0 ...]   문장별 녹음(이름을 주면 그 문장만 다시)
python3 ot.py vcheck <폴더>                  제미나이 목소리 검수(다시 녹음할 문장 최대 3개)
"""
import json, os, subprocess, sys, urllib.request, base64

GAP_S, GAP_SC, LEAD, BEFORE_LAST = 0.4, 0.75, 0.9, 1.0
CLOSERS = ("전주 모티프였습니다.",)
BASE_SAY = [("TSER", "티에스이알"), ("VLT", "브이엘티"), ("IRER", "아이알이알"), ("PPF", "피피에프"),
            ("제니스 IR", "제니스 아이알"), ("G라인", "지라인"), ("S라인", "에스라인"), ("LX", "엘엑스")]


def dur(f):
    return float(subprocess.check_output(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", f]))


def load_script(d):
    return json.load(open(os.path.join(d, "script.json"), encoding="utf-8"))


def say_map(d):
    f = os.path.join(d, "say.json")
    extra = json.load(open(f, encoding="utf-8")) if os.path.exists(f) else {}
    return list(extra.items()) + BASE_SAY   # 릴스 폴더의 say.json이 먼저(긴 구절부터)


def say(t, sm):
    for a, b in sm:
        t = t.replace(a, b)
    return t


def flat(S):
    return [(i, j, s) for i, sc in enumerate(S) for j, s in enumerate(sc)]


def record(d, only=()):
    K = open(os.path.expanduser("~/.eleven/key")).read().strip()
    vf = os.path.expanduser("~/.eleven/voice_b")
    V = open(vf).read().strip() if os.path.exists(vf) else "5WQiuyr3CgBT8RI5vL9r"
    S = load_script(d); sm = say_map(d); fl = flat(S)
    os.makedirs(os.path.join(d, "vo"), exist_ok=True)
    for k, (i, j, s) in enumerate(fl):
        name = f"p{i+1}_{j}"
        wav = os.path.join(d, "vo", name + ".wav")
        if only and name not in only:
            continue
        if not only and os.path.exists(wav):
            continue
        body = {"text": say(s, sm), "model_id": "eleven_multilingual_v2", "language_code": "ko",
                "voice_settings": {"stability": 0.6, "similarity_boost": 1.0, "style": 0, "use_speaker_boost": True, "speed": 0.9}}
        if k > 0: body["previous_text"] = say(fl[k-1][2], sm)
        if k + 1 < len(fl): body["next_text"] = say(fl[k+1][2], sm)
        req = urllib.request.Request(f"https://api.elevenlabs.io/v1/text-to-speech/{V}?output_format=mp3_44100_128",
                                     data=json.dumps(body).encode(), headers={"xi-api-key": K, "Content-Type": "application/json"})
        mp3 = os.path.join(d, "vo", name + ".mp3")
        open(mp3, "wb").write(urllib.request.urlopen(req, timeout=180).read())
        subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-i", mp3, "-af",
                        "silenceremove=start_periods=1:start_threshold=-45dB,areverse,silenceremove=start_periods=1:start_threshold=-45dB,areverse",
                        "-ar", "48000", "-ac", "1", wav], check=True)
        print("녹음", name, flush=True)
    assemble(d)


def assemble(d):
    S = load_script(d)
    t = LEAD; tm = []; parts = []
    for i, sc in enumerate(S):
        if i > 0: t += GAP_SC - GAP_S
        row = []
        for j, s in enumerate(sc):
            f = os.path.join(d, "vo", f"p{i+1}_{j}.wav"); dd = dur(f)
            if s.strip() in CLOSERS: t += BEFORE_LAST
            row.append([round(t, 3), round(dd, 3), s]); parts.append((f, t)); t += dd + GAP_S
        tm.append(row)
    end = t - GAP_S
    json.dump({"scenes": tm, "voice_end": round(end, 3)}, open(os.path.join(d, "timing.json"), "w"), ensure_ascii=False, indent=1)
    inp, fl = [], []
    for k, (f, st) in enumerate(parts):
        inp += ["-i", f]; fl.append(f"[{k}]adelay={int(st*1000)}[a{k}]")
    fl.append("".join(f"[a{k}]" for k in range(len(parts))) + f"amix=inputs={len(parts)}:normalize=0[m]")
    subprocess.run(["ffmpeg", "-loglevel", "error", "-y", *inp, "-filter_complex", ";".join(fl), "-map", "[m]", "-ar", "48000",
                    os.path.join(d, "voice.wav")], check=True)
    print(f"목소리 끝 {end:.2f}초 → timing.json · voice.wav")


def gemini(parts, model="gemini-3.8-flash"):
    K = open(os.path.expanduser("~/.gemini/key")).read().strip()
    body = {"contents": [{"parts": parts}], "generationConfig": {"temperature": 0.2}}
    for m in (model, "gemini-flash-latest", "gemini-pro-latest"):
        try:
            req = urllib.request.Request(f"https://generativelanguage.googleapis.com/v1beta/models/{m}:generateContent?key={K}",
                                         data=json.dumps(body).encode(), headers={"Content-Type": "application/json"})
            r = json.load(urllib.request.urlopen(req, timeout=300))
            return r["candidates"][0]["content"]["parts"][0]["text"]
        except urllib.error.HTTPError as e:
            if e.code != 404: raise
    raise RuntimeError("제미나이 모델 없음")


def audio_part(f):
    mp3 = "/tmp/_ot_check.mp3"
    subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-i", f, "-ac", "1", "-b:a", "96k", mp3], check=True)
    return {"inline_data": {"mime_type": "audio/mp3", "data": base64.b64encode(open(mp3, "rb").read()).decode()}}


def vcheck(d):
    T = json.load(open(os.path.join(d, "timing.json"), encoding="utf-8"))
    lines = [f"p{i+1}_{j} [{st:.1f}초] {s}" for i, sc in enumerate(T["scenes"]) for j, (st, du, s) in enumerate(sc)]
    prompt = ("한국어 릴스 내레이션 검수. 아래 대본과 녹음을 비교해 발음이 틀리거나 끊기거나 어색한 억양인 문장만 골라라. "
              "다시 녹음할 문장은 최대 3개, 문제가 없으면 없음. 형식: 문장이름 - 이유(한 줄). 다른 말은 쓰지 마라.\n" + "\n".join(lines))
    print(gemini([{"text": prompt}, audio_part(os.path.join(d, "voice.wav"))]))


def sfx_check(wav, events):
    prompt = ("릴스 효과음 트랙 검수. 고급스러운 자동차 시공점 릴스에 들어갈 효과음이다. 거슬리거나 싸구려처럼 들리는 소리를 최대 3개만 "
              "'시각(초) - 이유' 형식으로 적어라. 문제 없으면 없음.\n배치: " + ", ".join(f"{n}@{t:.1f}" for n, t in events[:120]))
    print(gemini([{"text": prompt}, audio_part(wav)]))
